//
//  OffersSettingsViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 21/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import Kingfisher


/// Creates offers settings view. Here, user can add partner to preferred if he provide a correct business code.
class OffersSettingsViewController: ViewController {
    @IBOutlet var addPreferredPartnerView: UIView!
    @IBOutlet var hasPreferredPartnerView: UIView!
    
    @IBOutlet var preferredCodeTitle: UILabel!
    @IBOutlet var splitter1: UIView!
    @IBOutlet var preferredCodeTextField: UITextField!
    @IBOutlet var applyLabel: UILabel!
    
    @IBOutlet var preferredTitle: UILabel!
    @IBOutlet var splitter2: UIView!
    @IBOutlet var prefferedPartnerImage: UIImageView!
    @IBOutlet var preferredPartnerNameLabel: UILabel!
    
    var viewModel : OffersSettingsViewModel!
    var addPreferredPartner : AddPreferredPartner?
    
    override func viewWillAppear(_ animated: Bool) {

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.prepare(for:  UIStoryboardSegue(identifier: "",source: UIViewController() ,destination: UIViewController()), sender: nil)
        self.hideKeyboardWhenTappedAround()
        
        splitter1.backgroundColor = Colors.sectionTextUnderlineColor
        splitter2.backgroundColor = Colors.sectionTextUnderlineColor
        
        preferredCodeTitle.textColor = Colors.sectionTextColor
        preferredTitle.textColor = Colors.sectionTextColor
        
        preferredCodeTextField.textColor = Colors.lightBrown
        preferredCodeTextField.attributedPlaceholder = NSAttributedString(string: "Business Code",
                                                                attributes: [NSAttributedStringKey.foregroundColor: UIColor.black])
        
        applyLabel.backgroundColor = Colors.buttonGray
        applyLabel.layer.cornerRadius = 10
        applyLabel.layer.masksToBounds = true
        
        let onClickApply = UITapGestureRecognizer(target: self, action: #selector(OffersSettingsViewController.onClickApply))
        applyLabel.addGestureRecognizer(onClickApply)
        applyLabel.isUserInteractionEnabled = true
        
        viewModel = OffersSettingsViewModel(viewController : self)
        
        if(!isNullOrEmpty(string: viewModel.imageUri))
        {
            let url = URL(string: percentEncode(s: viewModel.imageUri))
            prefferedPartnerImage.kf.setImage(with: url)
        }
        
        if(selectedTab != nil && tabIndex != nil && tabIndex != -1)
        {
            checkForTabBar(tab : selectedTab, index: tabIndex)
            
            if(CustomTabbarViewController.navigationControllers != nil && CustomTabbarViewController.navigationControllers.count > tabIndex)
            {
                CustomTabbarViewController.navigationControllers[tabIndex] = self.navigationController!
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    @objc func onClickApply(sender : UITapGestureRecognizer) {
        if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
        {
            verifyPartnerCode()
        }
        else
        {
            let toast =  CustomToast()
            toast.setToast(viewController: self, message: NSLocalizedString("internetIsRequired", comment: ""))
            toast.show()
        }
        //applyLabel.backg backgroundColor = Colors.buttonGraySelected
    }
    
    @IBAction func codeChanged(_ sender: UITextField) {
        viewModel.partnerCode = sender.text
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    
    /// This function is been called when registration completed.
    func registrationCompleted() {
        viewModel.partnerCode = nil
        viewModel.displayWhiteLabelPartner = true
        MainViewModel.displayWhiteLabelPartner = viewModel.displayWhiteLabelPartner
        viewModel.updateWhiteLabelPartnerVisibility()
        //offersChilds.insert((localDatabase.getAppUser()?.partnerShortName)!, at: 0)
        
        let MainStoryBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let preferredOffersViewController = MainStoryBoard.instantiateViewController(withIdentifier: "PreferredOffersNavigationController") as! UINavigationController
        self.tabBarController?.viewControllers?.insert(preferredOffersViewController, at: 0)
        self.tabBarController?.tabBar.items![0].setTitleTextAttributes([NSAttributedStringKey.foregroundColor: UIColor.lightGray ], for: .normal)
        self.tabBarController?.tabBar.items![0].title = localDatabase.getAppUser()?.partnerShortName
        self.tabBarController?.tabBar.items![0].image = UIImage(named : "ic_left_drawer_preferred_business")
    }
    
    
    /// Verifies the preferred business code that the user has added.
    func verifyPartnerCode()
    {
        do
        {
            viewModel.verifyPartnerCode()
            
            if(!isNullOrEmpty(string: viewModel.imageUri))
            {
                let url = URL(string: percentEncode(s: viewModel.imageUri))
                prefferedPartnerImage.kf.setImage(with: url)
                
                for tab in leftDrawer.leftDrawerTabsList
                {
                    if(tab.type == LeftDrawerTabsType.Preferred.rawValue)
                    {
                        tab.isVissible = true
                        parameterizationDatabase.updateLeftDrawerTab(tab : tab)
                        
                        LeftDrawerViewController.leftDrawerGroupTabs.removeAll()
                        LeftDrawerViewController.leftDrawerGroupTabsID.removeAll()
                        
                        let initializer = APKInitializer()
                        APKInitializer.setProperties()
                        
                        leftDrawer.viewDidLoad()
                        leftDrawer.tableView.reloadData()
                    }
                }
                
                for tab in leftDrawer.leftDrawerTabsList
                {
                    if(tab.type == LeftDrawerTabsType.Settings.rawValue)
                    {
                        selectedTab = tab
                    }
                }
            }
        }
        catch
        {
            
        }
        
        let toast =  CustomToast()
        toast.setToast(viewController: self, message: viewModel.status)
        toast.show()
    }
}
