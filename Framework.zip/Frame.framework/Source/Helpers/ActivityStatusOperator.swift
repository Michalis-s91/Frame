//
//  ActivityStatusOperator.swift
//  RichReach2
//
//  Created by Eumbrella on 27/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/**
 * Returns whether the activity that created the task is still active.
 * @param activity The activity.
 * @return True if the activity is active, otherwise false.
 */
func isActivityActive(viewController : UIViewController ) -> Bool
{
    var isActive : Bool!
    
    DispatchQueue.main.async(execute: {() -> Void in
        if (viewController.viewIfLoaded?.window != nil)
        {
            isActive = true
        }
        else
        {
            isActive = false
        }
    })
    
    while (isActive == nil) {}
    return isActive
}
