//
//  CategoryModel.swift
//  RichReach2
//
//  Created by Eumbrella on 07/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class CategoryModel : Codable
{
    var id : Int64!
    var type : Int!
    var code : String!
    var name : String!
    var image : String!
    var parentCategoryID : Int!
    var parentCategory : CategoryModel!
    var level : Int!
    var products : [ProductModel]!
    var childCategories : [CategoryModel]!
    
    var textSize : Int!
    var textColor : String!
    var font : String!
    var backgroundColor : String!
    var tintColor : String!
    
    private enum CodingKeys : String, CodingKey {
        case id = "ID"
        case name = "TextStr"
        case parentCategoryID = "ParentCategoryID"
    }
}
