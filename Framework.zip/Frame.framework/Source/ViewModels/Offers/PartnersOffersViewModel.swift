//
//  PartnersOffersViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 08/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// PartnersOffersViewModel associated to the partner offers view. It saves data about partner offers, uses API to load partners offers and modifies offers table of local database.
class PartnersOffersViewModel
{
    var partner : PartnerModel!
    static var offersPageToLoad = 0
    private var offersList : [OfferModel] = []
    var OffersList : [OfferModel]!
    {
        get
        {
            if(self.offersList != nil)
            {
                return self.offersList
            }
            else
            {
                return nil
            }
        }
        
        set (offersList)
        {
            
            if(offersList == nil || offersList.count == 0)
            {
                isOffersNotAvailable = true
                self.offersList = []
            }
            else
            {
                isOffersNotAvailable = false
                self.offersList = offersList
            }
        }
    }
    var isOffersNotAvailable = false
    var viewController : OffersView!

    
    /// Constructor. Sets the partner model and the view controller.
    ///
    /// - Parameters:
    ///   - partner: The partner model.
    ///   - viewController: The current view controller.
    init(partner : PartnerModel!, viewController : OffersView)
    {
        self.partner = partner
        self.viewController = viewController
    }
    
    
    /// Loads partner offers from internet and return them in a list.
    ///
    /// - Returns: A list with partner offers.
    func loadFromInternet() -> [OfferModel]!
    {
        return PartnersWebApi.getPartnerOffers(userPhone: localDatabase.getAppUser()!.phoneNumber, partnerID: partner.partnerID, pageNumber: 1, localDB: localDatabase )
    }
    
    
    /// Modifies watchlist table at local database.
    ///
    /// - Parameter offer: The offer model we want to add/delete from table.
    func modifyWishList(offer : OfferModel)
    {
        if (!offer.isItemWatched)
        {
            localDatabase.insertFavouriteOffer(offer: offer)
        }
        else
        {
            localDatabase.deleteFavouriteOfferByID(offerID: offer.appOfferID)
        }
    }
    
    
    /// Loads more partner offers from internet and returns them into a list.
    func loadMoreFromInternet()
    {
        let moreItems = PartnersWebApi.getPartnerOffers(userPhone: (localDatabase.getAppUser()?.phoneNumber)!, partnerID: partner.partnerID, pageNumber: PartnersOffersViewModel.offersPageToLoad, localDB: localDatabase)
        var tmp : [OfferModel] = []
        
        if(moreItems != nil)
        {
            for i in moreItems!
            {
                //boolean isFavourite = dataService.IsFavouriteOffer(i.AppOfferID)
                let offerModel = OfferModel()
                offerModel.appOfferID = i.appOfferID
                offerModel.Description = i.Description
                offerModel.imageUrl = i.imageUrl
                offerModel.largeImageUrl = i.largeImageUrl
                offerModel.originalPrice = i.originalPrice
                offerModel.offerDescription = i.offerDescription
                offerModel.offerNewPrice = i.offerNewPrice
                offerModel.isStrikethrough = i.isStrikethrough
                offerModel.isItemWatched = i.isItemWatched
                offerModel.partnerName = i.partnerName
                offerModel.isPrivate = i.isPrivate
                offerModel.isGeneralOffer = i.isGeneralOffer
                offerModel.duration = i.duration
                offerModel.isNoPriceToShowOffer = i.isNoPriceToShowOffer
                offerModel.isPriceListOffer = i.isPriceListOffer
                offerModel.isSetOffer = i.isSetOffer
                
                tmp.append(offerModel)
            }
            
            OffersList = OffersList! + tmp
            OffersList = OffersList?.removeDuplicates()
            
            DispatchQueue.main.async(execute: {() -> Void in
                self.viewController.offersTableView.reloadData()
            })
            
            
            //If more items loaded more paging index to the next page
            if ((moreItems?.count)! > 0)
            {
                PartnersOffersViewModel.offersPageToLoad += 1
            }
        }
        
    }
}

