//
//  UserProfileModel2.swift
//  RichReach2
//
//  Created by Eumbrella on 26/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class UserProfileModel2 : Codable
{
    var id : Int64!
    var businessID : Int!
    var mobile : String!
    var name : String!
    var surname : String!
    var birthDate : Date!
    var birthDateString : String!
    var gender : Int!
    var address1 : String!
    var address2 : String!
    var city : String!
    var region : String!
    var postCode : String!
    var countryID : Int!
    var country : String!
    var email : String!
    var currentBalancePoints : Int!
    var blocked : Int!
    var isBlocked : Bool!
    var reasonBlocked : String!
    var isLoyaltyUser : Bool!
    var hasVerifiedEmailAddress : Bool!
    var emailVerifiedIPAddress : String!
    var emailVerifiedDatetime : String!
    
    //var preferredLanguageID : Int!
    var preferredLanguageID : Int!
    var houseNo : String!
    var communicationLanguage : String!
    var referedName : String!
    var flatHouseName : String!
    var isAdult : Bool! = false
    var shouldReceiveEmail : Bool! = false
    var shouldReceiveSms : Bool! = false
    var shouldReceiveLoyaltyCardNumberBySMS : Bool! = false
    
    var acceptNews1 : Int!
    var acceptNews2 : Int!
    var acceptNews3 : Int!
    var acceptNews4 : Int!
    var acceptNews5 : Int!
    var acceptNews6 : Int!
    var acceptNews7 : Int!
    var acceptNews8 : Int!
    
    var accountCreatedAtShop1 : Int!
    var accountCreatedAtShop2 : Int!
    var accountCreatedAtShop3 : Int!
    var accountCreatedAtShop4 : Int!
    var accountCreatedAtShop5 : Int!
    var accountCreatedAtShop6 : Int!
    var accountCreatedAtShop7 : Int!
    var accountCreatedAtShop8 : Int!
    
    var dateCreatedAtShop1 : String!
    var dateCreatedAtShop2 : String!
    var dateCreatedAtShop3 : String!
    var dateCreatedAtShop4 : String!
    var dateCreatedAtShop5 : String!
    var dateCreatedAtShop6 : String!
    var dateCreatedAtShop7 : String!
    var dateCreatedAtShop8 : String!
    
    var otherPhone1 : String!
    var otherPhone2 : String!
    var loyaltyCardNo : String!
    var agreeToTheTerms : Int!
    
    var accountID : Int64!
    var contactID : Int64!
    var middleName : String!
    var appClientUniqueID : Int64!
    var issueCoupon : String!
    
    private enum CodingKeys : String, CodingKey {
        case id = "ID"
        case businessID = "BusinessID"
        case mobile = "Mobile"
        case name = "Name"
        case surname = "Surname"
        case birthDateString = "BirthDate"
        case gender = "Gender"
        case address1 = "HomeAddress"
        case address2 = "Address2"
        case city = "City"
        case region = "Province"
        case postCode = "PostCode"
        case countryID = "CountryID"
        case country = "Country"
        
        case email = "EmailAddress"
        case currentBalancePoints = "CurrentBalancePoints"
        //case blocked = "Blocked"
        case isBlocked = "IsBlocked"
        case reasonBlocked = "ReasonBlocked"
        case isLoyaltyUser = "IsLoyaltyUser"
        case hasVerifiedEmailAddress = "HasVerifiedEmailAddress"
        case emailVerifiedIPAddress = "EmailVerifiedIPAddress"
        case emailVerifiedDatetime = "EmailVerifiedDatetime"
        
        case houseNo = "HouseNumber"
        //case communicationLanguage = "CommunicationLanguage"
        case referedName = "PreferredName"
        case flatHouseName = "HouseName"
        case preferredLanguageID = "PreferredLanguageID"
        case isAdult = "IsAdult"
        case shouldReceiveEmail = "ShouldReceiveEmail"
        case shouldReceiveSms = "ShouldReceiveSms"
        case shouldReceiveLoyaltyCardNumberBySMS = "ShouldReceiveLoyaltyCardNumberBySMS"
        
        case acceptNews1 = "AcceptNews1"
        case acceptNews2 = "AcceptNews2"
        case acceptNews3 = "AcceptNews3"
        case acceptNews4 = "AcceptNews4"
        case acceptNews5 = "AcceptNews5"
        case acceptNews6 = "AcceptNews6"
        case acceptNews7 = "AcceptNews7"
        case acceptNews8 = "AcceptNews8"
        
        case accountCreatedAtShop1 = "AccountCreatedAtShop1"
        case accountCreatedAtShop2 = "AccountCreatedAtShop2"
        case accountCreatedAtShop3 = "AccountCreatedAtShop3"
        case accountCreatedAtShop4 = "AccountCreatedAtShop4"
        case accountCreatedAtShop5 = "AccountCreatedAtShop5"
        case accountCreatedAtShop6 = "AccountCreatedAtShop6"
        case accountCreatedAtShop7 = "AccountCreatedAtShop7"
        case accountCreatedAtShop8 = "AccountCreatedAtShop8"
        
        case dateCreatedAtShop1 = "DateCreatedAtShop1"
        case dateCreatedAtShop2 = "DateCreatedAtShop2"
        case dateCreatedAtShop3 = "DateCreatedAtShop3"
        case dateCreatedAtShop4 = "DateCreatedAtShop4"
        case dateCreatedAtShop5 = "DateCreatedAtShop5"
        case dateCreatedAtShop6 = "DateCreatedAtShop6"
        case dateCreatedAtShop7 = "DateCreatedAtShop7"
        case dateCreatedAtShop8 = "DateCreatedAtShop8"
        
        case otherPhone1 = "OtherPhone1"
        case otherPhone2 = "OtherPhone2"
        case loyaltyCardNo = "LoyaltyCardNo"
        case agreeToTheTerms = "IAgreeToTheTerms"
    }
}
