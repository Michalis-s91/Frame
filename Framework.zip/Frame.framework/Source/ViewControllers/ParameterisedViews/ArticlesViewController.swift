//
//  ArticlesViewController.swift
//  RichReach
//
//  Created by Eumbrella on 25/01/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import UIKit

class BlogViewController: ViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var backgroundImage: UIImageView!
    @IBOutlet var articlesContainer: UIView!
    @IBOutlet var articlesTableView: UITableView!

    @IBOutlet var viewBottom: NSLayoutConstraint!
    @IBOutlet var viewTrailing: NSLayoutConstraint!
    @IBOutlet var viewLeading: NSLayoutConstraint!
    @IBOutlet var viewTop: NSLayoutConstraint!
    
    var viewModel : ArticlesViewModel!
    var task : WebApiTask!
    //var articlesList : [ArticlesModel]! = []
    var images : [ImageCacheModel] = []
    var numberOfCachedImages = 10
    var previousPartnersListSize : Int! = 0
    var viewIsNotDisplayed = true
    var viewDidAppear = false
    var isViewSaved = false
    var synchronized : Synchronized = Synchronized()
    var lock = NSObject()
    var ignoreLoadingMoreData = false
    var currentUIViewController: UIViewController!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(borderWidth > 0)
        {
            self.view.backgroundColor = UIColor(borderColor)
            viewTrailing.constant = CGFloat(borderWidth)
            viewBottom.constant = CGFloat(borderWidth)
            viewTop.constant = CGFloat(borderWidth)
            viewLeading.constant = CGFloat(borderWidth)
        }
        
        if(selectedTab.hasBackgroundImage)
        {
            let data = parameterizationDatabase.getBackgroundImage(apk: APK)
            
            if(data != nil)
            {
                backgroundImage.image = UIImage(data: data!)
            }
        }
        
        currentUIViewController = self
        
        articlesTableView.contentInset = UIEdgeInsets(top: -30, left: 0, bottom: -20, right: 0)
        
        articlesTableView.rowHeight = UITableViewAutomaticDimension
        articlesTableView.tableFooterView = UIView()
        articlesTableView.delegate = self
        articlesTableView.dataSource = self
        
    
        
        if(statusModel.areArticlesSaved)
        {
            self.viewModel = ArticlesViewModel()
            viewModel.tabID = selectedTab.id
            self.viewModel.loadFromLocalDB()
            
            if(viewModel.articleViewList == nil || viewModel.articleViewList.count == 0)
            {
                self.notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.articlesContainer!, text:"No available information")
                previousPartnersListSize = viewModel.articlesList != nil ? viewModel.articlesList.count : 0
            }
        }
        else
        {
            let waitingView =  showWaitingView(view: self, container: self.view, text: "No available information")
            DispatchQueue.global(qos: .background).async {
                while(!statusModel.areArticlesSaved)
                {
                    sleep(2)
                    if(!isActivityActive(viewController: self.currentUIViewController))
                    {
                        return
                    }
                    
                    if(!areParametersDownloading && errorOccured)
                    {
                        DispatchQueue.main.async(execute: {() -> Void in
                            waitingView.setText(text: "An error has occured. Please try again later...")
                            waitingView.showInternetIsRequired()
                        })
                        return
                    }
                }
                
                if(!areParametersDownloading && errorOccured)
                {
                    return
                }
                
                if(!isActivityActive(viewController: self.currentUIViewController))
                {
                    return
                }
                
                DispatchQueue.main.async(execute: {() -> Void in
                    waitingView.view.removeFromSuperview()
                    waitingView.removeFromParentViewController()
                    
                    self.viewModel = ArticlesViewModel()
                    self.viewModel.tabID = selectedTab.id
                    self.viewModel.loadFromLocalDB()
                    
                    if(self.viewModel.articleViewList == nil || self.viewModel.articleViewList.count == 0)
                    {
                        self.notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.articlesContainer!, text:"No available information")
                        self.previousPartnersListSize = self.viewModel.articlesList != nil ? self.viewModel.articlesList.count : 0
                    }
                    
                    self.articlesTableView.reloadData()
                })
            }
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidLayoutSubviews() {
        if(!viewIsNotDisplayed)
        {
            super.viewDidAppear(true)
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        navigation = self.navigationController
        viewDidAppear = true
    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if(viewModel != nil && viewModel.articlesList != nil)
        {
            return viewModel.articleViewList.count
        }
        else
        {
            return 0
        }
    }
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if(section == 0)
        {
            return 0
        }
        
        if(separatorHeight == 0)
        {
            return CGFloat.leastNormalMagnitude
        }
        
        return CGFloat(separatorHeight)
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return CGFloat.leastNormalMagnitude
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var information : GeneralInformation2!
        
        information = viewModel.articleViewList[indexPath.section]
        
        switch information.type {
        case SlotType.Title.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_title") as! InformationTitleViewCell
            var title : TitleModel! = information.title
            cell.titleLabel.text = title.title
            cell.titleLabel.font = UIFont (name: (title.titleFont)!, size: CGFloat((title.titleSize)!))
            cell.titleLabel.textColor = UIColor((title.titleColor)!)
            cell.titleLabel.backgroundColor = UIColor((title.titleBackgroundColor)!)
        
            
            if(title.isTitleCentered != nil && !title.isTitleCentered)
            {
                cell.titleLabel.textAlignment = .left
            }
            
            cell.selectionStyle = .none
            
            return cell
        case SlotType.Photo.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_image") as! InformationImageViewCell
            let photo : PhotoModel! = information.photo
            
            if(photo.title != nil)
            {
                let title : TitleModel! = photo.title
                
                cell.cellTitle.text = title.title
                cell.cellTitle.font = UIFont (name: (title.titleFont)!, size: CGFloat((title.titleSize)!))
                cell.cellTitle.textColor = UIColor((title.titleColor)!)
                cell.cellTitle.backgroundColor = UIColor((title.titleBackgroundColor)!)
                cell.titleHeightConstraint.constant = (title.title?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: UIFont (name: (title.titleFont)!, size: CGFloat((title.titleSize)!))!))!
            }
            else
            {
                cell.titleHeightConstraint.constant = 0
            }
            
            if(photo.link != nil)
            {
                cell.link = photo.link
                cell.awakeFromNib()
            }
            
            
            if(!photo.isImageLoaded)
            {
                images.append(ImageCacheModel(image: UIImage(data: viewModel.articleView.imageData)!, url: photo.imageUrl, photoModel : photo))
                cell.cellImage.image = (images.last)?.image
                photo.isImageLoaded = true
                
                if(images.count > numberOfCachedImages)
                {
                    images[0].photoModel.isImageLoaded = false
                    images.remove(at: 0)
                }
            }
            else
            {
                for i in 0..<images.count
                {
                    if(images[i].url ==  photo.imageUrl)
                    {
                        cell.cellImage.image = images[i].image
                        break
                    }
                }
            }
            
           
            if(photo.button != nil)
            {
                let button : ButtonModel! = photo.button
                
                cell.viewController = self
                cell.button = button
                
                cell.buttonWidth.constant = CGFloat(button.width)
                cell.buttonHeight.constant = CGFloat(button.height)
                cell.cellButton.setTitle(button.name, for: .normal)
                cell.cellButton.titleLabel?.font = UIFont (name: (button?.font)!, size: CGFloat(button.textSize))
                cell.cellButton.setTitleColor(UIColor(button.textColor), for: .normal)
                cell.cellButton.backgroundColor = UIColor(correctHexString(string: button.backgroundColor))
                
                cell.borderWidth.constant =  CGFloat(button.width + button.borderWidth * 2)
                cell.borderHeight.constant = CGFloat(button.height + button.borderWidth * 2)
                cell.buttonBorder.backgroundColor = button.borderWidth != 0 ? UIColor(correctHexString(string: button.borderColor)) : UIColor.clear
                
                
                var titleHeight : CGFloat! = 0.0
                
                if(information.photo.title != nil)
                {
                    titleHeight = photo.title.title?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: UIFont (name: (photo.title.titleFont)!, size: CGFloat((photo.title.titleSize)!))!)
                }
                
                var cellHeight : CGFloat!
                if(photo.aspectRatio != nil)
                {
                    cellHeight = UIScreen.main.bounds.size.width * CGFloat(photo.aspectRatio) + titleHeight
                }
                else
                {
                    cellHeight = UIScreen.main.bounds.size.width + titleHeight
                }
                
                switch button.buttonPosition
                {
                case 1:
                    break
                case 2:
                    cell.borderX.constant = UIScreen.main.bounds.size.width/2 - CGFloat(button.width + button.borderWidth * 2)/2
                    break
                case 3:
                    cell.borderX.constant = UIScreen.main.bounds.size.width - CGFloat(button.width) - CGFloat(button.borderWidth * 2)
                    break
                case 4:
                    cell.borderY.constant = cellHeight/2 - CGFloat(button.height + button.borderWidth * 2)/2
                    break
                case 5:
                    cell.borderY.constant = cellHeight/2 - CGFloat(button.height + button.borderWidth * 2)/2
                    cell.borderX.constant = UIScreen.main.bounds.size.width/2 - CGFloat(button.width + button.borderWidth * 2)/2
                    break
                case 6:
                    cell.borderY.constant = cellHeight/2 - CGFloat(button.height + button.borderWidth * 2)/2
                    cell.borderX.constant = UIScreen.main.bounds.size.width - CGFloat(button.width) - CGFloat(button.borderWidth * 2)
                    break
                case 7:
                    cell.borderY.constant = cellHeight - CGFloat(button.height) - CGFloat(button.borderWidth * 2)
                    break
                case 8:
                    cell.borderY.constant = cellHeight - CGFloat(button.height) - CGFloat(button.borderWidth * 2)
                    cell.borderX.constant = UIScreen.main.bounds.size.width/2 - CGFloat(button.width + button.borderWidth * 2)/2
                    break
                case 9:
                    cell.borderY.constant = cellHeight - CGFloat(button.height) - CGFloat(button.borderWidth * 2)
                    cell.borderX.constant = UIScreen.main.bounds.size.width - CGFloat(button.width) - CGFloat(button.borderWidth * 2)
                    break
                default :
                    break
                }
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case SlotType.Article.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_article") as! ArticleViewCell
            
            let article : ArticleModel! = information.article
            
            cell.title.text = article.title
            cell.title.font = UIFont (name: (article.titleFont)!, size: CGFloat((article.titleSize)!))
            cell.title.textColor = UIColor((article.titleColor)!)
            
            cell.category.text = article.category
            cell.category.font = UIFont (name: (article.categoryFont)!, size: CGFloat((article.categorySize)!))
            cell.category.textColor = UIColor((article.categoryColor)!)

            var date = article.publishDate.split(separator: " ")[0]
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let date2 = dateFormatter.date(from: String(date))!
            let dateFormatter2 = DateFormatter()
            dateFormatter2.dateFormat = "dd-MM-yyyy"
            
            cell.date.text = dateFormatter2.string(from: date2)
            
            cell.date.font = UIFont (name: (article.dateFont)!, size: CGFloat((article.dateTextSize)!))
            cell.date.textColor = UIColor((article.dateTextColor)!)
            
            if(article.areItemsSaved)
            {
                cell.articleImageHeight.constant = 0.75 * UIScreen.main.bounds.size.width * CGFloat(information.article.imageAspectRatio)
                
                if(!article.isImageLoaded)
                {
                    var image = UIImage(data: article!.imageData)
                    images.append(ImageCacheModel(image: image != nil ? image! : UIImage() , url: article.image, articleModel : article))
                    cell.articleImage.image = UIImage(data: article.imageData)
                    article.isImageLoaded = true
                    
                    if(images.count > numberOfCachedImages)
                    {
                        images[0].articleModel.isImageLoaded = false
                        images.remove(at: 0)
                    }
                }
                else
                {
                    for i in 0..<images.count
                    {
                        if(images[i].url ==  article.image)
                        {
                            cell.articleImage.image = images[i].image
                            break
                        }
                    }
                }
            }
            else
            {
                let url = URL(string: percentEncode(s:article.image))
                cell.articleImage.kf.setImage(with: url, completionHandler: {
                    (image, error, cacheType, imageUrl) in
                    // image: Image? `nil` means failed
                    // error: NSError? non-`nil` means failed
                    // cacheType: CacheType
                    //                  .none - Just downloaded
                    //                  .memory - Got from memory cache
                    //                  .disk - Got from disk cache
                    // imageUrl: URL of the image
                    
                    if(image != nil)
                    {
                        var aspectRatio = Double((image?.size.height)! / (image?.size.width)!)
                        
                        cell.articleImageHeight.constant = 0.75 * UIScreen.main.bounds.size.width * CGFloat(aspectRatio)
                        
                        if(cacheType == .none)
                        {
                            self.articlesTableView.reloadData()
                        }
                    }
                })
            }
            
            if(viewModel.articleViewList.count == indexPath.section + 1)
            {
                cell.splitter.backgroundColor = .white
            }
            else
            {
                cell.splitter.backgroundColor = .lightGray
            }
            
            cell.selectionStyle = .none
            
            return cell
        default:
            return tableView.dequeueReusableCell(withIdentifier: "general_info_text") as! InformationTextViewCell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var information : GeneralInformation2!
        
        information = viewModel.articleViewList[indexPath.section]
        
        switch information.type {
        case SlotType.Carousel.rawValue:
            let carousel = information.carousel
            var titleHeight : CGFloat! = 0.0
            
            if(carousel?.hasTitles)!
            {
                titleHeight = carousel?.urls[0].title.title?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: UIFont (name: (carousel?.urls[0].title.titleFont)!, size: CGFloat((carousel?.urls[0].title.titleSize)!))!)
            }
            
            var cellHeight : CGFloat!
            let aspcetRatio = carousel?.urls[0].aspectRatio
            if(aspcetRatio != nil)
            {
                cellHeight = UIScreen.main.bounds.size.width * CGFloat(aspcetRatio!) + titleHeight
            }
            else
            {
                cellHeight = UIScreen.main.bounds.size.width + titleHeight
            }
            
            return cellHeight
        case SlotType.Video.rawValue:
            return UIScreen.main.bounds.size.width/1.77 - 2
        case SlotType.Text.rawValue:
            return UITableViewAutomaticDimension
        case SlotType.Photo.rawValue:
            var titleHeight : CGFloat! = 0.0
            
            if(information.photo.title != nil)
            {
                titleHeight = information.photo.title.title?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: UIFont (name: (information.photo.title.titleFont)!, size: CGFloat((information.photo.title.titleSize)!))!)
            }
            
            var cellHeight : CGFloat!
            if(information.photo.aspectRatio != nil)
            {
                if(information.photo.takeFullWidth)
                {
                    cellHeight = UIScreen.main.bounds.size.width * CGFloat(information.photo.aspectRatio) + titleHeight
                }
                else
                {
                    cellHeight = 0.5 * UIScreen.main.bounds.size.width * CGFloat(information.photo.aspectRatio) + titleHeight
                }
            }
            else
            {
                cellHeight = UIScreen.main.bounds.size.width + titleHeight
            }
            
            return cellHeight
        case SlotType.Title.rawValue:
            let font = UIFont (name: (FontsAndSizes.titleFont), size: CGFloat((FontsAndSizes.titleTextSize)))
            return (information.title.title.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: font!) + 30)
        case SlotType.Product.rawValue:
            //return 0.75 * UIScreen.main.bounds.size.width * CGFloat(information.product.imageAspectRatio)
            return UITableViewAutomaticDimension
        case SlotType.Article.rawValue:
            //return 0.75 * UIScreen.main.bounds.size.width * CGFloat(information.product.imageAspectRatio)
            return UITableViewAutomaticDimension
        default:
            return 180
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if(viewModel.articleViewList[indexPath.section].type == SlotType.Article.rawValue)
        {
            let article = viewModel.articleViewList[indexPath.section].article
            
            viewsDB.insertSeenArticle(articleID: (article?.id)!)
            
            isViewPushed = true
            
            var informationsList : [GeneralInformation2] = []
            
            if((article?.areItemsSaved)!)
            {
                informationsList = viewsDB.getGenealInformations(isArticle: true, articleID: article!.id)
            }
            else
            {
                informationsList = (article?.articleItems)!
                
                for i in informationsList
                {
                    if(i.type == SlotType.Product.rawValue)
                    {
                        i.product =  productsDB.getProductByItemNo(itemNo : i.productItemCode)
                    }
                }
            }
            
            if(!isNullOrEmpty(string: article?.authorEmailAddress))
            {
                var author = viewsDB.getAuthorModel(emailAddress: article?.authorEmailAddress)
                
                if(author != nil)
                {
                    var parameters = viewsDB.getAuthorsParameters(emailAddress: article?.authorEmailAddress)
                    
                    if(parameters != nil)
                    {
                        if(!isNullOrEmpty(string: author?.name))
                        {
                            var nameTitle = GeneralInformation2()
                            
                            nameTitle.type = SlotType.Title.rawValue
                            nameTitle.title = TitleModel()
                            nameTitle.title.title = author?.name
                            nameTitle.title.titleColor = parameters?.nameTextColor
                            nameTitle.title.titleSize = parameters?.nameTextSize
                            nameTitle.title.titleFont = parameters?.nameFont
                            
                            informationsList.append(nameTitle)
                        }
                        
                        if(!isNullOrEmpty(string: author?.jobDescription))
                        {
                            var jobDescriptionTitle = GeneralInformation2()
                            
                            jobDescriptionTitle.type = SlotType.Title.rawValue
                            jobDescriptionTitle.title = TitleModel()
                            jobDescriptionTitle.title.title = author?.jobDescription
                            jobDescriptionTitle.title.titleColor = parameters?.jobDescriptionTextColor
                            jobDescriptionTitle.title.titleSize = parameters?.jobDescriptionTextSize
                            jobDescriptionTitle.title.titleFont = parameters?.jobDescriptionFont
                            
                            informationsList.append(jobDescriptionTitle)
                        }
                    }
                }
            }
            
            if(!isNullOrEmpty(string: article?.url))
            {
                var shareSlot = GeneralInformation2()
                shareSlot.type = SlotType.Share.rawValue
                shareSlot.share = ShareModel()
                
                shareSlot.share.description = "Share"
                shareSlot.share.descriptionFont = "CharpentierSansPro-Normal"
                shareSlot.share.descriptionTextColor = "#1D2D51"
                shareSlot.share.descriptionTextSize = 16
                shareSlot.share.tintColor = "#1D2D51"
                
                shareSlot.share.image = article?.imageData
                shareSlot.share.title = article?.title
                shareSlot.share.url = article?.url
                
                informationsList.append(shareSlot)
            }
            
            var count = 2
            for a in viewModel.articleViewList
            {
                if(a.type == SlotType.Article.rawValue)
                {
                    if(a.article.id != article?.id)
                    {
                        var relatedArticle = ArticleModel()
                        relatedArticle = a.article
                        
                        var relatedArticleSlot = GeneralInformation2()
                        relatedArticleSlot.article = a.article
                        relatedArticleSlot.type = SlotType.RelatedArticle.rawValue
                        
                        informationsList.append(relatedArticleSlot)
                        
                        count -= 1
                        if(count == 0)
                        {
                            break
                        }
                    }
                }
            }
            /*var relatedArticles = viewsDB.getGenealInformations(articleID: article!.id)
            
            if(relatedArticles != nil)
            {
                for r in relatedArticles!
                {
                    informationsList?.append(r)
                }
            }*/
            
            let InformationStoryBoard : UIStoryboard = UIStoryboard(name: "GeneralInformationView" , bundle: nil)
            let generalInformationView = InformationStoryBoard.instantiateInitialViewController() as! GeneralInformationViewController
            
            generalInformationView.viewController = self
            generalInformationView.isEmbeded = true
            generalInformationView.isArticle = true
            generalInformationView.informationsList = informationsList
            generalInformationView.areItemsSaved = article!.areItemsSaved
            generalInformationView.articleModel = article
            
            let embededViewParameters = viewsDB.getEmbededViewParameters(id: 1)
            borderWidth = embededViewParameters?.borderSize
            borderColor = embededViewParameters?.borderColor
            separatorHeight = embededViewParameters?.separatorHeight
            separatorColor = embededViewParameters?.separatorColor
            
            self.navigationController?.pushViewController(generalInformationView, animated: true)
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let  height = scrollView.frame.size.height
        let contentYoffset = scrollView.contentOffset.y
        let distanceFromBottom = scrollView.contentSize.height - contentYoffset
        if distanceFromBottom < height {
            synchronized.synchronize(obj: lock)
            {
                if (viewModel != nil && viewModel.articlesList != nil)
                {
                    if (!ignoreLoadingMoreData)
                    {
                        ignoreLoadingMoreData = true
                        task = WebApiTask(viewController: self, action: loadMoreArticles, displayToast: false, isSynchronizationTimerEnabled: false)
                        task.failureAction = setIgnoreLoadingMoreDataFlag
                        task.start()
                    }
                }
            }
        }
    }
    
    func loadMoreArticles()
    {
        viewModel.loadMoreArticles()
        
        if(previousPartnersListSize == viewModel.articlesList.count)
        {
            return
        }
        
        if (!isActivityActive(viewController: self) && CustomTabbarViewController.navigationControllers.count == 0)
        {
            return
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            //let contentOffset = self.articlesTableView.contentOffset
            //self.articlesTableView.reloadData()
            //self.articlesTableView.layoutIfNeeded()
            //self.articlesTableView.setContentOffset(contentOffset, animated: false)
            
            self.articlesTableView.reloadData()
        })
        
        previousPartnersListSize = viewModel.articlesList.count
        ignoreLoadingMoreData = false
    }
    
    func setIgnoreLoadingMoreDataFlag()
    {
        ignoreLoadingMoreData = false
    }

    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }

}
