//
//  CheckBoxModel.swift
//  RichReach2
//
//  Created by Eumbrella on 28/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class CheckBoxModel : Codable
{
    var id : Int!
    var text : String!
    var imageUrl : String!
    var imageData : Data!
    var image : UIImage!
    var imageAspectRatio : Double!
    var textColor : String!
    var textSize : Int!
    var textFont : String!
    var isRequired : Bool!
    var tintColor : String!
    var link : String!
    
    var alignment : Int!
    var isCheckBoxOnTheLeft : Bool! = false
    var isCheckBoxNearText : Bool! = true
    var connectionID : Int!
    var imageWidthPercentage : Int!
    
    var isChecked : Bool! = false
    
    private enum CodingKeys : String, CodingKey {
        case id = "ID"
        case text = "TextString"
        case imageUrl = "ImageUrl"
        case textColor = "TextColor"
        case textSize = "TextSize"
        case textFont = "TextFont"
        case isRequired = "IsRequired"
        case tintColor = "TintColor"
        case link = "Link"
        case connectionID = "ConnectionID"
        case imageWidthPercentage = "ImageWidthPercentage"
        
        case alignment = "Alignment"
        case isCheckBoxOnTheLeft = "IsCheckBoxOnTheLeft"
        case isCheckBoxNearText = "IsCheckBoxNearText"
    }
}
