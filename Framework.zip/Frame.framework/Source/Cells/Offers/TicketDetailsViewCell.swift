//
//  TicketDetailsViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 13/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// TicketDetailsViewCell is a cell that is been showing loyalty ticket details table
class TicketDetailsViewCell: UITableViewCell {
    
    @IBOutlet var ticketTitle: UILabel!
    
    @IBOutlet var ticketNoHeaderLabel: UILabel!
    @IBOutlet var ticketDateHeaderLabel: UILabel!
    @IBOutlet var rewardPointsHeaderLabel: UILabel!
    @IBOutlet var redemptionPointsHeaderLabel: UILabel!
    
    @IBOutlet var ticketNoLabel: UILabel!
    @IBOutlet var ticketDateLabel: UILabel!
    @IBOutlet var rewardPointsLabel: UILabel!
    @IBOutlet var redemptionPointsLabel: UILabel!
    
    @IBOutlet var line: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
