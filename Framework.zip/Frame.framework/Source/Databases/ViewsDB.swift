//
//  ViewsDB.swift
//  RichReach2
//
//  Created by Eumbrella on 22/06/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import SQLite
import QuartzCore
import Kingfisher

/// Views database is used for saving views(e.g. general view, contact us view) parameters.
class ViewsDB : NSObject
{
    let DATABASE_NAME = "ViewsDB"
    
    var database : Connection!
    var lock = NSObject()
    var version = 8
    
    let generalViewsTable = Table("GeneralViews")
    let pdfTable = Table("PDF")
    let textTable = Table("Text")
    let photoTable = Table("Photo")
    let buttonTable = Table("Button")
    let titleTable = Table("Title")
    let carouselTable = Table("Carousel")
    let urlTable = Table("Url")
    let videoTable = Table("Video")
    let switchTable = Table("Switch")
    let expanableListViewTable = Table("ExpanableListViewTable")
    let expanableListParentsTable = Table("ExpanableListParentsTable")
    let expandableListChildStyles = Table("ExpandableListChildStyles")
    let embededGeneralViewTable = Table("EmbededGeneralViewTable")
    let embededViewParametersTable = Table("embededViewParametersTable")
    let storeLocatorInfoParametersTable = Table("StoreLocatorParameters")
    let contactUsViewTable = Table("ContactUsViewTable")
    let contactUsTabsRelationsTable = Table("ContactUsTabsRelationsTable")
    let barcodeViewTable = Table("BarcodeViewTable")
    var generalSearchViewTable = Table("GeneralSearchViewTable")
    var radioButtonTable = Table("RadioButtonTable")
    var notAvailableViewTable = Table("NotAvailableViewTable")
    var checkBoxTable = Table("CheckBoxTable")
    var notAvailableImageTable = Table("NotAvailableImageTable")
    var blogViewTable = Table("BlogViewTable")
    var blogViewArticlesTable = Table("BlogViewArticlesTable")
    var articleItemsTable = Table("ArticleItemsTable")
    var articleTable = Table("ArticleTable")
    var articleCategoriesTable = Table("ArticleCategoriesTable")
    var apkAuthorParametersTable = Table("APKAuthorParametersTable")
    var apkAuthorsTable = Table("APKAuthorsTable")
    var authorTable = Table("AuthorTable")
    var seenArticlesTable = Table("SeenArticlesTable")
    var checkBoxGroupsTable = Table("CheckBoxGroupsTable")
    var checkBoxGroupsItemsTable = Table("CheckBoxGroupsItemsTable")
    var checkBoxGroupsRelationsTable = Table("CheckBoxGroupsRelationsTable")
    
    //General views columns
    let apk = Expression<String>("apk")
    let index = Expression<Int>("index")
    let type = Expression<Int>("type")
    let id = Expression<Int>("id")
    let tabID = Expression<Int>("tabID")
    let startDate = Expression<String?>("startDate")
    let endDate = Expression<String?>("endDate")
    
    //PDF columns
    let url = Expression<String?>("url")
    let numOfPages = Expression<Int>("numOfPages")
    
    //Text columns
    let title = Expression<String?>("title")
    let textDescription = Expression<String?>("textDescription")
    let titleFont = Expression<String>("titleFont")
    let titleSize = Expression<Int?>("titleSize")
    let titleColor = Expression<String>("titleColor")
    let descriptionFont = Expression<String>("descriptionFont")
    let descriptionSize = Expression<Int>("descriptionSize")
    let descriptionColor = Expression<String>("descriptionColor")
    let splitterColor = Expression<String?>("splitterColor")
    let backgroundColor = Expression<String>("backgroundColor")
    let isTitleCentered = Expression<Bool?>("isTitleCentered")
    let descriptionAlignmentType = Expression<Int>("descriptionAlignmentType")
    
    //Photo columns
    let link = Expression<String?>("link")
    let aspectRatio = Expression<Double?>("aspectRatio")
    let button = Expression<Int?>("button")
    let photoTitle = Expression<Int?>("photoTitle")
    
    //Button columns
    let name = Expression<String>("name")
    let height = Expression<Int>("height")
    let width = Expression<Int>("width")
    let font = Expression<String>("font")
    let nameTextSize = Expression<Int>("nameTextSize")
    let textColor = Expression<String>("textColor")
    let borderWidth = Expression<Int>("borderWidth")
    let borderColor = Expression<String?>("borderColor")
    let buttonPosition = Expression<Int?>("buttonPosition")
    let cornerRadius = Expression<Double?>("cornerRadius")
    
    //Carousel columns
    let hasTitles = Expression<Bool>("hasTitles")
    let interval = Expression<Int>("interval")
    let isManual = Expression<Bool>("isManual")
    let isAutomatic = Expression<Bool>("isAutomatic")
    let isScrollingEnabled = Expression<Bool>("isScrollingEnabled")
    
    //Url columns
    let carouselID = Expression<Int>("carouselID")
    let urlTitle = Expression<Int?>("urlTitle")
    
    //Video columns
    let autoPlay = Expression<Bool>("autoPlay")
    let alternativePhoto = Expression<String>("alternativePhoto")
    
    //Switch columns
    let fieldStyleID = Expression<Int>("fieldStyleID")
    let acceptType = Expression<Int>("acceptType")
    
    //Expanable List Parents columns
    let expandableListViewID = Expression<Int>("expandableListViewID")
    let tintColor = Expression<String>("tintColor")
    let image = Expression<String?>("image")
    let hasAlternatingStyles = Expression<Bool>("hasAlternatingStyles")
    let firstStyle = Expression<Int?>("firstStyle")
    let secondStyle = Expression<Int?>("secondStyle")
    let backgroundImage = Expression<String?>("backgroundImage")
    let labelPosition = Expression<Int?>("labelPosition")
    let labelBackgroundColor = Expression<String?>("labelBackgroundColor")
    let labelWidth = Expression<Int?>("labelWidth")
    let labelHeight = Expression<Int?>("labelHeight")
    
    //Embeded General View columns
    let slotID = Expression<Int>("slotID")
    let infoType = Expression<Int>("infoType")
    
    //Embeded View Parameters columns
    let embededViewID = Expression<Int>("embededViewID")
    let separatorHeight = Expression<Int?>("separatorHeight")
    let separatorColor = Expression<String?>("separatorColor")
    let borderSize = Expression<Int?>("borderSize")
    
    //storeLocatorParameters
    var sizeOfText = Expression<Int>("sizeOfText")
    let titleBackgroundColor = Expression<String>("titleBackgroundColor")
    let titleTextColor = Expression<String>("titleTextColor")
    let titleTextSize = Expression<Int>("titleTextSize")
    
    //contact us columns
    let types = Expression<Data>("types")
    let info = Expression<Data>("info")
    let typeTitle = Expression<String>("typeTitle")
    let typeFont = Expression<String>("typeFont")
    let typeTextSize = Expression<Int>("typeTextSize")
    let typeTextColor = Expression<String>("typeTextColor")
    //let tintColor = Expression<String>("typeTintColor")
    let messageTitle = Expression<String>("messageTitle")
    let messageFont = Expression<String>("messageFont")
    let messageTextSize = Expression<Int>("messageTextSize")
    let messageTextColor = Expression<String>("messageTextColor")
    let infoFont = Expression<String>("infoFont")
    let infoTextSize = Expression<Int>("infoTextSize")
    let infoTextColor = Expression<String>("infoTextColor")
    let buttonText = Expression<String>("buttonText")
    let buttonBackgroundColor = Expression<String>("buttonBackgroundColor")
    let buttonFont = Expression<String>("buttonFont")
    let buttonTextSize = Expression<Int>("buttonTextSize")
    let buttonTextColor = Expression<String>("buttonTextColor")
    let buttonBorderWidth = Expression<Int?>("buttonBorderWidth")
    let buttonBorderColor = Expression<String?>("buttonBorderColor")
    
    //contactUsTabsRelations columns
    let contactUsViewID = Expression<Int>("contactUsViewID")
    
    //barcode view columns
    let prototype = Expression<Int>("prototype")
    let pointsTextColor = Expression<String>("pointsTextColor")
    let pointsTextSize = Expression<Int>("pointsTextSize")
    let pointsFont = Expression<String>("pointsFont")
    let pointsType = Expression<Int?>("pointsType")
    
    //general search view columns
    let itemBackgroundColor =  Expression<String>("itemBackgroundColor")
    let itemTextColor =  Expression<String>("itemTextColor")
    let itemFont =  Expression<String>("itemFont")
    let itemTextSize =  Expression<Int>("itemTextSize")
    let searchTextColor =  Expression<String>("searchTextColor")
    let searchFont =  Expression<String>("searchFont")
    let searchTextSize =  Expression<Int>("searchTextSize")
    
    //radiio button columns
    let radioButtonName = Expression<String?>("radioButtonName")
    let imageUrl = Expression<String?>("imageUrl")
    let selectedColor = Expression<String>("selectedColor")
    let nonSelectedColor = Expression<String>("nonSelectedColor")
    let imageAspectRatio = Expression<Double?>("imageAspectRatio")
    let radioButtonNameTextSize = Expression<Int?>("radioButtonNameTextSize")
    let nameTextColor = Expression<String?>("nameTextColor")
    let nameFont = Expression<String?>("nameFont")
    let connectionID = Expression<Int?>("connectionID")
    
    //Titlte columns
    let topPadding = Expression<Int?>("radioButtonNameTextSize")
    let isSection = Expression<Bool?>("isSection")
    let isSectionExpanded = Expression<Bool?>("isSectionExpanded")

    let imageData = Expression<Data>("imageData")
    
    //check box columns
    let text = Expression<String>("text")
    let textSize = Expression<Int>("textSize")
    let isRequired = Expression<Bool>("isRequired")
    let imageDataNullable = Expression<Data?>("imageDataNullable")
    let alignment = Expression<Int?>("alignment")
    let isCheckBoxOnTheLeft = Expression<Bool?>("isCheckBoxOnTheLeft")
    let isCheckBoxNearText = Expression<Bool?>("isCheckBoxNearText")
    let isChecked = Expression<Bool?>("isChecked")
    let cbConnectionID = Expression<Int?>("connectionID")
    let imageWidthPercentage = Expression<Int?>("imageWidthPercentage")
    
    //checkbox groups
    let checkBoxID = Expression<Int>("checkBoxID")
    let firstGroupID = Expression<Int>("firstGroupID")
    let secondGroupID = Expression<Int>("secondGroupID")
    let validationFailedHeader = Expression<String>("validationFailedHeader")
    let validationFailedMessage = Expression<String>("validationFailedMessage")
    
    //article
    let categoryID = Expression<Int>("categoryID")
    let categoryTextSize = Expression<Int>("categoryTextSize")
    let categoryFont = Expression<String>("categoryFont")
    let categoryTextColor = Expression<String>("categoryTextColor")
    let articleID = Expression<Int64>("articleID")
    let titleFontNull = Expression<String?>("titleFontNull")
    let titleTextSizeNull = Expression<Int?>("titleTextSizeNull")
    let titleTextColorNull = Expression<String?>("titleTextColorNull")
    let publishDate = Expression<String>("publishDate")
    let expirationdDate = Expression<String?>("expiredDate")
    let dateFont = Expression<String>("dateFont")
    let dateTextSize = Expression<Int>("dateTextSize")
    let dateTextColor = Expression<String>("dateTextColor")
    let authorEmailAddress = Expression<String?>("authorEmailAddress")
    let emailAddress = Expression<String>("emailAddress")
    let categoryName = Expression<String>("categoryName")
    let productItemCode = Expression<String?>("productItemCode")
    
    let authorID = Expression<Int>("authorID")
    let authorName = Expression<String?>("authorName")
    let jobDescription = Expression<String?>("jobDescription")
    let authorPhotoUrl = Expression<String?>("authorPhotoUrl")
    let authorPhotoData = Expression<Data?>("authorPhotoData")
    let authorNameTextSize = Expression<Int?>("authorNameTextSize")
    let authorNameTextColor = Expression<String?>("authorNameTextColor")
    let authorNameFont = Expression<String?>("authorNameFont")
    let jobDescriptionTextSize = Expression<Int?>("jobDescriptionTextSize")
    let jobDescriptionTextColor = Expression<String?>("jobDescriptionTextColor")
    let jobDescriptionFont = Expression<String?>("jobDescriptionFont")

    
    override init(){
        do{
            let documentDirectory = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let fileUrl = documentDirectory.appendingPathComponent(DATABASE_NAME).appendingPathExtension("sqlite3")
            self.database = try Connection(fileUrl.path)
        } catch {
            print(error)
        }
    }
    
    /// Checks if database need to be upgraded, and upgrade it if needed.
    func checkForUpgrade()
    {
        createTables()
        
        switch database.userVersion {
        case 0:
            upgradeToVersion1()
        case 1:
            upgradeToVersion2()
        case 2:
            upgradeToVersion3()
        case 3:
            upgradeToVersion4()
        case 4:
            upgradeToVersion5()
        case 5:
            upgradeToVersion6()
        case 6:
            upgradeToVersion7()
        case 7:
            upgradeToVersion8()
        default:
            break
        }
        
        /*if database.userVersion == 0 {
            upgradeToVersion1()
            upgradeToVersion2()
            upgradeToVersion3()
            upgradeToVersion4()
            upgradeToVersion5()
            upgradeToVersion6()
            upgradeToVersion7()
        }
        
        if database.userVersion == 1 {
            upgradeToVersion2()
            upgradeToVersion3()
            upgradeToVersion4()
            upgradeToVersion5()
            upgradeToVersion6()
            upgradeToVersion7()
        }
        
        if database.userVersion == 2 {
            upgradeToVersion3()
            upgradeToVersion4()
            upgradeToVersion5()
            upgradeToVersion6()
            upgradeToVersion7()
        }
        
        if database.userVersion == 3 {
            upgradeToVersion4()
            upgradeToVersion5()
            upgradeToVersion6()
            upgradeToVersion7()
        }
        
        if database.userVersion == 4 {
            upgradeToVersion5()
            upgradeToVersion6()
            upgradeToVersion7()
        }
        
        if database.userVersion == 5 {
            upgradeToVersion6()
            upgradeToVersion7()
        }
        
        if database.userVersion == 6 {
            upgradeToVersion7()
        }
        
        if database.userVersion == 7 {
            upgradeToVersion8()
        }*/
        
        database.userVersion = version
    }
    
    /// Upgrade database to version 1.
    func upgradeToVersion1()
    {
        do
        {
            try database.run(self.contactUsViewTable.addColumn(self.buttonBorderColor))
            try database.run(self.contactUsViewTable.addColumn(self.buttonBorderWidth))
        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion2()
    }
    
    func upgradeToVersion2()
    {
        do
        {
            try database.run(self.titleTable.addColumn(self.topPadding))
        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion3()
    }
    
    func upgradeToVersion3()
    {
        do
        {
            try database.run(self.buttonTable.addColumn(self.buttonPosition))
            try database.run(self.urlTable.addColumn(self.aspectRatio))
        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion4()
    }
    
    func upgradeToVersion4()
    {
        do
        {
            try database.run(self.buttonTable.addColumn(self.link))
            
            try database.run(self.expanableListParentsTable.addColumn(self.backgroundImage))
            try database.run(self.expanableListParentsTable.addColumn(self.aspectRatio))
            try database.run(self.expanableListParentsTable.addColumn(self.labelPosition))
            try database.run(self.expanableListParentsTable.addColumn(self.labelBackgroundColor))
            try database.run(self.expanableListParentsTable.addColumn(self.labelWidth))
            try database.run(self.expanableListParentsTable.addColumn(self.labelHeight))
        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion5()
    }
    
    func upgradeToVersion5()
    {
        do
        {
            try database.run(self.radioButtonTable.addColumn(self.connectionID))
        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion6()
    }
    
    func upgradeToVersion6()
    {
        do
        {
            try database.run(self.generalViewsTable.addColumn(self.startDate))
            try database.run(self.generalViewsTable.addColumn(self.endDate))
        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion7()
    }
    
    func upgradeToVersion7()
    {
        do
        {
            try database.run(self.titleTable.addColumn(self.isSection))
            try database.run(self.titleTable.addColumn(self.isSectionExpanded))
            
            try database.run(self.buttonTable.addColumn(self.cornerRadius))
            
            try database.run(self.checkBoxTable.addColumn(self.imageUrl))
            try database.run(self.checkBoxTable.addColumn(self.imageDataNullable))
            try database.run(self.checkBoxTable.addColumn(self.imageAspectRatio))
            try database.run(self.checkBoxTable.addColumn(self.alignment))
            try database.run(self.checkBoxTable.addColumn(self.isCheckBoxOnTheLeft))
            try database.run(self.checkBoxTable.addColumn(self.isCheckBoxNearText))
            try database.run(self.checkBoxTable.addColumn(self.isChecked))
            try database.run(self.checkBoxTable.addColumn(self.cbConnectionID))
            try database.run(self.checkBoxTable.addColumn(self.imageWidthPercentage))

        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion8()
    }
    
    func upgradeToVersion8()
    {
        do
        {
            try database.run(self.barcodeViewTable.addColumn(self.pointsType))
            
            //statusModel = statusDB.getStatus(apk : APK)
            //statusModel.isBarcodeViewSaved = false
            //statusDB.insertStatus(status : statusModel, apk : APK)
        }
        catch
        {
            print(error)
        }
    }

    
    /// Checks if generals views are saved in local database.
    ///
    /// - Parameter apk: The APK we want to check.
    /// - Returns: True if generals views are saved, otherwise false.
    func areGeneralViewsSaved(apk : String) -> Bool!
    {
        objc_sync_enter(lock)
        do {
            let views = try self.database.prepare(self.generalViewsTable.filter(self.apk == APK))
            
            for _ in views
            {
                objc_sync_exit(lock)
                return true
            }

            objc_sync_exit(lock)
            return false
        }
        catch
        {
            print(error)
        }
        objc_sync_exit(lock)
        return false
    }
    
    /// Checks if expandable list views are saved in local database.
    ///
    /// - Parameter apk: The APK we want to check.
    /// - Returns: True if expandable list views are saved, otherwise false.
    func areExpandableListViewsSaved(apk : String) -> Bool!
    {
        objc_sync_enter(lock)
        do {
            let views = try self.database.prepare(self.expanableListViewTable.filter(self.apk == APK))
            
            for _ in views
            {
                objc_sync_exit(lock)
                return true
            }
            
            objc_sync_exit(lock)
            return false
        }
        catch
        {
            print(error)
        }
        objc_sync_exit(lock)
        return false
    }
    
    /// Checks if embeded views are saved in local database.
    ///
    /// - Parameter apk: The APK we want to check.
    /// - Returns: True if embeded views are saved, otherwise false.
    func areEmbededViewsSaved(apk : String) -> Bool!
    {
        objc_sync_enter(lock)
        do {
            let views = try self.database.prepare(self.embededGeneralViewTable.filter(self.apk == APK))
            
            for _ in views
            {
                objc_sync_exit(lock)
                return true
            }
            
            objc_sync_exit(lock)
            return false
        }
        catch
        {
            print(error)
        }
        objc_sync_exit(lock)
        return false
    }
    
    
    
    
    /*********************************************************                  CREATES                  *********************************************************/
    /// Creates the views database tables.
    func createTables()
    {
        objc_sync_enter(lock)
        createGeneralViewsTable()
        createPDFTable()
        createTextTable()
        createPhotoTable()
        createButtonTable()
        createTitleTable()
        createCarouselTable()
        createUrlTable()
        createVideoTable()
        createSwitchTable()
        createExpandableListViewTable()
        createExpanableListParentsTable()
        createExpandableListChildStyles()
        createEmbededGeneralViewTable()
        createEmbededViewParametersTable()
        createStoreLocatorInfoParametersTable()
        createContactViewTable()
        createContactUsTabsRelationsTable()
        createBarcodeViewTable()
        createGeneralSearchViewTable()
        createRadioButtonTable()
        createNotAvailableViewTable()
        createNotAvailableImageTable()
        createCheckBoxTable()
        createsImagesTable()
        createBlogViewTable()
        createBlogViewArticlesTable()
        createArticleItemsTable()
        createArticleTable()
        createArticleCategoriesTable()
        createSeenArticlesTable()
        createAPKAuthorParametersTable()
        createAPKAuthorsTable()
        createAuthorTable()
        createCheckBoxGroupsTable()
        createCheckBoxGroupsItemsTable()
        createCheckBoxGroupsRelationsTable()
        objc_sync_exit(lock)
    }
    
    /// Create general information table.
    func createGeneralViewsTable()
    {
        let createGeneralViewsTable = self.generalViewsTable.create { (table) in
            table.column(self.apk)
            table.column(self.index)
            table.column(self.type)
            table.column(self.id)
            table.column(self.tabID)
            table.column(self.startDate)
            table.column(self.endDate)
            
            table.primaryKey(self.apk,self.index, self.tabID)
        }
        
        do {
            try self.database.run(createGeneralViewsTable)
        } catch {
            print(error)
        }
    }
    
    func createBlogViewTable()
    {
        let createBlogViewTable = self.blogViewTable.create { (table) in
            table.column(self.apk)
            table.column(self.tabID)
            table.column(self.url)
            table.column(self.title)
            table.column(self.titleFontNull)
            table.column(self.titleTextSizeNull)
            table.column(self.titleTextColorNull)
            
            table.column(self.imageAspectRatio)
            table.column(self.imageData)
            
            table.primaryKey(self.apk , self.tabID)
        }
        
        do {
            try self.database.run(createBlogViewTable)
            
        } catch {
            print(error)
        }
    }
    
    func createBlogViewArticlesTable()
    {
        let createBlogViewArticlesTable = self.blogViewArticlesTable.create { (table) in
            table.column(self.apk)
            table.column(self.tabID)
            table.column(self.articleID)
            
            table.primaryKey(self.apk, self.tabID, self.articleID)
        }
        
        do {
            try self.database.run(createBlogViewArticlesTable)
        } catch {
            print(error)
        }
    }
    
    func createArticleItemsTable()
    {
        let createArticleItemsTable = self.articleItemsTable.create { (table) in
            table.column(self.articleID)
            table.column(self.index)
            table.column(self.type)
            table.column(self.id)
            table.column(self.productItemCode)
            
            table.primaryKey(self.articleID, self.index)
        }
        
        do {
            try self.database.run(createArticleItemsTable)
        } catch {
            print(error)
        }
    }
    
    func createArticleTable()
    {
        let createArticleTable = self.articleTable.create { (table) in
            table.column(self.articleID, primaryKey : true)
            table.column(self.image)
            table.column(self.title)
            table.column(self.categoryID)
            table.column(self.url)
            table.column(self.titleFont)
            table.column(self.titleSize)
            table.column(self.titleColor)
            table.column(self.categoryFont)
            table.column(self.categoryTextSize)
            table.column(self.categoryTextColor)
            table.column(self.publishDate)
            table.column(self.expirationdDate)
            table.column(self.dateFont)
            table.column(self.dateTextSize)
            table.column(self.dateTextColor)
            table.column(self.authorEmailAddress)
            table.column(self.aspectRatio)
            table.column(self.imageData)
        }
        
        do {
            try self.database.run(createArticleTable)
        } catch {
            print(error)
        }
    }
    
    func createArticleCategoriesTable()
    {
        let createArticleCategoriesTable = self.articleCategoriesTable.create { (table) in
            table.column(self.id, primaryKey : true)
            table.column(self.name)
        }
        
        do {
            try self.database.run(createArticleCategoriesTable)
        } catch {
            print(error)
        }
    }
    
    func createSeenArticlesTable()
    {
        let createSeenArticlesTable = self.seenArticlesTable.create { (table) in
            table.column(self.apk)
            table.column(self.articleID)
            
            table.primaryKey(self.apk, self.articleID)
        }
        
        do {
            try self.database.run(createSeenArticlesTable)
        } catch {
            print(error)
        }
    }
    
    /// Create pdf table.
    func createPDFTable()
    {
        let createPDFTable = self.pdfTable.create { (table) in
            table.column(self.id, primaryKey : true)
            table.column(self.url)
            table.column(self.numOfPages)
        }
        
        do {
            try self.database.run(createPDFTable)
        } catch {
            print(error)
        }
    }
    
    /// Create text table.
    func createTextTable()
    {
        let createTextTable = self.textTable.create { (table) in
            table.column(self.id, primaryKey : true)
            table.column(self.title)
            table.column(self.textDescription)
            table.column(self.titleFont)
            table.column(self.titleSize)
            table.column(self.titleColor)
            table.column(self.descriptionFont)
            table.column(self.descriptionSize)
            table.column(self.descriptionColor)
            table.column(self.splitterColor)
            table.column(self.backgroundColor)
            table.column(self.isTitleCentered)
            table.column(self.descriptionAlignmentType)
        }
        
        do {
            try self.database.run(createTextTable)
        } catch {
            print(error)
        }
    }
    
    /// Create photo table.
    func createPhotoTable()
    {
        let createPhotoTable = self.photoTable.create { (table) in
            table.column(self.id, primaryKey : true)
            table.column(self.url)
            table.column(self.link)
            table.column(self.aspectRatio)
            table.column(self.button)
            table.column(self.photoTitle)
        }
        
        do {
            try self.database.run(createPhotoTable)
        } catch {
            print(error)
        }
    }
    
    /// Create button table.
    func createButtonTable()
    {
        let createButtonTable = self.buttonTable.create { (table) in
            table.column(self.id, primaryKey : true)
            table.column(self.name)
            table.column(self.height)
            table.column(self.width)
            table.column(self.backgroundColor)
            table.column(self.font)
            table.column(self.nameTextSize)
            table.column(self.textColor)
            table.column(self.url)
            table.column(self.borderWidth)
            table.column(self.borderColor)
            table.column(self.tabID)
            table.column(self.buttonPosition)
            table.column(self.link)
            table.column(self.cornerRadius)
        }
        
        do {
            try self.database.run(createButtonTable)
        } catch {
            print(error)
        }
    }
    
    /// Create title table.
    func createTitleTable()
    {
        let createTitleTable = self.titleTable.create { (table) in
            table.column(self.id, primaryKey : true)
            table.column(self.title)
            table.column(self.titleFont)
            table.column(self.titleSize)
            table.column(self.titleColor)
            table.column(self.splitterColor)
            table.column(self.backgroundColor)
            table.column(self.isTitleCentered)
            table.column(self.topPadding)
            table.column(self.isSection)
            table.column(self.isSectionExpanded)
        }
        
        do {
            try self.database.run(createTitleTable)
        } catch {
            print(error)
        }
    }
    
    /// Create carousel table.
    func createCarouselTable()
    {
        let createCarouselTable = self.carouselTable.create { (table) in
            table.column(self.id, primaryKey : true)
            table.column(self.hasTitles)
            table.column(self.interval)
            table.column(self.isManual)
            table.column(self.isAutomatic)
            table.column(self.isScrollingEnabled)
            table.column(self.titleSize)
        }
        
        do {
            try self.database.run(createCarouselTable)
        } catch {
            print(error)
        }
    }
    
    /// Create url table.
    func createUrlTable()
    {
        let createUrlTable = self.urlTable.create { (table) in
            table.column(self.id, primaryKey : true)
            table.column(self.carouselID)
            table.column(self.url)
            table.column(self.urlTitle)
            table.column(self.aspectRatio)
        }
        
        do {
            try self.database.run(createUrlTable)
        } catch {
            print(error)
        }
    }
    
    /// Create video table.
    func createVideoTable()
    {
        let createVideoTable = self.videoTable.create { (table) in
            table.column(self.id, primaryKey : true)
            table.column(self.url)
            table.column(self.autoPlay)
            table.column(self.alternativePhoto)
            table.column(self.aspectRatio)
        }
        
        do {
            try self.database.run(createVideoTable)
        } catch {
            print(error)
        }
    }
    
    /// Create switch table.
    func createSwitchTable()
    {
        let createSwitchTable = self.switchTable.create { (table) in
            table.column(self.id, primaryKey : true)
            table.column(self.title)
            table.column(self.textDescription)
            table.column(self.fieldStyleID)
            table.column(self.acceptType)
        }
        
        do {
            try self.database.run(createSwitchTable)
        } catch {
            print(error)
        }
    }
    
    func createCheckBoxTable()
    {
        let createCheckBoxTable = self.checkBoxTable.create { (table) in
            table.column(self.id, primaryKey : true)
            table.column(self.text)
            table.column(self.textColor)
            table.column(self.textSize)
            table.column(self.font)
            table.column(self.isRequired)
            table.column(self.tintColor)
            table.column(self.link)
            table.column(self.imageUrl)
            table.column(self.imageDataNullable)
            table.column(self.imageAspectRatio)
            table.column(self.alignment)
            table.column(self.isCheckBoxOnTheLeft)
            table.column(self.isCheckBoxNearText)
            table.column(self.isChecked)
            table.column(self.cbConnectionID)
            table.column(self.imageWidthPercentage)

        }
        
        do {
            try self.database.run(createCheckBoxTable)
        } catch {
            print(error)
        }
    }
    
    /// Create expandable list view table.
    func createExpandableListViewTable()
    {
        let createExpandableListViewTable = self.expanableListViewTable.create { (table) in
            table.column(self.id, primaryKey : true)
            table.column(self.apk)
            table.column(self.tabID)
        }
        
        do {
            try self.database.run(createExpandableListViewTable)
        } catch {
            print(error)
        }
    }
    
    /// Create expandable list parents table.
    func createExpanableListParentsTable()
    {
        let createExpanableListParentsTable = self.expanableListParentsTable.create { (table) in
            table.column(self.expandableListViewID)
            table.column(self.id)
            table.column(self.type)
            table.column(self.backgroundColor)
            table.column(self.font)
            table.column(self.nameTextSize)
            table.column(self.textColor)
            table.column(self.tintColor)
            table.column(self.image)
            table.column(self.name)
            table.column(self.hasAlternatingStyles)
            table.column(self.firstStyle)
            table.column(self.secondStyle)
            table.column(self.backgroundImage)
            table.column(self.aspectRatio)
            table.column(self.labelPosition)
            table.column(self.labelBackgroundColor)
            table.column(self.labelWidth)
            table.column(self.labelHeight)
            
            table.primaryKey(self.expandableListViewID, self.id)
        }
        
        do {
            try self.database.run(createExpanableListParentsTable)
        } catch {
            print(error)
        }
    }
    
    /// Create expandable list child style table.
    func createExpandableListChildStyles()
    {
        let createExpandableListChildStyles = self.expandableListChildStyles.create { (table) in
            table.column(self.id, primaryKey : true)
            table.column(self.backgroundColor)
            table.column(self.font)
            table.column(self.nameTextSize)
            table.column(self.textColor)
            table.column(self.tintColor)
        }
        
        do {
            try self.database.run(createExpandableListChildStyles)
        } catch {
            print(error)
        }
    }
    
    /// Create embeded general view table.
    func createEmbededGeneralViewTable()
    {
        let createGeneralViewsTable = self.embededGeneralViewTable.create { (table) in
            table.column(self.apk)
            table.column(self.id)
            table.column(self.index)
            table.column(self.type)
            table.column(self.slotID)
            table.column(self.infoType)
            
            table.primaryKey(self.apk,self.id, self.index)
        }
        
        do {
            try self.database.run(createGeneralViewsTable)
        } catch {
            print(error)
        }
    }
    
    /// Create embeded view parameters table.
    func createEmbededViewParametersTable()
    {
        let createGeneralViewsTable = self.embededViewParametersTable.create { (table) in
            table.column(self.apk)
            table.column(self.embededViewID)
            table.column(self.separatorHeight)
            table.column(self.separatorColor)
            table.column(self.borderSize)
            table.column(self.borderColor)
            
            table.primaryKey(self.apk,self.embededViewID)
        }
        
        do {
            try self.database.run(createGeneralViewsTable)
        } catch {
            print(error)
        }
    }
    
    /// Create store locator information parameters table.
    func createStoreLocatorInfoParametersTable()
    {
        let createStoreLocatorInfoParametersTable = self.storeLocatorInfoParametersTable.create { (table) in
            table.column(self.apk, primaryKey : true)
            table.column(self.font)
            table.column(self.sizeOfText)
            table.column(self.textColor)
            table.column(self.tintColor)
            table.column(self.borderSize)
            table.column(self.borderColor)
            table.column(self.titleBackgroundColor)
            table.column(self.titleTextColor)
            table.column(self.titleTextSize)
            table.column(self.titleFont)

        }
        
        do {
            try self.database.run(createStoreLocatorInfoParametersTable)
        } catch {
            print(error)
        }
    }
    
    /// Create contact us tabs relations table.
    func createContactUsTabsRelationsTable()
    {
        let createContactUsTabsRelationsTable = self.contactUsTabsRelationsTable.create { (table) in
            table.column(self.apk)
            table.column(self.tabID)
            table.column(self.contactUsViewID)
            
            table.primaryKey(self.tabID, self.contactUsViewID)
        }
        
        do {
            try self.database.run(createContactUsTabsRelationsTable)
        } catch {
            print(error)
        }
    }
    
    /// Create contact us view table.
    func createContactViewTable()
    {
        let createContactViewTable = self.contactUsViewTable.create { (table) in
            table.column(self.id, primaryKey : true)
            table.column(self.apk)
            table.column(self.types)
            table.column(self.info)
            table.column(self.typeTitle)
            table.column(self.typeFont)
            table.column(self.typeTextSize)
            table.column(self.typeTextColor)
            table.column(self.tintColor)
            table.column(self.messageTitle)
            table.column(self.messageFont)
            table.column(self.messageTextSize)
            table.column(self.messageTextColor)
            table.column(self.infoFont)
            table.column(self.infoTextSize)
            table.column(self.infoTextColor)
            table.column(self.buttonText)
            table.column(self.buttonBackgroundColor)
            table.column(self.buttonFont)
            table.column(self.buttonTextSize)
            table.column(self.buttonTextColor)
            table.column(self.buttonBorderWidth)
            table.column(self.buttonBorderColor)
        }
        
        do {
            try self.database.run(createContactViewTable)
        } catch {
            print(error)
        }
    }
    
    /// Create barcode view table.
    func createBarcodeViewTable()
    {
        let createBarcodeViewTable = self.barcodeViewTable.create { (table) in
            table.column(self.apk, primaryKey : true)
            table.column(self.prototype)
            table.column(self.backgroundColor)
            table.column(self.pointsTextColor)
            table.column(self.pointsTextSize)
            table.column(self.pointsFont)
            table.column(self.infoTextColor)
            table.column(self.infoTextSize)
            table.column(self.infoFont)
            table.column(self.pointsType)
        }
        
        do {
            try self.database.run(createBarcodeViewTable)
        } catch {
            print(error)
        }
    }
    
    func createGeneralSearchViewTable()
    {
        let createsGeneralSearchViewTable = self.generalSearchViewTable.create { (table) in
            table.column(self.apk)
            table.column(self.id)
            table.column(self.tintColor)
            table.column(self.itemBackgroundColor)
            table.column(self.itemTextColor)
            table.column(self.itemFont)
            table.column(self.itemTextSize)
            table.column(self.searchTextColor)
            table.column(self.searchFont)
            table.column(self.searchTextSize)
            
            table.primaryKey(self.apk, self.id)
        }
        
        do {
            try self.database.run(createsGeneralSearchViewTable)
        } catch {
            print(error)
        }
    }
    
    func createRadioButtonTable()
    {
        let createRadioButtonTable = self.radioButtonTable.create { (table) in
            table.column(self.id, primaryKey : true)
            table.column(self.apk)
            table.column(self.imageUrl)
            table.column(self.radioButtonName)
            table.column(self.selectedColor)
            table.column(self.nonSelectedColor)
            table.column(self.imageAspectRatio)
            table.column(self.radioButtonNameTextSize)
            table.column(self.nameTextColor)
            table.column(self.nameFont)
            table.column(self.connectionID)
        }
        
        do {
            try self.database.run(createRadioButtonTable)
        } catch {
            print(error)
        }
    }
    
    func createNotAvailableViewTable()
    {
        let createNotAvailableViewTable = self.notAvailableViewTable.create { (table) in
            table.column(self.apk, primaryKey : true)
            table.column(self.backgroundColor)
            table.column(self.messageTextColor)
            table.column(self.messageTextSize)
            table.column(self.messageFont)
            table.column(self.image)
        }
        
        do {
            try self.database.run(createNotAvailableViewTable)
        } catch {
            print(error)
        }
    }
    
    func createNotAvailableImageTable()
    {
        let createNotAvailableImageTable = self.notAvailableImageTable.create { (table) in
            table.column(self.apk, primaryKey : true)
            table.column(self.imageData)
        }
        
        do {
            try self.database.run(createNotAvailableImageTable)
        } catch {
            print(error)
        }
    }
    
    
    func createAPKAuthorParametersTable()
    {
        let createAPKAuthorParametersTable = self.apkAuthorParametersTable.create { (table) in
            table.column(self.apk, primaryKey : true)
            table.column(self.authorNameTextSize)
            table.column(self.authorNameTextColor)
            table.column(self.authorNameFont)
            table.column(self.jobDescriptionTextSize)
            table.column(self.jobDescriptionTextColor)
            table.column(self.jobDescriptionFont)
        }
        
        do {
            try self.database.run(createAPKAuthorParametersTable)
        } catch {
            print(error)
        }
    }
    
    func createAPKAuthorsTable()
    {
        let createAPKAuthorsTable = self.apkAuthorsTable.create { (table) in
            table.column(self.apk)
            table.column(self.emailAddress)
            table.column(self.authorName)
            table.column(self.authorPhotoUrl)
            table.column(self.imageData)
            table.column(self.imageAspectRatio)
            
            table.primaryKey(self.apk,self.emailAddress)
        }
        
        do {
            try self.database.run(createAPKAuthorsTable)
        } catch {
            print(error)
        }
    }
    
    
    func createAuthorTable()
    {
        let createAuthorTable = self.authorTable.create { (table) in
            table.column(self.emailAddress, primaryKey : true)
            table.column(self.jobDescription)
        }
        
        do {
            try self.database.run(createAuthorTable)
        } catch {
            print(error)
        }
    }
    
    func createCheckBoxGroupsTable()
    {
        let createCheckBoxGroupsTable = self.checkBoxGroupsTable.create { (table) in
            table.column(self.id, primaryKey : true)
            table.column(self.apk)
        }
        
        do {
            try self.database.run(createCheckBoxGroupsTable)
        } catch {
            print(error)
        }
    }
    
    func createCheckBoxGroupsItemsTable()
    {
        let createCheckBoxGroupsItemsTable = self.checkBoxGroupsItemsTable.create { (table) in
            table.column(self.id)
            table.column(self.checkBoxID)
            
            table.primaryKey(self.id , self.checkBoxID)
        }
        
        do {
            try self.database.run(createCheckBoxGroupsItemsTable)
        } catch {
            print(error)
        }
    }
    
    func createCheckBoxGroupsRelationsTable()
    {
        let createCheckBoxGroupsRelationsTable = self.checkBoxGroupsRelationsTable.create { (table) in
            table.column(self.firstGroupID)
            table.column(self.secondGroupID)
            table.column(self.validationFailedHeader)
            table.column(self.validationFailedMessage)
            
            table.primaryKey(self.firstGroupID , self.secondGroupID)

        }
        
        do {
            try self.database.run(createCheckBoxGroupsRelationsTable)
        } catch {
            print(error)
        }
    }
    
    
    /// Drop all tables.
    func dropTables()
    {
        objc_sync_enter(lock)
        do
        {
            try self.database.run(self.generalViewsTable.drop())
        }
        catch {}
        
        do
        {
            try self.database.run(self.pdfTable.drop())
        }
        catch {}
        
        do
        {
            try self.database.run(self.textTable.drop())
        }
        catch {}
        
        do
        {
            try self.database.run(self.photoTable.drop())
        }
        catch {}
        
        do
        {
            try self.database.run(self.buttonTable.drop())
        }
        catch {}
        
        do
        {
            try self.database.run(self.titleTable.drop())
        }
        catch {}
        
        do
        {
            try self.database.run(self.carouselTable.drop())
        }
        catch {}
        
        do
        {
            try self.database.run(self.urlTable.drop())
        }
        catch {}
        
        do
        {
            try self.database.run(self.videoTable.drop())
        }
        catch {}
        
        objc_sync_exit(lock)
    }
    
    
    
    /*********************************************************                  INSERTS                  *********************************************************/
    
    
    /// Insert general view.
    ///
    /// - Parameter view: The general view to be added.
    func insertView(view : GeneralViewModel!)
    {
        while(waitingForGettingImage)
        {
            
        }
        
        objc_sync_enter(lock)
        if(view != nil)
        {
            do {
                let insertGeneralview = self.generalViewsTable.insert(or: .replace,
                                                                      self.apk <- view.apk,
                                                                      self.index <- view.index,
                                                                      self.type <- view.type,
                                                                      self.id <- view.id,
                                                                      self.tabID <- view.tabID,
                                                                      self.startDate <- view.startDate,
                                                                      self.endDate <- view.endDate)
                
                try self.database.run(insertGeneralview)
                print("General view added")
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    func insertBlogView(blogView : BlogModel)
    {
        objc_sync_enter(lock)
        do
        {
            if(blogView != nil)
            {
                let insertBlogView = self.blogViewTable.insert(or: .replace,
                                                                  self.apk <- APK,
                                                                  self.tabID <- blogView.tabID,
                                                                  self.url <-  blogView.image,
                                                                  self.title <-  blogView.title,
                                                                  self.titleFontNull <- correctFontString(s: blogView.titleFont),
                                                                  self.titleTextSizeNull <-  blogView.titleSize,
                                                                  self.titleTextColorNull <-  blogView.titleColor,
                                                                  self.imageAspectRatio <-  blogView.imageAspectRatio,
                                                                  self.imageData <-  blogView.imageData)
                
                try self.database.run(insertBlogView)
                print("blog view added")
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertBlogViewArticles(blogViewArticles : [BlogViewArticleModel])
    {
        objc_sync_enter(lock)
        do
        {
            var flag = false
            if(blogViewArticles != nil)
            {
                for a in blogViewArticles
                {
                    let insertBlogViewArticle = self.blogViewArticlesTable.insert(or: .replace,
                                                                                  self.apk <- APK,
                                                                                  self.tabID <- a.tabID,
                                                                                  self.articleID <- a.articleID)
                    
                    do
                    {
                        try self.database.run(insertBlogViewArticle)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    print("article added")
                    
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertArticleItems(articleItems : [ArticleItemModel])
    {
        objc_sync_enter(lock)
        do
        {
            if(articleItems != nil)
            {
                for a in articleItems
                {
                    let insertArticle = self.articleItemsTable.insert(or: .replace,
                                                                      self.articleID <- a.articleID,
                                                                      self.index <- a.index,
                                                                      self.type <- a.type,
                                                                      self.id <- a.id,
                                                                      self.productItemCode <- a.productItemCode)
                    
                    do
                    {
                        try self.database.run(insertArticle)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    print("article item added")
                    
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertArticle(article : ArticleModel)
    {
        while(waitingForGettingImage)
        {
            
        }
        
        objc_sync_enter(lock)
        do
        {
            if(article != nil)
            {
                let insertArticle = self.articleTable.insert(or: .replace,
                                                             self.articleID <- article.id,
                                                             self.image <- article.image,
                                                             self.title <- article.title,
                                                             self.categoryID <- article.categoryID,
                                                             self.url <- article.url,
                                                             self.titleFont <- correctFontString(s: article.titleFont),
                                                             self.titleSize <- article.titleSize,
                                                             self.titleColor <- article.titleColor,
                                                             self.categoryFont <- correctFontString(s: article.categoryFont),
                                                             self.categoryTextSize <- article.categorySize,
                                                             self.categoryTextColor <- article.categoryColor,
                                                             self.publishDate <- article.publishDate, //String(article.publishDate.split(separator: " ")[0]),
                                                             self.expirationdDate <- article.expirationDate,
                                                            //isNullOrEmpty(string: article.expirationDate) ? article.expirationDate : String(article.expirationDate.split(separator: " ")[0]),
                                                             self.dateFont <- correctFontString(s: article.dateFont),
                                                             self.dateTextSize <- article.dateTextSize,
                                                             self.dateTextColor <- article.dateTextColor,
                                                             self.authorEmailAddress <- article.authorEmailAddress,
                                                             self.aspectRatio <- article.imageAspectRatio,
                                                             self.imageData <- article.imageData)
                
                do
                {
                    try self.database.run(insertArticle)
                }
                catch
                {
                    print(error)
                }
                
                print("article added")
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertArticlesCategories(articlesCategories : [ArticleCategoryModel])
    {
        objc_sync_enter(lock)
        do
        {
            if(articlesCategories != nil)
            {
                for c in articlesCategories
                {
                    let insertArticleCategory = self.articleCategoriesTable.insert(or: .replace,
                                                                                   self.id <- c.id,
                                                                                   self.name <- c.name)
                    
                    try self.database.run(insertArticleCategory)
                }
                
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertSeenArticle(articleID : Int64)
    {
        objc_sync_enter(lock)
        do
        {
            let insertSeenArticle = self.seenArticlesTable.insert(or: .replace,
                                                                  self.apk <- APK,
                                                                  self.articleID <- articleID)
            
            try self.database.run(insertSeenArticle)
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }

    /// Insert pdf.
    ///
    /// - Parameters:
    ///   - id: The id of pdf.
    ///   - pdf: The model of pdf.
    func insertPDF(id : Int, pdf : PDFModel!)
    {
        while(waitingForGettingImage)
        {
            
        }
        objc_sync_enter(lock)
        if(pdf != nil)
        {
            do {
                let insertPDF = self.pdfTable.insert(or: .replace,
                                                     self.id <-  id,
                                                     self.url <- pdf.pdfUrl,
                                                     self.numOfPages <- pdf.numOfPages)
                
                try self.database.run(insertPDF)
                print("PDF added")
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    /// Insert text.
    ///
    /// - Parameters:
    ///   - id: The id of text.
    ///   - text: The model of text.
    func insertText(id : Int , text : TextModel!)
    {
        while(waitingForGettingImage)
        {
            
        }
        
        objc_sync_enter(lock)
        if(text != nil)
        {
            do {
                let insertPDF = self.textTable.insert(or: .replace,
                                                      self.id <-  id,
                                                      self.title <- text.title,
                                                      self.textDescription <- text.description,
                                                      self.titleFont <- correctFontString(s: text.titleFont),
                                                      self.titleSize <- text.titleSize,
                                                      self.titleColor <- text.titleColor,
                                                      self.descriptionFont <- correctFontString(s: text.descriptionFont),
                                                      self.descriptionSize <- text.descriptionSize,
                                                      self.descriptionColor <- text.descriptionColor,
                                                      self.splitterColor <- text.splitterColor,
                                                      self.backgroundColor <- text.backgroundColor,
                                                      self.isTitleCentered <- text.isTitleCentered,
                                                      self.descriptionAlignmentType <- text.descriptionAlignmentType!.rawValue)
                
                try self.database.run(insertPDF)
                print("Text added")
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    /// Insert photo.
    ///
    /// - Parameters:
    ///   - id: The id of photo.
    ///   - photo: The model of photo.
    func insertPhoto(id : Int, photo : PhotoModel!, isStore : Bool = false)
    {
        while(waitingForGettingImage)
        {
            
        }
        objc_sync_enter(lock)
        if(photo != nil)
        {
            do {
                
                if(photo.aspectRatio == nil)
                {
                    photo.aspectRatio = calculateImageAspectRatio(imageUrl: photo.imageUrl)
                    
                    /*if(!isStore)
                    {
                        self.waitForNavImageToDownloaded = true
                        
                        self.downloadImage(url: photo.imageUrl)
                        
                        while(self.waitForNavImageToDownloaded)
                        {
                            
                        }
                    }
                    else
                    {
                        storesDB.waitForNavImageToDownloaded = true
                        
                        storesDB.downloadImage(url: photo.imageUrl)
                        
                        while(storesDB.waitForNavImageToDownloaded)
                        {
                            
                        }
                    }*/
                    
                }
                
                
                
                let insertImage = self.photoTable.insert(or: .replace,
                                                         self.id <- id,
                                                         self.url <- photo.imageUrl,
                                                         self.link <- photo.link,
                                                         self.aspectRatio <- photo.aspectRatio == nil ? 0 : photo.aspectRatio,
                                                         self.button <- photo.button != nil ? photo.button.id : nil,
                                                         self.photoTitle <- photo.title != nil ? photo.title.id : nil)
                
                try self.database.run(insertImage)
                
                if(photo.button != nil && photo.button.id != nil)
                {
                    insertButton(id : photo.button.id, button : photo.button)
                }
                
                if(photo.title != nil && photo.title.id != nil)
                {
                    insertTitle(id: photo.title.id, title: photo.title)
                }
                
                print("\(photo.imageUrl) Photo added")
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    /// Insert button.
    ///
    /// - Parameters:
    ///   - id: The id of button.
    ///   - button: The model of button.
    func insertButton(id: Int, button : ButtonModel!)
    {
        while(waitingForGettingImage)
        {
            
        }
        objc_sync_enter(lock)
        if(button != nil)
        {
            do {
                let insertButton = self.buttonTable.insert(or: .replace,
                                                           self.id <- id,
                                                           self.name <- button.name,
                                                           self.height <- button.height,
                                                           self.width <- button.width,
                                                           self.backgroundColor <- button.backgroundColor,
                                                           self.font <- correctFontString(s: button.font),
                                                           self.nameTextSize <- button.textSize,
                                                           self.textColor <- button.textColor,
                                                           self.url <- button.imageUrl,
                                                           self.borderWidth <- button.borderWidth,
                                                           self.borderColor <- button.borderColor,
                                                           self.tabID <- button.tabID == nil ? -1 : button.tabID,
                                                           self.buttonPosition <- button.buttonPosition,
                                                           self.link <- button.link,
                                                           self.cornerRadius <- button.cornerRadius)
                
                try self.database.run(insertButton)
                print("Button added")
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    /// Insert title.
    ///
    /// - Parameters:
    ///   - id: The id of title.
    ///   - title: The model of title.
    func insertTitle(id: Int, title : TitleModel!)
    {
        while(waitingForGettingImage)
        {
            
        }
        objc_sync_enter(lock)
        if(title != nil)
        {
            do {
                let insertTitle = self.titleTable.insert(or: .replace,
                                                         self.id <- id,
                                                         self.title <- title.title == nil ? "" : title.title,
                                                         self.titleFont <- correctFontString( s: title.titleFont),
                                                         self.titleSize <- title.titleSize,
                                                         self.titleColor <- title.titleColor,
                                                         self.splitterColor <- title.splitterColor,
                                                         self.backgroundColor <- title.titleBackgroundColor,
                                                         self.isTitleCentered <- title.isTitleCentered,
                                                         self.topPadding <- title.topPadding,
                                                         self.isSection <- title.isSection,
                                                         self.isSectionExpanded <- title.isSectionExpanded)
                
                try self.database.run(insertTitle)
                print("Title added")
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    /// Insert carousel.
    ///
    /// - Parameters:
    ///   - id: The id of carousel.
    ///   - carousel: The model of carousel.
    func insertCarousel(id: Int, carousel : CarouselModel!, isStore : Bool! = false)
    {
        while(waitingForGettingImage)
        {
            
        }
        
        objc_sync_enter(lock)
        if(carousel != nil)
        {
            do {
                let insertCarousel = self.carouselTable.insert(or: .replace,
                                                               self.id <- id,
                                                               self.hasTitles <- carousel.hasTitles == nil ? false :  carousel.hasTitles,
                                                               self.interval <- carousel.interval,
                                                               self.isManual <- carousel.isManual,
                                                               self.isAutomatic <- carousel.isAutomatic,
                                                               self.isScrollingEnabled <- carousel.isScrollingEnabled,
                                                               self.titleSize <- carousel.titleSize)
                
                insertUrls(urls: carousel.urls, carouselID: id, isStore: isStore)
                
                try self.database.run(insertCarousel)
                print("Carousel added")
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    /// Insert urls for carousel.
    ///
    /// - Parameters:
    ///   - urls: The urls.
    ///   - carouselID: The id of carousel.
    func insertUrls(urls : [UrlModel]!, carouselID : Int, isStore : Bool = false)
    {
        while(waitingForGettingImage)
        {
            
        }
        objc_sync_enter(lock)
        if (urls != nil && urls.count > 0)
        {
            var isTheFirst = true
            for u in urls
            {
                do {
                    //let url = URL(string: u.url)!
                    //let imageView = UIImageView()
                    //imageView.kf.setImage(with: url)
                    
                    var insertUrl : Insert!
                    
                    //let url = URL(string: percentEncode(s: u.url))
                    
                    /*if(!isStore)
                    {
                        self.waitForNavImageToDownloaded = true
                        self.downloadImage(url: u.url!)
                        
                        while(self.waitForNavImageToDownloaded)
                        {
                            
                        }
                    }
                    else
                    {
                        storesDB.waitForNavImageToDownloaded = true
                        storesDB.downloadImage(url: u.url!)
                        
                        while(storesDB.waitForNavImageToDownloaded)
                        {
                            
                        }
                    }*/
                    
                    if(isTheFirst)
                    {
                        insertUrl = self.urlTable.insert(or: .replace,
                                                             self.id <- u.id,
                                                             self.carouselID <- carouselID,
                                                             self.url <- u.url,
                                                             self.urlTitle <- u.title != nil ? u.title.id : nil,
                                                             self.aspectRatio <- calculateImageAspectRatio(imageUrl: (u.url)!))
                        isTheFirst = false
                    }
                    else
                    {
                        insertUrl = self.urlTable.insert(or: .replace,
                                                             self.id <- u.id,
                                                             self.carouselID <- carouselID,
                                                             self.url <- u.url,
                                                             self.urlTitle <- u.title != nil ? u.title.id : nil)
                    }
                    
                    if(u.title != nil && u.title.id != nil)
                    {
                        insertTitle(id: u.title.id, title: u.title)
                    }
                    
                    try self.database.run(insertUrl)
                    print("Url added")
                }
                catch
                {
                    print(error)
                }
            }
        }
        objc_sync_exit(lock)
    }
    
    /// Insert video.
    ///
    /// - Parameters:
    ///   - id: The id of video.
    ///   - video: The model of video.
    func insertVideo(id : Int, video : VideoModel!)
    {
        while(waitingForGettingImage)
        {
            
        }
        
        objc_sync_enter(lock)
        if (video != nil)
        {
            do {
                let insertVideo = self.videoTable.insert(or: .replace,
                                                         self.id <-  id,
                                                         self.url <- video.videoUrl,
                                                         self.autoPlay <- video.autoPlay,
                                                         self.alternativePhoto <- video.alternativePhoto,
                                                         self.aspectRatio <- video.alternativePhotoAspectRatio)
                
                try self.database.run(insertVideo)
                print("Video added")
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    func insertSwitch(id : Int, switchModel : SwitchModel!)
    {
        objc_sync_enter(lock)
        if (switchModel != nil)
        {
            do {
                let insertSwitch = self.switchTable.insert(or: .replace,
                                                         self.id <-  id,
                                                         self.title <- switchModel.title,
                                                         self.textDescription <- switchModel.description,
                                                         self.fieldStyleID <- switchModel.fieldStyleID,
                                                         self.acceptType <- switchModel.acceptType)
                
                try self.database.run(insertSwitch)
                print("Switch added")
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    /// Insert button.
    ///
    /// - Parameters:
    ///   - id: The id of button.
    ///   - button: The model of button.
    func insertCheckBox(id: Int, checkBox : CheckBoxModel!)
    {
        while(waitingForGettingImage)
        {
            
        }
        
        objc_sync_enter(lock)
        if(checkBox != nil)
        {
            do {
                let insertCheckBox = self.checkBoxTable.insert(or: .replace,
                                                             self.id <- id,
                                                             self.text <- checkBox.text,
                                                             self.textColor <- checkBox.textColor,
                                                             self.textSize <- checkBox.textSize,
                                                             self.font <- correctFontString(s: checkBox.textFont),
                                                             self.isRequired <- checkBox.isRequired,
                                                             self.tintColor <- checkBox.tintColor,
                                                             self.link <- checkBox.link,
                                                             self.imageUrl <- checkBox.imageUrl,
                                                             self.imageDataNullable <- checkBox.imageData,
                                                             self.imageAspectRatio <- checkBox.imageAspectRatio,
                                                             self.alignment <- checkBox.alignment,
                                                             self.isCheckBoxOnTheLeft <- checkBox.isCheckBoxOnTheLeft,
                                                             self.isCheckBoxNearText <- checkBox.isCheckBoxNearText,
                                                             self.isChecked <- checkBox.isChecked,
                                                             self.cbConnectionID <- checkBox.connectionID,
                                                             self.imageWidthPercentage <- checkBox.imageWidthPercentage)
                
                try self.database.run(insertCheckBox)
                print("CheckBox added")
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    func setCheckBoxesCheckedFlag(checkBoxes : [CheckBoxModel])
    {
        objc_sync_enter(lock)
        if(checkBoxes != nil)
        {
            do {
                for checkBox in checkBoxes
                {
                    let checkBoxRow = checkBoxTable.filter(id == checkBox.id)
                    try self.database.run(checkBoxRow.update(isChecked <- checkBox.isChecked))
                }
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    func setCheckBoxCheckedFlag(checkBox : CheckBoxModel)
    {
        objc_sync_enter(lock)
        if(checkBox != nil)
        {
            do {
                let checkBoxRow = checkBoxTable.filter(id == checkBox.id)
                try self.database.run(checkBoxRow.update(isChecked <- checkBox.isChecked))
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    /// Insert expandable list views.
    ///
    /// - Parameter expandableListView: The expandable list views.
    func insertExpandableListView(expandableListView : [ExpandableListModel]!)
    {
        while(waitingForGettingImage)
        {
            
        }
        objc_sync_enter(lock)
        if (expandableListView != nil && expandableListView.count > 0)
        {
            do {
                for e in expandableListView
                {
                    let insertExpandableListView = self.expanableListViewTable.insert(or: .replace,
                                                                                      self.id <-  e.id,
                                                                                      self.apk <- e.apk,
                                                                                      self.tabID <- e.tabID)
                    
                    do {
                        try self.database.run(insertExpandableListView)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    print("Expandable list view added")
                }
                
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    
    /// Insert expandavle list parents.
    ///
    /// - Parameter expandableListParents: The expandable list parents.
    func insertExpandableListParents(expandableListParents : [ExpandableListParentModel]!)
    {
        while(waitingForGettingImage)
        {
            
        }
        objc_sync_enter(lock)
        if (expandableListParents != nil && expandableListParents.count > 0)
        {
            do {
                for e in expandableListParents
                {
                    let expandableListParentsTemp = try self.database.prepare(self.expanableListParentsTable.filter(self.id == e.id))
                    
                    for et in expandableListParentsTemp {
                        if(!isNullOrEmpty(string: et[self.backgroundImage]) && et[self.backgroundImage] != e.backgroundImage)
                        {
                            self.deleteImage(url:  et[self.backgroundImage]!)
                        }
                        
                        if(!isNullOrEmpty(string: et[self.image]) && et[self.image] != e.image)
                        {
                            self.deleteImage(url:  et[self.image]!)
                        }
                    }
                    
                    /*if(!isNullOrEmpty(string: e.backgroundImage))
                    {
                        e.aspectRatio = calculateImageAspectRatio(imageUrl: e.backgroundImage)
                        
                        self.waitForNavImageToDownloaded = true
                        self.downloadImage(url: e.backgroundImage)
    
                        while(self.waitForNavImageToDownloaded)
                        {
                            
                        }
                    }
                    
                    if(!isNullOrEmpty(string: e.image))
                    {
                        self.waitForNavImageToDownloaded = true
                        self.downloadImage(url: e.image)
                        
                        while(self.waitForNavImageToDownloaded)
                        {
                            
                        }
                    }*/
                    
                    let insertExpandableListParent = self.expanableListParentsTable.insert(or: .replace,
                                                                                           self.expandableListViewID <-  e.expandableListViewID,
                                                                                           self.id <- e.id,
                                                                                           self.type <- e.type,
                                                                                           self.backgroundColor <- e.backgroundColor,
                                                                                           self.font <- correctFontString(s: e.font),
                                                                                           self.nameTextSize <- e.textSize,
                                                                                           self.textColor <- e.textColor,
                                                                                           self.tintColor <- e.tintColor,
                                                                                           self.image <- e.image,
                                                                                           self.name <- e.name,
                                                                                           self.hasAlternatingStyles <- e.hasAlternatingStyles,
                                                                                           self.firstStyle <- e.firstStyle == nil ? nil : e.firstStyle.id,
                                                                                           self.secondStyle <- e.secondStyle == nil ? nil : e.secondStyle.id,
                                                                                           self.backgroundImage <- e.backgroundImage,
                                                                                           self.aspectRatio <- e.aspectRatio,
                                                                                           self.labelPosition <- e.labelPosition,
                                                                                           self.labelBackgroundColor <- e.labelBackgroundColor,
                                                                                           self.labelWidth <- e.labelWidth,
                                                                                           self.labelHeight <- e.labelHeight)
                    
                    if(e.firstStyle != nil)
                    {
                        insertExpandableListChildStyle(expandableListChildStyle: e.firstStyle)
                    }
                    
                    if(e.secondStyle != nil)
                    {
                        insertExpandableListChildStyle(expandableListChildStyle: e.secondStyle)
                    }
                    
                    do {
                        try self.database.run(insertExpandableListParent)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    print("Expandable list parent added")
                }
                
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    
    /// Insert expandable list child style.
    ///
    /// - Parameter expandableListChildStyle: The expandable list chidl style.
    func insertExpandableListChildStyle(expandableListChildStyle : StyleModel!)
    {
        while(waitingForGettingImage)
        {
            
        }
        objc_sync_enter(lock)
        if(expandableListChildStyle != nil)
        {
            do {
                let insertExpandableListChildStyle = self.expandableListChildStyles.insert(or: .replace, self.id <- expandableListChildStyle.id,
                                                                                       self.backgroundColor <- expandableListChildStyle.backgroundColor,
                                                                                       self.font <- correctFontString(s: expandableListChildStyle.font),
                                                                                       self.nameTextSize <- expandableListChildStyle.textSize,
                                                                                       self.textColor <- expandableListChildStyle.textColor,
                                                                                       self.tintColor <- expandableListChildStyle.tintColor)
                
                try self.database.run(insertExpandableListChildStyle)
                print("Expandable list child style added")
                
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    
    /// Insert embeded general views.
    ///
    /// - Parameter embededGeneralViews: The embeded general views.
    func insertEmbededGeneralViews(embededGeneralViews : [EmbededGeneralViewModel]!)
    {
        while(waitingForGettingImage)
        {
            
        }
        
        
        if(embededGeneralViews != nil)
        {
            do
            {
                for e in embededGeneralViews
                {
                    objc_sync_enter(lock)
                    let insertEmbededGeneralView = self.embededGeneralViewTable.insert(or: .replace,
                                                                                       self.apk <- APK,
                                                                                       self.id <- e.id,
                                                                                       self.type <- e.type,
                                                                                       self.index <- e.index,
                                                                                       self.slotID <- e.slotID,
                                                                                       self.infoType <- e.infoType)
                    
                    do
                    {
                        try self.database.run(insertEmbededGeneralView)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    objc_sync_exit(lock)
                    print("Embeded View Added")
                    if(e.slotID != 0)
                    {
                        switch (e.type)
                        {
                        case SlotType.PDF.rawValue:
                            do
                            {
                                let yourURL = NSURL(string: percentEncode(s:e.pdf.pdfUrl))
                                //Create a URL request
                                let urlRequest = NSURLRequest(url: yourURL! as URL)
                                //get the data
                                let theData = try NSURLConnection.sendSynchronousRequest(urlRequest as URLRequest, returning: nil)
                                
                                //Get the local docs directory and append your local filename.
                                var docURL = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)).last as NSURL?
                                
                                print("\(APK)\(e.index!)\(e.slotID!).pdf")
                                docURL = docURL?.appendingPathComponent( "\(APK.replacingOccurrences(of: ".", with: ""))\(e.index!)\(e.slotID!).pdf") as NSURL?
                                
                                //Lastly, write your file to the disk.
                                try theData.write(to: docURL! as URL,options : Data.WritingOptions.atomic )
                                
                                let url : NSURL! = NSURL(string: percentEncode(s: e.pdf.pdfUrl))
                                
                                /*let pdf = Bundle.main.url(forResource: "myFileName", withExtension: "pdf", subdirectory: nil, localization: nil)
                                 let req = NSURLRequest(url: pdf!)*/
                                
                                if(url != nil)
                                {
                                    APKChanger.webView.loadRequest(NSURLRequest(url: url as URL) as URLRequest)
                                    //webView.delegate = self
                                }
                                
                                viewsDB.insertPDF(id: e.slotID, pdf: e.pdf)
                            }
                            catch
                            {
                                print(error)
                            }
                            break
                        case SlotType.Text.rawValue:
                            viewsDB.insertText(id: e.slotID, text: e.text)
                            break
                        case SlotType.Photo.rawValue:
                            if(e.photo != nil)
                            {
                                e.photo.aspectRatio = calculateImageAspectRatio(imageUrl: e.photo.imageUrl)
                                cacheImage(url: e.photo.imageUrl)
                                viewsDB.insertPhoto(id: e.slotID, photo: e.photo)
                            }
                            /*let url = URL(string: g.photo.imageUrl)!
                             let imageView = UIImageView()
                             imageView.kf.setImage(with: url)*/
                            break
                        case SlotType.Carousel.rawValue:
                            viewsDB.insertCarousel(id: e.slotID, carousel: e.carousel)
                            break
                        case SlotType.Video.rawValue:
                            e.video.alternativePhotoAspectRatio = calculateImageAspectRatio(imageUrl: e.video.alternativePhoto)
                            downloadImage(url: e.video.alternativePhoto)
                            
                            /*let url = URL(string: g.video.alternativePhoto)!
                             let imageView = UIImageView()
                             imageView.kf.setImage(with: url)*/
                            
                            viewsDB.insertVideo(id: e.slotID, video: e.video)
                            //viewsDB.insertPhoto(id: g.video.alternativePhotoID, photo: g.video.alternativePhoto)
                            break
                        case SlotType.Title.rawValue:
                            viewsDB.insertTitle(id: e.slotID, title: e.title)
                            break
                        default :
                            break
                        }
                        
                    }
                }
            }
            catch
            {
                print(error)
            }
        }
        
        objc_sync_exit(lock)
    }
    
    
    /// Inesrt embeded views parameters.
    ///
    /// - Parameter embededViewsParameters: The embeded view parameters.
    func insertEmbededViewsParameters( embededViewsParameters : [EmbededViewParametersModel]!)
    {
        while(waitingForGettingImage)
        {
            
        }
        objc_sync_enter(lock)
        if(embededViewsParameters != nil)
        {
            do
            {
                for e in embededViewsParameters
                {
                    let insertEmbededViewParameters = self.embededViewParametersTable.insert(or: .replace,
                                                                                             self.apk <- APK,
                                                                                             self.embededViewID <- e.embededViewID,
                                                                                             self.separatorHeight <- e.separatorHeight,
                                                                                             self.separatorColor <- e.separatorColor,
                                                                                             self.borderSize <- e.borderSize,
                                                                                             self.borderColor <- e.borderColor)
                    do
                    {
                        try self.database.run(insertEmbededViewParameters)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    print("Embeded View Parameters Added")
                }
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    
    /// Insert store locator info parameters.
    ///
    /// - Parameter storeLocatorInfoParameters: The store locator info paramaters.
    func insertStoreLocatorInfoParameters(storeLocatorInfoParameters : StoreLocatorInfoParametersModel!)
    {
        while(waitingForGettingImage)
        {
            
        }
        objc_sync_enter(lock)
        if(storeLocatorInfoParameters != nil)
        {
            do
            {
                let insertStoreLocatorInfo = self.storeLocatorInfoParametersTable.insert(or: .replace,
                                                                                         self.apk <- APK,
                                                                                         self.font <- correctFontString(s: storeLocatorInfoParameters.textFont) ,
                                                                                         self.sizeOfText <- storeLocatorInfoParameters.sizeOfText,
                                                                                         self.textColor <- storeLocatorInfoParameters.textColor,
                                                                                         self.tintColor <- storeLocatorInfoParameters.tintColor,
                                                                                         self.borderSize <- storeLocatorInfoParameters.borderSize == nil ? 0 : storeLocatorInfoParameters.borderSize,
                                                                                         self.borderColor <- storeLocatorInfoParameters.borderColor,
                                                                                         self.titleBackgroundColor <- storeLocatorInfoParameters.titleBackgroundColor,
                                                                                         self.titleTextSize <- storeLocatorInfoParameters.titleTextSize,
                                                                                         self.titleTextColor <- storeLocatorInfoParameters.titleTextColor,
                                                                                         self.titleFont <- correctFontString(s: storeLocatorInfoParameters.titleFont))
                
                try self.database.run(insertStoreLocatorInfo)
                print("Store locator info parameters added")
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    
    /// Insert contact us tab relations.
    ///
    /// - Parameter contactUsTabRelations: The contact us tab relations.
    func insertContactUsTabRelations(contactUsTabRelations : [ContactUsTabRelation]!)
    {
        objc_sync_enter(lock)
        if(contactUsTabRelations != nil)
        {
            do
            {
                for c in contactUsTabRelations
                {
                    let insertContactUsTabRelations = self.contactUsTabsRelationsTable.insert(or: .replace,
                                                                                              self.apk <- APK,
                                                                                              self.tabID <- c.tabID,
                                                                                              self.contactUsViewID <- c.contactUsViewID)
                    do
                    {
                        try self.database.run(insertContactUsTabRelations)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    print("Contact us - Tab relation added")
                }
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    
    /// Insert contact us view.
    ///
    /// - Parameter contactUsView: The contact us view.
    func insertContactUsView(contactUsView : [ContactUsModel]!)
    {
        objc_sync_enter(lock)
        if(contactUsView != nil)
        {
            do
            {
                for c in contactUsView
                {
                    let jsonEncoder = JSONEncoder()
                    
                    let types = StringTable()
                    let infos = StringTable()
                    
                    for t in c.types
                    {
                        types.strings.append(t)
                    }
                    
                    for i in c.info
                    {
                        infos.strings.append(i.info)
                        infos.types.append(i.type)
                    }
                    
                    let jsonTypes = try jsonEncoder.encode(types)
                    let jsonInfo = try jsonEncoder.encode(infos)
                    
                    let insertContactUsView = self.contactUsViewTable.insert(or: .replace,
                                                                             self.id <- c.id,
                                                                             self.apk <- APK,
                                                                             self.types <- jsonTypes,
                                                                             self.info <- jsonInfo,
                                                                             self.typeTitle <- c.typeTitle,
                                                                             self.typeFont <- correctFontString(s: c.typeFont),
                                                                             self.typeTextSize <- c.typeTextSize,
                                                                             self.typeTextColor <- c.typeTextColor,
                                                                             self.tintColor <- c.tintColor,
                                                                             self.messageTitle <- c.messageTitle,
                                                                             self.messageFont <- correctFontString(s: c.messageFont),
                                                                             self.messageTextSize <- c.messageTextSize,
                                                                             self.messageTextColor <- c.messageTextColor,
                                                                             self.infoFont <- correctFontString(s:c.infoFont),
                                                                             self.infoTextSize <- c.infoTextSize,
                                                                             self.infoTextColor <- c.infoTextColor,
                                                                             self.buttonText <- c.buttonText,
                                                                             self.buttonBackgroundColor <- c.buttonBackgroundColor,
                                                                             self.buttonFont <- correctFontString(s: c.buttonFont),
                                                                             self.buttonTextSize <- c.buttonTextSize,
                                                                             self.buttonTextColor <- c.buttonTextColor,
                                                                             self.buttonBorderWidth <- c.buttonBorderWidth,
                                                                             self.buttonBorderColor <- c.buttonBorderColor)
                    do
                    {
                        try self.database.run(insertContactUsView)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    print("Contact us view added")
                }
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    
    /// Insert barcode view.
    ///
    /// - Parameter barcodeView: The barcode view.
    func insertBarcodeView(barcodeView : BarcodeModel2!)
    {
        objc_sync_enter(lock)
        if(barcodeView != nil)
        {
            do
            {
                let insertBarcodeView = self.barcodeViewTable.insert(or: .replace,
                                                                     self.apk <- APK,
                                                                     self.prototype <- barcodeView.prototype,
                                                                     self.backgroundColor <- barcodeView.backgroundColor,
                                                                     self.pointsTextColor <- barcodeView.pointsTextColor,
                                                                     self.pointsTextSize <- barcodeView.pointsTextSize,
                                                                     self.pointsFont <- correctFontString(s: barcodeView.pointsFont) ,
                                                                     self.infoTextColor <- barcodeView.infoTextColor,
                                                                     self.infoTextSize <- barcodeView.infoTextSize,
                                                                     self.infoFont <- correctFontString(s: barcodeView.infoFont),
                                                                     self.pointsType <- barcodeView.pointsType)
                
                try self.database.run(insertBarcodeView)
                print("Barcode view added")                
            }
            catch
            {
                print(error)
            }
        }
        objc_sync_exit(lock)
    }
    
    func insertGeneralSearchViews(generalSearchViews : [GeneralSearchView]!)
    {
        objc_sync_enter(lock)
        do
        {
            if(generalSearchViews != nil)
            {
                for g in generalSearchViews
                {
                    let insertGeneralSearchViews = self.generalSearchViewTable.insert(or: .replace,
                                                                                      self.apk <- APK,
                                                                                      self.id <- g.id,
                                                                                      self.tintColor <- g.tintColor,
                                                                                      self.itemBackgroundColor <- g.itemBackgroundColor,
                                                                                      self.itemTextColor <- g.itemTextColor,
                                                                                      self.itemFont <- correctFontString(s: g.itemFont),
                                                                                      self.itemTextSize <- g.itemTextSize,
                                                                                      self.searchTextColor <- g.searchTextColor,
                                                                                      self.searchFont <- correctFontString(s: g.searchFont),
                                                                                      self.searchTextSize <- g.searchTextSize)
                    do
                    {
                        try self.database.run(insertGeneralSearchViews)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    print("General search view added")
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertRadioButton(radioButton : RadioButtonModel! )
    {
        while(waitingForGettingImage)
        {
            
        }
        
        objc_sync_enter(lock)
        do
        {
            if(radioButton != nil)
            {
                if(radioButton.name == nil && radioButton.imageUrl != nil)
                {
                    radioButton.imageAspectRatio = calculateImageAspectRatio(imageUrl: percentEncode(s: radioButton.imageUrl))
                    
                    /*self.waitForNavImageToDownloaded = true
                    self.downloadImage(url: radioButton.imageUrl)
                    
                    while(self.waitForNavImageToDownloaded)
                    {
                        
                    }*/
                    
                    let insertRadioButton = self.radioButtonTable.insert(or: .replace,
                                                                         self.id <- radioButton.id,
                                                                         self.apk <- APK,
                                                                         self.imageUrl <- radioButton.imageUrl,
                                                                         self.radioButtonName <- radioButton.name,
                                                                         self.selectedColor <- radioButton.selectedColor,
                                                                         self.nonSelectedColor <- radioButton.nonSelectedColor,
                                                                         self.imageAspectRatio <- radioButton.imageAspectRatio,
                                                                         self.radioButtonNameTextSize <- radioButton.nameTextSize,
                                                                         self.nameTextColor <- radioButton.nameTextColor,
                                                                         self.nameFont <- correctFontString(s: radioButton.nameFont),
                                                                         self.connectionID <- radioButton.connectionID)
                    
                    do
                    {
                        try self.database.run(insertRadioButton)
                    }
                    catch
                    {
                        
                    }
                    
                    print("Radio button added")
                }
                else
                {
                    let insertRadioButton = self.radioButtonTable.insert(or: .replace,
                                                                    self.id <- radioButton.id,
                                                                    self.apk <- APK,
                                                                    self.imageUrl <- radioButton.imageUrl,
                                                                    self.radioButtonName <- radioButton.name,
                                                                    self.selectedColor <- radioButton.selectedColor,
                                                                    self.nonSelectedColor <- radioButton.nonSelectedColor,
                                                                    self.radioButtonNameTextSize <- radioButton.nameTextSize,
                                                                    self.nameTextColor <- radioButton.nameTextColor,
                                                                    self.nameFont <- correctFontString(s: radioButton.nameFont),
                                                                    self.connectionID <- radioButton.connectionID)
                    
                    
                    try self.database.run(insertRadioButton)
                    print("Radio button added")
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertNotAvailableView(notAvailableView : NotAvailableModel!) throws
    {
        objc_sync_enter(lock)
        do
        {
            if(notAvailableView != nil)
            {
                if(!isNullOrEmpty(string: notAvailableView.image))
                {
                    let imageData = ImageDownloader.downloadImage(url: notAvailableView.image)
                    
                    try self.database.run(self.notAvailableImageTable.insert(or: .replace,
                                                                             self.apk <- APK,
                                                                             self.imageData <- imageData != nil ? imageData! : Data()))
                }
                
                let insertNotAvailableView = self.notAvailableViewTable.insert(or: .replace,
                                                                               self.apk <- APK,
                                                                               self.backgroundColor <- notAvailableView.backgroundColor,
                                                                               self.messageTextColor <- notAvailableView.messageTextColor,
                                                                               self.messageTextSize <- notAvailableView.messageTextSize,
                                                                               self.messageFont <- correctFontString(s: notAvailableView.messageFont),
                                                                               self.image <- notAvailableView.image)
                
                try self.database.run(insertNotAvailableView)
                print("Not available view added")
            }
        }
        objc_sync_exit(lock)
    }

    
    func insertAuthorsParameters(authorsParameters : BlogAuthors)
    {
        objc_sync_enter(lock)
        do
        {
            if(authorsParameters != nil)
            {
                
                let insertAuthorsParamaters = self.apkAuthorParametersTable.insert(or: .replace,
                                                                                   self.apk <- APK,
                                                                                   self.authorNameTextSize <- authorsParameters.nameTextSize,
                                                                                   self.authorNameTextColor <- authorsParameters.nameTextColor,
                                                                                   self.authorNameFont <- correctFontString(s: authorsParameters.nameFont),
                                                                                   self.jobDescriptionTextSize <- authorsParameters.jobDescriptionTextSize,
                                                                                   self.jobDescriptionTextColor <- authorsParameters.jobDescriptionTextColor,
                                                                                   self.jobDescriptionFont <- correctFontString(s: authorsParameters.jobDescriptionFont))
                do
                {
                    try self.database.run(insertAuthorsParamaters)
                }
                catch
                {
                    print(error)
                }
                
                print("Author added")
            }
            
            if(authorsParameters.authorsList != nil)
            {
                
                
                for a in authorsParameters.authorsList
                {
                    let insertAuthor = self.authorTable.insert(or: .replace,
                                                               self.emailAddress <- a.emailAddress,
                                                               self.jobDescription <- a.jobDescription)
                    
                    do
                    {
                        try self.database.run(insertAuthor)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    
                    let insertAPKAuthor = self.apkAuthorsTable.insert(or: .replace,
                                                                      self.apk <- APK,
                                                                      self.emailAddress <- a.emailAddress,
                                                                      self.authorName <- a.name,
                                                                      self.authorPhotoUrl <- a.photoUrl,
                                                                      self.imageData <- a.photoData,
                                                                      self.imageAspectRatio <- a.photoAspectRatio)
                    
                    do
                    {
                        try self.database.run(insertAPKAuthor)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                }
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertCheckBoxGroups(checkBoxGroupsList : [CheckBoxGroup]!)
    {
        objc_sync_enter(lock)
        do
        {
            if(checkBoxGroupsList != nil)
            {
                for c in checkBoxGroupsList
                {
                    let insertCheckBoxGroups = self.checkBoxGroupsTable.insert(or: .replace,
                                                                                   self.id <- c.groupID,
                                                                                   self.apk <- APK )
                    do
                    {
                        try self.database.run(insertCheckBoxGroups)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    for checkBoxID in c.checkBoxItemsList
                    {
                        let insertCheckBoxGroupsItem = self.checkBoxGroupsItemsTable.insert(or: .replace,
                                                                                       self.id <- c.groupID,
                                                                                       self.checkBoxID <- checkBoxID )
                        do
                        {
                            try self.database.run(insertCheckBoxGroupsItem)
                        }
                        catch
                        {
                            print(error)
                        }
                    }
                    
                    for relation in c.checkBoxRelationsList
                    {
                        let insertCheckBoxGroupsRelation = self.checkBoxGroupsRelationsTable.insert(or: .replace,
                                                                                       self.firstGroupID <- c.groupID,
                                                                                       self.secondGroupID <- relation.groupID,
                                                                                       self.validationFailedHeader <- relation.validationFailedHeader,
                                                                                       self.validationFailedMessage <- relation.validationFailedMessage)
                        do
                        {
                            try self.database.run(insertCheckBoxGroupsRelation)
                        }
                        catch
                        {
                            print(error)
                        }
                    }
                    
                    print("Checkbox group added")
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    /*********************************************************                  GETS                  *********************************************************/
    
    func getBlogView(tabID : Int) -> BlogModel!
    {
        objc_sync_enter(lock)
        do {
            let articlViewModel = BlogModel()
            
            let blogView = try self.database.prepare(self.blogViewTable.filter(self.apk == APK && self.tabID == tabID ))
            
            for b in blogView {
                articlViewModel.image = b[self.url]
                articlViewModel.title = b[self.title]
                articlViewModel.titleFont = b[self.titleFontNull]
                articlViewModel.titleSize = b[self.titleTextSizeNull]
                articlViewModel.titleColor = b[self.titleTextColorNull]
                articlViewModel.imageAspectRatio = b[self.imageAspectRatio]
                articlViewModel.imageData = b[self.imageData]
                
                objc_sync_exit(lock)
                return articlViewModel
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getBlogViewArticles(tabID : Int, apk : String) -> [ArticleModel]!
    {
        var articles : [ArticleModel] = []
        
        objc_sync_enter(lock)
        do {
            let blogViewArticles = try self.database.prepare(self.blogViewArticlesTable.filter(self.tabID == tabID &&  self.apk == apk))
            
            for b in blogViewArticles {
                
                let articleModel = getArticle(id: b[self.articleID])
                
                if(articleModel != nil)
                {
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy-MM-dd"
                    dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00")
                    
                    var currentDate = Date()
                    currentDate.addTimeInterval(60 * 60 * 2)

                    //let date2 = Date().description(with: Locale.current)
                    
                    if( !isNullOrEmpty(string: articleModel?.publishDate) && !isNullOrEmpty(string: articleModel?.expirationDate) )
                    {
                        let startDate = dateFormatter.date(from: String(articleModel!.publishDate.split(separator: " ")[0]))
                        var endDate = dateFormatter.date(from:  String(articleModel!.expirationDate.split(separator: " ")[0]))
                        endDate?.addTimeInterval(60 * 60 * 24)
                        
                        if(((endDate ?? Date()) < currentDate ?? Date()) || (currentDate ?? Date() < (startDate ?? Date())) )
                        {
                            continue
                        }
                    }
                    else if(!isNullOrEmpty(string: articleModel?.publishDate))
                    {
                        let startDate = dateFormatter.date(from: String(articleModel!.publishDate.split(separator: " ")[0]))
                        
                        if currentDate ?? Date() < (startDate ?? Date()) {
                            continue
                        }
                    }
                    else if(!isNullOrEmpty(string: articleModel?.expirationDate))
                    {
                        var endDate = dateFormatter.date(from:  String(articleModel!.expirationDate.split(separator: " ")[0]))
                        endDate?.addTimeInterval(60 * 60 * 24)
                        
                        if (endDate ?? Date()) < currentDate ?? Date()  {
                            continue
                        }
                    }
                    
                    if(articleModel?.categoryID != nil)
                    {
                        articleModel?.category = getArticleCategoryName(id : (articleModel?.categoryID)!)
                    }
                    
                    print(articleModel?.imageData.count)
                    articles.append(articleModel!)
                }
            }
            
            articles = articles.sorted(by: { $0.publishDate > $1.publishDate })
            objc_sync_exit(lock)
            return articles
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return articles
    }
    
    func getArticle(id : Int64) -> ArticleModel!
    {
        objc_sync_enter(lock)
        do {
            let articleModel = ArticleModel()
            
            let article = try self.database.prepare(self.articleTable.filter(self.articleID == id ))
            
            for a in article {
                articleModel.id = id
                articleModel.image = a[self.image]
                articleModel.title = a[self.title]
                articleModel.categoryID = a[self.categoryID]
                articleModel.url = a[self.url]
                articleModel.titleFont = a[self.titleFont]
                articleModel.titleSize = a[self.titleSize]
                articleModel.titleColor = a[self.titleColor]
                articleModel.categoryFont = a[self.categoryFont]
                articleModel.categorySize = a[self.categoryTextSize]
                articleModel.categoryColor = a[self.categoryTextColor]
                articleModel.publishDate = a[self.publishDate]
                articleModel.expirationDate = a[self.expirationdDate]
                articleModel.dateFont = a[self.dateFont]
                articleModel.dateTextSize = a[self.dateTextSize]
                articleModel.dateTextColor = a[self.dateTextColor]
                articleModel.url = a[self.url]
                articleModel.authorEmailAddress = a[self.authorEmailAddress]
                
                articleModel.imageAspectRatio = a[self.aspectRatio]
                articleModel.imageData = a[self.imageData]
                
                objc_sync_exit(lock)
                return articleModel
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getArticleCategoryName(id : Int) -> String
    {
        objc_sync_enter(lock)
        do {
            
            
            let articleCategory = try self.database.prepare(self.articleCategoriesTable.filter(self.id == id ))
            
            for a in articleCategory {
                objc_sync_exit(lock)
                return a[self.name]
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return ""
    }

    
    /// Return the pdf which has the given id.
    ///
    /// - Parameter id: The id of pdf.
    /// - Returns: The model of pdf if exists, otherwise nil.
    func getPDF(id : Int) -> PDFModel!
    {
        objc_sync_enter(lock)
        do {
            /*var query = viewTable
             .select(viewTable[self.id], pdfTable[*])
             .join(pdfTable, on: viewTable[self.id] == pdfTable[self.id])*/
            
            let pdfModel = PDFModel()
            
            let pdf = try self.database.prepare(self.pdfTable.filter(self.id == id ))
            
            for p in pdf {
                pdfModel.pdfUrl = p[self.url]
                pdfModel.numOfPages = p[self.numOfPages]
                
                objc_sync_exit(lock)
                return pdfModel
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
        
    }
    
    /// Return the text which has the given id.
    ///
    /// - Parameter id: The id of text.
    /// - Returns: The model of text if exists, otherwise nil.
    func getText(id : Int) -> TextModel!
    {
        objc_sync_enter(lock)
        do {
            let textModel = TextModel()
            
            let text = try self.database.prepare(self.textTable.filter(self.id == id ))
            
            for t in text {
                textModel.title = t[self.title]
                textModel.description = t[self.textDescription]
                textModel.splitterColor = t[self.splitterColor]
                textModel.backgroundColor = t[self.backgroundColor]
                textModel.isTitleCentered = t[self.isTitleCentered]!
                textModel.descriptionFont = t[self.descriptionFont]
                textModel.descriptionAlignmentType = AlignmentType(rawValue: t[self.descriptionAlignmentType])
                textModel.titleFont = t[self.titleFont]
                textModel.titleSize = t[self.titleSize]
                textModel.descriptionSize = t[self.descriptionSize]
                textModel.titleColor = t[self.titleColor]
                textModel.descriptionColor = t[self.descriptionColor]
                
                objc_sync_exit(lock)
                return textModel
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
        
    }
    
    /// Return the button which has the given id.
    ///
    /// - Parameter id: The id of button.
    /// - Returns: The model of button if exists, otherwise nil.
    func getButton(id : Int!) -> ButtonModel!
    {
        objc_sync_enter(lock)
        do {
            let buttonModel = ButtonModel()
            
            let button = try self.database.prepare(self.buttonTable.filter(self.id == id ))
            
            for b in button {
                buttonModel.name = b[self.name]
                buttonModel.height = b[self.height]
                buttonModel.width = b[self.width]
                buttonModel.imageUrl = b[self.url]
                buttonModel.backgroundColor = b[self.backgroundColor]
                buttonModel.borderWidth = b[self.borderWidth]
                buttonModel.borderColor = b[self.borderColor]
                buttonModel.font = b[self.font]
                buttonModel.tabID = b[self.tabID]
                buttonModel.textColor = b[self.textColor]
                buttonModel.textSize = b[self.nameTextSize]
                buttonModel.buttonPosition = b[self.buttonPosition]
                buttonModel.link = b[self.link]
                buttonModel.cornerRadius = b[self.cornerRadius] == nil ? 0 : b[self.cornerRadius]
                
                objc_sync_exit(lock)
                return buttonModel
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        return nil
    }
    
    /// Return the title which has the given id.
    ///
    /// - Parameter id: The id of title.
    /// - Returns: The model of title if exists, otherwise nil.
    func getTitle(id : Int!) -> TitleModel!
    {
        objc_sync_enter(lock)
        do {
            let titleModel = TitleModel()
            
            let title = try self.database.prepare(self.titleTable.filter(self.id == id ))
            
            for t in title {
                titleModel.id = id
                titleModel.title = t[self.title]
                titleModel.titleColor = t[self.titleColor]
                titleModel.titleFont = t[self.titleFont]
                titleModel.titleSize = t[self.titleSize]
                titleModel.titleBackgroundColor = t[self.backgroundColor]
                titleModel.isTitleCentered = t[self.isTitleCentered]
                titleModel.splitterColor = t[self.splitterColor]
                titleModel.topPadding = t[self.topPadding]
                titleModel.isSection = t[self.isSection] == nil ? false : t[self.isSection]
                titleModel.isSectionExpanded = t[self.isSectionExpanded] == nil ? true : t[self.isSectionExpanded]
                
                objc_sync_exit(lock)
                return titleModel
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        return nil
    }
    
    /// Return the photo which has the given id.
    ///
    /// - Parameter id: The id of photo.
    /// - Returns: The model of photo if exists, otherwise nil.
    func getPhoto(id : Int) -> PhotoModel!
    {
        objc_sync_enter(lock)
        do {
            let photoModel = PhotoModel()
            
            let photo = try self.database.prepare(self.photoTable.filter(self.id == id ))
            
            for p in photo {
                photoModel.imageUrl = p[self.url]
                photoModel.link = p[self.link]
                photoModel.aspectRatio = p[self.aspectRatio]
                
                if(p[self.button] != nil)
                {
                    photoModel.button = getButton(id : p[self.button])
                }
                
                if(p[self.photoTitle] != nil)
                {
                    photoModel.title = getTitle(id : p[self.photoTitle])
                }
                
                objc_sync_exit(lock)
                return photoModel
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        return nil
    }
    
    /// Return the carousel which has the given id.
    ///
    /// - Parameter id: The id of carousel.
    /// - Returns: The model of carousel if exists, otherwise nil.
    func getCarousel(id : Int) -> CarouselModel!
    {
        objc_sync_enter(lock)
        do {
            let carouselModel = CarouselModel()
            
            let carousel = try self.database.prepare(self.carouselTable.filter(self.id == id ))
            
            for c in carousel {
                carouselModel.hasTitles = c[self.hasTitles]
                carouselModel.interval = c[self.interval]
                carouselModel.isManual = c[self.isManual]
                carouselModel.isAutomatic = c[self.isAutomatic]
                carouselModel.isScrollingEnabled = c[self.isScrollingEnabled]
                carouselModel.urls = getUrls(carouselID: c[self.id])
                
                objc_sync_exit(lock)
                return carouselModel
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        return nil
    }
    
    /// Return the urls which has the given carousel id.
    ///
    /// - Parameter id: The id of carousel.
    /// - Returns: The models of urls if exists, otherwise nil.
    func getUrls(carouselID : Int) -> [UrlModel]!
    {
        objc_sync_enter(lock)
        do {
            var urlsTable : [UrlModel] = []
            let urls = try self.database.prepare(self.urlTable.filter(self.carouselID == carouselID ))
            
            for u in urls {
                let url = UrlModel()
                
                url.url = u[self.url]
                url.aspectRatio = u[self.aspectRatio]
                
                if(u[self.urlTitle] != nil)
                {
                    url.title = getTitle(id: u[self.urlTitle])
                }
                
                urlsTable.append(url)
            }
            
            objc_sync_exit(lock)
            return urlsTable
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        return nil
    }
    
    /// Return the video which has the given id.
    ///
    /// - Parameter id: The id of video.
    /// - Returns: The model of video if exists, otherwise nil.
    func getVideo(id : Int) -> VideoModel!
    {
        objc_sync_enter(lock)
        do {
            
            let videoModel = VideoModel()
            
            let video = try self.database.prepare(self.videoTable.filter(self.id == id ))
            
            for v in video {
                videoModel.videoUrl = v[self.url]
                videoModel.autoPlay = v[self.autoPlay]
                videoModel.alternativePhoto = v[self.alternativePhoto]
                videoModel.alternativePhotoAspectRatio = v[self.aspectRatio]
                
                objc_sync_exit(lock)
                return videoModel
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        return nil
    }
    
    func getSwitch(id : Int) -> SwitchModel!
    {
        objc_sync_enter(lock)
        do {
            
            let switchModel = SwitchModel()
            
            let swicth = try self.database.prepare(self.switchTable.filter(self.id == id ))
            
            for s in swicth {
                switchModel.title = s[self.title]
                switchModel.description = s[self.textDescription]
                switchModel.fieldStyleID = s[self.fieldStyleID]
                switchModel.acceptType = s[self.acceptType]
                
                switchModel.fieldStyle = userProfileDB.getFieldStyle(id: switchModel.fieldStyleID)
                
                objc_sync_exit(lock)
                return switchModel
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        return nil
    }
    
    func getCheckBox(id : Int!) -> CheckBoxModel!
    {
        objc_sync_enter(lock)
        do {
            
            let checkBoxModel = CheckBoxModel()
            
            let checkBox = try self.database.prepare(self.checkBoxTable.filter(self.id == id ))
            
            for c in checkBox {
                checkBoxModel.id = id
                checkBoxModel.text = c[self.text]
                checkBoxModel.textColor = c[self.textColor]
                checkBoxModel.textSize = c[self.textSize]
                checkBoxModel.textFont = c[self.font]
                checkBoxModel.isRequired = c[self.isRequired]
                checkBoxModel.tintColor = c[self.tintColor]
                checkBoxModel.link = c[self.link]
                checkBoxModel.imageUrl = c[self.imageUrl]
                checkBoxModel.connectionID = c[self.cbConnectionID]
                checkBoxModel.imageWidthPercentage = c[self.imageWidthPercentage] == nil ? 0 : c[self.imageWidthPercentage]
                
                if(!isNullOrEmpty(string: checkBoxModel.imageUrl))
                {
                    checkBoxModel.imageAspectRatio = c[self.imageAspectRatio]
                    
                    if(c[self.imageDataNullable] != nil)
                    {
                        print(c[self.imageDataNullable]!.count)
                        checkBoxModel.image = UIImage(data: c[self.imageDataNullable]!)
                    }
                    else
                    {
                        checkBoxModel.image = UIImage()
                    }
                }
                
                checkBoxModel.alignment = c[self.alignment] == nil ? 1 : c[self.alignment]
                checkBoxModel.isCheckBoxOnTheLeft = c[self.isCheckBoxOnTheLeft] == nil ? true : c[self.isCheckBoxOnTheLeft]
                checkBoxModel.isCheckBoxNearText = c[self.isCheckBoxNearText] == nil ? true : c[self.isCheckBoxNearText]
                checkBoxModel.isChecked = c[self.isChecked] == nil ? false : c[self.isChecked]
                
                objc_sync_exit(lock)
                return checkBoxModel
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        return nil
    }

    
    /// Return the genaral view of given tab.
    ///
    /// - Parameter tabID: The tab id of general view.
    /// - Returns: The genaral view.
    func getGenealInformations(tabID : Int = 0, isArticle : Bool = false, articleID : Int64 = 0) -> [GeneralInformation2]!
    {
        var generalInformations : [GeneralInformation2]! = []
        //waitingForGettingImage = true
        
        objc_sync_enter(lock)
        do {
            
            let views : AnySequence<Row>!
            
            if(isArticle)
            {
                views = try self.database.prepare(self.articleItemsTable.filter(self.articleID == articleID))
            }
            else
            {
                views = try self.database.prepare(self.generalViewsTable.filter(self.tabID == tabID && self.apk == APK ))
            }
            
            for v in views {
                let generalInformation = GeneralInformation2()
                generalInformation.index = v[self.index]
                generalInformation.type = v[self.type]
                
                if(!isArticle)
                {
                    generalInformation.startDate = v[self.startDate]
                    generalInformation.endDate = v[self.endDate]
                }
                
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "dd/MM/yyyy"
                dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00")
                
                var currentDate = Date()
                currentDate.addTimeInterval(60 * 60 * 2)
                
                //let date2 = Date().description(with: Locale.current)

                if( !isNullOrEmpty(string: generalInformation.startDate) && !isNullOrEmpty(string: generalInformation.endDate) )
                {
                    let startDate = dateFormatter.date(from: generalInformation.startDate)
                    var endDate = dateFormatter.date(from: generalInformation.endDate)
                    endDate?.addTimeInterval(60 * 60 * 24)
                    
                    if(((endDate ?? Date()) < currentDate ?? Date()) || (currentDate ?? Date() < (startDate ?? Date())) )
                    {
                        continue
                    }
                }
                else if(!isNullOrEmpty(string: generalInformation.startDate))
                {
                    let startDate = dateFormatter.date(from: generalInformation.startDate)
                    
                    if currentDate ?? Date() < (startDate ?? Date()) {
                        continue
                    }
                }
                else if(!isNullOrEmpty(string: generalInformation.endDate))
                {
                    var endDate = dateFormatter.date(from: generalInformation.endDate)
                    endDate?.addTimeInterval(60 * 60 * 24)
                    
                    if (endDate ?? Date()) < currentDate ?? Date()  {
                        continue
                    }
                }
                
                switch (v[self.type])
                {
                case SlotType.PDF.rawValue:
                    let pdf = getPDF(id: v[self.id])
                    if(pdf != nil)
                    {
                        generalInformation.pdf = pdf
                        generalInformations.append(generalInformation)
                    }
                    break
                case SlotType.Text.rawValue:
                    let text = getText(id: v[self.id])
                    if(text != nil)
                    {
                        generalInformation.text = text
                        generalInformations.append(generalInformation)
                    }
                    break
                case SlotType.Photo.rawValue:
                    let photo = getPhoto(id: v[self.id])
                    if(photo != nil)
                    {
                        generalInformation.photo = photo
                        generalInformations.append(generalInformation)
                    }
                    break
                case SlotType.Carousel.rawValue:
                    let carousel = getCarousel(id: v[self.id])
                    if(carousel != nil)
                    {
                        if(isArticle)
                        {
                            carousel?.widthPercentage = 90
                        }
                        generalInformation.carousel = carousel
                        generalInformations.append(generalInformation)
                    }
                    break
                case SlotType.Video.rawValue:
                    let video = getVideo(id: v[self.id])
                    
                    if(video != nil)
                    {
                        if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
                        {
                            generalInformation.video = video
                            generalInformations.append(generalInformation)
                        }
                        else
                        {
                            generalInformation.type = SlotType.Photo.rawValue
                            let photo = PhotoModel()
                            photo.imageUrl = video?.alternativePhoto
                            photo.aspectRatio = video?.alternativePhotoAspectRatio
                            generalInformation.photo = photo
                            generalInformations.append(generalInformation)
                        }
                    }
                    break
                case SlotType.Title.rawValue:
                    let title = getTitle(id: v[self.id])
                    if(title != nil)
                    {
                        generalInformation.title = title
                        generalInformations.append(generalInformation)
                    }
                    break
                case SlotType.Article.rawValue:
                    /*let articleModel = getArticle(id: v[self.id])
                    if(articleModel != nil)
                    {
                        generalInformation.article = articleModel
                        generalInformations.append(generalInformation)
                    }*/
                    break
                case SlotType.Product.rawValue:
                    //generalInformation.productItemCode = v[self.productItemCode]
                    if(!isNullOrEmpty(string: v[self.productItemCode]))
                    {
                        var product = productsDB.getProductByItemNo(itemNo : v[self.productItemCode]!)
                        if(product != nil)
                        {
                            generalInformation.product = product
                            generalInformations.append(generalInformation)
                        }
                    }
                    break
                default :
                    break
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        //waitingForGettingImage = false
        
        return generalInformations
    }
    
    
    /// Return the expandable list view of given tab.
    ///
    /// - Parameter tabID: The tab id of expandable list view.
    /// - Returns: The expandable list view.
    func getExpandableListView(tabID : Int) -> ExpandableListModel!
    {
        objc_sync_enter(lock)
        do {
            
            let expandableListModel = ExpandableListModel()
            
            let expandableListViews = try self.database.prepare(self.expanableListViewTable.filter(self.tabID == tabID && self.apk == APK))
            
            for e in expandableListViews {
                expandableListModel.id = e[self.id]
                
                objc_sync_exit(lock)
                return expandableListModel
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        return nil
    }
    
    
    /// Return the expandable list parents of given expandable list view.
    ///
    /// - Parameter expandableListViewID: The expandable list view.
    /// - Returns: The the expandable list parents.
    func getExpandableListParents(expandableListViewID : Int) -> [ExpandableListParentModel]!
    {
        while(waitingForGettingImage)
        {
            print("waiting")
        }
        
        objc_sync_enter(lock)
        print("insert lock 5")
        do {
            
            var expandableListParentModels : [ExpandableListParentModel] = []
            
            var expandableListParents : AnySequence<Row>! = try self.database.prepare(self.expanableListParentsTable.filter(self.expandableListViewID == expandableListViewID))
            
            for e in expandableListParents {
                let expandableListParentModel = ExpandableListParentModel()
                expandableListParentModel.type = e[self.type]
                expandableListParentModel.backgroundColor = e[self.backgroundColor]
                expandableListParentModel.font = e[self.font]
                expandableListParentModel.textSize = e[self.nameTextSize]
                expandableListParentModel.textColor = e[self.textColor]
                expandableListParentModel.tintColor = e[self.tintColor]
                expandableListParentModel.image = e[self.image]
                expandableListParentModel.name = e[self.name]
                expandableListParentModel.hasAlternatingStyles = e[self.hasAlternatingStyles]
                
                expandableListParentModel.backgroundImage = e[self.backgroundImage]
                expandableListParentModel.labelPosition = e[self.labelPosition]
                expandableListParentModel.labelBackgroundColor = e[self.labelBackgroundColor]
                expandableListParentModel.labelWidth = e[self.labelWidth]
                expandableListParentModel.labelHeight = e[self.labelHeight]
                expandableListParentModel.aspectRatio = e[self.aspectRatio]
                
                if(e[self.firstStyle] != nil)
                {
                    expandableListParentModel.firstStyle = getExpandableListChildStyle(id : e[self.firstStyle])
                }
                
                if(e[self.secondStyle] != nil)
                {
                    expandableListParentModel.secondStyle = getExpandableListChildStyle(id : e[self.secondStyle])
                }

                expandableListParentModels.append(expandableListParentModel)
            }
            
            //sqlite3_close_v2(database.handle)
            expandableListParents = nil
            objc_sync_exit(lock)
            print("exit lock 5")
            return expandableListParentModels
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        return nil
    }
    
    
    /// Return the expandable list child style.
    ///
    /// - Parameter id: The id of expandable list.
    /// - Returns: The expandable list child style.
    func getExpandableListChildStyle(id : Int!) -> StyleModel!
    {
        objc_sync_enter(lock)
        do {
            
            let expandableListChildStyleModel = StyleModel()
            
            let expandableListChildStyles = try self.database.prepare(self.expandableListChildStyles.filter(self.id == id))
            
            for e in expandableListChildStyles {
                expandableListChildStyleModel.backgroundColor = e[self.backgroundColor]
                expandableListChildStyleModel.font = e[self.font]
                expandableListChildStyleModel.textSize = e[self.nameTextSize]
                expandableListChildStyleModel.textColor = e[self.textColor]
                expandableListChildStyleModel.tintColor = e[self.tintColor]
                
                objc_sync_exit(lock)
                return expandableListChildStyleModel
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        return nil
    }
    
    
    /// Return the embeded view of given embeded view id.
    ///
    /// - Parameters:
    ///   - id: The id of embeded view.
    ///   - product: The model of product(we use this model when embeded view is a product view).
    /// - Returns: The general view of embeded view.
    func getEmbededViewInformationList(id : Int, product : ProductModel, showImage : Bool = true, isForArticle : Bool = false, videoSrcUrl : String! = nil) -> [GeneralInformation2]!
    {
        var generalInformations : [GeneralInformation2]! = []
        
        objc_sync_enter(lock)
        do
        {
            let views = try self.database.prepare(self.embededGeneralViewTable.filter(self.id == id && self.apk == APK ))
            
            for v in views {
                
                let generalInformation = GeneralInformation2()
                generalInformation.type = v[self.type]
                
                switch (v[self.type])
                {
                case SlotType.PDF.rawValue:
                    let pdf = getPDF(id: v[self.id])
                    if(pdf != nil)
                    {
                        generalInformation.pdf = pdf
                        generalInformations.append(generalInformation)
                    }
                    break
                case SlotType.Text.rawValue:
                    let text = getText(id: v[self.slotID])
                    if(text != nil)
                    {
                        switch v[self.infoType]
                        {
                        case ProductInfoType.OverView.rawValue:
                            if(product.overViewText == nil || product.overViewText.count == 0 || isForArticle)
                            {
                                break
                            }
                            text?.description = product.overViewText
                        case ProductInfoType.Price.rawValue:
                            if(product.priceIncludingVAT == nil)
                            {
                                break
                            }
                            text?.description = "€ " + String(format: "%.2f" , product.priceIncludingVAT)
                        case ProductInfoType.Ingredients.rawValue:
                            if(product.ingredientsText == nil || product.ingredientsText.count == 0 || isForArticle)
                            {
                                break
                            }
                            text?.description = product.ingredientsText
                        case ProductInfoType.HowToUse.rawValue:
                            if(product.howToUseText == nil || product.howToUseText.count == 0 || isForArticle)
                            {
                                break
                            }
                            text?.description = product.howToUseText
                        case ProductInfoType.OfferAvailability.rawValue:
                            if(product.overViewText == nil || product.ingredientsText.count == 0)
                            {
                                break
                            }
                            text?.description = "16/07/2018 - 30/07/2018"
                        case ProductInfoType.TermsAndConditions.rawValue:
                            if(product.overViewText == nil || product.ingredientsText.count == 0)
                            {
                                break
                            }
                            text?.description = "Terms and condtions"
                        case ProductInfoType.Brand.rawValue:
                            if(product.manufacturerName == nil || product.manufacturerName.count == 0)
                            {
                                break
                            }
                            text?.description = product.manufacturerName
                        case ProductInfoType.ItemCode.rawValue:
                            if(product.itemNo == nil || isForArticle)
                            {
                                break
                            }
                            text?.description = String(product.itemNo)
                        case ProductInfoType.Barcode.rawValue:
                            let barcode = productsDB.getProductBarcode(itemNo : product.itemNo )
                            if(barcode == nil  || isForArticle)
                            {
                                break
                            }
                            text?.description = barcode
                            text?.showBarcode = true
                        default:
                            break
                        }
                        
                        if(text?.description != nil &&  (text?.description.count)! > 0)
                        {
                            generalInformation.text = text
                            generalInformations.append(generalInformation)
                        }
                    }
                    break
                case SlotType.Photo.rawValue:
                    var photo = getPhoto(id:  v[self.slotID])
                    if(showImage && photo == nil && !isForArticle)
                    {
                        photo = PhotoModel()
                        photo?.takeFullWidth = false
                        photo?.imageUrl = product.imageA
                        
                        if(product.imageA != nil && product.imageA.count > 0)
                        {
                            /*do
                             {
                             KingfisherManager.shared.retrieveImage (with: URL(string: percentEncode(s: product.imageA) )!, options: nil, progressBlock: nil, completionHandler:
                             { (image, error, cacheType, imageURL) -> () in
                             if(image != nil)
                             {
                             photo?.aspectRatio = Double((image?.size.height)! / (image?.size.width)!)
                             }
                             else
                             {
                             photo?.aspectRatio = 0
                             }
                             
                             generalInformation.photo = photo
                             generalInformations.append(generalInformation)
                             })*/
                            
                            photo?.aspectRatio = 0
                            generalInformation.photo = photo
                            generalInformations.append(generalInformation)
                            
                            /*if let data : Data = try Data(contentsOf: URL(string: percentEncode(s: product.imageA) )!)
                             {
                             var waitToCalculateAspecRatio = true
                             
                             KingfisherManager.shared.retrieveImage (with: URL(string: percentEncode(s: product.imageA) )!, options: nil, progressBlock: nil, completionHandler:
                             { (image, error, cacheType, imageURL) -> () in
                             if(image != nil)
                             {
                             photo?.aspectRatio = Double((image?.size.height)! / (image?.size.width)!)
                             }
                             else
                             {
                             photo?.aspectRatio = 0
                             }
                             
                             waitToCalculateAspecRatio = false
                             })
                             
                             while(waitToCalculateAspecRatio)
                             {}
                             
                             generalInformation.photo = photo
                             generalInformations.append(generalInformation)
                             }
                             }
                             catch
                             {}*/
                        }
                        else if(product.imageB != nil && product.imageB.count > 0)
                        {
                            photo?.aspectRatio = 0
                            generalInformation.photo = photo
                            generalInformations.append(generalInformation)
                        }
                    }
                    
                    
                    break
                case SlotType.Carousel.rawValue:
                    let carousel = getCarousel(id: v[self.id])
                    if(carousel != nil)
                    {
                        generalInformation.carousel = carousel
                        generalInformations.append(generalInformation)
                    }
                    break
                case SlotType.Video.rawValue:
                    let video = getVideo(id: v[self.id])
                    
                    if(video != nil)
                    {
                        if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
                        {
                            generalInformation.video = video
                            generalInformations.append(generalInformation)
                        }
                        else
                        {
                            generalInformation.type = SlotType.Photo.rawValue
                            let photo = PhotoModel()
                            photo.imageUrl = video?.alternativePhoto
                            photo.aspectRatio = video?.alternativePhotoAspectRatio
                            generalInformation.photo = photo
                            
                            generalInformations.append(generalInformation)
                        }
                    }
                    break
                case SlotType.Title.rawValue:
                    let title = getTitle(id: v[self.slotID])
                    if(title != nil && !isForArticle)
                    {
                        title?.title = product.webDescription
                        generalInformation.title = title
                        generalInformations.append(generalInformation)
                    }
                    break
                default :
                    break
                }
            }
            
            if (!isNullOrEmpty(string: videoSrcUrl)){
                
                print(videoSrcUrl)
                let generalInformation = GeneralInformation2()
                let productvideo = VideoModel()
                productvideo.videoUrl = videoSrcUrl
                productvideo.autoPlay = false
                generalInformation.type = 2
                generalInformation.video = productvideo
                generalInformations.append(generalInformation)
            }
            else{
                print("No available video")
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        return generalInformations
    }
    
    
    /// Return the view paramaters of given embeded view.
    ///
    /// - Parameter id: The id of embeded view.
    /// - Returns: The embeded view paramaters.
    func getEmbededViewParameters(id : Int) -> EmbededViewParametersModel!
    {
        objc_sync_enter(lock)
        do {
            
            let embededViewParametersModel = EmbededViewParametersModel()
            
            let embededViewParameter = try self.database.prepare(self.embededViewParametersTable.filter(self.apk == APK && self.embededViewID == id))
            
            for e in embededViewParameter
            {
                embededViewParametersModel.separatorHeight = e[self.separatorHeight]
                embededViewParametersModel.separatorColor = e[self.separatorColor]
                embededViewParametersModel.borderSize = e[self.borderSize]
                embededViewParametersModel.borderColor = e[self.borderColor]
                
                objc_sync_exit(lock)
                return embededViewParametersModel
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        return nil
    }
    
    
    /// Return store locator info parameters.
    ///
    /// - Returns: The store locator info parameters.
    func getStoreLocatorInfoParameters() -> StoreLocatorInfoParametersModel!
    {
        objc_sync_enter(lock)
        do {
            
            let storeLocatorInfoParametersModel = StoreLocatorInfoParametersModel()
            
            let storeLocatorInfoParameters = try self.database.prepare(self.storeLocatorInfoParametersTable.filter(self.apk == APK))
            
            for s in storeLocatorInfoParameters
            {
                storeLocatorInfoParametersModel.textFont = s[self.font]
                storeLocatorInfoParametersModel.sizeOfText = s[self.sizeOfText]
                storeLocatorInfoParametersModel.textColor = s[self.textColor]
                storeLocatorInfoParametersModel.tintColor = s[self.tintColor]
                storeLocatorInfoParametersModel.borderSize = s[self.borderSize]
                storeLocatorInfoParametersModel.borderColor = s[self.borderColor]
                storeLocatorInfoParametersModel.titleBackgroundColor = s[self.titleBackgroundColor]
                storeLocatorInfoParametersModel.titleTextColor = s[self.titleTextColor]
                storeLocatorInfoParametersModel.titleTextSize = s[self.titleTextSize]
                storeLocatorInfoParametersModel.titleFont = s[self.titleFont]
                
                objc_sync_exit(lock)
                return storeLocatorInfoParametersModel
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        return nil
    }
    
    
    /// Return contact us view.
    ///
    /// - Parameter id: The id of contact us view.
    /// - Returns: The contact us view.
    func getContactUsView(id : Int) -> ContactUsModel!
    {
        objc_sync_enter(lock)
        do {
            
            let contactUsModel = ContactUsModel()
            
            let contactUsView = try self.database.prepare(self.contactUsViewTable.filter(self.id == id))
            
            for c in contactUsView
            {
                let jsonDecoder = JSONDecoder()
                
                let types = c[self.types]
                let stringTable = try jsonDecoder.decode(StringTable.self, from: types)
                
                for s in stringTable.strings
                {
                    contactUsModel.types.append(s)
                }
                
                let infos = c[self.info]
                let infoTable = try jsonDecoder.decode(StringTable.self, from: infos)
                
                var i = 0
                for s in infoTable.strings
                {
                    let c = ContactUsInfoModel()
                    c.info = s
                    c.type = infoTable.types[i]
                    contactUsModel.info.append(c)
                    i += 1
                }
                
                
                contactUsModel.tintColor = c[self.tintColor]
                contactUsModel.typeTitle = c[self.typeTitle]
                contactUsModel.typeFont = c[self.typeFont]
                contactUsModel.typeTextSize = c[self.typeTextSize]
                contactUsModel.typeTextColor = c[self.typeTextColor]
                contactUsModel.messageTitle = c[self.messageTitle]
                contactUsModel.messageFont = c[self.messageFont]
                contactUsModel.messageTextSize = c[self.messageTextSize]
                contactUsModel.messageTextColor = c[self.messageTextColor]
                contactUsModel.infoFont = c[self.infoFont]
                contactUsModel.infoTextSize = c[self.infoTextSize]
                contactUsModel.infoTextColor = c[self.infoTextColor]
                contactUsModel.buttonText = c[self.buttonText]
                contactUsModel.buttonBackgroundColor = c[self.buttonBackgroundColor]
                contactUsModel.buttonFont = c[self.buttonFont]
                contactUsModel.buttonTextSize = c[self.buttonTextSize]
                contactUsModel.buttonTextColor = c[self.buttonTextColor]
                contactUsModel.buttonBorderWidth = c[self.buttonBorderWidth]
                contactUsModel.buttonBorderColor = c[self.buttonBorderColor]
                
                objc_sync_exit(lock)
                return contactUsModel
            }
        }
        catch
        {
            print(error)
        }
    
        objc_sync_exit(lock)
        
        return nil
    }
    
    
    /// Seacrhes for contact us view based on given tab id.
    ///
    /// - Parameter tabID: The tab id.
    /// - Returns: The id of contact us view.
    func findContactUsViewID(tabID : Int) -> Int
    {
        objc_sync_enter(lock)
        do {
            let contactUsTabRelations = try self.database.prepare(self.contactUsTabsRelationsTable.filter(self.apk == APK && self.tabID == tabID))
            
            for c in contactUsTabRelations
            {
                objc_sync_exit(lock)
                return c[self.contactUsViewID]
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        return -1
    }
    
    
    /// Return the barcode view.
    ///
    /// - Returns: The barcode view.
    func getBarcodeView() -> BarcodeModel2!
    {
        objc_sync_enter(lock)
        do {
            let barcodeView = try self.database.prepare(self.barcodeViewTable.filter(self.apk == APK))
            
            for b in barcodeView
            {
                let barcodeModel = BarcodeModel2()
                
                barcodeModel.prototype = b[self.prototype]
                barcodeModel.backgroundColor = b[self.backgroundColor]
                barcodeModel.pointsTextColor = b[self.pointsTextColor]
                barcodeModel.pointsTextSize = b[self.pointsTextSize]
                barcodeModel.pointsFont = b[pointsFont]
                barcodeModel.infoTextColor = b[self.infoTextColor]
                barcodeModel.infoTextSize = b[self.infoTextSize]
                barcodeModel.infoFont = b[self.infoFont]
                barcodeModel.pointsType = b[self.pointsType] == nil ? PointsType.PointsOnly.rawValue : b[self.pointsType]
                
                objc_sync_exit(lock)
                return barcodeModel
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getGeneralSearchView() -> GeneralSearchView!
    {
        objc_sync_enter(lock)
        do {
            let generalSearchViewModel = GeneralSearchView()
            
            let generalSearchView = try self.database.prepare(self.generalSearchViewTable.filter(self.apk == APK))
            
            for g in generalSearchView
            {
                generalSearchViewModel.tintColor = g[self.tintColor]
                generalSearchViewModel.itemBackgroundColor = g[self.itemBackgroundColor]
                generalSearchViewModel.itemTextColor = g[self.itemTextColor]
                generalSearchViewModel.itemFont = g[self.itemFont]
                generalSearchViewModel.itemTextSize = g[self.itemTextSize]
                generalSearchViewModel.searchTextColor = g[self.searchTextColor]
                generalSearchViewModel.searchFont = g[self.searchFont]
                generalSearchViewModel.searchTextSize = g[self.searchTextSize]
                
                objc_sync_exit(lock)
                return generalSearchViewModel
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getRadioButton(id : Int) -> RadioButtonModel!
    {
        objc_sync_enter(lock)
        do {
            let radioButtonModel = RadioButtonModel()
            
            let radioButton = try self.database.prepare(self.radioButtonTable.filter(self.id == id ))
            
            for r in radioButton {
                radioButtonModel.imageUrl = r[self.imageUrl]
                radioButtonModel.name = r[self.radioButtonName]
                radioButtonModel.selectedColor = r[self.selectedColor]
                radioButtonModel.nonSelectedColor = r[self.nonSelectedColor]
                radioButtonModel.imageAspectRatio = r[self.imageAspectRatio]
                radioButtonModel.nameTextSize = r[self.radioButtonNameTextSize]
                radioButtonModel.nameTextColor = r[self.nameTextColor]
                radioButtonModel.nameFont = r[self.nameFont]
                radioButtonModel.connectionID = r[self.connectionID]
                
                objc_sync_exit(lock)
                return radioButtonModel
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        return nil
    }
    
    func getNotAvailableView() -> NotAvailableModel!
    {
        objc_sync_enter(lock)
        do {
            let notAvailableModel = NotAvailableModel()
            
            let notAvailableView = try self.database.prepare(self.notAvailableViewTable.filter(self.apk == APK))
            
            for n in notAvailableView
            {
                notAvailableModel.backgroundColor = n[self.backgroundColor]
                notAvailableModel.messageTextColor = n[self.messageTextColor]
                notAvailableModel.messageTextSize = n[self.messageTextSize]
                notAvailableModel.messageFont = n[self.messageFont]
                notAvailableModel.image = n[self.image]
                
                objc_sync_exit(lock)
                return notAvailableModel
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getNotAvailableImage() -> UIImage!
    {
        objc_sync_enter(lock)
        do {
            let image = try self.database.prepare(self.notAvailableImageTable.filter(self.apk == APK))
            
            for i in image
            {
                objc_sync_exit(lock)
                return UIImage(data: i[self.imageData])
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getAuthorModel(emailAddress : String!) -> AuthorModel!
    {
        objc_sync_enter(lock)
        do {
            let authorModel = AuthorModel()
            
            let author = try self.database.prepare(self.authorTable.filter(self.emailAddress == emailAddress))
            
            for a in author
            {
                authorModel.jobDescription = a[self.jobDescription]
            }
            
            let apkAuthor = try self.database.prepare(self.apkAuthorsTable.filter(self.apk == APK && self.emailAddress == emailAddress))
            
            for aa in apkAuthor
            {
                authorModel.name = aa[self.authorName]
                authorModel.photoUrl = aa[self.authorPhotoUrl]
                authorModel.photoData = aa[self.imageData]
                authorModel.photoAspectRatio = aa[self.imageAspectRatio]!
            }
            
            objc_sync_exit(lock)
            return authorModel
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    
    
    func getAuthorsParameters(emailAddress : String!) -> BlogAuthors!
    {
        objc_sync_enter(lock)
        do {
            let authorParamaters = BlogAuthors()
            
            let authorParameters = try self.database.prepare(self.apkAuthorParametersTable.filter(self.apk == APK))
            
            for a in authorParameters
            {
                authorParamaters.nameTextColor = a[self.authorNameTextColor ]
                authorParamaters.nameTextSize = a[self.authorNameTextSize]
                authorParamaters.nameFont = a[self.authorNameFont]
                authorParamaters.jobDescriptionTextSize = a[self.jobDescriptionTextSize]
                authorParamaters.jobDescriptionTextColor = a[self.jobDescriptionTextColor]
                authorParamaters.jobDescriptionFont = a[self.jobDescriptionFont]
                
                objc_sync_exit(lock)
                return authorParamaters
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
            
    func getCheckBoxGroups () -> [CheckBoxGroup]!
    {
        objc_sync_enter(lock)
        do {
            var checkBoxGroupsModels : [CheckBoxGroup] = []
            
            let checkBoxGroups = try self.database.prepare(self.checkBoxGroupsTable.filter(self.apk == APK))
            
            for checkBoxGroup in checkBoxGroups {
                
                var checkBoxGroupModel = CheckBoxGroup()
                
                checkBoxGroupModel.groupID = checkBoxGroup[self.id]
                
                checkBoxGroupModel.checkBoxItemsList = []
                checkBoxGroupModel.checkBoxRelationsList = []
                
                var items = try self.database.prepare(self.checkBoxGroupsItemsTable.filter(self.id == checkBoxGroupModel.groupID))
                
                for item in items
                {
                    checkBoxGroupModel.checkBoxItemsList.append(item[self.checkBoxID])
                }
                
                var relations = try self.database.prepare(self.checkBoxGroupsRelationsTable.filter(self.firstGroupID == checkBoxGroupModel.groupID))
                
                for r in relations
                {
                    var relation = CheckBoxGroupRelation()
                    
                    relation.groupID = r[self.secondGroupID]
                    relation.validationFailedHeader = r[self.validationFailedHeader]
                    relation.validationFailedMessage = r[self.validationFailedMessage]
                    
                    checkBoxGroupModel.checkBoxRelationsList.append(relation)
                }
                
                checkBoxGroupsModels.append(checkBoxGroupModel)
            }
            
            objc_sync_exit(lock)
            return checkBoxGroupsModels
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    /*********************************************************                  UPDATES                  *********************************************************/
    /// Deletes entries for speicfic APK from left drawer tabs table.
    
    func deletePDF(apk : String, g: Row )
    {
        objc_sync_enter(lock)
         do{
            
            let pdfsToBeDeleted = try self.database.prepare(self.pdfTable.filter(self.id == g[id]))
        
            for p in pdfsToBeDeleted
            {
                let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
                let url = NSURL(fileURLWithPath: path)
                if let pathComponent = url.appendingPathComponent("\(APK)\(g[self.index])\(g[self.tabID]).pdf") {
                    let filePath = pathComponent.path
                    let fileManager = FileManager.default
                    if fileManager.fileExists(atPath: filePath) {
                        let url = URL(fileURLWithPath: path).appendingPathComponent("\(APK.replacingOccurrences(of: ".", with: ""))\(g[self.index])\(g[self.tabID]).pdf")
                        try fileManager.removeItem(atPath: url.absoluteString)
                    } else {
                        print("\(APK.replacingOccurrences(of: ".", with: ""))\(g[self.index])\(g[self.tabID]).pdf")
                        print("FILE NOT AVAILABLE")
                    }
                } else {
                    print("FILE PATH NOT AVAILABLE")
                }
            }
       
            try self.database.run(self.pdfTable.filter(self.id == g[id]).delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    func deleteText(apk : String, id : Int)
    {
        objc_sync_enter(lock)
        let textsToBeDeleted = self.textTable.filter(self.apk == apk && self.id == id)
        
        do{
            try self.database.run(textsToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    func deletePhoto(apk : String , id : Int)
    {
        objc_sync_enter(lock)
        do{
            let photoToBeDeleted = try self.database.prepare(self.photoTable.filter(self.apk == apk && self.id == id))
            
            for p in photoToBeDeleted
            {
                self.deleteImage(url: p[self.url] == nil ? "" : p[self.url]! )
                try self.database.run(self.photoTable.filter(self.apk == apk && self.id == id).delete())
            }
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    func deleteButton(id : Int)
    {
        objc_sync_enter(lock)
        let buttonToBeDeleted = self.buttonTable.filter(self.id == id)
        
        do{
            try self.database.run(buttonToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    func deleteTitle(apk : String, id : Int)
    {
        objc_sync_enter(lock)
        let titlesToBeDeleted = self.titleTable.filter(self.apk == apk && self.id == id)
        
        do{
            try self.database.run(titlesToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    func deleteCarousel(apk : String, id : Int)
    {
        objc_sync_enter(lock)
        do{
            let carouselsToBeDeleted = try self.database.prepare(self.carouselTable.filter(self.apk == apk && self.id == id))
            
            for _ in carouselsToBeDeleted
            {
                let urls = try self.database.prepare(self.urlTable.filter(self.carouselID == id ))
                
                for u in urls {
                    self.deleteImage(url: u[self.url] == nil ? "" : u[self.url]! )
                }
                
                try self.database.run(self.carouselTable.filter(self.apk == apk && self.id == id).delete())
            }
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
        
    }
    
    func deleteVideo(id : Int)
    {
        objc_sync_enter(lock)
        let videoToBeDeleted = self.videoTable.filter(self.id == id)
        
        do{
            try self.database.run(videoToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    
    func deleteSwitch(id : Int)
    {
        objc_sync_enter(lock)
        let switchToBeDeleted = self.switchTable.filter(self.id == id)
        
        do{
            try self.database.run(switchToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    func deleteRadioButton(id : Int)
    {
        objc_sync_enter(lock)
        let radioButtonToBeDeleted = self.checkBoxTable.filter(self.id == id)
        
        do{
            try self.database.run(radioButtonToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    func deleteCheckBox(id : Int)
    {
        objc_sync_enter(lock)
        let checkBoxToBeDeleted = self.switchTable.filter(self.id == id)
        
        do{
            try self.database.run(checkBoxToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }

    func deleteCheckBoxConnections(apk : String)
    {
        objc_sync_enter(lock)
        do{
            let checkBoxGroups = try self.database.prepare(self.checkBoxGroupsTable.filter(self.apk == apk))
            
            for c in checkBoxGroups {
                let groupID = c[self.id]
                let checkBoxGroupItemToBeDeleted = self.checkBoxGroupsItemsTable.filter(self.id == groupID)
                let checkBoxGroupRelationsToBeDeleted1 = self.checkBoxGroupsRelationsTable.filter(self.firstGroupID == groupID)
                let checkBoxGroupRelationsToBeDeleted2 = self.checkBoxGroupsRelationsTable.filter(self.secondGroupID == groupID)
                
                do{
                    try self.database.run(checkBoxGroupItemToBeDeleted.delete())
                    try self.database.run(checkBoxGroupRelationsToBeDeleted1.delete())
                    try self.database.run(checkBoxGroupRelationsToBeDeleted2.delete())
                } catch {
                    print(error)
                }
            }
            
            let checkBoxGroupsToBeDeleted = self.checkBoxGroupsTable.filter(self.apk == apk)
            try self.database.run(checkBoxGroupsToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    /*func deleteArticles(apk : String!, blogViewsArticles : [ArticleModel])
    {
        do
        {
            let articles = try self.database.prepare(self.blogViewArticlesTable.filter(self.apk == apk))
            
            for a in articles
            {
                try self.database.run(self.articleTable.filter(self.articleID == a[self.articleID]).delete())
                
                let articleID = a[self.articleID]
                
                for b in blogViewsArticles
                {
                    if(b.id == articleID)
                    {
                        continue
                    }
                }
                
                var articleItems  : AnySequence<Row>! = try self.database.prepare(self.articleItemsTable.filter(self.articleID == articleID))
                
                for item in articleItems {
                    switch (item[self.type])
                    {
                    case SlotType.PDF.rawValue:
                        deletePDF(apk: apk, g: item)
                        break
                    case SlotType.Photo.rawValue:
                        deletePhoto(apk: apk, id: item[self.id])
                        break
                    case SlotType.Carousel.rawValue:
                        deleteCarousel(apk: apk, id: item[self.id])
                        break
                    case SlotType.Video.rawValue:
                        let video = getVideo(id: item[self.id])
                        
                        if(video != nil && video?.alternativePhoto != nil)
                        {
                            self.deleteImage(url: (video?.alternativePhoto)!)
                        }
                        break
                    case SlotType.Text.rawValue:
                        deleteText(apk: apk, id : item[self.id])
                        break
                    case SlotType.Title.rawValue:
                        deleteTitle(apk: apk, id : item[self.id])
                        break
                    default :
                        break
                    }
                }
                
                articleItems = nil
                try self.database.run(self.articleItemsTable.filter(self.articleID == a[self.articleID]).delete())
            }
        }
        catch
        {
            
        }
        
        do{
            try self.database.run(self.blogViewArticlesTable.filter(self.apk == apk).delete())
        } catch {
            print(error)
        }
    }*/
    
    func isArticleNeeded(articleID : Int64) -> Bool
    {
        objc_sync_enter(lock)
        do {
            var articles : [ArticleModel] = []
            
            let blogViewArticles = try self.database.prepare(self.blogViewArticlesTable.filter(self.articleID == articleID))
            
            for b in blogViewArticles {
                objc_sync_exit(lock)
                return true
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return false
    }
    
    func deleteArticle(apk : String, articleID : Int64, tabID : Int )
    {
        do
        {
            do{
                try self.database.run(self.blogViewArticlesTable.filter(self.apk == apk && self.tabID == tabID && self.articleID == articleID).delete())
            } catch {
                print(error)
            }
            
            if(isArticleNeeded(articleID: articleID))
            {
                return
            }
            
            try self.database.run(self.articleTable.filter(self.articleID == articleID).delete())
            
            var articleItems  : AnySequence<Row>! = try self.database.prepare(self.articleItemsTable.filter(self.articleID == articleID))
            
            for item in articleItems {
                switch (item[self.type])
                {
                case SlotType.PDF.rawValue:
                    deletePDF(apk: apk, g: item)
                    break
                case SlotType.Photo.rawValue:
                    deletePhoto(apk: apk, id: item[self.id])
                    break
                case SlotType.Carousel.rawValue:
                    deleteCarousel(apk: apk, id: item[self.id])
                    break
                case SlotType.Video.rawValue:
                    let video = getVideo(id: item[self.id])
                    
                    if(video != nil && video?.alternativePhoto != nil)
                    {
                        self.deleteImage(url: (video?.alternativePhoto)!)
                    }
                    break
                case SlotType.Text.rawValue:
                    deleteText(apk: apk, id : item[self.id])
                    break
                case SlotType.Title.rawValue:
                    deleteTitle(apk: apk, id : item[self.id])
                    break
                default :
                    break
                }
            }
            
            articleItems = nil
            try self.database.run(self.articleItemsTable.filter(self.articleID == articleID).delete())
        }
        catch
        {
            
        }
    }
    
    func deleteAllGeneralViews(apk : String)
    {
        if(!statusModel.areGeneralViewsSaved)
        {
            do
            {
                let generalViews = try self.database.prepare(self.generalViewsTable.filter(self.apk == apk))
                
                for g in generalViews {
                    switch (g[self.type])
                    {
                    case SlotType.PDF.rawValue:
                        deletePDF(apk: apk, g: g)
                        break
                    case SlotType.Photo.rawValue:
                        deletePhoto(apk: apk, id: g[self.id])
                        break
                    case SlotType.Carousel.rawValue:
                        deleteCarousel(apk: apk, id: g[self.id])
                        break
                    case SlotType.Video.rawValue:
                        let video = getVideo(id: g[self.id])
                        
                        if(video != nil && video?.alternativePhoto != nil)
                        {
                            self.deleteImage(url: (video?.alternativePhoto)!)
                        }
                        deleteVideo(id: g[self.id])
                        break
                    default :
                        break
                    }
                }
            }
            catch
            {
                
            }
            
            do{
                try self.database.run(self.generalViewsTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
    }
    
    func deleteEntries(apk : String)
    {
        objc_sync_enter(lock)
        
        
        if(!statusModel.areExpandableListViewsSaved)
        {
            do
            {
                let expandableListViews = try self.database.prepare(self.expanableListViewTable.filter(self.apk == apk))
                
                for e in expandableListViews {
                    
                    do{
                        try self.database.run(self.expanableListParentsTable.filter(self.expandableListViewID == e[self.id]).delete())
                    } catch {
                        print(error)
                    }
                }
            }
            catch
            {}
            
            do{
                try self.database.run(self.expanableListViewTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
            
            
            /*do{
                try self.database.run(self.expandableListChildStyles.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }*/
        }
        
        if(!statusModel.areAuthorsSaved)
        {
            do{
                try self.database.run(self.apkAuthorsTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
        
        if(!statusModel.areArticlesSaved)
        {
            do{
                try self.database.run(self.blogViewTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
            
            /*do
            {
                /*do {
                 let docsTrans = try self.database.prepare("DELETE FROM ArticleTable WHERE articleID NOT IN (SELECT articleID FROM BlogViewArticlesTable)")
                 
                 try database.transaction(.immediate) { () -> Void in
                 do
                 {
                 try docsTrans.run()
                 }
                 catch
                 {
                 print(error)
                 }
                 }
                 } catch
                 {
                 print(error)
                 }*/
                
                let articles = try self.database.prepare(self.articleTable) //try self.database.prepare(self.blogViewArticlesTable.filter(self.apk == apk))
                
                for a in articles
                {
                    let articleID = a[self.articleID]
                    
                    if(isArticleNeeded(articleID: articleID))
                    {
                        continue
                    }
                    
                    try self.database.run(self.articleTable.filter(self.articleID == a[self.articleID]).delete())
                    
                    var articleItems  : AnySequence<Row>! = try self.database.prepare(self.articleItemsTable.filter(self.articleID == articleID))
                    
                    for item in articleItems {
                        switch (item[self.type])
                        {
                        case SlotType.PDF.rawValue:
                            deletePDF(apk: apk, g: item)
                            break
                        case SlotType.Photo.rawValue:
                            deletePhoto(apk: apk, id: item[self.id])
                            break
                        case SlotType.Carousel.rawValue:
                            deleteCarousel(apk: apk, id: item[self.id])
                            break
                        case SlotType.Video.rawValue:
                            let video = getVideo(id: item[self.id])
                            
                            if(video != nil && video?.alternativePhoto != nil)
                            {
                                self.deleteImage(url: (video?.alternativePhoto)!)
                            }
                            break
                        case SlotType.Text.rawValue:
                            deleteText(apk: apk, id : item[self.id])
                            break
                        case SlotType.Title.rawValue:
                            deleteTitle(apk: apk, id : item[self.id])
                            break
                        default :
                            break
                        }
                    }
                    
                    articleItems = nil
                    try self.database.run(self.articleItemsTable.filter(self.articleID == a[self.articleID]).delete())
                }
            }
            catch
            {
                
            }*/
        }
        
        if(!statusModel.areEmbededViewsSaved)
        {
            do{
                try self.database.run(self.embededGeneralViewTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
        
        if(!statusModel.areEmbededViewsParametersSaved)
        {
            do{
                try self.database.run(self.embededViewParametersTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
        
        if(!statusModel.isContactUsViewSaved)
        {
            do{
                try self.database.run(self.contactUsViewTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
        
        if(!statusModel.areContactUsTabRelationsSaved)
        {
            do{
                try self.database.run(self.contactUsTabsRelationsTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
        
        if(!statusModel.areGeneralSearchViewSaved)
        {
            do{
                try self.database.run(self.generalSearchViewTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
        
        if(!statusModel.areSplashScrennParametersSaved)
        {
            deleteGeneralView(apk : apk, tabID : 0)
        }
        
        /*if(!statusModel.isFirstViewSaved)
        {
            deleteGeneralView(apk : apk, tabID : defaultTabID)
        }*/
        
        objc_sync_exit(lock)
    }
    
    func deleteEntries2(apk : String)
    {
        objc_sync_enter(lock)
        
        let leftDrawerTabs = parameterizationDatabase.getLeftDrawerTabs(apk: apk)
        
        if(leftDrawerTabs != nil)
        {
            if(syncModel.updateHome)
            {
                for t in leftDrawerTabs!
                {
                    if(t.tabType == TabType.Home.rawValue)
                    {
                        deleteGeneralView(apk : apk, tabID : t.id)
                    }
                }
            }
            
            if(syncModel.updateOffers)
            {
                for t in leftDrawerTabs!
                {
                    if(t.tabType == TabType.Offers.rawValue)
                    {
                        deleteGeneralView(apk : apk, tabID : t.id)
                    }
                }
            }
            
            if(syncModel.updateAbout)
            {
                for t in leftDrawerTabs!
                {
                    if(t.tabType == TabType.About.rawValue)
                    {
                        deleteGeneralView(apk : apk, tabID : t.id)
                    }
                }
            }
            
            if(syncModel.updateRedemption)
            {
                for t in leftDrawerTabs!
                {
                    if(t.tabType == TabType.RedemptionPolicy.rawValue)
                    {
                        deleteGeneralView(apk : apk, tabID : t.id)
                    }
                }
            }
            
            if(syncModel.updateTerms)
            {
                for t in leftDrawerTabs!
                {
                    if(t.tabType == TabType.TermsAndConditions.rawValue)
                    {
                        deleteGeneralView(apk : apk, tabID : t.id)
                    }
                }
            }
        }
        
        objc_sync_exit(lock)
    }
    
    func deleteGeneralView(apk : String ,tabID : Int)
    {
        do
        {
            let generalViews = try self.database.prepare(self.generalViewsTable.filter(self.apk == apk && self.tabID == tabID))
            
            for g in generalViews {
                switch (g[self.type])
                {
                case SlotType.PDF.rawValue:
                    deletePDF(apk: apk, g: g)
                    break
                case SlotType.Photo.rawValue:
                    deletePhoto(apk: apk, id: g[self.id])
                    break
                case SlotType.Carousel.rawValue:
                    deleteCarousel(apk: apk, id: g[self.id])
                    break
                case SlotType.Video.rawValue:
                    let video = getVideo(id: g[self.id])
                    
                    if(video != nil && video?.alternativePhoto != nil)
                    {
                        self.deleteImage(url: (video?.alternativePhoto)!)
                    }
                    break
                default :
                    break
                }
            }
        }
        catch
        {
            
        }
        
        do{
            try self.database.run(self.generalViewsTable.filter(self.apk == apk && self.tabID == tabID).delete())
        } catch {
            print(error)
        }
    }
    
    var waitForNavImageToDownloaded = false
    var waitToInsertPhoto = true
    var waitingForGettingImage = false
    var isGettingImagesFinished = false
    var imagesTable = Table("ImagesTable")
    var urlTemp = Expression<String>("urlTemp")
    
    func createsImagesTable()
    {
        let createsImagesTable = self.imagesTable.create { (table) in
            table.column(self.urlTemp)
            table.column(self.apk)
            table.column(self.imageData)
            
            table.primaryKey(self.apk, self.urlTemp)
        }
        
        do {
            try self.database.run(createsImagesTable)
        } catch {
            print(error)
        }
    }
    
    func downloadImage(url: String) {
        /*if(waitingForGettingImage)
         {
         while(!isGettingImagesFinished)
         {
         
         }
         }*/
        let urlTemp = URL(string: percentEncode(s: url))
        getDataFromUrl(url: urlTemp!) { data, response, error in
            guard let data = data, error == nil else
            {
                DispatchQueue.global(qos: .background).async {
                    self.waitForNavImageToDownloaded = false
                }
                return
            }
            
            self.insertImage(url : url,str: data)
            self.waitForNavImageToDownloaded = false
        }
    }
    
    func insertImage(url : String,str : Data)
    {
        while(waitingForGettingImage)
        {
            sleep(1)
        }
        
        if(str != nil)
        {
            objc_sync_enter(lock)
            do {
                let storeImage = self.imagesTable.insert(or: .replace,
                                                              self.urlTemp <- url,
                                                              self.apk <- APK,
                                                              self.imageData <- str)
                
                try self.database.run(storeImage)
                print("View image added")
            }
            catch
            {
                print(error)
            }
            objc_sync_exit(lock)
        }
    }
    
    func getImage(url : String) -> UIImage!
    {
        while(waitingForGettingImage)
        {
            sleep(1)
        }
        
        waitingForGettingImage = true
        objc_sync_enter(lock)

        print("insert lock")
        do {
                                                                        
            var storeImage : AnySequence<Row>!  = try self.database.prepare(self.imagesTable.filter(self.apk == APK && self.urlTemp == url))
            
            print("image getted")

            for s in storeImage
            {
                print("start converting")
                let image = UIImage(data: s[self.imageData])
                print("data converted")
                storeImage = nil
                objc_sync_exit(lock)
                waitingForGettingImage = false
                print("exit lock")
                return image
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        waitingForGettingImage = false
        return nil
    }
    
    func getImageData(url : String) -> Data!
    {
        while(waitingForGettingImage)
        {
            sleep(1)
        }
        
        waitingForGettingImage = true
        objc_sync_enter(lock)
        
        print("insert lock")
        do {
            
            var storeImage : AnySequence<Row>!  = try self.database.prepare(self.imagesTable.filter(self.apk == APK && self.urlTemp == url))
            
            print("image getted")
            
            for s in storeImage
            {
                print("start converting")
                let imageData = s[self.imageData]
                storeImage = nil
                objc_sync_exit(lock)
                waitingForGettingImage = false
                print("exit lock")
                return imageData
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        waitingForGettingImage = false
        return nil
    }
    
    func deleteImage(url : String)
    {
        //objc_sync_enter(lock)
        do{
            try self.database.run(self.imagesTable.filter(self.apk == APK && self.urlTemp == url).delete())
        } catch {
            print(error)
        }
        //objc_sync_exit(lock)
    }
}
