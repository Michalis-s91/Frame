//
//  DateTimeOperator.swift
//  RichReach2
//
//  Created by Eumbrella on 24/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// DateTimeOperator provides functionality that allows us to perform several operations and validations related to datetimes (e.g. check whether a year is a leap year).
class DateTimeOperator {
    /// Returns whether the provided year is a leap year or not.
    ///
    /// - Parameter year: The year to be checked.
    /// - Returns: True if the input year is a leap year, otherwise false.
    func isLeapYear(year : Int) -> Bool
    {
        if(year % 4 == 0)
        {
            if(year % 100 == 0)
            {
                if(year % 400 == 0)
                {
                    return true
                }
                else
                {
                    return false
                    
                }
            }
            else
            {
                return true
            }
        }
        else
        {
            return false
        }
        
    }
    
    /// Creates and returns a list that contains years between (and including) the input min and max years that
    ///
    /// - Parameters:
    ///   - minYear: The min year.
    ///   - maxYear: The max year.
    /// - Returns: A list that contains years between (and including) the input min and max years that are provided.
    func getYears(minYear : Int, maxYear : Int) -> [SingleTextModel]
    {
        var years : [SingleTextModel] = []
        for year in minYear...maxYear
        {
            let singleTextModel =  SingleTextModel(textStr: String(year))
            years.append(singleTextModel)
        }
        
        return years
        
    }
    
    /// Returns the month number in string format given the month name. For example for "January", "01" is returned.
    ///
    /// - Parameter monthName: The month name (e.g. "January" etc.).
    /// - Returns: The month number in string format (e.g. "01").
    func getMonthNumberFromMonthName(monthName : String) -> String!
    {
        let months = getMonths()
        
        var month : MonthModel!
        
        for m in months
        {
            if(m.month == monthName)
            {
                month = m
                break
            }
        }
        
        if (month != nil)
        {
            return month.monthNumber
        }
        
        return nil
    }
    
    /// Returns the month name given the month number. For example for "01", "January" is returned.
    ///
    /// - Parameter monthNumber: The month number (e.g. 01, 02 etc.).
    /// - Returns: The month name.
    func getMonthNameFromMonthNumber(monthNumber : String) -> String!
    {
        let months = getMonths()
        
        var month : MonthModel!
        
        for m in months
        {
            if(m.monthNumber == monthNumber)
            {
                month = m
                break
            }
        }
        
        if(month != nil)
        {
            return month.month
        }
        
        return nil
    }
    
    /// Returns the number of days for the input month (e.g. January has 31 days).
    ///
    /// - Parameter monthName: The month name.
    /// - Returns: The number of days for the input month.
    func getMonthNumOfDays(monthName : String) -> Int
    {
        if(!isNullOrEmpty(string : monthName))
        {
            let months = getMonths()
            
            
            var month : MonthModel!
            
            for m in months
            {
                if(m.month == monthName)
                {
                    month = m
                    break
                }
            }
            
            if (month != nil)
            {
                return month.numOfDays
            }
        }
        
        return 31
    }
    
    /// Returns the number of days for the input month (e.g. January has 31 days).
    ///
    /// - Parameters:
    ///   - monthName: The month name.
    ///   - year: The year.
    /// - Returns: The number of days for the input month.
    func getMonthNumOfDays(monthName : String , year : String) -> Int
    {
        if(!isNullOrEmpty(string : monthName) && (monthName == "February") && !isNullOrEmpty(string : year))
        {
            //var iYear = 0

            
            if let iYear = Int(year)
            {
                if(isLeapYear(year: iYear))
                {
                    return 29
                }
                else
                {
                    return 28
                }
            }
            else
            {
                return 29
            }
        }
        else
        {
            return getMonthNumOfDays(monthName: monthName)
        }
    }
    
    /// Returns a list that contains all 12 months with additional information.
    ///
    /// - Returns: A list that contains all 12 months.
    func getMonths() -> [MonthModel]
    {
        var months : [MonthModel] = []
        months.append(MonthModel( month: "January", monthNumber : "01", numOfDays : 31))
        months.append(MonthModel(month: "February", monthNumber: "02", numOfDays: 28))
        months.append(MonthModel(month: "March", monthNumber: "03", numOfDays: 31))
        months.append(MonthModel(month: "April", monthNumber: "04", numOfDays: 30))
        months.append(MonthModel(month: "May", monthNumber: "05", numOfDays: 31))
        months.append(MonthModel(month: "June", monthNumber: "06", numOfDays: 30))
        months.append(MonthModel(month: "July", monthNumber: "07", numOfDays: 31))
        months.append(MonthModel(month: "August", monthNumber: "08", numOfDays: 31))
        months.append(MonthModel(month: "September", monthNumber: "09", numOfDays: 30))
        months.append(MonthModel(month: "October", monthNumber: "10", numOfDays: 31))
        months.append(MonthModel(month: "November", monthNumber: "11", numOfDays: 30))
        months.append(MonthModel(month: "December", monthNumber: "12", numOfDays: 31))
        
        return months
    }
    
    /// Uses the input day, month name and year to create a date string in the form dd/mm/yyyy and returns the string to the user.
    ///
    /// - Parameters:
    ///   - day: The day (e.g. 1, 12 etc.).
    ///   - monthName: The month name (e.g. January).
    ///   - year: The year (e.g. 2000).
    /// - Returns: The date string to the user.
    func getDate(day : String, monthName : String, year : String) -> String!
    {
        var tempDate = day
        var iDay = 0
        
        do
        {
            iDay = Int(day)!
        }
        catch
        {
            
        }
        
        if(iDay > 0)
        {
            if(iDay < 10)
            {
                tempDate = "0" + day
            }
            
            let  months = getMonths()
            var month : MonthModel!
            
            for m in months
            {
                if(m.month == monthName)
                {
                    month = m
                    break
                }
            }
            if (month != nil)
            {
                let date = tempDate + "/" + month.monthNumber + "/" + year
                return date
            }
            else
            {
                return nil
            }
        }
        else
        {
            return nil
        }
    }
}


