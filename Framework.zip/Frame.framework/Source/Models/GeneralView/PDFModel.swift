//
//  PDFModel.swift
//  RichReach2
//
//  Created by Eumbrella on 04/06/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class PDFModel : Codable
{
    var id : Int64!
    var pdfUrl : String!
    var numOfPages : Int!
    
    private enum CodingKeys : String, CodingKey {
        case id = "ID"
        case pdfUrl = "Url"
        case numOfPages = "NumOfPages"
    }
}
