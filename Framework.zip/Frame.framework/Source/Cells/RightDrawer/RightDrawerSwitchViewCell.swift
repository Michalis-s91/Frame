//
//  RightDrawerSwitchViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 30/04/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// RightDrawerSwitchViewCell is a cell that is been used for showing a switch at right drawer table view.
class RightDrawerSwitchViewCell: RightDrawerViewCell {

    @IBOutlet var cellSwitch: UISwitch!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        cellSwitch.transform = CGAffineTransform(scaleX: 0.80, y: 0.80)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
