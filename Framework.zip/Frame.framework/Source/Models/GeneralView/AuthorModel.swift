//
//  AuthorModel.swift
//  RichReach
//
//  Created by Eumbrella on 13/02/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

class AuthorModel : Codable
{
    var emailAddress : String!
    var name : String!
    var jobDescription : String!
    var photoUrl : String!
    
    var photoData : Data = Data()
    var photoAspectRatio : Double = 1.0
    
    private enum CodingKeys : String, CodingKey {
        case emailAddress = "EmailAddress"
        case name = "Name"
        case jobDescription = "JobDescription"
        case photoUrl = "PhotoUrl"
    }
}

class BlogAuthors : Codable
{
    var nameTextSize : Int!
    var nameTextColor : String!
    var nameFont : String!
    var jobDescriptionTextSize : Int!
    var jobDescriptionTextColor : String!
    var jobDescriptionFont : String!
    var authorsList : [AuthorModel] = []
    
    private enum CodingKeys : String, CodingKey {
        case nameTextSize = "AuthorNameTextSize"
        case nameTextColor = "AuthorNameTextColor"
        case nameFont = "AuthorNameFont"
        case jobDescriptionTextSize = "AuthorJobDescriptionTextSize"
        case jobDescriptionTextColor = "AuthorJobDescriptionTextColor"
        case jobDescriptionFont = "AuthorJobDescriptionFont"
        case authorsList = "AuthorsList"
    }
}
