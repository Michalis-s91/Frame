//
//  OfferModel.swift
//  RichReach2
//
//  Created by Eumbrella on 05/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// OfferModel saves data about offers like which partner is offer, the duration etc.
class OfferModel : Encodable, Equatable, Decodable
{
    static func ==(lhs: OfferModel, rhs: OfferModel) -> Bool {
        return lhs.appOfferID == rhs.appOfferID
    }
    
    var offerType : Int!
    var campaignID : Int64!
    var rowNumber : Int!
    var appOfferID : Int!   // Used for offer products.
    var productID : Int64! = 0// Used for eOrdering products.
    private var description : String! = ""
    var Description : String!
    {
        get
        {
            return self.description
        }
        set(description)
        {
            
            self.description = replaceBackslashSpecialCharacters(str: description)
        }
    }
    var imageUrl : String!
    var largeImageUrl : String!
    var originalPrice : String!
    var offerDescription : String!
    var extendedDescription : String!
    var offerNewPrice : String!
    var isStrikethrough : Bool! = false
    var partnerName : String!
    var isPrivate : Bool! = false
    var isGeneralOffer : Bool! = false
    var isPriceListOffer : Bool! = false
    var isNoPriceToShowOffer : Bool! = false
    var isSetOffer : Bool! = false
    private var isToAvoidOfferDetails : Bool! = true
    var IsToAvoidOfferDetails : Bool!
    {
        get
        {
            if (isGeneralOffer || isPriceListOffer || isNoPriceToShowOffer || isSetOffer)
            {
                self.isToAvoidOfferDetails = true
            }
            else
            {
                self.isToAvoidOfferDetails = false
            }
            
            return self.isToAvoidOfferDetails
        }
        set (toAvoidOfferDetails)
        {
            self.isToAvoidOfferDetails = toAvoidOfferDetails
        }
    }
    var duration : String!
    var isItemWatched : Bool = false
    var isSeen : Bool = false
    
    var isSms : Bool!
    var smsHeader : String!
    var smsBody : String!
    
    
    /// Returns the general offer title.
    ///
    /// - Returns: The general offer title.
    func getGeneralOfferTitle() -> String
    {
        if (isGeneralOffer)
        {
            return "Offer"
        }
        else if (isPriceListOffer)
        {
            return ""
        }
        else if (isSetOffer)
        {
            return "Combo Offer"
        }
        else if (isNoPriceToShowOffer)
        {
            return "Price On Request"
        }
        else
        {
            return ""
        }
    }
    
    /// Returns the new value of offer.
    ///
    /// - Returns: The new value of offer.
    func getOfferNewValue() -> String
    {
        if (isGeneralOffer || isPriceListOffer || isNoPriceToShowOffer || isSetOffer)
        {
            return offerDescription
        }
        return offerNewPrice
    }
    
    /// Returns if is general offer or not.
    ///
    /// - Returns: True if is not general offer, otherwise false.
    func isNotGeneralOffer() -> Bool
    {
        return !isToAvoidOfferDetails
    }
    
    private enum CodingKeys : String, CodingKey {
        case rowNumber = "RowNumber"
        case appOfferID = "ID"
        //case  = "CurrentValue"
        //case  = "StoreOfferID"
        //case  = "Timestamp"
        case description = "Description"
        case offerDescription = "OfferText"
        case extendedDescription = "ExtendedDescription"
        case partnerName = "PartnerName"
        //case  = "StoreItemID"
        //case = "OriginalPrice"
        case originalPrice = "OriginalPriceStr"
        case offerType = "StoreOfferTypeID"
        //case  = "Discount"
        //case  = "FreeUnit"
        //case  = "NewPrice"
        case offerNewPrice = "NewPriceStr"
        //case  = "ItemPercentageFree"
        //case  = "GeneralOfferDetails"
        case isGeneralOffer = "IsGeneralOffer"
        case isPriceListOffer = "IsPriceListOffer"
        case isNoPriceToShowOffer = "IsNoPriceToShowOffer"
        case isSetOffer = "IsSetOffer"
        //case  = "StartDate"
        //case  = "EndDate"
        case isStrikethrough = "IsStrikethrough"
        case campaignID = "CampaignID"
        case imageUrl = "ImageUrl"
        case largeImageUrl = "LargeImageUrl"
        //case  = "ReportID"
        //case isItemWatched = "IsSeen"
        //case  = "Barcode"
        case duration = "Duration"
        case isSeen = "IsSeen"
        case isSms = "IsSms"
        case smsHeader = "SmsHeader"
        case smsBody = "SmsBody"
    }
}
