//
//  Partner.swift
//  RichReach2
//
//  Created by Eumbrella on 20/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Holds information about partner, like partner ID, partner name and etc.
class Partner : Codable
{
    var id : Int!
    var partnerID : Int!
    var name : String!
    var isRoot : Bool!
    var isFavourite : Bool!
    var information : String!
    var imageUri : String!
    var imageLargeUri : String!
    var stores : String!
    var phones : String!
    var addresses : String!
    var website : String!
    var optInDate : Date!
}
