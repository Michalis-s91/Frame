//
//  LeftDrawerTabs.swift
//  RichReach2
//
//  Created by Eumbrella on 10/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// String enumeration for left drawer tabs.
enum LeftDrawerTabsString : String
{
    case Offers = "Offers"
    case Businesses = "Businesses"
    case WishList = "Wish List"
    case History = "History"
    case Settings = "Settings"
    case Loyalty = "Loyalty"
    case Notifications = "Notifications"
    case HelpAndSupport = "Help & Support"
    case Profile = "My Personal Profile"
    case Barcode = "My Barcode"
    case About = "About"
}
