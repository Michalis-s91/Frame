//
//  WaitingView.swift
//  RichReach2
//
//  Created by Eumbrella on 22/10/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class WaitingViewController : UIViewController
{
    
    @IBOutlet var image: UIImageView!
    @IBOutlet var label: UILabel!
    @IBOutlet var indicator: UIActivityIndicatorView!
    
    var activityIdicator : UIActivityIndicatorView!
    var notAvailableView : NotAvailableModel!
    var labelText : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        notAvailableView = viewsDB.getNotAvailableView()
        
        if(notAvailableView != nil)
        {
            self.view.backgroundColor = UIColor(notAvailableView.backgroundColor)
            
            label.textColor = UIColor(notAvailableView.messageTextColor)
            label.font = UIFont (name: (notAvailableView.messageFont)!, size: CGFloat((notAvailableView.messageTextSize)!))
            
            //image.image = viewsDB.getNotAvailableImage()
        }
        
        activityIdicator = UIActivityIndicatorView(frame: CGRect(x: self.view.center.x ,y: self.view.center.y, width : 50, height: 50)) as UIActivityIndicatorView
        activityIdicator.center = self.view.center
        activityIdicator.hidesWhenStopped = true
        activityIdicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
        //activityIdicator.startAnimating()
        self.view.addSubview(activityIdicator)
    }
    
    func showIndicator()
    {
        activityIdicator.startAnimating()
        image.image = UIImage(named: "")
        label.text = ""
    }
    
    func showInternetIsRequired()
    {
        activityIdicator.stopAnimating()
        label.text = labelText
        //indicator.stopAnimating()
        
        if(notAvailableView != nil)
        {
            if(!isNullOrEmpty(string: notAvailableView.image))
            {
                image.image = viewsDB.getNotAvailableImage()
            }
        }
    }
    
    func setText(text : String)
    {
        self.labelText = text
        //label.text = labelText
    }
}
