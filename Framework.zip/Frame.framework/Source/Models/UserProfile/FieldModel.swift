//
//  FieldModel.swift
//  RichReach2
//
//  Created by Eumbrella on 02/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class FieldModel : Codable
{
    
    var type : Int!
    var index : Int!
    var isDropDown : Bool!
    var dropDownItems : [String]?
    var dropDownItemsModel : [SingleTextModel]!
    var selectedDropDownItem : Int!
    var inputType : Int!
    var placeHolder : String!
    var isRequirement : Bool!
    var labelName : String!
    var styleID : Int!
    
    var value : String! = ""
    var isValueEmpty = false
    var fieldStyle : FieldStyleModel!
    
    var isVerified = false
    var verificationCode : String!
    var isValid = true
    
    private enum CodingKeys : String, CodingKey {
        case type = "FieldType"
        case index = "FieldIndex"
        case isDropDown = "IsDropDown"
        case dropDownItems = "DropDownItems"
        case inputType = "InputType"
        case placeHolder = "PlaceHolder"
        case isRequirement = "IsRequirement"
        case labelName = "LabelName"
        case styleID = "FieldStyleID"
    }
}
