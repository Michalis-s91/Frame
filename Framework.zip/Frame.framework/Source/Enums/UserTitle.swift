//
//  UserTitle.swift
//  RichReach
//
//  Created by Eumbrella on 18/12/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

enum UserTitle : Int
{
    case Mr = 1
    case Ms = 2
    case Mrs = 3
    case Miss = 4
}

func isTitleMale(titleID : Int) -> Bool
{
    return titleID == UserTitle.Mr.rawValue ? true : false
}

func isTitleFemale(titleID : Int) -> Bool
{
    return (titleID == UserTitle.Ms.rawValue || titleID == UserTitle.Mrs.rawValue || titleID == UserTitle.Miss.rawValue) ? true : false
}
