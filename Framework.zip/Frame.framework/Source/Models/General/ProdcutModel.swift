//
//  ProdcutModel.swift
//  RichReach2
//
//  Created by Eumbrella on 11/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

protocol Copying {
    init(original: Self)
}

extension Copying {
    func copy() -> Self {
        return Self.init(original: self)
    }
}

class ProductModel : Codable, Hashable, Copying
{
    required init(original: ProductModel) {
        self.webDescription = original.webDescription
        self.ingredientsText = original.ingredientsText
        self.productDescription = original.productDescription
        self.manufacturerName = original.manufacturerName
        self.overViewText = original.overViewText
        self.categoryCodeString = original.categoryCodeString
        self.itemNo = original.itemNo
        self.priceIncludingVAT = original.priceIncludingVAT
        self.productDescription = original.productDescription
        self.howToUseText = original.howToUseText
        self.imageA = original.imageA
        self.imageB = original.imageB
    }
    
    init() {
    
    }
    
    var hashValue: Int = 0
    
    
    
    static func == (lhs: ProductModel, rhs: ProductModel) -> Bool {
        return lhs.itemNo == rhs.itemNo
    }
    
    var itemNoString : String!
    var itemNo : Int64!
    //var barcode : String!
    var commonItemNo : String!
    var productDescription : String!
    var webDescription : String!
    var overViewText : String!
    var ingredientsText : String!
    var howToUseText : String!
    var categoryCodeString : String!
    var categoryCode : Int64!
    var familyCode : String!
    var manufacturerCode : String!
    var manufacturerName : String!
    var sapStatus : String!
    var imageA : String!
    var imageB : String!
    var availabilityForOnlineInt : Int!
    var availabilityForOnline : Bool!
    var priceIncludingVAT : Double!
    
    var category : CategoryModel!
    var category2 : ProductMenuModel!
    var brand : CategoryModel!
    
    var textColor : String!
    var textSize : Int!
    var backgroundColor : String!
    var font : String!
    
    var imageAspectRatio : Double! = 0
    var areInformationsDisplayed = false
    var informationList : [GeneralInformation2] = []
    
    var searchPoints : Int! = 0
    
    private enum CodingKeys : String, CodingKey {
        case itemNoString = "ItemNo"
        //case barcode = "Barcode"
        case commonItemNo = "CommonItemNo"
        case productDescription = "Description"
        case webDescription = "WEBDescription"
        case overViewText = "OverViewText"
        case ingredientsText = "IngredientsText"
        case howToUseText = "HowToUseText"
        case categoryCodeString = "ItemCategory"
        case familyCode = "ItemFamilyCode"
        case manufacturerCode = "ManufacturerCode"
        case manufacturerName = "ManufacturerName"
        case sapStatus = "ItemSAPStatus"
        case imageA = "ImageCodeA"
        case imageB = "ImageCodeB"
        case availabilityForOnlineInt = "AvailabilityForOnline"
        case priceIncludingVAT = "UnitPriceIncludingVAT"

    }
}
