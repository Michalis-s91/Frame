//
//  ListHoursModel.swift
//  RichReach2
//
//  Created by Eumbrella on 28/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class ListHoursModel : Codable
{
    var addressID : Int!
    var startTime1 : [String?]! = []
    var endTime1 : [String?]! = []
    var startTime2 : [String?]! = []
    var endTime2 : [String?]! = []
}
