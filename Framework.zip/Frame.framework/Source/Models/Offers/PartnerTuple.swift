//
//  PartnerTuple.swift
//  RichReach2
//
//  Created by Eumbrella on 21/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Class for saving data from unpacked string.
class PartnerTuple
{
    var item1 : Int!
    var item2 : String!
    var item3 : String!
    var item4 : String!
    
    
    /// Constructor. Initialises the properties of class.
    ///
    /// - Parameters:
    ///   - item1: The first item.
    ///   - item2: The second item.
    ///   - item3: The third item.
    ///   - item4: The fourth item.
    init(item1 : Int, item2 : String, item3 : String, item4 : String)
    {
        self.item1 = item1
        self.item2 = item2
        self.item3 = item3
        self.item4 = item4
    }
}
