//
//  BlogViewModel.swift
//  RichReach
//
//  Created by Eumbrella on 25/01/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

class BlogViewModel
{
    var blogView : BlogModel!
    var articlesList : [ArticleModel]! = []
    var articleViewList : [GeneralInformation2] = []
    
    var pageToLoad : Int = 2
    var tabID : Int!
    var ignoreLoadingMoreData = false
    var blogViewController : BlogViewController!
    
    func loadFromLocalDB() -> [GeneralInformation2]!
    {
        if(statusModel.areArticlesSaved)
        {
            blogView = viewsDB.getBlogView(tabID: tabID)
            articlesList = viewsDB.getBlogViewArticles(tabID: tabID, apk: APK)
            
            if(blogView != nil && articlesList != nil && articlesList.count > 0)
            {
                if(!isNullOrEmpty(string: blogView.image))
                {
                    let photo = GeneralInformation2()
                    photo.type = SlotType.Photo.rawValue
                    photo.photo = PhotoModel()
                    photo.photo.imageUrl = blogView.image
                    photo.photo.aspectRatio = blogView.imageAspectRatio
                    
                    articleViewList.append(photo)
                }
                else if (!isNullOrEmpty(string: blogView.title))
                {
                    let title = GeneralInformation2()
                    title.type = SlotType.Title.rawValue
                    title.title = TitleModel()
                    title.title.title = blogView.title
                    title.title.titleColor = blogView.titleColor
                    title.title.titleFont = blogView.titleFont
                    title.title.titleSize = blogView.titleSize
                    title.title.isTitleCentered = true
                    title.title.titleBackgroundColor = "#00000000"
                    
                    articleViewList.append(title)
                }
            }
        }
        
        if(articlesList != nil && articlesList.count > 0)
        {
            blogViewController.indicator.stopAnimating()
            for a in articlesList
            {
                var article = GeneralInformation2()
                
                article.type = SlotType.Article.rawValue
                article.article = a
                article.article.areItemsSaved = true
                
                articleViewList.append(article)
            }
        }
        else
        {
            pageToLoad = 1
            if (!ignoreLoadingMoreData)
            {
                ignoreLoadingMoreData = true
                var task = WebApiTask(viewController: blogViewController, action: blogViewController.loadMoreArticles, displayToast: false, isSynchronizationTimerEnabled: false)
                task.isFailureActionToast = false
                task.failureAction = setIgnoreLoadingMoreDataFlag
                task.start()
                
                //blogViewController.loadMoreArticles()
            }
        }
        
        return articleViewList
    }
    
    func loadMoreArticles()
    {
        do
        {
            var moreArticles : BlogView! = try ViewsWebApi.getBlogView(tabID: tabID ,pageToLoad: pageToLoad)
            
            if(moreArticles != nil && moreArticles?.blogViewsArticles != nil)
            {
                if((moreArticles?.blogViewsArticles.count)! > 0)
                {
                    if(moreArticles?.categories != nil)
                    {
                        viewsDB.insertArticlesCategories(articlesCategories: (moreArticles?.categories)!)
                    }
                    
                    if(pageToLoad == 1)
                    {
                        if(!isNullOrEmpty(string: moreArticles.image))
                        {
                            let photo = GeneralInformation2()
                            photo.type = SlotType.Photo.rawValue
                            photo.photo = PhotoModel()
                            photo.photo.imageUrl = moreArticles.image
                            
                            articleViewList.append(photo)
                        }
                        else if (!isNullOrEmpty(string: moreArticles.title))
                        {
                            let title = GeneralInformation2()
                            title.type = SlotType.Title.rawValue
                            title.title = TitleModel()
                            title.title.title = moreArticles.title
                            title.title.titleColor = moreArticles.titleTextColor
                            title.title.titleFont = moreArticles.titleFont
                            title.title.titleSize = moreArticles.titleTextSize
                            title.title.isTitleCentered = true
                            title.title.titleBackgroundColor = "#00000000"
                            
                            articleViewList.append(title)
                        }
                        
                        /*DispatchQueue.global(qos: .background).async {
                            do
                            {
                                self.saveArticles(blogView : moreArticles, tapID: self.tabID)
                            }catch
                            {}
                        }*/
                    }
                    
                    for m in (moreArticles?.blogViewsArticles!)!
                    {
                        var isArticleDuplicate = false
                        for a in articlesList
                        {
                            if (a.id == m.id)
                            {
                                isArticleDuplicate = true
                            }
                        }
                        
                        if(isArticleDuplicate)
                        {
                            continue
                        }
                        
                        var article = GeneralInformation2()
                        
                        article.type = SlotType.Article.rawValue
                        m.category = viewsDB.getArticleCategoryName(id:m.categoryID)
                        m.categoryFont = correctFontString(s: m.categoryFont)
                        m.titleFont = correctFontString(s: m.titleFont)
                        m.dateFont = correctFontString(s: m.dateFont)
                        article.article = m
                        article.article.areItemsSaved = false
                        
                        for item in article.article.articleItems
                        {
                            switch item.type
                            {
                            case SlotType.Text.rawValue:
                                item.text.titleFont = correctFontString(s: item.text.titleFont)
                                item.text.descriptionFont = correctFontString(s: item.text.descriptionFont)
                            case SlotType.Title.rawValue:
                                item.title.titleFont = correctFontString(s: item.title.titleFont)
                            default:
                                break
                            }
                        }
                        articlesList.append(article.article)
                        articleViewList.append(article)
                    }
                    
                    pageToLoad += 1
                    
                }
            }
            
            DispatchQueue.global(qos: .background).async {
                do
                {
                    try APKChanger.loadAuthors()
                }catch
                {}
            }
            
        }
        catch
        {
            ignoreLoadingMoreData = false
        }
    }
    
    func setIgnoreLoadingMoreDataFlag()
    {
        ignoreLoadingMoreData = false
    }
    
    func saveArticles(blogView : BlogView!, tapID : Int)
    {
        do
        {
            var blogModel = BlogModel()
            blogModel.tabID = tapID
            blogModel.image = blogView?.image
            blogModel.title = blogView?.title
            blogModel.titleFont = blogView?.titleFont
            blogModel.titleSize = blogView?.titleTextSize
            blogModel.titleColor = blogView?.titleTextColor
            
            var savedBlogModel = viewsDB.getBlogView(tabID: tapID)
            
            if((!isNullOrEmpty(string: blogView?.image) && savedBlogModel == nil) || (savedBlogModel != nil && !isNullOrEmpty(string: savedBlogModel!.image) && blogView?.image != savedBlogModel!.image))
            {
                blogModel.imageData = downloadImage3(url: (blogView?.image)!)
                blogModel.imageAspectRatio =  calculateImageAspectRatio(imageUrl: (blogView?.image)!)
            }
            else if(!isNullOrEmpty(string: blogView?.image)) //&& !isNullOrEmpty(string: savedBlogModel!.image))
            {
                blogModel.imageData = downloadImage3(url: (blogView?.image)!)
                blogModel.imageAspectRatio =  calculateImageAspectRatio(imageUrl: (blogView?.image)!)
            }
            
            viewsDB.insertBlogView(blogView : blogModel)
            
            var blogViewArticles : [BlogViewArticleModel] = []
            
            if(blogView?.blogViewsArticles != nil)
            {
                var savedArticles = viewsDB.getBlogViewArticles(tabID: tapID, apk: APK)
                
                if(savedArticles != nil && (savedArticles?.count)! > 0)
                {
                    for s in savedArticles!
                    {
                        var isArticleFound = false
                        for a in (blogView?.blogViewsArticles)!
                        {
                            if(a.id == s.id)
                            {
                                a.isArticleSaved = true
                                isArticleFound = true
                                var blogViewArticle = BlogViewArticleModel()
                                blogViewArticle.tabID = tabID
                                blogViewArticle.articleID = a.id
                                blogViewArticles.append(blogViewArticle)
                                
                                if(!isNullOrEmpty(string: a.image) && !isNullOrEmpty(string: s.image) && a.image != s.image)
                                {
                                    /*var imageProperties = downloadImage4(url: (a.image)!)
                                     a.imageData = imageProperties.data
                                     a.imageAspectRatio =  imageProperties.aspectRatio*/
                                    a.imageData = downloadImage3(url: (a.image)!)
                                    a.imageAspectRatio =  calculateImageAspectRatio(imageUrl: a.image)
                                }
                                else if(!isNullOrEmpty(string: a.image) && !isNullOrEmpty(string: s.image))
                                {
                                    a.imageData = s.imageData
                                    a.imageAspectRatio =  s.imageAspectRatio
                                }
                                
                                viewsDB.insertArticle(article: a)
                                
                                var articleItems : [ArticleItemModel] = []
                                s.articleItems = viewsDB.getGenealInformations(tabID: tabID, isArticle: true, articleID: a.id)
                                for g in a.articleItems
                                {
                                    var articleItem = ArticleItemModel()
                                    articleItem.articleID = a.id
                                    articleItem.index = g.index
                                    articleItem.type = g.type
                                    articleItem.id = g.id
                                    articleItem.productItemCode = g.productItemCode
                                    articleItems.append(articleItem)
                                    
                                    var isSaved = false
                                    if(g.type == SlotType.Photo.rawValue)
                                    {
                                        for i in s.articleItems
                                        {
                                            if(i.type == SlotType.Photo.rawValue)
                                            {
                                                if(g.photo.imageUrl == i.photo.imageUrl)
                                                {
                                                    isSaved = true
                                                    
                                                    g.photo.aspectRatio = i.photo.aspectRatio
                                                    viewsDB.insertPhoto(id: g.id, photo: g.photo)
                                                    viewsDB.insertImage(url: g.photo.imageUrl, str: viewsDB.getImageData(url: i.photo.imageUrl))
                                                }
                                            }
                                        }
                                    }
                                    
                                    if(!isSaved)
                                    {
                                        do
                                        {
                                            try APKChanger.getSlot(slot: g, article : a)
                                        }
                                        catch{}
                                    }
                                }
                                
                                viewsDB.insertArticleItems(articleItems: articleItems)
                                break
                            }
                        }
                        
                        if(!isArticleFound)
                        {
                            viewsDB.deleteArticle(apk: APK, articleID: s.id, tabID: tabID)
                        }
                        
                    }
                    
                    for a in (blogView?.blogViewsArticles)!
                    {
                        if(!a.isArticleSaved)
                        {
                            var blogViewArticle = BlogViewArticleModel()
                            blogViewArticle.tabID = tapID
                            blogViewArticle.articleID = a.id
                            blogViewArticles.append(blogViewArticle)
                            
                            if(!isNullOrEmpty(string: a.image))
                            {
                                /*var imageProperties = downloadImage4(url: (a.image)!)
                                 a.imageData = imageProperties.data
                                 a.imageAspectRatio =  imageProperties.aspectRatio*/
                                a.imageData = downloadImage3(url: (a.image)!)
                                a.imageAspectRatio =  calculateImageAspectRatio(imageUrl: a.image)
                            }
                            
                            viewsDB.insertArticle(article: a)
                            
                            var articleItems : [ArticleItemModel] = []
                            
                            for g in a.articleItems
                            {
                                var articleItem = ArticleItemModel()
                                articleItem.articleID = a.id
                                articleItem.index = g.index
                                articleItem.type = g.type
                                articleItem.id = g.id
                                articleItem.productItemCode = g.productItemCode
                                articleItems.append(articleItem)
                                
                                try APKChanger.getSlot(slot: g, article : a)
                            }
                            
                            viewsDB.insertArticleItems(articleItems: articleItems)
                        }
                    }
                    
                }
                else
                {
                    for a in (blogView?.blogViewsArticles)!
                    {
                        var blogViewArticle = BlogViewArticleModel()
                        blogViewArticle.tabID = tapID
                        blogViewArticle.articleID = a.id
                        blogViewArticles.append(blogViewArticle)
                        
                        if(!isNullOrEmpty(string: a.image))
                        {
                            /*var imageProperties = downloadImage4(url: (a.image)!)
                             a.imageData = imageProperties.data
                             a.imageAspectRatio =  imageProperties.aspectRatio*/
                            a.imageData = downloadImage3(url: (a.image)!)
                            a.imageAspectRatio =  calculateImageAspectRatio(imageUrl: a.image)
                        }
                        
                        viewsDB.insertArticle(article: a)
                        
                        var articleItems : [ArticleItemModel] = []
                        
                        for g in a.articleItems
                        {
                            var articleItem = ArticleItemModel()
                            articleItem.articleID = a.id
                            articleItem.index = g.index
                            articleItem.type = g.type
                            articleItem.id = g.id
                            articleItem.productItemCode = g.productItemCode
                            articleItems.append(articleItem)
                            
                            try APKChanger.getSlot(slot: g, article : a)
                        }
                        
                        viewsDB.insertArticleItems(articleItems: articleItems)
                    }
                }
            }
            
            viewsDB.insertBlogViewArticles(blogViewArticles: blogViewArticles)
            
        }catch
        {
            
        }
    }
}
