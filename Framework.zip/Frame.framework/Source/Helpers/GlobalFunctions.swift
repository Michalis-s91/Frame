//
//  GlobalFunctions.swift
//  RichReach2
//
//  Created by Eumbrella on 09/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import Kingfisher
import ImageIO
import CoreLocation

/// Returns whether the activity that created the task is still active.
///
/// - Parameter viewController: The activity.
/// - Returns: True if the activity is active, otherwise false.
func isActivityActive(viewController : UIViewController ) -> Bool
{
    var isActive : Bool!
    
    DispatchQueue.main.async(execute: {() -> Void in
        if (viewController.viewIfLoaded?.window != nil)
        {
            isActive = true
        }
        else
        {
            isActive = false
        }
    })
    
    while (isActive == nil)
    {
        
    }
    return isActive
}

/// Checks if object1 is equal with object2.
///
/// - Parameters:
///   - object1: The first object.
///   - object2: The second object.
/// - Returns: True if both objects are null or equal, otherwise false.
func areEqual(object1 : AnyObject! ,object2 : AnyObject!) -> Bool
{
    if (object1 == nil && object2 == nil)
    {
        return true
    }
    else if ((object1 == nil && object2 != nil) || (object1 != nil && object2 == nil) || !(object1.isEqual(object2) ))
    {
        return false
    }
    else
    {
        return true
    }
}

/// Remove quotes characters from input string
///
/// - Parameter message: The string we have to process.
/// - Returns: String without quotes.
func removeQuotesCharacters(message : String) -> String
{
    if(!isNullOrEmpty( string : message))
    {
        return message.replacingOccurrences(of: "\"", with: " ")
    }
    
    return message
}

/// Removes special characters from the input string and returns the updated string.
///
/// - Parameter inputString: The input string.
/// - Returns: The updated string.
func getUpdatedJsonStr(inputString : String) -> String
{
    if (isNullOrEmpty(string: inputString) || inputString.lowercased() == "null")
    {
        return ""
    }
    
    var outputString = inputString.replacingOccurrences(of: "|", with: "\"")
    outputString = outputString.replacingOccurrences(of: "\\\\",with: "\\")
    //outputString = outputString.replacingOccurrences(of: "'",with: "")
    //outputString = outputString.replacingOccurrences(of: "'",with: "")
    //outputString = outputString.replacingOccurrences(of: "\n",with: "")
    //outputString = outputString.replacingOccurrences(of: "\t",with: "")
    //outputString = outputString.replacingOccurrences(of: "{",with: "[")
    //outputString = outputString.replacingOccurrences(of: "}",with: "]")
    if(outputString[0] == "\"")
    {
        outputString = String(outputString.dropFirst(1))
    }
    
    if(outputString[outputString.count - 1] == "\"")
    {
        outputString = String(outputString.dropLast())
    }
    
    return  outputString//System.Text.RegularExpressions.Regex.Unescape(outputString)
}


/// Creates image with inpout color and returns that image.
///
/// - Parameters:
///   - color: The color of image.
///   - size: The size of image.
/// - Returns: The image with color.
func imageWithColor(color: UIColor, size: CGSize = CGSize(width: 60, height: 60)) -> UIImage {
    let rect = CGRect(x: 0,y: 0, width: size.width,height: size.height)
    UIGraphicsBeginImageContext(rect.size)
    let context = UIGraphicsGetCurrentContext()
    
    context!.setFillColor(color.cgColor)
    context!.fill(rect)
    
    let image = UIGraphicsGetImageFromCurrentImageContext()
    
    UIGraphicsEndImageContext()
    
    return image!
}

/// Check if input string is null or empty
///
/// - Parameter string: The string we want to check.
/// - Returns: True if string is null or empty, otherwise return false.
func isNullOrEmpty (string : String!) -> Bool{
    if(string == nil || string.isEmpty)
    {
        return true
    }
    else
    {
        return false
    }
}


/// Rounds the corners of given UIView.
///
/// - Parameters:
///   - corners: The corners we want to round.
///   - radius: The radious of rounded corners.
///   - view: The UIView we want to round the corners.
func roundCorners(_ corners: UIRectCorner, radius: CGFloat, view : UIView) {
    let path = UIBezierPath(roundedRect: view.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
    let mask = CAShapeLayer()
    mask.path = path.cgPath
    view.layer.mask = mask
    view.layer.masksToBounds = true
}


/// Resize the given image to given size (with scale).
///
/// - Parameters:
///   - image: The image.
///   - targetSize: The size we want.
/// - Returns: The resized image.
func resizeImage(image: UIImage, targetSize: CGSize) -> UIImage {
    let size = image.size
    
    let widthRatio  = targetSize.width  / size.width
    let heightRatio = targetSize.height / size.height
    
    // Figure out what our orientation is, and use that to form the rectangle
    var newSize: CGSize
    if(widthRatio > heightRatio) {
        newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
    } else {
        newSize = CGSize(width: size.width * widthRatio, height: size.height * widthRatio)
    }
    
    // This is the rect that we've calculated out and this is what is actually used below
    let rect = CGRect(x :0, y: 0, width: newSize.width, height: newSize.height)
    
    // Actually do the resizing to the rect using the ImageContext stuff
    UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
    image.draw(in: rect)
    let newImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    
    return newImage!
}

/// Resize the given image to given size (without scale).
///
/// - Parameters:
///   - image: The image.
///   - targetSize: The size we want.
/// - Returns: The resized image.
func resizeImage2(image: UIImage, targetSize: CGSize) -> UIImage {
    let newSize = CGSize(width: targetSize.width, height: targetSize.height)
    
    
    // This is the rect that we've calculated out and this is what is actually used below
    let rect = CGRect(x :0, y: 0, width: newSize.width, height: newSize.height)
    
    // Actually do the resizing to the rect using the ImageContext stuff
    UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
    image.draw(in: rect)
    let newImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    
    return newImage!
}

/// Replace new line special characters with the proper characters.
///
/// - Parameter str: The input string.
/// - Returns: The string with proper characters.
public func replaceBackslashSpecialCharacters(str : String) -> String!
{
    var result : String!
    
    if (!isNullOrEmpty(string: str))
    {
        //replacingOccurrences(of: "\\n", with: "\n")
        result = str
        result = result.replacingOccurrences(of: "\\n", with: "\n")
        result = result.replacingOccurrences(of: "\\r", with: "\r")
        result = result.replacingOccurrences(of: "\\0", with: "\0")
        //result = str.replacingOccurrences(of: "\\b", with: "b")
        //result = str.replacingOccurrences(of: "\\f", with: "f")
        result = result.replacingOccurrences(of: "\\t", with: "\t")
        result = result.replacingOccurrences(of: "\\\"", with: "\"")
        result = result.replacingOccurrences(of: "\\\'", with: "\'")
    }
    
    return result
}


/// Scales input image to given size.
///
/// - Parameters:
///   - image: The image.
///   - size: The size we want.
/// - Returns: The scaled image.
func scaleUIImageToSize( image: UIImage, size: CGSize) -> UIImage {
    let hasAlpha = false
    let scale: CGFloat = 0.0 // Automatically use scale factor of main screen
    
    UIGraphicsBeginImageContextWithOptions(size, !hasAlpha, scale)
    image.draw(in: CGRect(origin: CGPoint.zero, size: size))
    
    let scaledImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    
    return scaledImage!
}

class APKChanger : UIViewController, UIWebViewDelegate
{
    static var webView = UIWebView()
    static var viewControllerTemp : ViewController!
    static var launchScreenTemp : UIViewController!
    static var launchScreenTemp2 : UIViewController!
    static var splashViewParameters : SplashViewParametersModel!
    static var downloadGroup : DispatchGroup = DispatchGroup()
    static var runnable : Runnable!
    static var runnableWithThrow : RunnableWithThrow!
    static var failureRunnable : Runnable!
    static var numOfTries = 0
    static var APKTemp : String!
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        for subview:UIView in webView.scrollView.subviews {
            if (subview is UIScrollView) {
                for shadowView: UIView in subview.subviews {
                    if (shadowView is UIImageView) {
                        shadowView.isHidden = true
                    }
                }
            }
            
            subview.layer.shadowOpacity = 0
            for subsubview in subview.subviews {
                subsubview.layer.shadowOpacity = 0
            }
        }
    }
    
    static func backToRichReach(viewController : ViewController)
    {
        var launchScreen : UIViewController!
        //let LaunchScreenStoryBoard = UIStoryboard(name: "OverlaySplashScreen", bundle: nil)
        
        switch APK {
        case APKsEnum.RichReach.rawValue:
            let LaunchScreenStoryBoard2 = UIStoryboard(name: "RichReachLaunchScreen", bundle: nil)
            launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
        case APKsEnum.BeautyLine.rawValue :
            let LaunchScreenStoryBoard2 = UIStoryboard(name: "BeautyLineLaunchScreen", bundle: nil)
            launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
        case APKsEnum.HollandAndBarrett.rawValue :
            let LaunchScreenStoryBoard2 = UIStoryboard(name: "HollandAndBarrettLaunchScreen", bundle: nil)
            launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
        default:
            let LaunchScreenStoryBoard2 = UIStoryboard(name: "RichReachLaunchScreen", bundle: nil)
            launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
        }
        
        var splashViewParameters = parameterizationDatabase.getSplashViewParameters()
        
        func dismiss()
        {
            launchScreen.dismiss(animated: true, completion: nil)
        }
        
        viewController.present(launchScreen, animated: true, completion: { () in
            
            let LaunchScreenStoryBoard = UIStoryboard(name: "OverlaySplashScreen", bundle: nil)
            var launchScreen2 : OverlaySplashViewController! = LaunchScreenStoryBoard.instantiateViewController(withIdentifier: "OverlaySplashView") as? OverlaySplashViewController
            
            if(splashViewParameters != nil)
            {
                launchScreen2.splashViewParameters = splashViewParameters
                launchScreen2.finishedRunnable = dismiss
                launchScreen.present(launchScreen2, animated: true, completion: nil)
            }
            
            let initializer = APKInitializer()
            
            LeftDrawerViewController.leftDrawerGroupTabs.removeAll()
            LeftDrawerViewController.leftDrawerGroupTabsID.removeAll()
            
            APKInitializer.setProperties()
            
            if(APK != Bundle.main.bundleIdentifier!)
            {
                LeftDrawerViewController.leftDrawerGroupTabs.append("BACK TO RICHREACH")
                LeftDrawerViewController.leftDrawerGroupTabsID.append(-1)
            }
            
            if(viewControllerTemp != nil)
            {
                viewControllerTemp.viewDidLoad()
            }
            
            leftDrawer.viewDidLoad()
            leftDrawer.tableView.reloadData()
            leftDrawer.selectTab(tabString: leftDrawer.leftDrawerTabsList[0].name)
            
            if(selectedTab.isChild && selectedTab.showAtTabbar)
            {
                CustomTabbarViewController.currentIndex = 0
            }
            
            viewController.showView(tab: selectedTab, index: 0)
            
            if(splashViewParameters == nil)
            {
                launchScreen.dismiss(animated: true, completion: nil)
            }
        })
    }
    
    static func handleError()
    {
        if(APK != Bundle.main.bundleIdentifier &&  APK != APKsEnum.Test.rawValue)
        {
            APK = Bundle.main.bundleIdentifier!
            clientID = ClientIDs.RichReach.rawValue
            
            statusModel = statusDB.getStatus(apk: APK)
            
            let initializer = APKInitializer()
            
            LeftDrawerViewController.leftDrawerGroupTabs.removeAll()
            LeftDrawerViewController.leftDrawerGroupTabsID.removeAll()
            
            APKInitializer.setProperties()
            
            if(APK != Bundle.main.bundleIdentifier!)
            {
                LeftDrawerViewController.leftDrawerGroupTabs.append("BACK TO RICHREACH")
                LeftDrawerViewController.leftDrawerGroupTabsID.append(-1)
            }
            
            if(viewControllerTemp != nil)
            {
                viewControllerTemp.viewDidLoad()
            }
            
            leftDrawer.viewDidLoad()
            leftDrawer.tableView.reloadData()
            leftDrawer.selectTab(tabString: leftDrawer.leftDrawerTabsList[0].name)
            
            //viewControllerTemp.tabbar.viewDidLoad()
            
            if(selectedTab.isChild && selectedTab.showAtTabbar)
            {
                CustomTabbarViewController.currentIndex = 0
            }
        }
        
        areParametersDownloading = false
        
        
        /*if(APK == APKsEnum.RichReach.rawValue && viewControllerTemp != nil)
         {
         
         }*/
        
        //viewController.showView(tab: selectedTab, index: 0)
        
        if(launchScreenTemp2 != nil)
        {
            /*if(!statusModel.isAPKSaved)
             {
             UIView.animate(withDuration: 5, animations: {
             launchScreenTemp2.dismiss(animated: true, completion: { () in
             launchScreenTemp.dismiss(animated: true, completion: { () in
             //if(viewControllerTemp != nil)
             //{
             failureRunnable()
             //}
             })
             })
             
             })
             }*/
            
            //if(!statusModel.isAPKSaved)
            //{
            launchScreenTemp2.dismiss(animated: true, completion: { () in
                launchScreenTemp.dismiss(animated: true, completion: { () in
                    //if(viewControllerTemp != nil)
                    //{
                    failureRunnable()
                    //}
                })
            })
            //}
        }
        else
        {
            UIView.animate(withDuration: 2, animations: {
                launchScreenTemp.dismiss(animated: true, completion: { () in
                    //if(viewControllerTemp != nil)
                    //{
                    failureRunnable()
                    //}
                })
            })
            
        }
        
        
        
        /*if(launchScreenTemp2 != nil)
         {
         launchScreenTemp2.dismiss(animated: true, completion: nil)
         }
         
         launchScreenTemp.dismiss(animated: true, completion: nil)
         
         if(viewControllerTemp != nil)
         {
         let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
         let dialog = sb.instantiateInitialViewController()! as! MessageDialog
         dialog.dismissWhenClickOutside = false
         dialog.titleText = "Initialisation failed"
         dialog.descriptionText = "Internet connection was interupted during initialisation. Please ensure your internet connection is active and try again."
         dialog.buttonText = NSLocalizedString("ok", comment: "")
         viewControllerTemp.present(dialog,animated:true)
         }*/
    }
    
    static func handleError2()
    {
        if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
        {
            sleep(5)
            numOfTries += 1
            if(numOfTries < 3)
            {
                areParametersDownloading = true
                getRestViews()
            }
            else
            {
                areParametersDownloading = false
                errorOccured = true
                
                if(waitingViewController != nil)
                {
                    DispatchQueue.main.async(execute: {() -> Void in
                        waitingViewController.setText(text: "An error has occured. Please try again later...")
                        waitingViewController.showInternetIsRequired()
                    })
                }
            }
        }
    }
    
    static func downloadParameters (viewController : ViewController! = nil , launchScreen : UIViewController, failureAction : @escaping Runnable) throws
    {
        do
        {
            APKTemp = APK
            
            if(!areParametersDownloading)
            {
                areParametersDownloading = true
            }
            
            if(localDatabase.getAppUser() == nil)
            {
                localDatabase.addAppUser(appUser: AppUser())
            }
            
            numOfImages = 0
            errorHandled = false
            numOfTries = 0
            errorOccured2 = false
            
            viewControllerTemp = viewController
            launchScreenTemp = launchScreen
            launchScreenTemp2 = nil
            failureRunnable = failureAction
            generalViewsIDsNeedUpdate = []
            
            statusModel = statusDB.getStatus(apk: APK)
            
            if(!statusModel.areSplashScrennParametersSaved)
            {
                splashViewParameters = try ViewsWebApi.getSplashViewParameters()
                parameterizationDatabase.insertSplashViewParameters(splashViewParameters: splashViewParameters)
                
                runnable = continueDownloading
                try getGeneralViews(isSplashView: true)
                
                if(errorOccured2)
                {
                    throw Errors.error
                }
                
                statusModel.areSplashScrennParametersSaved = true
                statusDB.insertStatus(status: statusModel, apk: APK)
            }
            else
            {
                splashViewParameters = parameterizationDatabase.getSplashViewParameters()
                continueDownloading()
            }
            
        }
        catch
        {
            handleError()
            throw Errors.error
        }
        
    }
    
    static func continueDownloading()
    {
        if(splashViewParameters != nil && splashViewParameters.time != 0)
        {
            let LaunchScreenStoryBoard = UIStoryboard(name: "OverlaySplashScreen", bundle: nil)
            let launchScreen2 =  LaunchScreenStoryBoard.instantiateViewController(withIdentifier: "OverlaySplashView") as! OverlaySplashViewController
            launchScreen2.splashViewParameters = splashViewParameters
            
            if(viewControllerTemp == nil)
            {
                launchScreen2.finishedRunnable = appDelegate.showFirstTab
            }
            
            launchScreenTemp2 = launchScreen2
            
            DispatchQueue.main.async(execute: {() -> Void in
                UIView.animate(withDuration: 2, animations: {
                    launchScreenTemp.present(launchScreenTemp2, animated: false, completion: { () in
                        DispatchQueue.global(qos: .background).async {
                            do
                            {
                                try setRestParamaters()
                            }
                            catch
                            {
                                handleError()
                            }
                        }
                    })
                })
            })
            
            
        }
        else
        {
            DispatchQueue.global(qos: .background).async {
                do
                {
                    try setRestParamaters()
                }
                catch
                {
                    handleError()
                }
            }
        }
        
    }
    
    static func setRestParamaters() throws
    {
        do
        {
            let initializer = APKInitializer()
            
            LeftDrawerViewController.leftDrawerGroupTabs.removeAll()
            LeftDrawerViewController.leftDrawerGroupTabsID.removeAll()
            
            if(!statusModel.areStylesSaved)
            {
                if(initializer.getProperties() == false)
                {
                    //handleError()
                    throw Errors.error
                }
                
                statusModel.areStylesSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            APKInitializer.setProperties()
            
            if(viewControllerTemp != nil)
            {
                let MainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
                
                if (leftDrawer == nil)
                {
                    leftDrawer = MainStoryBoard.instantiateViewController(withIdentifier: "LeftDrawerViewController") as? LeftDrawerViewController
                    if #available(iOS 11.0, *) {
                        leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: viewControllerTemp.view.safeAreaLayoutGuide.layoutFrame.size.height)
                    } else {
                        leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: viewControllerTemp.view.frame.size.height)
                    }
                }
                
                
                viewControllerTemp.tabbar2 = MainStoryBoard.instantiateViewController(withIdentifier: "Tabbar2") as? CustomTabbarViewController
                
                viewControllerTemp.tabbar2.view.frame = CGRect(x: 0, y: viewControllerTemp.view.frame.height, width: UIScreen.main.bounds.size.width, height: 50 )
                
                if(APK != Bundle.main.bundleIdentifier!)
                {
                    LeftDrawerViewController.leftDrawerGroupTabs.append("BACK TO RICHREACH")
                    LeftDrawerViewController.leftDrawerGroupTabsID.append(-1)
                }
                
                DispatchQueue.main.async(execute: {() -> Void in
                    viewControllerTemp.viewDidLoad()
                    
                    leftDrawer.viewDidLoad()
                    leftDrawer.tableView.reloadData()
                    leftDrawer.selectTab(tabString: leftDrawer.leftDrawerTabsList[0].name)
                    
                    if(selectedTab.isChild && selectedTab.showAtTabbar)
                    {
                        CustomTabbarViewController.currentIndex = 0
                    }
                })
                
            }
            
            if(!(statusModel?.areContactUsTabRelationsSaved)!)
            {
                let contactUsTabRelations = try ViewsWebApi.getContactUsTabRelations()
                viewsDB.insertContactUsTabRelations(contactUsTabRelations:contactUsTabRelations)
                statusModel.areContactUsTabRelationsSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            if(!(statusModel?.isContactUsViewSaved)!)
            {
                let contactUsView = try ViewsWebApi.getContactUsView()
                viewsDB.insertContactUsView(contactUsView: contactUsView)
                
                statusModel.isContactUsViewSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            if(!(statusModel?.isNotAvailableViewSaved)!)
            {
                let notAvailableView = try ViewsWebApi.getNotAvailableView()
                try viewsDB.insertNotAvailableView(notAvailableView: notAvailableView)
                
                statusModel.isNotAvailableViewSaved = true
                statusDB.insertStatus(status: statusModel, apk: APK)
            }
            
            if(!(statusModel?.isBarcodeViewSaved)!)
            {
                let barcodeView = try ViewsWebApi.getBarcodeView()
                viewsDB.insertBarcodeView(barcodeView: barcodeView)
                statusModel.isBarcodeViewSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            if(!(statusModel?.areEmbededViewsSaved)!)
            {
                let embededViews = try ViewsWebApi.getEmbededViews()
                viewsDB.insertEmbededGeneralViews(embededGeneralViews: embededViews)
                statusModel.areEmbededViewsSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            if(!(statusModel?.areEmbededViewsParametersSaved)!)
            {
                let embededViewsParameters = try ViewsWebApi.getEmbededViewsParameters()
                viewsDB.insertEmbededViewsParameters(embededViewsParameters: embededViewsParameters)
                statusModel.areEmbededViewsParametersSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            if(!(statusModel?.isPointsStatementViewSaved)!)
            {
                let pointsStatementView = try LoyaltyWebApi.getPointsStamentView()
                loyaltyDB.insertPointsStatementView(pointsStatementView: pointsStatementView)
                statusModel.isPointsStatementViewSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            if(!(statusModel?.isTicketViewSaved)!)
            {
                let ticketView = try LoyaltyWebApi.getTicketView()
                loyaltyDB.insertTicketView(ticketView: ticketView)
                statusModel.isTicketViewSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            if(!(statusModel?.areTicketStylesSaved)!)
            {
                let ticketStyles = try LoyaltyWebApi.getTicketStyles()
                loyaltyDB.insertTicketStyles(ticketStyles: ticketStyles)
                statusModel.areTicketStylesSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            if(!(statusModel?.areGeneralSearchViewSaved)!)
            {
                let generalSearchViews = try ViewsWebApi.getGeneralSearchView()
                viewsDB.insertGeneralSearchViews(generalSearchViews : generalSearchViews)
                statusModel.areGeneralSearchViewSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
                
                let signupBonus = try ParameterizationWebApi.getSignupBonus()
                try parameterizationDatabase.insertSignupBonus(signupBonus: signupBonus)
            }
            
            if(!(statusModel?.isUserProfileViewSaved)!)
            {
                //APK = "test"
                let userProfileView = try UserProfileWebApi.getUserProfileView()
                
                if(userProfileView != nil)
                {
                    //APK = APKTemp
                    userProfileDB.insertVerificationView(verificationView: userProfileView?.verificationViewList)
                    
                    if(userProfileView?.checkBoxGroupsList != nil)
                    {
                        viewsDB.insertCheckBoxGroups(checkBoxGroupsList: userProfileView?.checkBoxGroupsList)
                    }
                    
                    for u in (userProfileView?.userProfileViewList!)!
                    {
                        switch u.type
                        {
                        case UserProfileCellType.RadioButton.rawValue:
                            if(u.radioButton.name == nil && u.radioButton.imageUrl != nil)
                            {
                                u.radioButton.imageAspectRatio = calculateImageAspectRatio(imageUrl: percentEncode(s: u.radioButton.imageUrl))
                                downloadImage(url: u.radioButton.imageUrl)
                                
                                if(errorOccured2)
                                {
                                    throw Errors.error
                                }
                            }
                            
                            viewsDB.insertRadioButton(radioButton: u.radioButton)
                        case UserProfileCellType.CheckBox.rawValue:
                            if(!isNullOrEmpty(string: u.checkBox.imageUrl))
                            {
                                u.checkBox.imageAspectRatio = calculateImageAspectRatio(imageUrl: percentEncode(s: u.checkBox.imageUrl))
                                u.checkBox.imageData = downloadImage3(url: u.checkBox.imageUrl)
                                
                                if(errorOccured2)
                                {
                                    throw Errors.error
                                }
                            }
                            
                            viewsDB.insertCheckBox(id: u.id1, checkBox: u.checkBox)
                        default:
                            break
                        }
                    }
                    
                    userProfileDB.insertUserProfileView(userProfileView: userProfileView!.userProfileViewList)
                    statusModel.isUserProfileViewSaved = true
                    statusDB.insertStatus(status : statusModel, apk : APK)
                    
                    
                    if(!(statusModel?.areUserProfileFieldsSaved)!)
                    {
                        //let userProfileFields = try UserProfileWebApi.getUserProfileFields()
                        userProfileDB.insertFields(fields: userProfileView?.fieldsList)
                        statusModel.areUserProfileFieldsSaved = true
                        statusDB.insertStatus(status : statusModel, apk : APK)
                    }
                    
                    if(!(statusModel?.areUserProfileFieldsStylesSaved)!)
                    {
                        //let userProfileFieldsStyle = try UserProfileWebApi.getUserProfileFieldsStyles()
                        userProfileDB.insertFieldsStyles(fieldsStyles: userProfileView?.fieldsStylesList)
                        statusModel.areUserProfileFieldsStylesSaved = true
                        statusDB.insertStatus(status : statusModel, apk : APK)
                    }
                    
                    if(localDatabase.isAPKVerified(clientID: clientID)!)
                    {
                        let itemsTemp = userProfileDB.getVerificationView()
                        if(itemsTemp != nil)
                        {
                            var isRegistered = true
                            var appUser = localDatabase.getAppUser()
                            
                            for i in itemsTemp!
                            {
                                if(i.type == UserProfileCellType.Field.rawValue)
                                {
                                    let field = i.fields[0]
                                    //field.fieldStyle.asteriskColor = "#00000000"
                                    
                                    if(field.type == UserProfileFieldType.Phoneumber.rawValue && !appUser!.hasVerifiedPhoneNumber)
                                    {
                                        isRegistered = false
                                    }
                                    else if(field.type == UserProfileFieldType.Email.rawValue && !appUser!.hasVerifiedEmailAddress)
                                    {
                                        isRegistered = false
                                    }
                                }
                            }
                            
                            if(!isRegistered)
                            {
                                localDatabase.deleteRegisteredAPK()
                            }
                        }
                        
                    }
                }
                
                
            }
            
            
            if(!(statusModel?.isFirstViewSaved)!)
            {
                waitingForImages = true
                runnable = dismissSplash
                try self.getFirstView()
                
                statusModel.isFirstViewSaved = true
                statusDB.insertStatus(status: statusModel, apk: APK)
            }
            else
            {
                dismissSplash()
            }
            
        }
        catch
        {
            //handleError()
            throw Errors.error
        }
    }
    
    static func dismissSplash()
    {
        if(errorOccured2)
        {
            errorOccured2 = false
            statusModel.isFirstViewSaved = false
            statusDB.insertStatus(status: statusModel, apk: APK)
            
            handleError()
            return
        }
        
        /*if(launchScreenTemp2 != nil)
         {
         if(!statusModel.isAPKSaved)
         {
         UIView.animate(withDuration: 5, animations: {
         launchScreenTemp2.dismiss(animated: true, completion: { () in
         launchScreenTemp.dismiss(animated: true, completion: nil)
         })
         
         }) { _ in
         
         }
         }
         }
         else
         {
         UIView.animate(withDuration: 5, animations: {
         launchScreenTemp.dismiss(animated: true, completion: nil)
         }) { _ in
         
         }
         
         }*/
        
        if(!statusModel.isAPKSaved)
        {
            statusModel.isAPKSaved = true
            statusDB.insertStatus(status : statusModel, apk : APK)
        }
        
        /*if(viewControllerTemp == nil)
         {
         appDelegate.showFirstTab()
         }*/
        
        //UIView.animate(withDuration: 5, animations: {
        //    launchScreenTemp.dismiss(animated: true, completion: nil)
        //}) { _ in
        
        //}
        
        
        
        if(viewControllerTemp != nil)
        {
            isViewPushed = false
            ViewController.viewDidAppear = false
            ViewController.viewDidAppear2 = false
            
            DispatchQueue.main.async(execute: {() -> Void in
                viewControllerTemp.showView(tab: selectedTab, index: 0, showingEmbeded : true)
                
                if(launchScreenTemp2 == nil)
                {
                    launchScreenTemp.dismiss(animated: true, completion: nil)
                }
            })
            
        }
        else if (launchScreenTemp2 == nil)
        {
            appDelegate.showFirstTab()
        }
        
        getRestViews()
    }
    
    static func getRestViews()
    {
        errorOccured = false
        
        if(!areParametersDownloading)
        {
            areParametersDownloading = true
        }
        
        if(APKTemp != nil && APKTemp != APK)
        {
            return
        }
        
        
        if(localDatabase.isAPKVerified(clientID: clientID))
        {
            do
            {
                var appUser = localDatabase.getAppUser()
                var userInformations : UserProfileModel2! = UserProfileWebApi.getUserProfile2(clientID: clientID, phoneNumber: appUser?.phoneNumber, emailAddress: (appUser?.hasVerifiedEmailAddress)! ? appUser?.emailAddress : "", mustUserBelongToBusiness: false, apkID: businessID, timeout: 60)
                
                if(userInformations != nil)
                {
                    localDatabase.insertVerifiedAPK(bussinessID: clientID, isBlocked : userInformations.isBlocked )
                }
            } catch{}
        }
        
        generalViewsIDsNeedUpdate = []
        
        let leftDrawerTabs = parameterizationDatabase.getLeftDrawerTabs(apk: APK)
        
        if(leftDrawerTabs != nil)
        {
            if(!statusModel.isHomeSaved)
            {
                for t in leftDrawerTabs!
                {
                    if(t.tabType == TabType.Home.rawValue)
                    {
                        generalViewsIDsNeedUpdate.append(t.id)
                    }
                }
            }
            
            if(!statusModel.isOffersSaved)
            {
                for t in leftDrawerTabs!
                {
                    if(t.tabType == TabType.Offers.rawValue)
                    {
                        generalViewsIDsNeedUpdate.append(t.id)
                    }
                }
            }
            
            if(!statusModel.isAboutSaved)
            {
                for t in leftDrawerTabs!
                {
                    if(t.tabType == TabType.About.rawValue)
                    {
                        generalViewsIDsNeedUpdate.append(t.id)
                    }
                }
            }
            
            if(!statusModel.isRedemptionSaved)
            {
                for t in leftDrawerTabs!
                {
                    if(t.tabType == TabType.RedemptionPolicy.rawValue)
                    {
                        generalViewsIDsNeedUpdate.append(t.id)
                    }
                }
            }
            
            if(!statusModel.isTermsSaved)
            {
                for t in leftDrawerTabs!
                {
                    if(t.tabType == TabType.TermsAndConditions.rawValue)
                    {
                        generalViewsIDsNeedUpdate.append(t.id)
                    }
                }
            }
        }
        
        if(APKTemp != nil && APKTemp != APK)
        {
            return
        }
        
        DispatchQueue.global(qos: .background).async {
            do
            {
                if(!(statusModel?.areGeneralViewsSaved)!)
                {
                    waitingForImages = true
                    print("set runnable")
                    runnable = continueDownloading2
                    
                    try self.getGeneralViews()
                }
                else
                {
                    continueDownloading2()
                }
            }
            catch
            {
                areParametersDownloading = false
                handleError2()
            }
        }
    }
    
    static func continueDownloading2()
    {
        do
        {
            print("Came here")
            if(errorOccured2)
            {
                throw Errors.error
            }
            
            if(APKTemp != nil && APKTemp != APK)
            {
                return
            }
            
            print("Came here")
            statusModel.isOffersSaved = true
            statusModel.isHomeSaved = true
            statusModel.isAboutSaved = true
            statusModel.isTermsSaved = true
            statusModel.isRedemptionSaved = true
            
            if(!(statusModel?.areGeneralViewsSaved)!)
            {
                statusModel.areGeneralViewsSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            try getStoresInfo()
            
            if(APKTemp != nil && APKTemp != APK)
            {
                return
            }
            
            try getRestParameters2()
        }
        catch
        {
            areParametersDownloading = false
            handleError2()
        }
    }
    
    static func getProximityOffers() throws
    {
        do
        {
            var proximityOffersPage = 1
            let phoneNumber = localDatabase.getAppUser()?.phoneNumber
            var proximityOffers : [ProximityOfferModel]! = []
            
            repeat{
                proximityOffers = try StoresWepApi.getProximityOffers(clientID: clientID, pageNumber: proximityOffersPage, userPhone: phoneNumber!)
                if (proximityOffers != nil){
                    storesDB.insertProximityOffers(proximityOffers: proximityOffers, businessID: businessID, apk: APK)
                    proximityOffersPage += 1
                }
                else {
                    break
                }
            }while proximityOffers.count > 0
            
            statusModel.areProximityOffersSaved = true
            statusDB.insertStatus(status : statusModel, apk : APK)
        }
        catch
        {
            throw Errors.error
        }
    }
    
    static func getStoresInfo() throws
    {
        do
        {
            if(!(statusModel?.areStoreLocatorParametersSaved)!)
            {
                let storeLocatorInfoParameters =  try StoresWepApi.getStoreLocatorInfoParameters(clientID: clientID)
                
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                viewsDB.insertStoreLocatorInfoParameters(storeLocatorInfoParameters: storeLocatorInfoParameters)
                statusModel.areStoreLocatorParametersSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            if(!(statusModel?.areProximityOffersSaved)! && (localDatabase.isAPKRegistered(bussinessID: clientID))!){
                try getProximityOffers()
            }
            
            
            if(!(statusModel?.areStoresSaved)!)
            {
                let stores = try StoresWepApi.getStores(clientID: clientID)
                let storesHours : [HoursModel]! = try StoresWepApi.getStoresHours(clientID: clientID)
                
                var listHoursTable : [ListHoursModel]! = []
                
                if(storesHours != nil)
                {
                    for s in storesHours
                    {
                        let listHours = ListHoursModel()
                        listHours.addressID = s.addressID
                        
                        listHours.startTime1.append(s.monStartTime1)
                        listHours.startTime1.append(s.tueStartTime1)
                        listHours.startTime1.append(s.wedStartTime1)
                        listHours.startTime1.append(s.thuStartTime1)
                        listHours.startTime1.append(s.friStartTime1)
                        listHours.startTime1.append(s.satStartTime1)
                        listHours.startTime1.append(s.sunStartTime1)
                        
                        listHours.endTime1.append(s.monEndTime1)
                        listHours.endTime1.append(s.tueEndTime1)
                        listHours.endTime1.append(s.wedEndTime1)
                        listHours.endTime1.append(s.thuEndTime1)
                        listHours.endTime1.append(s.friEndTime1)
                        listHours.endTime1.append(s.satEndTime1)
                        listHours.endTime1.append(s.sunEndTime1)
                        
                        listHours.startTime2.append(s.monStartTime2)
                        listHours.startTime2.append(s.tueStartTime2)
                        listHours.startTime2.append(s.wedStartTime2)
                        listHours.startTime2.append(s.thuStartTime2)
                        listHours.startTime2.append(s.friStartTime2)
                        listHours.startTime2.append(s.satStartTime2)
                        listHours.startTime2.append(s.sunStartTime2)
                        
                        listHours.endTime2.append(s.monEndTime2)
                        listHours.endTime2.append(s.tueEndTime2)
                        listHours.endTime2.append(s.wedEndTime2)
                        listHours.endTime2.append(s.thuEndTime2)
                        listHours.endTime2.append(s.friEndTime2)
                        listHours.endTime2.append(s.satEndTime2)
                        listHours.endTime2.append(s.sunEndTime2)
                        
                        listHoursTable.append(listHours)
                    }
                }
                
                if(stores != nil && storesHours != nil)
                {
                    for s in stores!
                    {
                        if(APKChanger.APKTemp != nil && APKChanger.APKTemp != APK)
                        {
                            return
                        }
                        
                        switch Int(s.infoType)
                        {
                        case SlotType.Photo.rawValue:
                            downloadImage2(url: s.photo.imageUrl)
                            
                            /*if(errorOccured2)
                             {
                             throw Errors.error
                             }*/
                        case SlotType.Carousel.rawValue:
                            for u in s.carousel.urls
                            {
                                downloadImage2(url: u.url)
                                
                                /*if(errorOccured2)
                                 {
                                 throw Errors.error
                                 }*/
                            }
                        default:
                            break
                        }
                    }
                    
                }
                
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                storesDB.insertStores(stores: stores, storesHours: listHoursTable)
                statusModel.areStoresSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            if(!(statusModel?.areHolidaysSaved)!)
            {
                let holidays = try StoresWepApi.getYearlyHolidays(clientID: clientID)
                
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                storesDB.insertHolidays(holidays: holidays)
                
                let shopHolidays = try StoresWepApi.getShopYearlyHolidays(clientID: clientID)
                
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                storesDB.insertShopHolidays(shopHolidays: shopHolidays)
                
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                statusModel.areHolidaysSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
        }
        catch
        {
            areParametersDownloading = false
            //handleError2()
            throw Errors.error
        }
        
    }
    
    
    static func getPointsStatementAndBalance()
    {
        do
        {
            let phoneNumber = localDatabase.getAppUser()?.phoneNumber
            
            AppUpdatesOperator.updateApp()
            let date : Date! = loyaltyDB.getPointsStatementLastUpdateDate()
            
            var page : Int = 1 //statusModel.pointsStatementPageNo
            var pointsStatement : [LoyaltyStatementModel]! = []
            var moreItems = try LoyaltyWebApi.getPointsStatementNew(userPhone: phoneNumber, partnerID: clientID, pageToLoad: page, date: date)
            while(moreItems != nil)
            {
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                loyaltyDB.insertPointsStatement(pointsStatement: moreItems)
                
                page += 1
                statusModel.pointsStatementPageNo = page
                statusDB.insertStatus(status : statusModel, apk : APK)
                
                for m in moreItems!
                {
                    pointsStatement.append(m)
                }
                
                moreItems = try LoyaltyWebApi.getPointsStatementNew(userPhone: phoneNumber, partnerID: clientID, pageToLoad: page, date: date)
            }
            
            statusModel.isPointsStatementSaved = true
            statusDB.insertStatus(status : statusModel, apk : APK)
            
            var allTickets  : [LoyaltyTicketModel] = []
            for p in pointsStatement
            {
                let tickets = try LoyaltyWebApi.getLoyaltyTicket(userPhone: phoneNumber!, partnerID: clientID, ticketNo: p.ticketNo)
                for t in tickets
                {
                    allTickets.append(t)
                }
            }
            
            if(APKTemp != nil && APKTemp != APK)
            {
                return
            }
            
            loyaltyDB.insertTickets(tickets: allTickets)
            statusModel.areTicketsSaved = true
            
            if(APKTemp != nil && APKTemp != APK)
            {
                return
            }
            
            statusDB.insertStatus(status : statusModel, apk : APK)
            
            /*let pointsBalance = UserProfileWebApi.getUserPointsBalance(clientID: clientID, phoneNumber: localDatabase.getAppUser()?.phoneNumber)
             
             if(APKTemp != nil && APKTemp != APK)
             {
             return
             }
             
             loyaltyDB.insertPoitsBalance(pointsBalance: pointsBalance)*/
        }
        catch
        {
            
        }
    }
    
    static func getRestParameters2() throws
    {
        do
        {
            if(localDatabase.isAPKRegistered(bussinessID: clientID))
            {
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
                {
                    getPointsStatementAndBalance()
                }
                
                statusModel.areAuthorsSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            
            continueDownloading3()
        }
        catch
        {
            areParametersDownloading = false
            //handleError2()
            throw Errors.error
        }
    }
    
    static func continueDownloading3()
    {
        do
        {
            if(!(statusModel?.areExpandableListViewsSaved)!)
            {
                try getExpandableListViews()
                
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                statusModel.areExpandableListViewsSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
           try loadAuthors()
            
            if(!(statusModel?.areArticlesSaved)!)
            {
                let leftDrawerTabs = try parameterizationDatabase.getLeftDrawerTabs(apk: APK)
                
                if(leftDrawerTabs != nil)
                {
                    for l in leftDrawerTabs!
                    {
                        if(l.type == LeftDrawerTabsType.Blog.rawValue)
                        {
                            let blogView = try ViewsWebApi.getBlogView(tabID: l.id , pageToLoad : 1)
                            
                            if(blogView != nil)
                            {
                                if(blogView?.categories != nil)
                                {
                                    viewsDB.insertArticlesCategories(articlesCategories: (blogView?.categories)!)
                                }
                                
                                runnable = continueDownloading3
                                
                                var blogModel = BlogModel()
                                blogModel.tabID = l.id
                                blogModel.image = blogView?.image
                                blogModel.title = blogView?.title
                                blogModel.titleFont = blogView?.titleFont
                                blogModel.titleSize = blogView?.titleTextSize
                                blogModel.titleColor = blogView?.titleTextColor
                                
                                var savedBlogModel = viewsDB.getBlogView(tabID: l.id)
                                
                                if((!isNullOrEmpty(string: blogView?.image) && savedBlogModel == nil) || (savedBlogModel != nil && !isNullOrEmpty(string: savedBlogModel!.image) && blogView?.image != savedBlogModel!.image))
                                {
                                    blogModel.imageData = downloadImage3(url: (blogView?.image)!)
                                    blogModel.imageAspectRatio =  calculateImageAspectRatio(imageUrl: (blogView?.image)!)
                                }
                                else if(!isNullOrEmpty(string: blogView?.image)) //&& !isNullOrEmpty(string: savedBlogModel!.image))
                                {
                                    blogModel.imageData = downloadImage3(url: (blogView?.image)!)
                                    blogModel.imageAspectRatio =  calculateImageAspectRatio(imageUrl: (blogView?.image)!)
                                }
                                
                                viewsDB.insertBlogView(blogView : blogModel)
                                
                                var blogViewArticles : [BlogViewArticleModel] = []
                                
                                if(blogView?.blogViewsArticles != nil)
                                {
                                    var savedArticles = viewsDB.getBlogViewArticles(tabID: l.id, apk: APK)
                                    
                                    if(savedArticles != nil && (savedArticles?.count)! > 0)
                                    {
                                        for s in savedArticles!
                                        {
                                            var isArticleFound = false
                                            for a in (blogView?.blogViewsArticles)!
                                            {
                                                if(a.id == s.id)
                                                {
                                                    a.isArticleSaved = true
                                                    isArticleFound = true
                                                    var blogViewArticle = BlogViewArticleModel()
                                                    blogViewArticle.tabID = l.id
                                                    blogViewArticle.articleID = a.id
                                                    blogViewArticles.append(blogViewArticle)
                                                    
                                                    if(!isNullOrEmpty(string: a.image) && !isNullOrEmpty(string: s.image) && a.image != s.image)
                                                    {
                                                        /*var imageProperties = downloadImage4(url: (a.image)!)
                                                         a.imageData = imageProperties.data
                                                         a.imageAspectRatio =  imageProperties.aspectRatio*/
                                                        a.imageData = downloadImage3(url: (a.image)!)
                                                        a.imageAspectRatio =  calculateImageAspectRatio(imageUrl: a.image)
                                                    }
                                                    else if(!isNullOrEmpty(string: a.image) && !isNullOrEmpty(string: s.image))
                                                    {
                                                        a.imageData = s.imageData
                                                        a.imageAspectRatio =  s.imageAspectRatio
                                                    }
                                                    
                                                    viewsDB.insertArticle(article: a)
                                                    
                                                    var articleItems : [ArticleItemModel] = []
                                                    s.articleItems = viewsDB.getGenealInformations(tabID: l.id, isArticle: true, articleID: a.id)
                                                    for g in a.articleItems
                                                    {
                                                        var articleItem = ArticleItemModel()
                                                        articleItem.articleID = a.id
                                                        articleItem.index = g.index
                                                        articleItem.type = g.type
                                                        articleItem.id = g.id
                                                        articleItem.productItemCode = g.productItemCode
                                                        articleItems.append(articleItem)
                                                        
                                                        var isSaved = false
                                                        if(g.type == SlotType.Photo.rawValue)
                                                        {
                                                            for i in s.articleItems
                                                            {
                                                                if(i.type == SlotType.Photo.rawValue)
                                                                {
                                                                    if(g.photo.imageUrl == i.photo.imageUrl)
                                                                    {
                                                                        isSaved = true
                                                                        
                                                                        g.photo.aspectRatio = i.photo.aspectRatio
                                                                        viewsDB.insertPhoto(id: g.id, photo: g.photo)
                                                                        viewsDB.insertImage(url: g.photo.imageUrl, str: viewsDB.getImageData(url: i.photo.imageUrl))
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        
                                                        if(!isSaved)
                                                        {
                                                            do
                                                            {
                                                                try getSlot(slot: g, article : a)
                                                            }
                                                            catch{}
                                                        }
                                                    }
                                                    
                                                    viewsDB.insertArticleItems(articleItems: articleItems)
                                                    break
                                                }
                                            }
                                            
                                            if(!isArticleFound)
                                            {
                                                viewsDB.deleteArticle(apk: APK, articleID: s.id, tabID: l.id)
                                            }
                                            
                                        }
                                        
                                        for a in (blogView?.blogViewsArticles)!
                                        {
                                            if(!a.isArticleSaved)
                                            {
                                                var blogViewArticle = BlogViewArticleModel()
                                                blogViewArticle.tabID = l.id
                                                blogViewArticle.articleID = a.id
                                                blogViewArticles.append(blogViewArticle)
                                                
                                                if(!isNullOrEmpty(string: a.image))
                                                {
                                                    /*var imageProperties = downloadImage4(url: (a.image)!)
                                                     a.imageData = imageProperties.data
                                                     a.imageAspectRatio =  imageProperties.aspectRatio*/
                                                    a.imageData = downloadImage3(url: (a.image)!)
                                                    a.imageAspectRatio =  calculateImageAspectRatio(imageUrl: a.image)
                                                }
                                                
                                                viewsDB.insertArticle(article: a)
                                                
                                                var articleItems : [ArticleItemModel] = []
                                                
                                                for g in a.articleItems
                                                {
                                                    var articleItem = ArticleItemModel()
                                                    articleItem.articleID = a.id
                                                    articleItem.index = g.index
                                                    articleItem.type = g.type
                                                    articleItem.id = g.id
                                                    articleItem.productItemCode = g.productItemCode
                                                    articleItems.append(articleItem)
                                                    
                                                    try getSlot(slot: g, article : a)
                                                }
                                                
                                                viewsDB.insertArticleItems(articleItems: articleItems)
                                            }
                                        }
                                        
                                    }
                                    else
                                    {
                                        for a in (blogView?.blogViewsArticles)!
                                        {
                                            var blogViewArticle = BlogViewArticleModel()
                                            blogViewArticle.tabID = l.id
                                            blogViewArticle.articleID = a.id
                                            blogViewArticles.append(blogViewArticle)
                                            
                                            if(!isNullOrEmpty(string: a.image))
                                            {
                                                /*var imageProperties = downloadImage4(url: (a.image)!)
                                                 a.imageData = imageProperties.data
                                                 a.imageAspectRatio =  imageProperties.aspectRatio*/
                                                a.imageData = downloadImage3(url: (a.image)!)
                                                a.imageAspectRatio =  calculateImageAspectRatio(imageUrl: a.image)
                                            }
                                            
                                            viewsDB.insertArticle(article: a)
                                            
                                            var articleItems : [ArticleItemModel] = []
                                            
                                            for g in a.articleItems
                                            {
                                                var articleItem = ArticleItemModel()
                                                articleItem.articleID = a.id
                                                articleItem.index = g.index
                                                articleItem.type = g.type
                                                articleItem.id = g.id
                                                articleItem.productItemCode = g.productItemCode
                                                articleItems.append(articleItem)
                                                
                                                try getSlot(slot: g, article : a)
                                            }
                                            
                                            viewsDB.insertArticleItems(articleItems: articleItems)
                                        }
                                    }
                                }
                                
                                viewsDB.insertBlogViewArticles(blogViewArticles: blogViewArticles)
                            }
                        }
                    }
                }
                
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                statusModel.areArticlesSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            
            if(!(statusModel?.isProductMenuSaved)!)
            {
                let productMenu = try ProductsWepApi.getProductMenu()
                
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                productsDB.insertProductMenu(productMenu: productMenu)
                statusModel.isProductMenuSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            if(!(statusModel?.areProductMenuRelationsSaved)!)
            {
                let productMenuRelations = try ProductsWepApi.getProductMenuRelations()
                
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                productsDB.insertProductMenuRelations(productMenuRelations: productMenuRelations)
                statusModel.areProductMenuRelationsSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            /*if(!(statusModel?.areCategoriesSaved)!)
             {
             let categories = ProductsWepApi.getCategories()
             productsDB.insertCategories(categories: categories)
             statusModel.areCategoriesSaved = true
             statusDB.insertStatus(status : statusModel, apk : APK)
             }*/
            
            if(!(statusModel?.areBrandsSaved)!)
            {
                let brands = ProductsWepApi.getBrands()
                
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                productsDB.insertBrands(brands: brands)
                statusModel.areBrandsSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            if(!(statusModel?.areProductsSaved)!)
            {
                DispatchQueue.global(qos: .background).async {
                    getProducts()
                }
            }
            else
            {
                DispatchQueue.global(qos: .background).async {
                    getChangedProducts()
                }
            }
            
            if(!(statusModel?.areBarcodesSaved)!)
            {
                DispatchQueue.global(qos: .background).async {
                    getBarcodes()
                }
            }
            
            areParametersDownloading = false
        }
        catch
        {
            areParametersDownloading = false
            handleError2()
            //throw Errors.error
        }
    }
    
    
    /*static func handleDownalingError()
     {
     LeftDrawerViewController.leftDrawerGroupTabs.removeAll()
     LeftDrawerViewController.leftDrawerGroupTabsID.removeAll()
     
     APK = Bundle.main.bundleIdentifier!
     let initializer = APKInitializer()
     
     initializer.setProperties()
     launchScreenTemp.viewDidLoad()
     
     leftDrawer.viewDidLoad()
     leftDrawer.tableView.reloadData()
     leftDrawer.selectTab(tabString: leftDrawer.leftDrawerTabsList[0].name)
     
     launchScreenTemp.tabbar.viewDidLoad()
     
     if(selectedTab.isChild && selectedTab.showAtTabbar)
     {
     CustomTabbarViewController2.currentIndex = 0
     }
     
     if(launchScreenTemp2 != nil)
     {
     launchScreenTemp2.dismiss(animated: true, completion: nil)
     }
     
     launchScreenTemp.dismiss(animated: true, completion: nil)
     }*/
    
    
    static func loadAuthors() throws
    {
        do{
            if(!(statusModel?.areAuthorsSaved)!)
            {
                let blogAuthors = try ViewsWebApi.getBogAuthors()
                
                if(blogAuthors != nil )
                {
                    if(blogAuthors?.authorsList != nil)
                    {
                        for b in (blogAuthors?.authorsList)!
                        {
                            if(!isNullOrEmpty(string: b.photoUrl))
                            {
                                b.photoData =  downloadImage3(url: (b.photoUrl)!)
                                b.photoAspectRatio =  calculateImageAspectRatio(imageUrl: (b.photoUrl)!)
                            }
                        }
                    }
                    
                    viewsDB.insertAuthorsParameters(authorsParameters: blogAuthors!)
                }
                
                statusModel.areAuthorsSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
        }catch
        {
            throw Errors.error
        }
    }
    
    static func getSlot(isSplashView : Bool = false, slot : GeneralInformation2, article : ArticleModel! = nil) throws
    {
        switch (slot.type)
        {
        case SlotType.PDF.rawValue:
            do
            {
                let yourURL = NSURL(string: percentEncode(s: slot.pdf.pdfUrl))
                //Create a URL request
                let urlRequest = NSURLRequest(url: yourURL! as URL)
                //get the data
                let theData = try NSURLConnection.sendSynchronousRequest(urlRequest as URLRequest, returning: nil)
                
                //Get the local docs directory and append your local filename.
                var docURL = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)).last as NSURL?
                
                print(theData.count)
                print("\(APK)\(slot.index!)\(slot.tabID!).pdf")
                docURL = docURL?.appendingPathComponent( "\(APK.replacingOccurrences(of: ".", with: ""))\(slot.index!)\(slot.tabID!).pdf")! as NSURL?
                
                //Lastly, write your file to the disk.
                try theData.write(to: docURL! as URL,options : Data.WritingOptions.atomic )
                
                //let url : NSURL! = NSURL(string: percentEncode(s: g.pdf.pdfUrl))
                
                /*let pdf = Bundle.main.url(forResource: "myFileName", withExtension: "pdf", subdirectory: nil, localization: nil)
                 let req = NSURLRequest(url: pdf!)*/
                
                /*if(url != nil)
                 {
                 
                 APKChanger.webView.loadRequest(NSURLRequest(url: url as URL) as URLRequest)
                 //webView.delegate = self
                 }*/
                
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                viewsDB.insertPDF(id: slot.id, pdf: slot.pdf)
            }
            catch
            {
                //areParametersDownloading = false
                //handleError()
                throw Errors.error
            }
            break
        case SlotType.Text.rawValue:
            
            viewsDB.insertText(id: slot.id, text: slot.text)
            break
        case SlotType.Photo.rawValue:
            /*g.photo.aspectRatio = calculateImageAspectRatio(imageUrl: g.photo.imageUrl)
             
             if(g.photo.aspectRatio == 0.0 && !NetworkHelper.isNetworkAvailable())
             {
             throw Errors.error
             }*/
            
            if(APKTemp != nil && APKTemp != APK)
            {
                return
            }
            
            //waitingForImages = true
            //cacheImage(url: slot.photo.imageUrl, photo : slot.photo, id : slot.id)
            
            
            
            if(article != nil && article.image == slot.photo.imageUrl)
            {
                slot.photo.aspectRatio = article.imageAspectRatio
                viewsDB.insertPhoto(id: slot.id, photo: slot.photo)
                viewsDB.insertImage(url: slot.photo.imageUrl, str: article.imageData)
            }
            else
            {
                /*var imageProperties = downloadImage4(url: (slot.photo.imageUrl)!)
                 slot.photo.aspectRatio = imageProperties.aspectRatio
                 viewsDB.insertPhoto(id: slot.id, photo: slot.photo)
                 viewsDB.insertImage(url: slot.photo.imageUrl, str: imageProperties.data)*/
                
                slot.photo.aspectRatio = calculateImageAspectRatio(imageUrl: slot.photo.imageUrl)
                viewsDB.insertPhoto(id: slot.id, photo: slot.photo)
                viewsDB.insertImage(url: slot.photo.imageUrl, str: downloadImage3(url: slot.photo.imageUrl))
            }
            
            //viewsDB.insertPhoto(id: g.id, photo: g.photo)
            break
        case SlotType.Carousel.rawValue:
            if(APKTemp != nil && APKTemp != APK)
            {
                return
            }
            
            waitingForImages = true
            viewsDB.insertCarousel(id: slot.id, carousel: slot.carousel)
            
            for u in slot.carousel.urls
            {
                if(article != nil && article.image == u.url)
                {
                    viewsDB.insertImage(url: u.url, str: article.imageData)
                }
                else
                {
                    viewsDB.insertImage(url: u.url, str: downloadImage3(url: u.url))
                }
                
                //cacheImage(url: u.url , photo: nil, id: 0)
            }
            break
        case SlotType.Video.rawValue:
            slot.video.alternativePhotoAspectRatio = calculateImageAspectRatio(imageUrl: slot.video.alternativePhoto)
            
            if(APKTemp != nil && APKTemp != APK)
            {
                return
            }
            
            downloadImage(url: slot.video.alternativePhoto)
            
            if(isSplashView && errorOccured2)
            {
                throw Errors.error
            }
            //cacheImage(url: g.video.alternativePhoto)
            
            viewsDB.insertVideo(id: slot.id, video: slot.video)
            //viewsDB.insertPhoto(id: g.video.alternativePhotoID, photo: g.video.alternativePhoto)
            break
        case SlotType.Title.rawValue:
            viewsDB.insertTitle(id: slot.id, title: slot.title)
            break
        case SlotType.Article.rawValue:
            /*slot.article.imageAspectRatio = calculateImageAspectRatio(imageUrl: slot.article.image)
             
             if(APKTemp != nil && APKTemp != APK)
             {
             return
             }
             
             slot.article.imageData = downloadImage3(url: slot.article.image)
             
             viewsDB.insertArticle(id: slot.id, article: slot.article)*/
            break
        default :
            break
        }
    }
    
    static func getFirstView() throws
    {
        waitingForImages = false
        var defaultView : [GeneralInformation2]!
        
        do
        {
            defaultView = try ViewsWebApi.getFirstView()
            
            isIterationFinished = false
            
            if(defaultView != nil)
            {
                for g in defaultView!
                {
                    let generalView = GeneralViewModel()
                    generalView.apk = APK
                    generalView.index = g.index
                    generalView.type = g.type
                    generalView.id = g.id
                    generalView.tabID = g.tabID
                    generalView.startDate = g.startDate
                    generalView.endDate = g.endDate
                    
                    viewsDB.insertView(view: generalView)
                    
                    switch (g.type)
                    {
                    case SlotType.PDF.rawValue:
                        do
                        {
                            let yourURL = NSURL(string: percentEncode(s: g.pdf.pdfUrl))
                            //Create a URL request
                            let urlRequest = NSURLRequest(url: yourURL! as URL)
                            //get the data
                            let theData = try NSURLConnection.sendSynchronousRequest(urlRequest as URLRequest, returning: nil)
                            
                            //Get the local docs directory and append your local filename.
                            var docURL = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)).last as NSURL?
                            
                            print("\(APK)\(g.index!)\(g.tabID!).pdf")
                            docURL = docURL?.appendingPathComponent( "\(APK.replacingOccurrences(of: ".", with: ""))\(g.index!)\(g.tabID!).pdf")! as NSURL?
                            
                            //Lastly, write your file to the disk.
                            try theData.write(to: docURL! as URL,options : Data.WritingOptions.atomic )
                            
                            //let url : NSURL! = NSURL(string: percentEncode(s: g.pdf.pdfUrl))
                            
                            /*let pdf = Bundle.main.url(forResource: "myFileName", withExtension: "pdf", subdirectory: nil, localization: nil)
                             let req = NSURLRequest(url: pdf!)*/
                            
                            /*if(url != nil)
                             {
                             APKChanger.webView.loadRequest(NSURLRequest(url: url as URL) as URLRequest)
                             //webView.delegate = self
                             }*/
                            
                            viewsDB.insertPDF(id: g.id, pdf: g.pdf)
                        }
                        catch
                        {
                            //handleError()
                            throw Errors.error
                        }
                        break
                    case SlotType.Text.rawValue:
                        
                        viewsDB.insertText(id: g.id, text: g.text)
                        break
                    case SlotType.Photo.rawValue:
                        /*g.photo.aspectRatio = calculateImageAspectRatio(imageUrl: g.photo.imageUrl)
                         
                         if(g.photo.aspectRatio == 0.0 && !NetworkHelper.isNetworkAvailable())
                         {
                         throw Errors.error
                         }*/
                        
                        waitingForImages = true
                        cacheImage(url: g.photo.imageUrl, photo : g.photo, id : g.id)
                        
                        
                        /*let url = URL(string: g.photo.imageUrl)!
                         let imageView = UIImageView()
                         imageView.kf.setImage(with: url)*/
                        
                        //viewsDB.insertPhoto(id: g.id, photo: g.photo)
                        break
                    case SlotType.Carousel.rawValue:
                        viewsDB.insertCarousel(id: g.id, carousel: g.carousel)
                        
                        for u in g.carousel.urls
                        {
                            cacheImage(url: u.url , photo: nil, id: 0)
                        }
                        break
                    case SlotType.Video.rawValue:
                        g.video.alternativePhotoAspectRatio = calculateImageAspectRatio(imageUrl: g.video.alternativePhoto)
                        downloadImage(url: g.video.alternativePhoto)
                        if(errorOccured2)
                        {
                            throw Errors.error
                        }
                        //cacheImage(url: g.video.alternativePhoto)
                        
                        
                        /*let url = URL(string: g.video.alternativePhoto)!
                         let imageView = UIImageView()
                         imageView.kf.setImage(with: url)*/
                        
                        viewsDB.insertVideo(id: g.id, video: g.video)
                        //viewsDB.insertPhoto(id: g.video.alternativePhotoID, photo: g.video.alternativePhoto)
                        break
                    case SlotType.Title.rawValue:
                        viewsDB.insertTitle(id: g.id, title: g.title)
                        break
                    default :
                        break
                    }
                }
                
            }
            
            if(waitingForImages == false)
            {
                if(runnable != nil)
                {
                    runnable()
                    print("make runnable null2")
                    runnable = nil
                }
                else if(runnableWithThrow != nil)
                {
                    try runnableWithThrow()
                    runnableWithThrow = nil
                }
            }
        }
        catch
        {
            //handleError()
            throw Errors.error
        }
        
        isIterationFinished = true
    }
    
    static func getGeneralViews(isSplashView : Bool = false) throws
    {
        waitingForImages = false
        var generalViews : [GeneralInformation2]!
        
        do
        {
            if(isSplashView)
            {
                generalViews = try ViewsWebApi.getSplashViewBanners()
            }
            else
            {
                generalViews = try ViewsWebApi.getGeneralViews()
            }
            
            isIterationFinished = false
            
            if(generalViews != nil)
            {
                for g in generalViews!
                {
                    if(generalViewsIDsNeedUpdate.count > 0 && !generalViewsIDsNeedUpdate.contains(g.tabID))
                    {
                        continue
                    }
                    
                    if(APKTemp != nil && APKTemp != APK)
                    {
                        return
                    }
                    
                    let generalView = GeneralViewModel()
                    generalView.apk = APK
                    generalView.index = g.index
                    generalView.type = g.type
                    generalView.id = g.id
                    generalView.tabID = g.tabID
                    generalView.startDate = g.startDate
                    generalView.endDate = g.endDate
                    
                    viewsDB.insertView(view: generalView)
                    
                    switch (g.type)
                    {
                    case SlotType.PDF.rawValue:
                        do
                        {
                            let yourURL = NSURL(string: percentEncode(s: g.pdf.pdfUrl))
                            //Create a URL request
                            let urlRequest = NSURLRequest(url: yourURL! as URL)
                            //get the data
                            let theData = try NSURLConnection.sendSynchronousRequest(urlRequest as URLRequest, returning: nil)
                            
                            //Get the local docs directory and append your local filename.
                            var docURL = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)).last as NSURL?
                            
                            print(theData.count)
                            print("\(APK)\(g.index!)\(g.tabID!).pdf")
                            docURL = docURL?.appendingPathComponent( "\(APK.replacingOccurrences(of: ".", with: ""))\(g.index!)\(g.tabID!).pdf")! as NSURL?
                            
                            //Lastly, write your file to the disk.
                            try theData.write(to: docURL! as URL,options : Data.WritingOptions.atomic )
                            
                            //let url : NSURL! = NSURL(string: percentEncode(s: g.pdf.pdfUrl))
                            
                            /*let pdf = Bundle.main.url(forResource: "myFileName", withExtension: "pdf", subdirectory: nil, localization: nil)
                             let req = NSURLRequest(url: pdf!)*/
                            
                            /*if(url != nil)
                             {
                             
                             APKChanger.webView.loadRequest(NSURLRequest(url: url as URL) as URLRequest)
                             //webView.delegate = self
                             }*/
                            
                            if(APKTemp != nil && APKTemp != APK)
                            {
                                return
                            }
                            
                            viewsDB.insertPDF(id: g.id, pdf: g.pdf)
                        }
                        catch
                        {
                            //areParametersDownloading = false
                            //handleError()
                            throw Errors.error
                        }
                        break
                    case SlotType.Text.rawValue:
                        
                        viewsDB.insertText(id: g.id, text: g.text)
                        break
                    case SlotType.Photo.rawValue:
                        /*g.photo.aspectRatio = calculateImageAspectRatio(imageUrl: g.photo.imageUrl)
                         
                         if(g.photo.aspectRatio == 0.0 && !NetworkHelper.isNetworkAvailable())
                         {
                         throw Errors.error
                         }*/
                        
                        if(APKTemp != nil && APKTemp != APK)
                        {
                            return
                        }
                        
                        waitingForImages = true
                        cacheImage(url: g.photo.imageUrl, photo : g.photo, id : g.id)
                        
                        /*let url = URL(string: g.photo.imageUrl)!
                         let imageView = UIImageView()
                         imageView.kf.setImage(with: url)*/
                        
                        //viewsDB.insertPhoto(id: g.id, photo: g.photo)
                        break
                    case SlotType.Carousel.rawValue:
                        if(APKTemp != nil && APKTemp != APK)
                        {
                            return
                        }
                        
                        waitingForImages = true
                        viewsDB.insertCarousel(id: g.id, carousel: g.carousel)
                        
                        for u in g.carousel.urls
                        {
                            cacheImage(url: u.url , photo: nil, id: 0)
                        }
                        break
                    case SlotType.Video.rawValue:
                        g.video.alternativePhotoAspectRatio = calculateImageAspectRatio(imageUrl: g.video.alternativePhoto)
                        
                        if(APKTemp != nil && APKTemp != APK)
                        {
                            return
                        }
                        
                        downloadImage(url: g.video.alternativePhoto)
                        
                        if(isSplashView && errorOccured2)
                        {
                            throw Errors.error
                        }
                        //cacheImage(url: g.video.alternativePhoto)
                        
                        viewsDB.insertVideo(id: g.id, video: g.video)
                        //viewsDB.insertPhoto(id: g.video.alternativePhotoID, photo: g.video.alternativePhoto)
                        break
                    case SlotType.Title.rawValue:
                        viewsDB.insertTitle(id: g.id, title: g.title)
                        break
                    default :
                        break
                    }
                }
                
            }
            
            if(waitingForImages == false)
            {
                if(runnable != nil)
                {
                    runnable()
                    print("make runnable null")
                    runnable = nil
                }
                else if(runnableWithThrow != nil)
                {
                    try runnableWithThrow()
                    runnableWithThrow = nil
                }
            }
        }
        catch
        {

            throw Errors.error
        }
        
        if(numOfImages == 0 && waitingForImages && runnable != nil)
        {
            runnable()
        }
        
        isIterationFinished = true
    }
    
    
    static func getExpandableListViews() throws
    {
        do
        {
            let expandableListViews = try ViewsWebApi.getExpandableListViews()
            
            if(APKTemp != nil && APKTemp != APK)
            {
                return
            }
            
            viewsDB.insertExpandableListView(expandableListView: expandableListViews)
            
            let expandableLists = ViewsWebApi.getExpandableLists()
            
            if(expandableLists != nil)
            {
                for e in expandableLists!
                {
                    if(!isNullOrEmpty(string: e.backgroundImage))
                    {
                        e.aspectRatio = calculateImageAspectRatio(imageUrl: e.backgroundImage)
                        downloadImage(url: e.backgroundImage)
                    }
                    
                    if(!isNullOrEmpty(string: e.image))
                    {
                        downloadImage(url: e.image)
                    }
                }
            }
            
            if(APKTemp != nil && APKTemp != APK)
            {
                return
            }
            
            viewsDB.insertExpandableListParents(expandableListParents: expandableLists)
            
            if(expandableLists != nil)
            {
                for e in expandableLists!
                {
                    if(e.image != nil)
                    {
                        if(APKTemp != nil && APKTemp != APK)
                        {
                            return
                        }
                        
                        cacheImage(url: e.image)
                    }
                }
            }
        }
        catch
        {
            //areParametersDownloading = false
            //handleError()
            throw Errors.error
        }
    }
    
    static func getChangedProducts()
    {
        let apkTemp : String! = APK
        var pageNo = 0
        var changedProducts : [ProductModel]!
        repeat
        {
            try changedProducts = ProductsWepApi.getChangedProducts(pageNo: pageNo)
            
            if(changedProducts == nil)
            {
                numOfTries += 1
                
                if(numOfTries >= 10)
                {
                    return
                }
                
                changedProducts = []
                changedProducts.append(ProductModel())
                sleep(4)
            }
            else
            {
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                productsDB.insertProducts(products: changedProducts, apk : apkTemp)
            }
            
            pageNo += 1
            print()
        } while changedProducts.count > 0 && APK == apkTemp
        
        var statusModelTemp = statusDB.getStatus(apk: APK)
        statusModel.lastProductsSyncDate = statusModelTemp!.lastUpdateDate
        statusDB.insertStatus(status : statusModel, apk : APK)
        
    }
    
    static func getProducts()
    {
        let apkTemp : String! = APK
        var products : [ProductModel]! = []
        var pageNo = statusModel.productsPageNo + 1
        var numOfTries = 0
        
        repeat{
            products = ProductsWepApi.getProducts(pageNo: pageNo)
            
            if(products == nil)
            {
                numOfTries += 1
                
                if(numOfTries >= 10)
                {
                    return
                }
                
                products = []
                products.append(ProductModel())
                sleep(4)
            }
            else
            {
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                productsDB.insertProducts(products: products, apk : apkTemp)
                
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                statusModel.productsPageNo = pageNo
                statusDB.insertStatus(status : statusModel, apk : APK)
                
                /*if(selectedTab != nil && selectedTab.tabType == TabType.ProductFinder.rawValue && currentViewController2 != nil)
                 {
                 let a = currentViewController2 as? ExpandableListViewController
                 if(a != nil)
                 {
                 a!.reloadCategoriesAndBrands()
                 }
                 }*/
                pageNo += 1
            }
        } while products.count > 0 && APK == apkTemp
        
        if(APK == apkTemp)
        {
            if(APKTemp != nil && APKTemp != APK)
            {
                return
            }
            
            if(APK == apkTemp)
            {
                statusModel.areProductsSaved = true
                var statusModelTemp = statusDB.getStatus(apk: APK)
                statusModel.lastProductsSyncDate = statusModelTemp!.lastUpdateDate
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            if(currentViewController2 != nil && leftDrawer != nil)
            {
                currentViewController2.loadBrandsAndCategories()
            }
        }
    }
    
    static func getBarcodes()
    {
        let apkTemp : String! = APK
        var barcodes : [BarcodeModel]! = []
        var pageNo = statusModel.barcodesPageNo + 1
        var numOfTries = 0
        
        repeat{
            barcodes = ProductsWepApi.getBarcodes(pageNo: pageNo)
            
            if(barcodes == nil)
            {
                numOfTries += 1
                
                if(numOfTries >= 10)
                {
                    return
                }
                
                barcodes = []
                barcodes.append(BarcodeModel())
                sleep(4)
            }
            else
            {
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                productsDB.insertBarcodes(barcodes: barcodes, apk : apkTemp)
                
                if(APKTemp != nil && APKTemp != APK)
                {
                    return
                }
                
                statusModel.barcodesPageNo = pageNo
                statusDB.insertStatus(status : statusModel, apk : apkTemp)
                
                pageNo += 1
            }
        } while barcodes.count > 0  && APK == apkTemp
        
        if(APKTemp != nil && APKTemp != APK)
        {
            return
        }
        
        if(APK == apkTemp)
        {
            statusModel.areBarcodesSaved = true
            statusDB.insertStatus(status : statusModel, apk : APK)
        }
    }
}

var numOfImages = 0
var errorHandled = false
var waitingForImages = false
var isIterationFinished = false
var waitForNavImageToDownloaded = false
var errorOccured = false
var errorOccured2 = false

func downloadImage(url: String) {
    waitForNavImageToDownloaded = true
    errorOccured2 = false
    
    let urlTemp = URL(string: percentEncode(s: url))
    getDataFromUrl(url: urlTemp!) { data, response, error in
        guard let data = data, error == nil else
        {
            DispatchQueue.global(qos: .background).async {
                errorOccured2 = true
                waitForNavImageToDownloaded = false
            }
            return
        }
        
        viewsDB.insertImage(url : url,str: data)
        waitForNavImageToDownloaded = false
    }
    
    while(waitForNavImageToDownloaded)
    {
        sleep(1)
    }
}

func downloadImage2(url: String) {
    waitForNavImageToDownloaded = true
    errorOccured2 = false
    
    let urlTemp = URL(string: percentEncode(s: url))
    getDataFromUrl(url: urlTemp!) { data, response, error in
        guard let data = data, error == nil else
        {
            DispatchQueue.global(qos: .background).async {
                errorOccured2 = true
                waitForNavImageToDownloaded = false
            }
            return
        }
        
        if(APKChanger.APKTemp != nil && APKChanger.APKTemp != APK)
        {
            return
        }
        
        storesDB.insertImage(url : url,str: data)
        waitForNavImageToDownloaded = false
    }
    
    while(waitForNavImageToDownloaded)
    {
        sleep(1)
    }
}

func downloadImage3(url: String) -> Data {
    waitForNavImageToDownloaded = true
    errorOccured2 = false
    
    var imageData = Data()
    
    let urlTemp = URL(string: percentEncode(s: url))
    getDataFromUrl(url: urlTemp!) { data, response, error in
        guard let data = data, error == nil else
        {
            DispatchQueue.global(qos: .background).async {
                errorOccured2 = true
                waitForNavImageToDownloaded = false
            }
            return
        }
        
        imageData = data
        waitForNavImageToDownloaded = false
    }
    
    while(waitForNavImageToDownloaded)
    {
        sleep(1)
    }
    
    if(imageData.count == 0 && !errorOccured2)
    {
        return downloadImage3(url: url)
    }
    
    return imageData
}

class ImageProperties
{
    var data : Data!
    var aspectRatio : Double!
}

func downloadImage4(url: String) -> ImageProperties {
    var properties = ImageProperties()
    var waiting = true
    
    //ImageCache.default.removeImage(forKey:  percentEncode(s: url))
    KingfisherManager.shared.retrieveImage(with: URL(string: percentEncode(s: url) )!, options: nil, progressBlock: nil, completionHandler:
        { (image, error, cacheType, imageURL) -> () in
            
            if(image != nil)
            {
                properties.aspectRatio = Double((image?.size.height)!) / Double((image?.size.width)!)
                properties.data = UIImagePNGRepresentation(image!)
                waiting = false
            }
    })
    
    while(waiting)
    {
        sleep(1)
    }
    
    return properties
}

func cacheImage(url : String, photo : PhotoModel! = nil, id : Int  = 0)
{
    if(waitingForImages)
    {
        numOfImages += 1
    }
    
    ImageCache.default.removeImage(forKey:  percentEncode(s: url))
    KingfisherManager.shared.retrieveImage(with: URL(string: percentEncode(s: url) )!, options: nil, progressBlock: nil, completionHandler:
        { (image, error, cacheType, imageURL) -> () in
            
            if(waitingForImages)
            {
                numOfImages -= 1
            }
            
            if(image == nil && !errorHandled)
            {
                //errorHandled = true
                //errorOccured2 = true
                
                /*APKChanger.handleError()*/
                viewsDB.insertPhoto(id: id, photo: photo)
            }
            else if (image != nil)
            {
                if(photo != nil)
                {
                    photo.aspectRatio = Double((image?.size.height)!) / Double((image?.size.width)!)
                    print(id)
                    print(photo.aspectRatio)
                    print("image downloaded")
                    
                    
                    if(APKChanger.APKTemp != nil && APKChanger.APKTemp != APK)
                    {
                        return
                    }
                    
                    viewsDB.insertPhoto(id: id, photo: photo)
                    viewsDB.insertImage(url: url, str: UIImagePNGRepresentation(image!)!)
                    //ImageCache.default.removeImage(forKey: percentEncode(s: url))
                    
                }
                else
                {
                    print("caching image")
                    viewsDB.insertImage(url: url, str: UIImagePNGRepresentation(image!)!)
                }
            }
            
            print(numOfImages)
            print(waitingForImages)
            print(isIterationFinished)
            print(APKChanger.runnable)
            print(APKChanger.runnable)
            if(numOfImages == 0 && waitingForImages && isIterationFinished)
            {
                if(APKChanger.runnable != nil)
                {
                    DispatchQueue.global(qos: .background).async {
                        var runnalbeTemp = APKChanger.runnable
                        print("make runnable null3")
                        APKChanger.runnable = nil
                        runnalbeTemp!()
                    }
                }
                else if(APKChanger.runnableWithThrow != nil)
                {
                    DispatchQueue.global(qos: .background).async {
                        do
                        {
                            try APKChanger.runnableWithThrow()
                        }  catch { }
                        
                        APKChanger.runnableWithThrow = nil
                    }
                }
                
                do
                {
                    //try APKChanger.getRestParameters2()
                }
                catch
                {
                    //APKChanger.handleDownalingError()
                }
            }
            
            if(numOfImages == 0 && waitingForImages)
            {
                waitingForImages = false
            }
            
    })
}

/*func cacheImage(url : String)
 {
 KingfisherManager.shared.retrieveImage(with: URL(string: percentEncode(s: url) )!, options: nil, progressBlock: nil, completionHandler:
 { (image, error, cacheType, imageURL) -> () in })
 }*/


func calculateImageAspectRatio(imageUrl : String) -> Double
{
    if(!isNullOrEmpty(string: imageUrl))
    {
        let url = URL(string: percentEncode(s: imageUrl))
        
        if let imageSource = CGImageSourceCreateWithURL(url! as CFURL, nil) {
            if let imageProperties = CGImageSourceCopyPropertiesAtIndex(imageSource, 0, nil) as Dictionary? {
                let pixelWidth = imageProperties[kCGImagePropertyPixelWidth] as! Int
                let pixelHeight = imageProperties[kCGImagePropertyPixelHeight] as! Int
                
                print(pixelWidth)
                return Double(pixelHeight) / Double(pixelWidth)
            }
        }
        
        let imageSoucre = FTImageSize.getImageSize(percentEncode(s: imageUrl)) //getImageSizeFromImageURL(percentEncode(s: imageUrl), perferdWidth: 200) //getImageSize(percentEncode(s: imageUrl))
        if(imageSoucre.width == 0.0)
        {
            return 0
        }
        
        return Double(imageSoucre.height) / Double(imageSoucre.width)
    }
    
    
    return 0
}

func correctHexString(string : String) -> String
{
    if(string.count == 7)
    {
        return string
    }
    else
    {
        var newString = string
        
        let firstAlpha = newString[1]
        let secondAlpha = newString[2]
        
        newString.remove(at: newString.startIndex)
        newString.remove(at: newString.startIndex)
        newString.remove(at: newString.startIndex)
        
        newString.insert("#", at: newString.startIndex)
        newString.insert(firstAlpha, at: newString.endIndex)
        newString.insert(secondAlpha, at: newString.endIndex)
        
        return newString
    }
}

func correctFontString(s : String!) -> String
{
    if(s != nil)
    {
        return s.contains(".") ? s.substring(to: s.index(s.endIndex, offsetBy: -4)) : s
    }
    else
    {
        return ""
    }
}

/// Download left drawer image and save it to local database.
///
/// - Parameter url: The url of left drawer image.
func downloadLeftDrawerImage(url: URL) {
    getDataFromUrl(url: url) { data, response, error in
        guard let data = data, error == nil else { return }
        DispatchQueue.main.async() {
            //self.navigationItem.leftBarButtonItem?.image = UIImage(data: data)?.resizeImage(28, opaque: false)
            parameterizationDatabase.insertLeftDrawerImage(str: data)
        }
    }
}

/// Get data using given url.
///
/// - Parameters:
///   - url: The url.
///   - completion: The completion of task.
func getDataFromUrl(url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
    URLSession.shared.dataTask(with: url) { data, response, error in
        completion(data, response, error)
        }.resume()
}

/// Sets the storyboard name and view id for given tab.
///
/// - Parameter tab: The tab.
func setStoryboardNameAndID(tab : inout Tab)
{
    switch tab.type
    {
    case LeftDrawerTabsType.Offers.rawValue :
        tab.storyboardName = ViewStoryboardName.Offers.rawValue
        tab.viewID = ViewStoryboardID.Businesses.rawValue
    case LeftDrawerTabsType.Loyalty.rawValue :
        tab.storyboardName = ViewStoryboardName.Offers.rawValue
        tab.viewID = ViewStoryboardID.Businesses.rawValue
        AllPartnersView.displayLoyaltyPartnersOnly = true
    case LeftDrawerTabsType.Notifications.rawValue :
        tab.storyboardName = ViewStoryboardName.Notifications.rawValue
        tab.viewID = ViewStoryboardID.Notifications.rawValue
    case LeftDrawerTabsType.SalesOrdering.rawValue :
        break
    case LeftDrawerTabsType.PurchaseOrdering.rawValue :
        break
    case LeftDrawerTabsType.HelpAndSupport.rawValue :
        tab.storyboardName = ViewStoryboardName.HelpAndSupport.rawValue
        tab.viewID = ViewStoryboardID.HelpAndSupport.rawValue
    case LeftDrawerTabsType.Profile.rawValue :
        tab.storyboardName = ViewStoryboardName.Profile.rawValue
        tab.viewID = ViewStoryboardID.Profile.rawValue
    case LeftDrawerTabsType.Barcode.rawValue :
        tab.storyboardName = ViewStoryboardName.Barcode.rawValue
        tab.viewID = ViewStoryboardID.Barcode.rawValue
    case LeftDrawerTabsType.About.rawValue :
        tab.storyboardName = ViewStoryboardName.About.rawValue
        tab.viewID = ViewStoryboardID.About.rawValue
    case LeftDrawerTabsType.Preferred.rawValue :
        tab.storyboardName = ViewStoryboardName.Offers.rawValue
        tab.viewID = ViewStoryboardID.Preferred.rawValue
    case LeftDrawerTabsType.Businesses.rawValue :
        tab.storyboardName = ViewStoryboardName.Offers.rawValue
        tab.viewID = ViewStoryboardID.Businesses.rawValue
    case LeftDrawerTabsType.WishList.rawValue :
        tab.storyboardName = ViewStoryboardName.Offers.rawValue
        tab.viewID = ViewStoryboardID.WishList.rawValue
    case LeftDrawerTabsType.History.rawValue :
        tab.storyboardName = ViewStoryboardName.Offers.rawValue
        tab.viewID = ViewStoryboardID.History.rawValue
    case LeftDrawerTabsType.Settings.rawValue :
        tab.storyboardName = ViewStoryboardName.Settings.rawValue
        tab.viewID = ViewStoryboardID.Settings.rawValue
    case LeftDrawerTabsType.OrderReturnNow.rawValue :
        break
    case LeftDrawerTabsType.OrderReturnHistory.rawValue :
        break
    case LeftDrawerTabsType.OrderSettings.rawValue :
        break
    case LeftDrawerTabsType.Suppliers.rawValue :
        break
    case LeftDrawerTabsType.DirectLink.rawValue :
        break
    case LeftDrawerTabsType.SocialMedia.rawValue :
        break
    case LeftDrawerTabsType.GeneralView.rawValue :
        tab.storyboardName = ViewStoryboardName.General.rawValue
        tab.viewID = ViewStoryboardID.General.rawValue
    case LeftDrawerTabsType.BenefitsCard.rawValue :
        tab.storyboardName = ViewStoryboardName.BenefitsCard.rawValue
        tab.viewID = ViewStoryboardID.BenefitsCard.rawValue
    case LeftDrawerTabsType.ExpandableList.rawValue, LeftDrawerTabsType.BarcodeScan.rawValue :
        tab.storyboardName = ViewStoryboardName.ExpandableList.rawValue
        tab.viewID = ViewStoryboardID.ExpandableList.rawValue
    case LeftDrawerTabsType.ContactUs.rawValue , LeftDrawerTabsType.Feedback.rawValue:
        tab.storyboardName = ViewStoryboardName.ContactUs.rawValue
        tab.viewID = ViewStoryboardID.ContactUs.rawValue
    case LeftDrawerTabsType.LoyaltyStatement.rawValue :
        tab.storyboardName = ViewStoryboardName.LoyaltyStatement.rawValue
        tab.viewID = ViewStoryboardID.LoyaltyStatement.rawValue
    case LeftDrawerTabsType.Profile2.rawValue :
        tab.storyboardName = ViewStoryboardName.Profile2.rawValue
        tab.viewID = ViewStoryboardID.Profile2.rawValue
    default :
        break
    }
}

func showFirstView()
{
    var window = UIWindow(frame: UIScreen.main.bounds)
    var leftDrawerTabsList : [Tab]! = []
    leftDrawerTabsList = parameterizationDatabase.getLeftDrawerTabs(apk: APK)
    
    let firstTab = leftDrawerTabsList[0]
    
    if(!firstTab.isParent)
    {
        
        let storyboard = UIStoryboard(name: firstTab.storyboardName , bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: firstTab.viewID) as! UINavigationController
        window.rootViewController = viewController
        separatorHeight = firstTab.separatorHeight
        separatorColor = firstTab.separatorColor
        //self.window?.makeKeyAndVisible()
    }
    else
    {
        var relations : [PCRelation]!
        relations = parameterizationDatabase.getPCRelations(apk: APK)
        
        for r in relations!
        {
            if (r.parentID == leftDrawerTabsList[0].id)
            {
                for t in leftDrawerTabsList
                {
                    if(t.id == r.childID)
                    {
                        window = UIWindow(frame: UIScreen.main.bounds)
                        let storyboard = UIStoryboard(name: t.storyboardName , bundle: nil)
                        let viewController = storyboard.instantiateViewController(withIdentifier: t.viewID) as! UINavigationController
                        window.rootViewController = viewController
                        separatorHeight = t.separatorHeight
                        separatorColor = t.separatorColor
                        //self.window?.makeKeyAndVisible()
                        break
                    }
                }
                break
            }
        }
    }
}

func copyProduct (product : ProductModel!) -> ProductModel{
    let copy = ProductModel()
    
    copy.hashValue = product.hashValue
    copy.itemNoString = product.itemNoString
    copy.itemNo = product.itemNo
    copy.commonItemNo = product.commonItemNo
    copy.productDescription = product.productDescription
    copy.webDescription = product.webDescription
    copy.overViewText = product.overViewText
    copy.ingredientsText = product.ingredientsText
    copy.howToUseText = product.howToUseText
    copy.categoryCodeString = product.categoryCodeString
    copy.categoryCode = product.categoryCode
    copy.familyCode = product.familyCode
    copy.manufacturerCode = product.manufacturerCode
    copy.manufacturerName = product.manufacturerName
    copy.sapStatus = product.sapStatus
    copy.imageA = product.imageA
    copy.imageB = product.imageB
    copy.availabilityForOnlineInt = product.availabilityForOnlineInt
    copy.availabilityForOnline = product.availabilityForOnline
    copy.priceIncludingVAT = product.priceIncludingVAT
    copy.category = product.category
    copy.category2 = product.category2
    copy.brand = product.brand
    copy.textColor = product.textColor
    copy.textSize = product.textSize
    copy.backgroundColor = product.backgroundColor
    copy.font = product.font
    copy.imageAspectRatio = product.imageAspectRatio
    copy.areInformationsDisplayed = product.areInformationsDisplayed
    copy.informationList = product.informationList
    
    return copy
}

func showProductView(productModel : ProductModel!, viewController : ViewController) -> GeneralInformationViewController
{
    isViewPushed = true
    
    let item = copyProduct(product: productModel)
    let videoUrl = hasVideoUrl(productVideoUrl: item)
    print(item.overViewText)
    removeSpecialcharacters(product : item)
    
    let informationsList = viewsDB.getEmbededViewInformationList(id: 0, product : item, videoSrcUrl : videoUrl)
    
    let InformationStoryBoard : UIStoryboard = UIStoryboard(name: "GeneralInformationView" , bundle: nil)
    let generalInformationView = InformationStoryBoard.instantiateInitialViewController() as! GeneralInformationViewController
    
    generalInformationView.viewController = viewController
    generalInformationView.isEmbeded = true
    generalInformationView.informationsList = informationsList
    
    let embededViewParameters = viewsDB.getEmbededViewParameters(id: 0)
    borderWidth = embededViewParameters?.borderSize
    borderColor = embededViewParameters?.borderColor
    separatorHeight = embededViewParameters?.separatorHeight
    separatorColor = embededViewParameters?.separatorColor
    
    return generalInformationView
}

func hasVideoUrl(productVideoUrl : ProductModel) -> String {
    
    if(!isNullOrEmpty(string : productVideoUrl.overViewText) && productVideoUrl.overViewText.contains("http")){
        
        let endIndex = productVideoUrl.overViewText.index(of: "controls=")
        let startIndex = productVideoUrl.overViewText.index(of: "http")
        if(startIndex != nil && endIndex != nil)
        {
            let range = productVideoUrl.overViewText[startIndex!..<endIndex!]
            let substringToString = String(range)
            let videoScrUrl = substringToString.replacingOccurrences(of: "Ď", with: ":")
            
            return videoScrUrl
        }
        else
        {
            return ""
        }
    }
    else
    {
        return ""
    }
    
}

func convertHourToDate(hour : String) -> Date
{
    let timeArray = hour.split(separator: ":")
    let timeHours = Int(timeArray[0])
    let timeMin = Int(timeArray[1])
    
    /*let formatter = DateFormatter()
     formatter.timeZone = TimeZone.current
     formatter.dateFormat = "yyyy-MM-dd HH:mm"
     let dateString = formatter.string(from: now)*/
    
    return Calendar.current.date(bySettingHour: timeHours!, minute: timeMin!, second: 0, of: Date())!
}

func isShopOpen(store : StoreModel!, holidays : [YearlyHolidaysModel]) -> Bool
{
    let date = Date()
    let calendar = Calendar(identifier: .gregorian)
    let day = calendar.component(.weekday, from: date)
    
    var openTime1 : String?
    var closeTime1 : String?
    
    var openTime2 : String?
    var closeTime2 : String?
    
    let formatter = DateFormatter()
    formatter.dateFormat = "dd/MM/yyyy"
    let dateStringFormat = formatter.string(from: date)
    
    var isShopOpen = false
    
    for h in holidays
    {
        if(h.holidayDate == dateStringFormat)
        {
            for op in store.opendHolidays
            {
                if(op.holidayDate == dateStringFormat)
                {
                    openTime1 = op.startTime1
                    closeTime1 = op.endTime1
                    
                    openTime2 = op.startTime2
                    closeTime2 = op.endTime2
                    
                    isShopOpen = true
                    break
                }
            }
            
            if(!isShopOpen)
            {
                return false
            }
            
            break
        }
    }
    
    if(!isShopOpen)
    {
        if(day == WeekDay.Sunday.rawValue)
        {
            openTime1 = store?.hours.startTime1[6]
            closeTime1 = store?.hours.endTime1[6]
            
            openTime2 = store?.hours.startTime2[6]
            closeTime2 = store?.hours.endTime2[6]
        }
        else
        {
            openTime1 = store?.hours.startTime1[day - 2]
            closeTime1 = store?.hours.endTime1[day - 2]
            
            openTime2 = store?.hours.startTime2[day - 2]
            closeTime2 = store?.hours.endTime2[day - 2]
        }
    }
    
    
    if(openTime1 == nil)
    {
        return false
    }
    else
    {
        let openTime1Date = convertHourToDate(hour : openTime1!)
        let closeTime1Date = convertHourToDate(hour : closeTime1!)
        
        let now = NSDate()
        
        if (now.compare(openTime1Date) == .orderedDescending && now.compare(closeTime1Date) != .orderedDescending)
        {
            return true
        }
        else
        {
            if(openTime2 == nil)
            {
                return false
            }
            else
            {
                let openTime2Date = convertHourToDate(hour : openTime2!)
                let closeTime2Date = convertHourToDate(hour : closeTime2!)
                
                let now = NSDate()
                
                if (now.compare(openTime2Date) == .orderedDescending && now.compare(closeTime2Date) != .orderedDescending)
                {
                    return true
                }
                else
                {
                    return false
                }
            }
        }
    }
}

class ShowRegistrationDialog : YesEventHandler, NoEventHandler {
    var viewController : ViewController!
    var showImage = false
    var image : Data!
    var imageUrl : String!
    var dialogTitle : String! = NSLocalizedString("registrationRequired", comment: "")
    var dialogMessage : String! = NSLocalizedString("registrationRequiredMessage", comment: "")
    var navigationController : UINavigationController!
    var yesButtonName : String = NSLocalizedString("registerNow", comment: "")
    var noButtonName: String = NSLocalizedString("registerLater", comment: "")
    
    func yesRaised() {
        for t in leftDrawer.leftDrawerTabsList
        {
            if(t.tabType == TabType.Profile.rawValue)
            {
                leftDrawer.selectTab(tabString: t.name)
                leftDrawer.currentTab = t.name
                viewController.showView(tab: t, index: 0)
                selectedTab = t
                leftDrawer.highlightedTabString = t.name
                break
            }
        }
    }
    
    func noRaised() {
        print()
    }
    
    func showRegistrationDialog(needEmailVerification : Bool = false)
    {
        if(needEmailVerification)
        {
            dialogTitle = NSLocalizedString("emailVerificationRequired", comment: "")
            dialogMessage = NSLocalizedString("emailVerificationRequiredMessage", comment: "")
            yesButtonName = NSLocalizedString("Yes", comment: "")
            noButtonName = NSLocalizedString("No", comment: "")
        }
        
        if(showImage)
        {
            let sb = UIStoryboard(name:"ImageDialog",bundle:nil)
            let dialog = sb.instantiateInitialViewController() as! ImageDialog
            dialog.imageData = image
            dialog.imageUrl = imageUrl
            
            if(self.viewController != nil)
            {
                self.viewController.present(dialog,animated:false)
            }
            else
            {
                self.navigationController.present(dialog,animated:true)
            }
            
            dialog.setDialogView(title : self.dialogTitle, message : self.dialogMessage, yesButtonName: yesButtonName , noButtonName: noButtonName )
            dialog.yesRaised = self
            dialog.noRaised = self
        }
        else
        {
            let sb = UIStoryboard(name:"YesNoMessageDialog",bundle:nil)
            let dialog = sb.instantiateInitialViewController() as! YesNoMessageDialog
            
            DispatchQueue.main.async(execute: {() -> Void in
                self.viewController.present(dialog,animated:true)
            })
            
            dialog.setDialogView(title : dialogTitle, message : dialogMessage, yesButtonName: yesButtonName, noButtonName: noButtonName)
            dialog.yesRaised = self
            dialog.noRaised = self
        }
        
    }
}

func removeSpecialcharacters(product : ProductModel )
{
    var overViewText : String!
    var ingredientsText : String!
    var howToUseText : String!
    
    if(!isNullOrEmpty(string: product.overViewText))
    {
        overViewText = product.overViewText.replacingOccurrences(of: "¶", with: "\n").replacingOccurrences(of: "я", with: "ÿ").replacingOccurrences(of: "Д", with: "").replacingOccurrences(of: "<br>", with: "\n").replacingOccurrences(of: "Ď", with: ":").replacingOccurrences(of: "Й", with: "É").replacingOccurrences(of: "Г", with: "").replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil).replacingOccurrences(of: "₫", with: "|").withoutHtml
    }
    
    if(!isNullOrEmpty(string: product.ingredientsText))
    {
        ingredientsText = product.ingredientsText.replacingOccurrences(of: "¶", with: "\n").replacingOccurrences(of: "я", with: "ÿ").replacingOccurrences(of: "Д", with: "").replacingOccurrences(of: "<br>", with: "\n").replacingOccurrences(of: "Ď", with: ":").replacingOccurrences(of: "Й", with: "É").replacingOccurrences(of: "Г", with: "").replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil).replacingOccurrences(of: "₫", with: "|").withoutHtml
    }
    
    if(!isNullOrEmpty(string: product.howToUseText))
    {
        howToUseText = product.howToUseText.replacingOccurrences(of: "¶", with: "\n").replacingOccurrences(of: "я", with: "ÿ").replacingOccurrences(of: "Д", with: "").replacingOccurrences(of: "<br>", with: "\n").replacingOccurrences(of: "Ď", with: ":").replacingOccurrences(of: "Й", with: "É").replacingOccurrences(of: "Г", with: "").replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil).replacingOccurrences(of: "₫", with: "|").withoutHtml
    }
    
    product.overViewText = overViewText
    product.ingredientsText = ingredientsText
    product.howToUseText = howToUseText
}

class ImageDownloader
{
    static var waitForNavImageToDownloaded = true
    static var errorOccured = false
    static var data : Data!
    
    static func downloadImage(url: String) -> Data! {
        waitForNavImageToDownloaded = true
        errorOccured = false
        data = nil
        
        let urlTemp = URL(string: percentEncode(s: url))
        getDataFromUrl(url: urlTemp!) { data, response, error in
            guard let data = data, error == nil else
            {
                DispatchQueue.global(qos: .background).async {
                    errorOccured = true
                    waitForNavImageToDownloaded = false
                }
                return
            }
            
            ImageDownloader.data = data
            waitForNavImageToDownloaded = false
        }
        
        while(waitForNavImageToDownloaded)
        {
            sleep(1)
        }
        
        return data
    }
}

func loadTab(tabID : Int, viewController : ViewController)
{
    for t in leftDrawer.leftDrawerTabsList
    {
        if(tabID == t.id)
        {
            if(t.needsUserRegistration)
            {
                if(localDatabase.isAPKRegistered(bussinessID: clientID))
                {
                    viewController.showView(tab: t, index: 0)
                }
                else
                {
                    let s = ShowRegistrationDialog()
                    s.viewController = viewController
                    s.showRegistrationDialog()
                }
            }
            else
            {
                viewController.showView(tab: t, index: 0)
            }
        }
    }
}


func checkForSync(APK : String)
{
    statusDB.needUpdate2(apk : APK)
    
    //syncModel.updateAll = true
    //syncModel.updateRestParameters = true
    //syncModel.updateAbout = true
    //syncModel.updateRedemption = true
    //syncModel.updateTerms = true
    
    //if(syncModel != nil)
   // {
    if(syncModel.updateAll)
    {
        statusModel = StatusModel()
        statusDB.insertStatus(status : statusModel, apk : APK)
        
        parameterizationDatabase.deleteEntries(apk : APK)
        viewsDB.deleteEntries(apk : APK)
        viewsDB.deleteAllGeneralViews(apk : APK)
        //loyaltyDB.deleteEntries(apk : APK)
        storesDB.deleteEntries(apk : APK)
        userProfileDB.deleteEntries(apk : APK)
        productsDB.deleteEntries(apk: APK)
        
        isUpdating = true
    }
    else
    {
        if(syncModel.updateSplash)
        {
            statusModel.isAPKSaved = false
            statusModel.areSplashScrennParametersSaved = false
            viewsDB.deleteEntries(apk: APK)
            isUpdating = true
        }
        
        if(syncModel.updateRestParameters)
        {
            statusModel.isAPKSaved = false
            
            statusModel.isNotAvailableViewSaved = false
            statusModel.isPointsStatementSaved = false
            statusModel.isPointsStatementViewSaved = false
            statusModel.isTicketViewSaved = false
            statusModel.areTicketStylesSaved = false
            statusModel.areEmbededViewsSaved = false
            statusModel.areEmbededViewsParametersSaved = false
            statusModel.isBarcodeViewSaved = false
            statusModel.areGeneralSearchViewSaved = false
            statusModel.isContactUsViewSaved = false
            statusModel.areContactUsTabRelationsSaved = false
            
            viewsDB.deleteEntries(apk: APK)
            parameterizationDatabase.deleteEntries(apk: APK)
            isUpdating = true
        }
        
        if(syncModel.updateProfile)
        {
            statusModel.isAPKSaved = false
            
            statusModel.isUserProfileViewSaved = false
            statusModel.areUserProfileFieldsSaved = false
            statusModel.areUserProfileFieldsStylesSaved = false
            
            userProfileDB.deleteEntries(apk: APK)
            isUpdating = true
        }
        
        if(syncModel.updateProducts)
        {
            statusModel.areProductMenuRelationsSaved = false
            statusModel.isProductMenuSaved = false
            statusModel.areBrandsSaved = false
            
            /*statusModel.areCategoriesSaved = false
             statusModel.areProductsSaved = false
             statusModel.productsPageNo = 0
             statusModel.areBarcodesSaved = false
             statusModel.barcodesPageNo = 0*/
            
            productsDB.deleteEntries(apk: APK)
        }
        
        if(syncModel.updateStyles)
        {
            statusModel.isAPKSaved = false
            
            statusModel.isThemeSaved = false
            statusModel.areStylesSaved = false
            statusModel.areLeftDrawerTabsSaved = false
            statusModel.areRelationsSaved = false
            statusModel.areSocialMediaSaved = false
            statusModel.isNavImageSaved = false
            statusModel.isLeftDrawerImageSaved = false
            statusModel.isBackgroundImageSaved = false
            
            parameterizationDatabase.deleteEntries(apk: APK)
            isUpdating = true
        }
        
        if(syncModel.updateAddresses)
        {
            statusModel.areStoresSaved = false
            statusModel.areHolidaysSaved = false
            statusModel.areStoreLocatorParametersSaved = false
            storesDB.deleteEntries(apk : APK)
        }
        
        if(syncModel.updateProximityOffers)
        {
            statusModel.areProximityOffersSaved = false
            storesDB.deleteEntries(apk : APK)
        }
        
        if(syncModel.updateExpandable)
        {
            statusModel.areExpandableListViewsSaved = false
            viewsDB.deleteEntries(apk: APK)
        }
        
        if(syncModel.updateAuthors)
        {
            statusModel.areAuthorsSaved = false
            viewsDB.deleteEntries(apk: APK)
        }
        
        if(syncModel.updateBlogViews)
        {
            statusModel.areArticlesSaved = false
            viewsDB.deleteEntries(apk: APK)
        }
        
        if(syncModel.updateHome)
        {
            statusModel.areGeneralViewsSaved = false
            statusModel.isHomeSaved = false
        }
        
        if(syncModel.updateOffers)
        {
            statusModel.areGeneralViewsSaved = false
            statusModel.isOffersSaved = false
        }
        
        if(syncModel.updateRedemption)
        {
            statusModel.areGeneralViewsSaved = false
            statusModel.isRedemptionSaved = false
        }
        
        if(syncModel.updateAbout)
        {
            statusModel.areGeneralViewsSaved = false
            statusModel.isAboutSaved = false
        }
        
        if(syncModel.updateTerms)
        {
            statusModel.areGeneralViewsSaved = false
            statusModel.isTermsSaved = false
        }
        
        let leftDrawerTabs = parameterizationDatabase.getLeftDrawerTabs(apk: APK)
        
        let theme  = parameterizationDatabase.getTheme(apk: APK)
        
        if(leftDrawerTabs != nil && defaultTabID != nil)
        {
            for t in leftDrawerTabs!
            {
                if(t.id == defaultTabID)
                {
                    switch t.tabType
                    {
                    case TabType.Home.rawValue:
                        if(syncModel.updateHome)
                        {
                            statusModel.isAPKSaved = false
                            isUpdating = true
                            statusModel.isFirstViewSaved = false
                        }
                    case TabType.Offers.rawValue:
                        if(syncModel.updateOffers)
                        {
                            statusModel.isAPKSaved = false
                            isUpdating = true
                            statusModel.isFirstViewSaved = false
                        }
                    case TabType.About.rawValue:
                        if(syncModel.updateAbout)
                        {
                            statusModel.isAPKSaved = false
                            isUpdating = true
                            statusModel.isFirstViewSaved = false
                        }
                    case TabType.TermsAndConditions.rawValue:
                        if(syncModel.updateTerms)
                        {
                            statusModel.isAPKSaved = false
                            isUpdating = true
                            statusModel.isFirstViewSaved = false
                        }
                    case TabType.RedemptionPolicy.rawValue:
                        if(syncModel.updateRedemption)
                        {
                            statusModel.isAPKSaved = false
                            isUpdating = true
                            statusModel.isFirstViewSaved = false
                        }
                    default:
                        break
                    }
                    break
                }
            }
        }
        
        statusDB.insertStatus(status : statusModel, apk : APK)
        viewsDB.deleteEntries2(apk: APK)
    }
    
}

func showNotifications()
{
    var isTabFound = false
    
    if(numberOfGeneralNotifications  >  numberOfPromotionNotifications)
    {
        for t in leftDrawer.leftDrawerTabsList
        {
            if(t.type == LeftDrawerTabsType.Notifications.rawValue)
            {
                leftDrawer.colapseTabs(selectTabFlag: false, selectedTab: 0)
                leftDrawer.selectTab(tabString: t.name)
                currentViewController2.showView(tab: t, index: 0)
                isTabFound = true
                break
            }
        }
    }
    else
    {
        for t in leftDrawer.leftDrawerTabsList
        {
            if(t.type == LeftDrawerTabsType.PromotionNotifications.rawValue)
            {
                leftDrawer.colapseTabs(selectTabFlag: false, selectedTab: 0)
                leftDrawer.selectTab(tabString: t.name)
                currentViewController2.showView(tab: t, index: 0)
                isTabFound = true
                break
            }
        }
    }
    
    if(!isTabFound)
    {
        for t in leftDrawer.leftDrawerTabsList
        {
            if(t.tabType == TabType.Notifications.rawValue)
            {
                leftDrawer.colapseTabs(selectTabFlag: false, selectedTab: 0)
                leftDrawer.selectTab(tabString: t.name)
                currentViewController2.showView(tab: t, index: 0)
                break
            }
        }
    }
}

func deg2rad(_ deg : Double) -> Double {
    return deg * Double.pi / 180
}

func rad2deg(_ rad : Double) -> Double {
    return rad * 180.0 / Double.pi
}

func distanceBetweenSpots(lat1 : Double, lon1 : Double, lat2 : Double, lon2 : Double, unit : String) -> Int {
    let theta = lon1 - lon2
    var dist = sin(deg2rad(lat1)) * sin(deg2rad(lat2)) + cos(deg2rad(lat1)) * cos(deg2rad(lat2)) * cos(deg2rad(theta))
    dist = acos(dist)
    dist = rad2deg(dist)
    dist = dist * 60 * 1.1515
    if (unit == "K") {
        dist = dist * 1.609344
    }
    else if (unit == "N") {
        dist = dist * 0.8684
    }
    return Int(dist * 1000)
}

func showArticleView(article : ArticleModel, navigationController : UINavigationController, articleViewList : [GeneralInformation2] = [], viewController : ViewController)
{
    viewsDB.insertSeenArticle(articleID: (article.id)!)
    
    isViewPushed = true
    
    var informationsList : [GeneralInformation2] = []
    
    if(article.areItemsSaved)
    {
        informationsList = viewsDB.getGenealInformations(isArticle: true, articleID: article.id)
    }
    else
    {
        for a in (article.articleItems)!
        {
            if(a.type == SlotType.Product.rawValue)
            {
                a.product =  productsDB.getProductByItemNo(itemNo : a.productItemCode)
                
                if(a.product == nil)
                {
                    continue
                }
            }
            
            informationsList.append(a)
        }
    }
    
    if(!isNullOrEmpty(string: article.authorEmailAddress))
    {
        var author = viewsDB.getAuthorModel(emailAddress: article.authorEmailAddress)
        
        if(author != nil)
        {
            var parameters = viewsDB.getAuthorsParameters(emailAddress: article.authorEmailAddress)
            
            if(parameters != nil)
            {
                var signature = GeneralInformation2()
                signature.text = TextModel()
                signature.type = SlotType.Text.rawValue
                signature.text.backgroundColor = "#ffffff"
                signature.text.isTitleCentered = true
                signature.text.descriptionAlignmentType = AlignmentType.Center
                signature.text.splitterColor = "#ffffff"
                
                
                if(!isNullOrEmpty(string: author?.photoUrl))
                {
                    var authorPhoto = GeneralInformation2()
                    authorPhoto.photo = PhotoModel()
                    authorPhoto.type = SlotType.Photo.rawValue
                    
                    authorPhoto.photo.imageUrl = author?.photoUrl
                    //authorPhoto.photo.
                    authorPhoto.photo.aspectRatio = author?.photoAspectRatio
                    authorPhoto.photo.isSignature = true
                    authorPhoto.photo.photoData = author?.photoData
                    
                    informationsList.append(authorPhoto)
                }
                
                if(!isNullOrEmpty(string: author?.name))
                {
                    signature.text.title = author?.name
                    signature.text.titleColor = parameters?.nameTextColor
                    signature.text.titleSize = parameters?.nameTextSize
                    signature.text.titleFont = parameters?.nameFont
                    signature.text.isTitleCentered = true
                    
                    
                    if(!isNullOrEmpty(string: author?.jobDescription))
                    {
                        signature.text.description = author?.jobDescription
                        signature.text.descriptionColor = parameters?.jobDescriptionTextColor
                        signature.text.descriptionSize = parameters?.jobDescriptionTextSize
                        signature.text.descriptionFont = parameters?.jobDescriptionFont
                        signature.text.descriptionAlignmentType = AlignmentType(rawValue: AlignmentType.Center.rawValue)
                        
                    }
                    
                    informationsList.append(signature)
                }
            }
            
            
        }
    }
    
    if(!isNullOrEmpty(string: article.url))
    {
        var shareSlot = GeneralInformation2()
        shareSlot.type = SlotType.Share.rawValue
        shareSlot.share = ShareModel()
        
        shareSlot.share.description = "Share"
        shareSlot.share.descriptionFont = article.titleFont
        shareSlot.share.descriptionTextColor = article.titleColor
        shareSlot.share.descriptionTextSize = 16
        shareSlot.share.tintColor = article.titleColor
        
        shareSlot.share.image = article.imageData
        shareSlot.share.title = article.title
        shareSlot.share.url = article.url
        
        informationsList.append(shareSlot)
    }
    
    if(articleViewList.count > 0)
    {
        var count = 2
        for a in articleViewList
        {
            if(a.type == SlotType.Article.rawValue)
            {
                if(a.article.id != article.id)
                {
                    var relatedArticle = ArticleModel()
                    relatedArticle = a.article
                    
                    var relatedArticleSlot = GeneralInformation2()
                    relatedArticleSlot.article = a.article
                    relatedArticleSlot.article.titleSize = relatedArticleSlot.article.titleSize
                    relatedArticleSlot.type = SlotType.RelatedArticle.rawValue
                    relatedArticleSlot.article.isImageLoaded = false
                    
                    informationsList.append(relatedArticleSlot)
                    
                    count -= 1
                    if(count == 0)
                    {
                        break
                    }
                }
            }
        }
    }
    /*var relatedArticles = viewsDB.getGenealInformations(articleID: article!.id)
     
     if(relatedArticles != nil)
     {
     for r in relatedArticles!
     {
     informationsList?.append(r)
     }
     }*/
    
    let InformationStoryBoard : UIStoryboard = UIStoryboard(name: "GeneralInformationView" , bundle: nil)
    let generalInformationView = InformationStoryBoard.instantiateInitialViewController() as! GeneralInformationViewController
    
    generalInformationView.viewController = viewController
    generalInformationView.isEmbeded = true
    generalInformationView.isArticle = true
    generalInformationView.informationsList = informationsList
    generalInformationView.areItemsSaved = article.areItemsSaved
    generalInformationView.articleModel = article
    
    let embededViewParameters = viewsDB.getEmbededViewParameters(id: 1)
    borderWidth = embededViewParameters?.borderSize
    borderColor = embededViewParameters?.borderColor
    separatorHeight = embededViewParameters?.separatorHeight
    separatorColor = embededViewParameters?.separatorColor
    
    navigationController.pushViewController(generalInformationView, animated: true)
}

func isYoutubeUrl(checkUrl: String) -> Bool {
    
    
    
    let youtubeUrl = checkUrl.suffix(5)
    
    if (!youtubeUrl.contains(".")){
        return true
    }
    else{
        return false
    }
    
}

func setLocationService()
{
    if CLLocationManager.locationServicesEnabled() {
        switch(CLLocationManager.authorizationStatus()) {
        case .authorizedAlways, .authorizedWhenInUse:
            if((apkUserPreferences?.acceptLocation)!)
            {
                //appDelegate.locationManager.stopMonitoringSignificantLocationChanges()
                appDelegate.locationManager.delegate = appDelegate
                appDelegate.locationManager.desiredAccuracy = kCLLocationAccuracyBest
                appDelegate.locationManager.distanceFilter = 0 //40
                appDelegate.locationManager.allowsBackgroundLocationUpdates = true // 1
                appDelegate.locationManager.startUpdatingLocation()// 2
                //appDelegate.locationManager.startMonitoringSignificantLocationChanges()
                
            }
            else
            {
                apkUserPreferences?.acceptLocation = false
                appDelegate.locationManager.stopUpdatingLocation()
                appDelegate.locationManager.stopMonitoringVisits()
                appDelegate.locationManager.stopMonitoringSignificantLocationChanges()
            }
        default:
            break
        }
    }
}
