//
//  ProximityOfferModel.swift
//  RichReach
//
//  Created by Eumbrella on 12/02/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

class ProximityOfferModel : Codable
{
    var title : String!
    var offerDescription : String!
    var startDate : String!
    var endDate : String!
    var offerDuration : Int!
    var termsAndConditions : String!
    var offerImage : Data!
    var offerImageUrl : String!
    var couponCode : String!
    var isOfferAlreadyGiven : Bool!
    var numOfDaysForNextOffer : Int!
    var index : Int!
    var offerID : Int!
    var storeIdList : [Int]! = []
    var givenOfferStoreID : Int!
    
    private enum CodingKeys : String, CodingKey {
        case title = "Title"
        case offerDescription = "Name"
        case startDate = "StartDate"
        case endDate = "EndDate"
        case offerDuration = "NumberOfHoursForOfferValidity"
        case termsAndConditions = "TermsAndConditions"
        case offerImageUrl = "LargeImageUrl"
        case couponCode = "CouponCode"
        case numOfDaysForNextOffer = "NoOfDatesForNextOffer"
        case index = "ViewPriority"
        case offerID = "OfferID"
        case storeIdList = "ValidStoresID"
    }
}
