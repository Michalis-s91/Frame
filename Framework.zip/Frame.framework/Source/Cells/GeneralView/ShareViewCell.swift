//
//  ShareViewCell.swift
//  RichReach
//
//  Created by Eumbrella on 11/02/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import UIKit

class ShareViewCell: UITableViewCell {

    @IBOutlet var shareIcon: UIImageView!
    @IBOutlet var shareDescription: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
