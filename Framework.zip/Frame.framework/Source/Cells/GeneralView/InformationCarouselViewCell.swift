//
//  InformationGalleryViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 17/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// InformationCarouselViewCell is a cell that is been used for showing a photo carusel.
class InformationCarouselViewCell: UITableViewCell, UIScrollViewDelegate {
    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var previousImage: UIImageView!
    @IBOutlet var nextImage: UIImageView!
    @IBOutlet var imageGallery: UIScrollView!
    @IBOutlet var previousView: UIView!
    @IBOutlet var nextView: UIView!
    @IBOutlet var previousViewClick: UIView!
    @IBOutlet var nextViewClick: UIView!
    
    @IBOutlet var imageGaleryWidth: NSLayoutConstraint!
    
    var urls : [UrlModel]!
    var hasTitles : Bool!
    var titleSize : Int!
    var currentIndex = 0
    var isImagePressed = false
    
    var duration : Int = 0
    var interval : Int = 4
    static var timer : Timer!
    
    var isManual : Bool! = true
    var isAutomatic : Bool! = true
    var isScrollingEnabled : Bool! = false
    var width : CGFloat!
    
    var galleryWidth : CGFloat! = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.imageGallery.delegate = self
        //previousView.isHidden = true
        
        let image = UIImage(named: "ic_left_drawer_expand")?.withRenderingMode(.alwaysTemplate)
        previousImage.image = image
        nextImage.image = image
        
        previousImage.tintColor = UIColor.white
        nextImage.tintColor = UIColor.white
        
        roundCorners(.allCorners, radius: 10, view: previousView)
        roundCorners(.allCorners, radius: 10, view: nextView)
        
        previousView.transform = CGAffineTransform(rotationAngle: CGFloat(-Double.pi))
        
        
        let onPreviousClick = UITapGestureRecognizer(target: self, action: #selector(InformationCarouselViewCell.onPreviousClick))
        previousViewClick.isUserInteractionEnabled = true
        previousViewClick.addGestureRecognizer(onPreviousClick)
        
        let onNextClick = UITapGestureRecognizer(target: self, action: #selector(InformationCarouselViewCell.onNextClick))
        nextViewClick.isUserInteractionEnabled = true
        nextViewClick.addGestureRecognizer(onNextClick)
        
        InformationCarouselViewCell.timer = nil
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        if (!isManual)
        {
            previousView.isHidden = true
            nextView.isHidden = true
        }
        else
        {
            previousView.isHidden = false
            nextView.isHidden = false
        }
        
        if(!isScrollingEnabled)
        {
            imageGallery.isScrollEnabled = false
        }
        else
        {
            imageGallery.isScrollEnabled = true
        }
        
        if(InformationCarouselViewCell.timer == nil && isAutomatic)
        {
            InformationCarouselViewCell.timer = Timer.scheduledTimer(timeInterval: TimeInterval(interval), target: self,   selector: (#selector(InformationCarouselViewCell.updateTimer)), userInfo: nil, repeats: true)
        }
        
        if(!hasTitles)
        {
            if(titleLabel != nil)
            {
                titleLabel.removeFromSuperview()
            }
        }
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        resetTimer()
        
        let page = Int(scrollView.contentOffset.x / scrollView.frame.size.width)
        currentIndex = page
        if(hasTitles)
        {
            let title : TitleModel! = urls[currentIndex].title
            self.titleLabel.text = title.title
            self.titleLabel.font = UIFont (name: (title.titleFont)!, size: CGFloat((titleSize)!))
            self.titleLabel.textColor = UIColor((title.titleColor)!)
            self.titleLabel.backgroundColor =  UIColor((title.titleBackgroundColor)!)
        }
    }
    
    @objc func onPreviousClick (sender:UITapGestureRecognizer) {
        if (isManual)
        {
            isImagePressed = true
            resetTimer()
            
            if(currentIndex == 0)
            {
                currentIndex = urls.count - 1
            }
            else
            {
                currentIndex -= 1
            }
            
            changeImage()
        }
    }
    
    @objc func onNextClick (sender:UITapGestureRecognizer) {
        if (isManual)
        {
            resetTimer()
            showNextImage()
        }
    }
    
    @objc func updateTimer(){
        showNextImage()
    }
    
    /// Shows next image.
    func showNextImage()
    {
        isImagePressed = true
        
        if(currentIndex == urls.count - 1 )
        {
            currentIndex = 0
        }
        else
        {
            currentIndex += 1
        }
        
        changeImage()
    }
    
    
    /// Show the image which has index equals with currentIndex.
    func changeImage()
    {
        if(hasTitles)
        {
            let title : TitleModel! = urls[currentIndex].title
            self.titleLabel.text = title.title
            self.titleLabel.font = UIFont (name: (title.titleFont)!, size: CGFloat((titleSize)!))
            self.titleLabel.textColor = UIColor((title.titleColor)!)
            self.titleLabel.backgroundColor =  UIColor((title.titleBackgroundColor)!)
        }
        
        UIView.animate(withDuration: 1, animations: {
            self.imageGallery.setContentOffset(CGPoint(x: CGFloat(self.currentIndex) * self.galleryWidth, y: 0), animated: false)
        })
    }
    
    /// Reset timer
    func resetTimer()
    {
        InformationCarouselViewCell.timer.invalidate()
        InformationCarouselViewCell.timer = Timer.scheduledTimer(timeInterval: TimeInterval(self.interval), target: self,   selector: (#selector(InformationCarouselViewCell.updateTimer)), userInfo: nil, repeats: true)
    }
    
    /// Set carusel images and titles.
    func setCarusel(isStore : Bool = false, width : CGFloat!)
    {
        galleryWidth = width
        //self.width = width
        var titleHeight : CGFloat! = 0.0
        
        if(hasTitles)!
        {
            titleHeight = urls[0].title.title?.height(withConstrainedWidth: width, font: UIFont (name: (urls[0].title.titleFont)!, size: CGFloat((urls[0].title.titleSize)!))!)
        }
        
        var cellHeight : CGFloat!
        let aspcetRatio = urls[0].aspectRatio
        if(aspcetRatio != nil)
        {
            cellHeight = width * CGFloat(aspcetRatio!) + titleHeight
        }
        else
        {
            cellHeight = width + titleHeight
        }
        
        if(hasTitles)
        {
            let title : TitleModel! = self.urls[0].title
            self.titleLabel.text = title.title
            self.titleLabel.font = UIFont (name: (title.titleFont)!, size: CGFloat((self.titleSize)!))
            self.titleLabel.textColor = UIColor((title.titleColor)!)
            self.titleLabel.backgroundColor =  UIColor((title.titleBackgroundColor)!)
        }
        
        for i in 0..<self.urls.count
        {
            let imageUrl = self.urls[i].url
            //let url = URL(string: percentEncode(s: image!))
            let imageView : UIImageView! = UIImageView()
            
            //imageView.kf.setImage(with: url)
            if(isStore)
            {
                imageView?.image = storesDB.getImage(url: imageUrl!)
                imageView.frame = CGRect(x: CGFloat(i) * width , y: 0, width: width, height: cellHeight)
                self.imageGallery.addSubview(imageView)
            }
            else
            {
                var image = viewsDB.getImage(url: imageUrl!)
                
                if(image != nil)
                {
                    imageView?.image = image
                    imageView.frame = CGRect(x: CGFloat(i) * width , y: 0, width: width, height: cellHeight)
                    self.imageGallery.addSubview(imageView)
                }
                else
                {
                    let url = URL(string: percentEncode(s: imageUrl!))
                    imageView.kf.setImage(with: url, completionHandler: {
                        (image, error, cacheType, imageUrl) in
                        // image: Image? `nil` means failed
                        // error: NSError? non-`nil` means failed
                        // cacheType: CacheType
                        //                  .none - Just downloaded
                        //                  .memory - Got from memory cache
                        //                  .disk - Got from disk cache
                        // imageUrl: URL of the image
                        
                        if(image != nil)
                        {
                            //photo?.aspectRatio = Double((image?.size.height)! / (image?.size.width)!)
                            
                            //if(cacheType == .none)
                            //{
                            //    self.informationTableView.reloadData()
                            //}
                            
                            imageView.frame = CGRect(x: CGFloat(i) * width , y: 0, width: width, height: cellHeight)
                            self.imageGallery.addSubview(imageView)
                        }
                    })
                }
            }
            
            print(self.imageGallery.frame.size.height)
            
        }
        
        self.imageGallery.contentSize.width = width * CGFloat(self.urls.count)
        
    }
    

}
