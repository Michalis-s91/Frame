//
//  HelpAndSupportViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 20/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Creates help and support view where user can ask for help and/or support.
class HelpAndSupportViewController: ViewController , ModalViewControllerDelegate{
    @IBOutlet var supportTypeLabel: UILabel!
    @IBOutlet weak var messageTextField: UITextField!
    
    var supportTypesDialog : TableDialog!
    var viewModel : HelpAndSupportViewModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.prepare(for:  UIStoryboardSegue(identifier: "a",source: UIViewController() ,destination: UIViewController()), sender: nil)
        
        let onClick = UITapGestureRecognizer(target: self, action: #selector(HelpAndSupportViewController.onClickSupportTypeLabel))
        supportTypeLabel.isUserInteractionEnabled = true
        supportTypeLabel.addGestureRecognizer(onClick)
        
        if (viewModel == nil)
        {
            viewModel = HelpAndSupportViewModel()
        }
        
        self.hideKeyboardWhenTappedAround()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    @objc func onClickSupportTypeLabel(sender:UITapGestureRecognizer) {
        let sb = UIStoryboard(name:"TableDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController()!
        supportTypesDialog = dialog as? TableDialog
        self.present(dialog,animated:true)
        supportTypesDialog.delegate = self
        supportTypesDialog.setDialogView(title: "Support", types: StaticDataRepository.getSupportTypesStrings(), selectedType: viewModel.selectedType )
    }
    
    @IBAction func textChanged(_ sender: UITextField) {
        viewModel.message = sender.text!
    }
    
    @IBAction func submitMessage(_ sender: UIBarButtonItem) {
        if(!(localDatabase.isAPKRegistered(bussinessID: clientID))!)
        {
            let s = ShowRegistrationDialog()
            s.viewController = self
            s.showRegistrationDialog()
        }
        else
        {

            if(!isNullOrEmpty(string: viewModel.message) )
            {
                let task = WebApiTask(viewController : self, action : submitMessage, displayToast : true)
                task.setFailureAction(action: showStatusMessage)
                task.start()
            }
            else
            {
                let toast = CustomToast()
                toast.setToast(viewController : self, message : NSLocalizedString("messageRequired", comment: ""))
                toast.show()
            }
        }
    }
    
    /// Show custom toast with message.
    private func showStatusMessage ()
    {
        DispatchQueue.main.async(execute: {() -> Void in
            let toast = CustomToast()
            toast.setToast(viewController : self, message : self.viewModel.verificationMessage , duration : 4)
            toast.show()
        })
    }
    
    /// Submit message.
    private func submitMessage()
    {
        viewModel.submitMessage()
        showStatusMessage()
    }
    
    /// Dismiss dialog.
    func dismissed() {
        viewModel.selectedType = supportTypesDialog.selectedType
        supportTypeLabel.text = viewModel.selectedType
    }
}
