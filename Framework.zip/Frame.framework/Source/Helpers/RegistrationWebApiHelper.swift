//
//  RegistrationWebApiHelper.swift
//  RichReach2
//
//  Created by Eumbrella on 23/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Helper for registration web api. Unpacks strings, deserialize objects and removes prefix.
class RegistrationWebApiHelper {
    
    private static let  START_CHAR : Character = "["
    private static let END_CHAR : Character = "]"
    private static let SPLIT_CHAR : Character = "|"
    private static let PARAMETER_SPLIT_CHAR : Character = ","
    
    /// Unpacks the input string into partners.
    ///
    /// - Parameter packageString: The packed string.
    /// - Returns: The partners.
    /// - Throws: error
    static func unpackPartnerIDs(packageString : String) throws -> [PartnerModel]!
    {
        do
        {
            var tupleList : [PartnerModel] = []
            
            if(packageString != "null")
            {
                let startIndex = packageString.index(of: START_CHAR)
                let endIndex = packageString.index(of: END_CHAR)
                
                if(startIndex == nil || endIndex == nil)
                {
                    throw Errors.error
                }
                
                let substring = packageString[startIndex! + 1..<endIndex!]
                let tokens = substring.split(separator: SPLIT_CHAR, omittingEmptySubsequences: false)
                
                for t in tokens
                {
                    if (!isNullOrEmpty(string: String(t)))
                    {
                        var subTokens = t.split(separator: PARAMETER_SPLIT_CHAR)
                        let partnerModel = PartnerModel()

                        partnerModel.id = Int(String(subTokens[0]))
                        partnerModel.partnerID = Int(String(subTokens[0]))
                        partnerModel.isRoot = String(subTokens[1]) == "1"
                        partnerModel.imageUri = String(subTokens[2])
                        partnerModel.name = String(subTokens[3])
                        partnerModel.shortName = String(subTokens[4])
                        tupleList.append(partnerModel)
                    }
                }
            }
            
            return tupleList
        }
        catch
        {
            
        }
        return nil
    }

    /// Unpacks the input string into a user profile object.
    ///
    /// - Parameter packageString: The packed string.
    /// - Returns: The unpacked user profile object.
    /// - Throws: error
    static func unPackUserProfile(packageString : String) throws -> UserProfileModel
    {
        let userProfile = UserProfileModel()
        do {
            let startIndex = packageString.index(of: START_CHAR)
            let endIndex = packageString.index(of: END_CHAR)
            
            if(startIndex == nil || endIndex == nil)
            {
                throw Errors.error
            }
            
            let substring = packageString[startIndex!..<endIndex!]
            var tokens = substring.split(separator: SPLIT_CHAR, omittingEmptySubsequences: false)
            
            userProfile.phoneNumber = String(tokens[0])
            userProfile.name = String(tokens[1])
            userProfile.surname = String(tokens[2])
            
            if(String(tokens[3]) == nil)
            {
                userProfile.gender = nil
            }
            else
            {
                print(String(tokens[3]))
                if (String(tokens[3]) == "1")
                {
                    userProfile.gender = 0
                }
                else if (String(tokens[3]) == "2")
                {
                    userProfile.gender = 1
                }
                else
                {
                    userProfile.gender = nil
                }
            }
            
            userProfile.emailAddress = String(tokens[4])
            userProfile.province = String(tokens[5])
            userProfile.city = String(tokens[6])
            userProfile.homeAddress = String(tokens[7])
            userProfile.postCode = String(tokens[8])
            userProfile.birthDate = String(tokens[9])
            
            userProfile.hasVerifiedEmailAddress = false
            
            userProfile.titleID = Int(String(tokens[11]))
            
            return userProfile
        }
        catch
        {
            
        }
        
        return userProfile
    }
}
