//
//  DescriptionDialog.swift
//  RichReach2
//
//  Created by Eumbrella on 13/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// DescriptionDialog is a dialog being displayed when we want to display a short description to the user about
/// something. Currently it is used in the "About" view to display the eOffers section description, the telephony
/// section description etc.
class DescriptionDialog: UIViewController {

    @IBOutlet var descriptionView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dialogView: UIView!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet var splitter: UIView!
    @IBOutlet var closeButton: UIButton!
    
    static var dialogDisappeared = false
    var dismissWhenClickOutside = true
    
    var titleText : String!
    var descriptionText : String!
    var viewIsAppeared = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        DescriptionDialog.dialogDisappeared = false
        
        titleLabel.textColor = Colors.sectionTextColor
        
        dialogView.sizeToFit()
        descriptionLabel.sizeToFit()
        descriptionLabel.numberOfLines = 0
        
        if(splitter != nil)
        {
            splitter.backgroundColor = Colors.dialogLineColor
        }
        
        if(closeButton != nil)
        {
            let closeImage = UIImage(named: "ic_dialog_close")?.withRenderingMode(.alwaysTemplate)
            closeButton.setImage(closeImage, for: .normal)
            closeButton.tintColor = Colors.dialogTintColor
        }
        
        let onBackgroundClick = UITapGestureRecognizer(target: self, action: #selector(DescriptionDialog.onBackgroundClick(sender:)))
        backgroundView.isUserInteractionEnabled = true
        backgroundView.addGestureRecognizer(onBackgroundClick)
        
        titleLabel.textColor = Colors.dialogTextColor
        
        titleLabel.font = UIFont (name: FontsAndSizes.dialogFont, size: CGFloat(FontsAndSizes.dialogTextSize))
        
        
        if(APK == APKsEnum.BeautyLine.rawValue)
        {
            descriptionLabel.font = UIFont (name: "CharpentierSansPro-Leger", size: CGFloat(FontsAndSizes.dialogTextSize))
            descriptionLabel.textColor = Colors.dialogTextColor
        }
    }

    override func viewDidLayoutSubviews() {
        if(viewIsAppeared)
        {
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height
        }
        else
        {
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        titleLabel.text = titleText
        descriptionLabel.text = descriptionText
        self.descriptionLabel.layoutIfNeeded()
        self.descriptionView.layoutIfNeeded()
        self.dialogView.layoutIfNeeded()
        
        if(splitter != nil)
        {
            splitter.backgroundColor = Colors.dialogLineColor
        }
        
        if(closeButton != nil)
        {
            let closeImage = UIImage(named: "ic_dialog_close")?.withRenderingMode(.alwaysTemplate)
            closeButton.setImage(closeImage, for: .normal)
            closeButton.tintColor = Colors.dialogTintColor
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        DescriptionDialog.dialogDisappeared = false
        roundCorners([.topLeft,.topRight], radius: 10, view: dialogView)
        
        UIView.animate(withDuration: 0.3, animations: {
            self.descriptionView.backgroundColor = Colors.dialogsBackgroundColor
            
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height
        }, completion: nil)
        self.dialogView.isHidden = false
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        DescriptionDialog.dialogDisappeared = true
    }
    
    @objc func onBackgroundClick(sender:UITapGestureRecognizer) {
        if(dismissWhenClickOutside)
        {
            dismissDialog()
        }
    }
    
    @IBAction func dismissDialog(_ sender: UIButton) {
        dismissDialog()
    }
    
    /// Sets the dialog view.
    ///
    /// - Parameters:
    ///   - title: The dialog title.
    ///   - description: The dialog description.
    func setDialogView(title: String, description: String)
    {
        titleText = title
        descriptionText = description
    }
    
    /// Update descritpion.
    ///
    /// - Parameter newDescription: The new description.
    func updateDescription(newDescription : String)
    {
        descriptionText = newDescription
        self.descriptionLabel.layoutIfNeeded()
        self.descriptionView.layoutIfNeeded()
        self.dialogView.layoutIfNeeded()
        //self.view.layoutIfNeeded()
    }
    
    
    /// Dismiss dialog with animation.
    func dismissDialog(){
        UIView.animate(withDuration: 0.3, animations: {
            if(self.descriptionView != nil && self.dialogView != nil)
            {
                self.descriptionView.backgroundColor = UIColor.init(red: 1,
                                                                    green: 1,
                                                                    blue: 1,
                                                                    alpha: 0)
                
                self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
            }
        }, completion: {(finished: Bool) in
            self.dismiss(animated: true,completion: nil)
        })
    }
    
    /// Dismiss dialog with animation.
    func dismissDialog(runnable : @escaping Runnable){
        UIView.animate(withDuration: 0.3, animations: {
            if(self.descriptionView != nil && self.dialogView != nil)
            {
                self.descriptionView.backgroundColor = UIColor.init(red: 1,
                                                                    green: 1,
                                                                    blue: 1,
                                                                    alpha: 0)
                
                self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
            }
        }, completion: {(finished: Bool) in
            self.dismiss(animated: true,completion: { () in
                if(runnable != nil)
                {
                    runnable()
                }
            })
        })
    }
    
}
