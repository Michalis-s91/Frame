//
//  RegistrationWebApi.swift
//  RichReach2
//
//  Created by Eumbrella on 23/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// Web apis for user registration and verification.
class RegistrationWebApi {
    private static var userProfile : UserProfileModel!
    
    /// Calls QuickRegistrationWithNoSMS api.
    ///
    /// - Parameters:
    ///   - phoneNumber: The phone number.
    ///   - prefix: The prefix.
    ///   - carrier: The carrier.
    ///   - deviceID: The device ID.
    ///   - applicationLanguage: The application language (e.g. "en" for english).
    /// - Returns: "OK" if the registration was successful otherwise returns the response of request.
    static func quickRegistration(phoneNumber : String, emailAddress : String! = "", prefix : String, carrier : String, deviceID : String, applicationLanguage : String) -> String
    {
        let httpRequest = HttpRequest()
    
        do
        {
            var emailAddressTemp = emailAddress
            if(emailAddressTemp == nil)
            {
                emailAddressTemp = ""
            }
            
            print("quick registration2")
            let currentAppVersion = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
            let currentAppBuildVersion = Bundle.main.infoDictionary?["CFBundleVersion"]  as! String
            
            try httpRequest.postAsync(url: "\(ApiUrlDefaults.REGISTRATION_URL)InitializeUserRegistration/",params: "PhoneNumber=\(phoneNumber)&Prefix=\(prefix)&DeviceID=\(deviceID ?? "")&NetworkOperator=\(carrier)&ApplicationLanguage=\(applicationLanguage)&EmailAddress=\(emailAddressTemp ?? "")&ApkID=\(businessID!)&IsBranded=\(Bundle.main.bundleIdentifier! == APKsEnum.RichReach.rawValue ? false : true)&BuildVersion=\(currentAppBuildVersion == nil ? "" : (currentAppBuildVersion ?? "") )&BuildVersionStr=\(currentAppVersion == nil ? "" : (currentAppVersion ?? "") )")
        
            return "OK"
        }
        catch
        {
            return httpRequest.requestResponse
        }
    }
    
    static func getVerificationCodeViaIncomingCall(phoneNumber : String, prefix : String, carrier : String, deviceID : String, applicationLanguage : String) -> String!
    {
        let httpRequest = HttpRequest()
        
        do
        {
            let currentAppVersion = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
            let currentAppBuildVersion = Bundle.main.infoDictionary?["CFBundleVersion"]  as! String
            
            try httpRequest.post3(url: "\(ApiUrlDefaults.REGISTRATION_URL)GetVerificationCodeViaIncomingCall/",params: "PhoneNumber=\(phoneNumber)&Prefix=\(prefix)&DeviceID=\(deviceID ?? "")&NetworkOperator=\(carrier)&ApplicationLanguage=\(applicationLanguage)")
            
            return httpRequest.requestResponse
        }
        catch
        {
            return httpRequest.requestResponse
        }
    }
    
    static func updateEmailAddress(phoneNumber : String, emailAddress : String!) -> String
    {
        let httpRequest = HttpRequest()
        
        do
        {
            var emailAddressTemp = emailAddress
            if(emailAddressTemp == nil)
            {
                emailAddressTemp = ""
            }
            
            try httpRequest.postAsync(url: "http://www.commtor.com/webapi/AccountApi/UpdatePendingRegistrationEmailAddress/",params: "PhoneNumber=\(phoneNumber)&EmailAddress=\(emailAddressTemp ?? "")&ApkID=\(businessID!)")
            
            return "OK"
        }
        catch
        {
            return httpRequest.requestResponse
        }
    }
    
    static func updateInitialRegistrationEmailAddress(phoneNumber : String, emailAddress : String!) -> EmailValidationStatus!
    {
        let httpRequest = HttpRequest()
        
        do
        {
            var emailAddressTemp = emailAddress
            if(emailAddressTemp == nil)
            {
                emailAddressTemp = ""
            }
            
            try httpRequest.post3(url: "\(ApiUrlDefaults.REGISTRATION_URL)UpdatePendingRegistrationEmailAddress_V2/",params: "PhoneNumber=\(phoneNumber)&EmailAddress=\(emailAddressTemp ?? "")&ApkID=\(businessID!)")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let status = try decoder.decode(EmailValidationStatus.self, from : (response.data(using: .utf8))!)
                
                return status
            }
        }
        catch
        {
        }
        
        return nil
    }

    /// Calls VerifyQRCode api.
    ///
    /// - Parameters:
    ///   - phoneNumber: The phone number.
    ///   - code: The verification code.
    ///   - deviceID: The device ID.
    ///   - partnerCode: The partner code.
    ///   - registrationSourceTypeEnum: The registration source type.
    /// - Returns: The response of request.
    static func quickRegistrationVerification( phoneNumber : String, code : String, deviceID : String, partnerCode : String, registrationSourceTypeEnum : Int) -> Int
    {
        do
        {
            print("quick registration1")
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "\(ApiUrlDefaults.REGISTRATION_URL)VerifyQRCode/",params: "PhoneNumber=\(phoneNumber)&Code=\(code)&DeviceID=\(deviceID ?? "")&PartnerCode=\(partnerCode)&RegistrationSourceType=\(String(registrationSourceTypeEnum))")
            
            return Int(httpRequest.requestResponse)!
        }
        catch
        {
            return ApiResponseEnumType.VerificationError.rawValue
        }
    }
    
    /// Calls GetVerificationCode api.
    ///
    /// - Parameters:
    ///   - phoneNumber: The phone number.
    ///   - prefix: The prefix.
    ///   - carrier: The carrier.
    ///   - deviceID: The device ID.
    ///   - applicationLanguage: The application language (e.g. "en" for english).
    /// - Returns: The response of request.
    static func getVerificationCodeViaSMS(phoneNumber : String,prefix : String, carrier : String, deviceID : String, applicationLanguage : String) throws -> String
    {
        let httpRequest = HttpRequest()
        
        do
        {
            if(appMode == AppModeType.Debug.rawValue)
            {
                //try httpRequest.post(url: "http://www.commtor.com/webapi/AccountApi/GetVerificationCodeDebug/",params: "PhoneNumber=\(phoneNumber)&Prefix=\(prefix)&DeviceID=\(deviceID ?? "")&NetworkOperator=\(carrier)&ApplicationLanguage=\(applicationLanguage)")
                try httpRequest.post3(url: "\(ApiUrlDefaults.REGISTRATION_URL)GetVerificationCodeViaSMS/",params: "PhoneNumber=\(phoneNumber)&Prefix=\(prefix)&DeviceID=\(deviceID ?? "")&NetworkOperator=\(carrier)&ApplicationLanguage=\(applicationLanguage)")
                
            }
            else
            {
                try httpRequest.post3(url: "\(ApiUrlDefaults.REGISTRATION_URL)GetVerificationCodeViaSMS/",params: "PhoneNumber=\(phoneNumber)&Prefix=\(prefix)&DeviceID=\(deviceID ?? "")&NetworkOperator=\(carrier)&ApplicationLanguage=\(applicationLanguage)")
            }
            
            return httpRequest.requestResponse
        }
        catch
        {
            throw Errors.error
        }
    }
    
    /// Calls GetVerificationCode api.
    ///
    /// - Parameters:
    ///   - phoneNumber: The phone number.
    ///   - prefix: The prefix.
    ///   - carrier: The carrier.
    ///   - deviceID: The device ID.
    ///   - applicationLanguage: The application language (e.g. "en" for english).
    /// - Returns: The response of request.
    static func getVerificationCodeViaEmail(phoneNumber : String, email : String ,prefix : String, carrier : String, deviceID : String, applicationLanguage : String) throws -> String
    {
        let httpRequest = HttpRequest()
        
        do
        {
            try httpRequest.post(url: "\(ApiUrlDefaults.REGISTRATION_URL)GetVerificationCodeViaEmail/",params: "PhoneNumber=\(phoneNumber)&Prefix=\(prefix)&Prefix=\(prefix)&DeviceID=\(deviceID ?? "")&NetworkOperator=\(carrier)&ApplicationLanguage=\(applicationLanguage)&ApkID=\(businessID!)")
            
            return httpRequest.requestResponse
        }
        catch
        {
            throw Errors.error
        }
    }
    
    /// Gets optin partners for specific user.
    ///
    /// - Parameter phoneNumber: The phone number.
    /// - Returns: The unpacked response of request.
    static func getOptinPartners(phoneNumber : String) -> [PartnerModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            print("ClientTelephone=\(phoneNumber ?? "")")
            try httpRequest.post(url: "http://www.commtor.com/webapi/PartnersApi/GetPartnerOptIns",params: "ClientTelephone=\(phoneNumber ?? "")")

            return try RegistrationWebApiHelper.unpackPartnerIDs(packageString: httpRequest.requestResponse)
        }
        catch
        {
            print("dsds")
            return nil
        }
    }
    
    /// Gets the user's profile information and returns them.
    ///
    /// - Parameter phone: The user's phone number.
    /// - Returns: An object that holds the user's profile information.
    static func getUserProfile(phone : String) -> UserProfileModel!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "\(ApiUrlDefaults.REGISTRATION_URL)GetUserProfile/",params: "PhoneNumber=\(phone)")
            let response = httpRequest.requestResponse
            userProfile = try RegistrationWebApiHelper.unPackUserProfile(packageString:  response!)
            return userProfile
        }
        catch
        {
            return nil
        }
    }
    
    /// Gets and returns the user's default options.
    ///
    /// - Parameter phoneNumber: The user's phone number.
    /// - Returns: An object that contains the user's default options.
    static func getUserDefaultOptions(phoneNumber : String!) -> UserDefaultOptions!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "\(ApiUrlDefaults.REGISTRATION_URL)GetUserDefaultOptions/",params: "PhoneNumber=\(phoneNumber ?? "")")

            var response  = httpRequest.requestResponse
            response = getUpdatedJsonStr(inputString: response!)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                return try decoder.decode(UserDefaultOptions.self, from : (response!.data(using: .utf8))!) as UserDefaultOptions
            }
        }
        catch
        {
            print()
        }
        
        return nil
    }
    
    static func verifyPhoneNumber(phoneNumber : String!,code : String, deviceID : String, partnerCode : String, registrationSourceType : Int, verificationType : Int) -> VerificationResponseModel!
    {
        do
        {
            
            /*var clientIDTemp = clientID
            if(clientID == ClientIDs.HollandAndBarrett.rawValue)
            {
                clientIDTemp = ClientIDs.BeautyLine.rawValue
            }*/
            
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://93.109.209.42/RichReachWebApplicationTest/api/RegistrationApi/VerifyPhoneNumber_V3/",params: "PhoneNumber=\(phoneNumber ?? "")&Code=\(code ?? "")&DeviceID=\(deviceID ?? "")&PartnerCode=\(partnerCode)&RegistrationSourceType=\(registrationSourceType)&VerificationType=\(verificationType)&BusinessID=\(clientID!)")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let verificationResponse = try decoder.decode(VerificationResponseModel.self, from : (response.data(using: .utf8))!)
                
                return verificationResponse
            }
        }
        catch
        {
            print()
        }
        
        return nil
    }
    
    static func verifyEmailAddress(phoneNumber : String!, emailAddress : String, code : String, deviceID : String, partnerCode : String, registrationSourceType : Int, verificationType : Int) -> VerificationResponseModel!
    {
        do
        {
            let httpRequest = HttpRequest()
            
            try httpRequest.post(url: "http://93.109.209.42/RichReachWebApplicationTest/api/RegistrationApi/VerifyEmailAddress_V3/",params: "PhoneNumber=\(phoneNumber ?? "")&EmailAddress=\(emailAddress ?? "")&Code=\(code ?? "")&DeviceID=\(deviceID ?? "")&PartnerCode=\(partnerCode)&RegistrationSourceType=\(registrationSourceType)&VerificationType=\(verificationType)&BusinessID=\(clientID!)")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let verificationResponse = try decoder.decode(VerificationResponseModel.self, from : (response.data(using: .utf8))!)
                
                return verificationResponse
            }
        }
        catch
        {
            print()
        }
        
        return nil
    }

}

class VerificationResponseModel : Codable
{
    var verificationStatus : Int!
    var userIPAddress : String!
    var verificationDate : String!
    var numOfActiveCoupons : Int!
    var phoneNumberCount : Int!
    var emailAddressCount : Int!
    var fieldCount : Int!
    
    private enum CodingKeys : String, CodingKey {
        case verificationStatus = "VerificationStatus"
        case userIPAddress = "UserIPAddress"
        case verificationDate = "VerificationDate"
        case numOfActiveCoupons = "ActiveCouponsCount"
        case phoneNumberCount = "BusinessPhoneNumberCount"
        case emailAddressCount = "BusinessEmailAddressCount"
    }
}
