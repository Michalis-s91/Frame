//
//  CustomTabbarViewController2.swift
//  RichReach2
//
//  Created by Eumbrella on 07/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// Provides customised tab bar class. Instead of the iOS default tab bar, our implementation has the same view with
/// default tab bar and same functionality. We create our own tab bar in order to resolve some problems we faced with default tab bar.
class CustomTabbarViewController: UIViewController, UIScrollViewDelegate {
    
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var previousView: UIView!
    @IBOutlet var nextView: UIView!
    
    static var font = "Roboto-Medium"
    static var textSize = 10
    var tabWidth = 94
    var tabHeight = 50
    var currentOffset : CGFloat = 0.0
    static var tabBarTabs : [Tab] = []
    var viewClicked = false
    
    static var currentIndex : Int! = 0
    static var navigationControllers : [UINavigationController]! = []
    var onViewsClickRecognizers : [UITapGestureRecognizer] = []
    static var isViewShowed: [Bool]! = []
    var views : [TabView] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.scrollView.delegate = self
        
        previousView.transform = CGAffineTransform(rotationAngle: CGFloat(-Double.pi))
        
        self.scrollView.frame.size.width = UIScreen.main.bounds.size.width - (2 * previousView.frame.size.width) //CGRect(x: self.scrollView.frame.origin.x, y: self.scrollView.frame.origin.y, width: Int(UIScreen.main.bounds.size.width - 56), height: tabHeight)
        
        let onPreviousClick = UITapGestureRecognizer(target: self, action: #selector(CustomTabbarViewController.onPreviousClick))
        previousView.isUserInteractionEnabled = true
        previousView.addGestureRecognizer(onPreviousClick)
        
        let onNextClick = UITapGestureRecognizer(target: self, action: #selector(CustomTabbarViewController.onNextClick))
        nextView.isUserInteractionEnabled = true
        nextView.addGestureRecognizer(onNextClick)
    }
    
    @objc func onPreviousClick (sender:UITapGestureRecognizer) {
        viewClicked = true
        if(currentOffset > 0)
        {
            currentOffset -= CGFloat(tabWidth)
            scrollView.setContentOffset(CGPoint(x: currentOffset, y: 0), animated: true)
        }
    }
    
    @objc func onNextClick (sender:UITapGestureRecognizer) {
        if(currentOffset < CGFloat((CustomTabbarViewController.tabBarTabs.count - 4) * tabWidth))
        {
            currentOffset += CGFloat(tabWidth)
            scrollView.setContentOffset(CGPoint(x: currentOffset, y: 0), animated: true)
        }
    }
    
    @objc func onViewClick(sender : UITapGestureRecognizer) {
        selectedTab = CustomTabbarViewController.tabBarTabs[(sender.view?.tag)!]
        tabIndex = (sender.view?.tag)!
        //setSelectedTab(index : (sender.view?.tag)!)
        showView(index : (sender.view?.tag)!)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let page = Int(round(scrollView.contentOffset.x / CGFloat(tabWidth)))
        currentOffset = CGFloat(page * tabWidth)
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        let page = Int(round(scrollView.contentOffset.x / CGFloat(tabWidth)))
        currentOffset = CGFloat(page * tabWidth)
    }
    
    /// Sets tab bar properties.
    ///
    /// - Parameter tabs: The tabs of tab bar.
    func setTabBar(tabs : [Tab])
    {
        CustomTabbarViewController.tabBarTabs = tabs
        
        if(tabs.count <= 4)
        {
            tabWidth = Int(self.scrollView.frame.width / CGFloat(tabs.count))
        }
        
        
        var i = 0
        for t in tabs
        {
            let view = TabView()
            view.frame = CGRect(x: i * tabWidth , y: 0, width: tabWidth, height: tabHeight)
            
            let theme  = parameterizationDatabase.getTheme(apk: APK)
            
            if(theme != nil)
            {
                
            }
            
            let image = UIImageView()
            image.image = UIImage(named : t.image)?.withRenderingMode(.alwaysTemplate)
            image.tintColor = Colors.tabBarTintColor
            image.frame.size.width = 28
            image.frame.size.height = 28
            image.center = CGPoint(x: tabWidth/2, y: tabHeight/2 - 8 )
            
            let label = UILabel()
            label.text = t.name
            label.textAlignment = .center
            label.frame = CGRect(x: 0 , y: Int(view.frame.height - 16), width: tabWidth, height: 10)
            //label.font = UIFont (name: CustomTabbarViewController.font, size: FontsAndSizes.ta)
            label.textColor = Colors.tabBarTextColor
            
            
            view.addSubview(image)
            view.addSubview(label)
            
            view.backgroundColor = Colors.tabBarBackground
            self.scrollView.addSubview(view)
            
            view.image = image
            view.label = label
            views.append(view)
            
            let onViewClick = UITapGestureRecognizer(target: self, action: #selector(CustomTabbarViewController.onViewClick))
            view.tag = i
            view.addGestureRecognizer(onViewClick)
            
            i += 1
        }
        
        self.scrollView.contentSize.width = CGFloat(tabWidth * tabs.count)
    }
    
    /// Set the selected tab.
    ///
    /// - Parameter index: The index of new selected tab.
    func setSelectedTab(index : Int)
    {
        for v in views
        {
            v.label.textColor = Colors.tabBarTextColor
            v.image.tintColor = Colors.tabBarTextColor
        }
        
        views[index].label.textColor = Colors.tabBarSelectedTextColor
        views[index].image.tintColor = Colors.tabBarSelectedTextColor
    }
    
    /// Shows the view of selected tab.
    ///
    /// - Parameter index: The index of selected tab.
    func showView(index : Int)
    {
        if(index != CustomTabbarViewController.currentIndex)
        {
            for i in 0..<CustomTabbarViewController.navigationControllers.count
            {
                if(i != index)
                {
                    CustomTabbarViewController.navigationControllers[i].view.removeFromSuperview()
                    //CustomTabbarViewController2.navigationControllers[i].dismiss(animated: false, completion: nil)
                }
            }
            
            AllPartnersView.displayLoyaltyPartnersOnly = false
            UIApplication.shared.keyWindow?.addSubview(CustomTabbarViewController.navigationControllers[index].view)

            if(!CustomTabbarViewController.isViewShowed[index])
            {
                //if(!CustomTabbarViewController.navigationControllers[index].isBeingPresented)
                //{
                
                //navigation.present(CustomTabbarViewController.navigationControllers[index], animated: false, completion: nil)
                
                    if(navigation != nil)
                    {
                        navigation.present(CustomTabbarViewController.navigationControllers[index], animated: false, completion: nil)
                    }
                    else
                    {
                        currentViewController2.present(CustomTabbarViewController.navigationControllers[index], animated: false, completion: nil)
                    }
                //}
                
                CustomTabbarViewController.isViewShowed[index] = true
            }
            
            //currentViewController2 = CustomTabbarViewController.navigationControllers[index].visibleViewController as! ViewController
            
            if(localDatabase.isAPKRegistered(bussinessID: clientID) && APK == APKsEnum.BeautyLine.rawValue)
            {
                let bell = UIBarButtonItem(badge: "\(numberOfNotifications)", title: "", target: self, action: #selector(self.onNotificationsClick))
                bell.badgedButton?.setImage(UIImage(named: "ic_left_drawer_notifications"), for: .normal)
                
                if(CustomTabbarViewController.navigationControllers[index].visibleViewController?.navigationItem != nil && CustomTabbarViewController.navigationControllers[index].visibleViewController?.navigationItem.rightBarButtonItems != nil && ((CustomTabbarViewController.navigationControllers[index].visibleViewController?.navigationItem.rightBarButtonItems?.count)! > 0 && CustomTabbarViewController.navigationControllers[index].visibleViewController?.navigationItem.rightBarButtonItems![0].badgedButton == nil))
                {
                    CustomTabbarViewController.navigationControllers[index].visibleViewController?.navigationItem.rightBarButtonItems = [CustomTabbarViewController.navigationControllers[index].visibleViewController?.navigationItem.rightBarButtonItems![0] , bell] as! [UIBarButtonItem]
                }
                else
                {
                    CustomTabbarViewController.navigationControllers[index].visibleViewController?.navigationItem.rightBarButtonItems = [bell]
                }
            }
            
            //navigation = nil
            
            if(CustomTabbarViewController.tabBarTabs.count > 0)
            {
                ViewController.previousTab = CustomTabbarViewController.tabBarTabs[index].type
            }
            
            CustomTabbarViewController.currentIndex = index
        }
    }
    
    @objc func onNotificationsClick (sender : UITapGestureRecognizer) {
        showNotifications()
    }
}
