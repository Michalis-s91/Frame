//
//  ViewStoryboardName.swift
//  RichReach2
//
//  Created by Eumbrella on 11/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Saves the storyborads names of corresponds views.
enum ViewStoryboardName : String
{
    //case Loyalty = "AllPartnersNavigationController"
    case Notifications = "NotificationsView"
    case HelpAndSupport = "HelpAndSupportView"
    case Profile = "UserProfileView"
    case Barcode = "BarcodeView"
    case About = "AboutView"
    //case Preferred = "PreferredOffersNavigationController"
    //case Businesses = "AllPartnersNavigationController"
    //case WishList = "WishListNavigationController"
    //case History = "OptInHistoryNavigationController"
    case Offers = "Main"
    case Settings = "OffersSettingsView"
    case General = "GeneralInformationView"
    case BenefitsCard = "BarcodeView2"
    case ExpandableList  = "ExpandableListView"
    //case BarcodeScan  = "ExpandableListView"
    case ContactUs  = "ContactUsView"
    case LoyaltyStatement  = "LoyaltyStatementView2"
    case Profile2 = "UserProfileView2"
    //case Feedback  = "ContactUsView"
}
