//
//  APNSManager.swift
//  RichReach2
//
//  Created by Eumbrella on 27/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation
import UIKit

/// APNSManager provides the basic functionality that allows us to perform actions related to APNS (Apple Push Notification Services).
class APNSManager : YesEventHandler, NoEventHandler
{
    var yesAction : Runnable!
    var noAction : Runnable!
    var token : String!
    var notification = Notification()
    var Window : UIWindow!
    
    /// Registers the user's device to APNS
    /*func registerDeviceToAPNS()
    {
        if #available(iOS 8.0, *)
        {
            var settings = UIUserNotificationSettings.init(types: UIUserNotificationType.alert | UIUserNotificationType.badge | UIUserNotificationType.sound, categories: NSSet())
            
            UIApplication.shared.registerUserNotificationSettings(settings)
            UIApplication.shared.registerForRemoteNotifications()
        }
        else
        {
            var notificationTypes : UIRemoteNotificationType = UIRemoteNotificationType.alert | UIRemoteNotificationType.badge | UIRemoteNotificationType.sound
            UIApplication.shared.registerForRemoteNotifications(matching: notificationTypes)
 
    }*/
    
    /// Sends the APNS registration token to the app's (RichReach) server
    func sendRegistrationToAppServer()
    {
        do
        {
            print("token=\(token)")
            
            if(appMode != AppModeType.Debug.rawValue)
            {
                let appUser = localDatabase .getAppUser()
                
                try APNSApi.sendGCMRegistrationToAppServerIOS(userPhone: (appUser?.phoneNumber)!, token: token)
                
                appUser?.isUserRegisteredToAPNS = true
                localDatabase.updateAppUser(appUser: appUser!)
            }
        }
        catch
        {
            
        }
    }
    
    /// Processes the push notification by:
    /// a) Extracting the notification information into a push notification object.
    /// b) Notifying the server about the notification delivery.
    /// c) Inserting the notification to the device's local database.
    ///
    /// - Parameters:
    ///   - notificationInformation: The notification information dictionary.
    ///   - displayAlertBool: A flag that indicates whether an alert should be displayed to the user or not.
    ///   - window: The application window.
    func processNotification(notificationInformation : [AnyHashable : Any], displayAlertBool : Bool, window : inout UIWindow)
    {
        //UIApplication.shared.applicationIconBadgeNumber += 1
        
        let notification = getNotification(notificationInformation: notificationInformation)
        //notifyServerAboutNotificationDelivery(notification: notification)
        
        /*if(notification.type ==  NotificationMessageType.SyncAPKParameters.rawValue )
        {
            if(wasAppClosed)
            {
                var currentViewController = getCurrentViewController(window: window)
                
                let sb = UIStoryboard(name:"YesNoMessageDialog",bundle:nil)
                let dialog = sb.instantiateInitialViewController() as! YesNoMessageDialog
                currentViewController.present(dialog,animated:true)
                dialog.setDialogView(title: notification.header, message: notification.body, yesButtonName: "View Now", noButtonName: "View Later")
                
                func yesRaised()
                {
                    displayCampaignOffers(notification: notification, window: &window)
                }
                
                func noRaised()
                {
                    
                }
                
                yesAction = yesRaised
                noAction = noRaised
                
                dialog.yesRaised = self
                dialog.noRaised = self
            }
            else
            {
                localDatabase = Database()
                localDatabase.checkForUpgrade()
                
                //localDatabase.createTables()
                
                parameterizationDatabase = Parameterization()
                parameterizationDatabase.checkForUpgrade()
                
                statusDB =  StatusDB()
                statusDB.checkForUpgrade()
                
                viewsDB = ViewsDB()
                viewsDB.checkForUpgrade()
                
                loyaltyDB = LoyaltyDB()
                loyaltyDB.checkForUpgrade()
                
                storesDB = StoresDB()
                storesDB.checkForUpgrade()
                
                userProfileDB = UserProfileDB()
                userProfileDB.checkForUpgrade()
                
                APK = notification.apk
                clientID = notification.clientID /* SOS */
                
                statusModel = StatusModel()
                
                var statusModelTemp = statusDB.getStatus(apk: APK)
                
                if(statusModelTemp != nil)
                {
                    statusModel.areProductsSaved = statusModelTemp?.areProductsSaved
                    statusModel.productsPageNo = statusModelTemp?.productsPageNo
                    statusModel.areBrandsSaved = statusModelTemp?.areBrandsSaved
                    statusModel.areBarcodesSaved = statusModelTemp?.areBarcodesSaved
                    statusModel.barcodesPageNo = statusModelTemp?.barcodesPageNo
                    statusModel.areProductMenuRelationsSaved = statusModelTemp?.areProductMenuRelationsSaved
                    statusModel.isProductMenuSaved = statusModelTemp?.isProductMenuSaved
                }
                
                statusDB.insertStatus(status: statusModel, apk: APK)
                
                parameterizationDatabase.deleteEntries(apk : APK)
                viewsDB.deleteEntries(apk : APK)
                //loyaltyDB.deleteEntries(apk : APK)
                storesDB.deleteEntries(apk : APK)
                userProfileDB.deleteEntries(apk : APK)
                
                displaySplashScreen(notification: notification, window: &window)
                
                func failureAction()
                {
                    
                }
                
                do
                {
                    try APKChanger.downloadParameters(launchScreen : UIViewController(), failureAction: failureAction)
                }
                catch
                {
                    
                }
            }
        }*/
        
        if(displayAlertBool)
        {
            displayAlert(notification : notification, window : &window)
        }
        else
        {
            switch (notification.type)
            {
            case NotificationMessageType.Campaign.rawValue,NotificationMessageType.SimpleMessage.rawValue :
                displayCampaignOffers(notification: notification, window: &window)
                break
            case NotificationMessageType.Update.rawValue :
                displayAppOnAppStore(window: window)
                break
                //case (int)NotificationMessageType.EnableOrdering:
                //    //EnableOrdering(window)
                //    break
                //case (int)NotificationMessageType.PendingOrder:
                //    //DisplayPendingOrder(notification, window)
                //    break
                //case (int)NotificationMessageType.OrderConfirmation:
                //    //DisplayPendingOrder(notification, window)
                //    break

            case NotificationMessageType.SyncAPKOffers.rawValue :
                productsDB = ProductsDB()
                productsDB.checkForUpgrade()
                
                statusDB =  StatusDB()
                statusDB.checkForUpgrade()
                
                APK = notification.apk
                clientID = notification.clientID
                
                productsDB.deleteEntries(apk : APK)
                
                statusModel = statusDB.getStatus(apk: APK)
                if(statusModel != nil)
                {
                    statusModel.areProductsSaved = false
                    statusModel.productsPageNo = 0
                    statusDB.insertStatus(status: statusModel, apk: APK)
                }
                
            default:
                break
            }
        }
    }
    
    /// Extracts the information from the notification information dictionary and uses it to create and return a push notification object.
    ///
    /// - Parameter notificationInformation: The notification information hash table.
    /// - Returns: The push notification object that was created by using the provided (input) notification information.
    func getNotification(notificationInformation : [AnyHashable : Any]) -> Notification
    {
        
        let aps = notificationInformation[AnyHashable("aps")] as! NSObject

        let alert = aps.value(forKey: "alert") as! NSDictionary
        
        let notificationTypeObj = notificationInformation[AnyHashable("type")] as! String
        notification.type = Int(notificationTypeObj)
        
        if(notification.type == NotificationMessageType.Campaign.rawValue)
        {
            notification.campaignID = Int64(notificationInformation[AnyHashable("id")] as! String)
            notification.apk = notificationInformation[AnyHashable("apkName")] as? String
        }
        else if (notification.type == NotificationMessageType.PendingOrder.rawValue || notification.type == NotificationMessageType.OrderConfirmation.rawValue)
        {
            notification.orderID = Int64(notificationInformation[AnyHashable("orderID")] as! String)
        }
        else if(notification.type == NotificationMessageType.SyncAPKOffers.rawValue || notification.type == NotificationMessageType.SyncAPKParameters.rawValue)
        {
            notification.apk = notificationInformation[AnyHashable("apkName")] as? String
            notification.clientID = Int64(notificationInformation[AnyHashable("apkID")] as! String)
        }
        
        notification.header = alert.value(forKey: "title") as? String //alert![AnyHashable("title")] as! String
        notification.body = alert.value(forKey: "body") as? String //alert.value(forKey: "body") as! String
        
        campaingID = notification.campaignID
        header = notification.header
        
        return notification
    }
    
    /// Displays a notification alert to the user using our custom bottom drawer.
    ///
    /// - Parameters:
    ///   - notification: The notification.
    ///   - window: The application window.
    func displayAlert(notification : Notification, window : inout UIWindow)
    {
        do
        {
            switch (notification.type)
            {
            case NotificationMessageType.Campaign.rawValue:
                displayCampaignBottomDrawer(notification: notification, window: &window)
                break
            case NotificationMessageType.Update.rawValue:
                displayAppUpdateBottomDrawer(notification: notification, window: window)
                break
                //case (int)NotificationMessageType.EnableOrdering:
                //    DisplayEnableOrderingBottomDrawer(notification, window)
                //    break
                //case (int)NotificationMessageType.PendingOrder:
                //    DisplayPendingOrderBottomDrawer(notification, window)
                //    break
                //case (int)NotificationMessageType.OrderConfirmation:
                //    DisplayPendingOrderBottomDrawer(notification, window)
                //    break
            default:
                break
            }
        }
        catch
        {
            
        }
    }
    
    /// Displays bottom drawer that asks to view now or later campaing offers.
    ///
    /// - Parameters:
    ///   - notification: The notification.
    ///   - window: The application window.
    func displayCampaignBottomDrawer(notification : Notification, window : inout UIWindow)
    {
        var currentViewController = getCurrentViewController(window: window)
        
        let sb = UIStoryboard(name:"YesNoMessageDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController() as! YesNoMessageDialog
        if(navigation != nil && navigation.visibleViewController != nil)
        {
            navigation.visibleViewController!.present(dialog,animated:true)
        }
        else
        {
            currentViewController2.present(dialog,animated:true)
        }
        
        dialog.setDialogView(title: notification.header, message: notification.body, yesButtonName: "View Now", noButtonName: "View Later")
        
        func yesRaised()
        {
            displayCampaignOffers(notification: notification, window: &window)
        }
        
        func noRaised()
        {
            
        }
        
        yesAction = yesRaised
        noAction = noRaised
        
        dialog.yesRaised = self
        dialog.noRaised = self
    }
    
    /// Displays bottom drawer that asks to update app now or later.
    ///
    /// - Parameters:
    ///   - notification: The notification.
    ///   - window: The application window.
    func displayAppUpdateBottomDrawer(notification : Notification, window : UIWindow)
    {
        var currentViewController = getCurrentViewController(window: window)
        
        var messageBody = "Update available! Update RichReach now and enjoy new features!"
        
        let sb = UIStoryboard(name:"YesNoMessageDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController() as! YesNoMessageDialog
        currentViewController.present(dialog,animated:true)
        dialog.setDialogView(title: notification.header, message: messageBody, yesButtonName: "Update Now", noButtonName: "Update Later")
        
        func yesRaised()
        {
            UIApplication.shared.openURL(NSURL(string: NSLocalizedString("RichReachAppStoreLink", comment: ""))! as URL)
        }
        
        func noRaised()
        {
            
        }
        
        yesAction = yesRaised
        noAction = noRaised
        
        dialog.yesRaised = self
        dialog.noRaised = self
        
    }
    
    /// Displays campaing offers in a new view controller.
    ///
    /// - Parameters:
    ///   - notification: The notification.
    ///   - window: The application window.
    func displayCampaignOffers(notification : Notification, window : inout UIWindow)
    {
        if(wasAppClosed)
        {
            var launchScreen : UIViewController!
            var splashViewParameters : SplashViewParametersModel!
            
            let LaunchScreenStoryBoard = UIStoryboard(name: "OverlaySplashScreen", bundle: nil)
            
            
            if(!isNullOrEmpty(string: notification.apk))
            {
                var status = statusDB.getStatus(apk: notification.apk)
                
                if(status != nil && (status?.isAPKSaved)!)
                {
                    switch notification.apk {
                    case APKsEnum.RichReach.rawValue:
                        let LaunchScreenStoryBoard2 = UIStoryboard(name: "RichReachLaunchScreen", bundle: nil)
                        launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
                    case APKsEnum.BeautyLine.rawValue :
                        let LaunchScreenStoryBoard2 = UIStoryboard(name: "BeautyLineLaunchScreen", bundle: nil)
                        launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
                    case APKsEnum.HollandAndBarrett.rawValue :
                        let LaunchScreenStoryBoard2 = UIStoryboard(name: "HollandAndBarrettLaunchScreen", bundle: nil)
                        launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
                    default:
                        let LaunchScreenStoryBoard2 = UIStoryboard(name: "RichReachLaunchScreen", bundle: nil)
                        launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
                    }
                    
                    /*Window = UIWindow(frame: UIScreen.main.bounds)
                    //let PushedOffersStoryBoard = UIStoryboard(name: "PushedOffersView", bundle: nil)
                    //let navigationController =  PushedOffersStoryBoard.instantiateInitialViewController() as! UINavigationController
                    
                    let LaunchScreenStoryBoard2 = UIStoryboard(name: "BeautyLineLaunchScreen", bundle: nil)
                    launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
                    var nav =  LaunchScreenStoryBoard2.instantiateViewController(withIdentifier: "abc") as! UINavigationController
                    Window.rootViewController = nav
                    window = Window
                    Window.makeKeyAndVisible()*/
                    
                    APK = notification.apk
                    
                    if(APK == Bundle.main.bundleIdentifier!)
                    {
                        Window = UIWindow(frame: UIScreen.main.bounds)
                        //let PushedOffersStoryBoard = UIStoryboard(name: "PushedOffersView", bundle: nil)
                        //let navigationController =  PushedOffersStoryBoard.instantiateInitialViewController() as! UINavigationController
                        Window.rootViewController = launchScreen
                        window = Window
                        Window.makeKeyAndVisible()
                    }
                    
                    
                    //self.Window?.rootViewController?.present(launchScreen, animated: false, completion: nil)
                    
                    
                    
                    let initializer = APKInitializer()
                    
                    LeftDrawerViewController.leftDrawerGroupTabs.removeAll()
                    LeftDrawerViewController.leftDrawerGroupTabsID.removeAll()
                    
                    APKInitializer.setProperties()
                    
                    if(APK != Bundle.main.bundleIdentifier!)
                    {
                        LeftDrawerViewController.leftDrawerGroupTabs.append("BACK TO RICHREACH")
                        LeftDrawerViewController.leftDrawerGroupTabsID.append(-1)
                    }
                    
                    //currentViewController2.showView(tab: selectedTab, index: 0)
                    
                    func finishRunnable()
                    {
                        //let PushedOffersStoryBoard = UIStoryboard(name: "PushedOffersView", bundle: nil)
                        //let navigationController =  PushedOffersStoryBoard.instantiateInitialViewController() as! UINavigationController
                        
                        let PushedOffersStoryBoard = UIStoryboard(name: "NotificationView2", bundle: nil)
                        let navigationController = PushedOffersStoryBoard.instantiateViewController(withIdentifier: "NotificationNavigationController") as! UINavigationController
                        
                        self.Window?.rootViewController?.present(navigationController, animated: true, completion: nil)
                        //APKChanger.getRestViews()
                        
                        //launchScreen.dismiss(animated: true, completion: nil)
                    }
                    
                    splashViewParameters = parameterizationDatabase.getSplashViewParameters()
                    
                    if(APK != Bundle.main.bundleIdentifier!)
                    {
                        Window = UIWindow(frame: UIScreen.main.bounds)
                        //let PushedOffersStoryBoard = UIStoryboard(name: "PushedOffersView", bundle: nil)
                        //let navigationController =  PushedOffersStoryBoard.instantiateInitialViewController() as! UINavigationController
                        
                        let PushedOffersStoryBoard = UIStoryboard(name: "NotificationView2", bundle: nil)
                        let navigationController = PushedOffersStoryBoard.instantiateViewController(withIdentifier: "NotificationNavigationController") as! UINavigationController
                        
                        navigation = navigationController
                        Window.rootViewController = navigationController
                        window = Window
                        Window.makeKeyAndVisible()
                    }
                    else
                    {
                        if(splashViewParameters != nil)
                        {
                            let LaunchScreenStoryBoard = UIStoryboard(name: "OverlaySplashScreen", bundle: nil)
                            let launchScreen2 =  LaunchScreenStoryBoard.instantiateViewController(withIdentifier: "OverlaySplashView") as! OverlaySplashViewController
                            launchScreen2.splashViewParameters = splashViewParameters
                            launchScreen2.finishedRunnable = finishRunnable
                            launchScreen.present(launchScreen2, animated: true, completion: nil)
                        }
                        else
                        {
                            splashViewParameters = SplashViewParametersModel()
                            //let PushedOffersStoryBoard = UIStoryboard(name: "PushedOffersView", bundle: nil)
                            //let navigationController =  PushedOffersStoryBoard.instantiateInitialViewController() as! UINavigationController
                            
                            let PushedOffersStoryBoard = UIStoryboard(name: "NotificationView2", bundle: nil)
                            let navigationController = PushedOffersStoryBoard.instantiateViewController(withIdentifier: "NotificationNavigationController") as! UINavigationController
                            
                            self.Window?.rootViewController?.present(navigationController, animated: true, completion: nil)
                        }
                    }
                }
                else
                {
                    Window = UIWindow(frame: UIScreen.main.bounds)
                    //let PushedOffersStoryBoard = UIStoryboard(name: "PushedOffersView", bundle: nil)
                    //let navigationController =  PushedOffersStoryBoard.instantiateInitialViewController() as! UINavigationController
                    
                    let PushedOffersStoryBoard = UIStoryboard(name: "NotificationView2", bundle: nil)
                    let navigationController = PushedOffersStoryBoard.instantiateViewController(withIdentifier: "NotificationNavigationController") as! UINavigationController
                    
                    navigation = navigationController
                    Window.rootViewController = navigationController
                    window = Window
                    Window.makeKeyAndVisible()
                }
            }
            else
            {
                Window = UIWindow(frame: UIScreen.main.bounds)
                //let PushedOffersStoryBoard = UIStoryboard(name: "PushedOffersView", bundle: nil)
                //let navigationController =  PushedOffersStoryBoard.instantiateInitialViewController() as! UINavigationController
                
                let PushedOffersStoryBoard = UIStoryboard(name: "NotificationView2", bundle: nil)
                let navigationController = PushedOffersStoryBoard.instantiateViewController(withIdentifier: "NotificationNavigationController") as! UINavigationController
                
                Window.rootViewController = navigationController
                window = Window
                Window.makeKeyAndVisible()
            }
            
            /*let PushedOffersStoryBoard = UIStoryboard(name: "PushedOffersView", bundle: nil)
            let viewController = PushedOffersStoryBoard.instantiateViewController(withIdentifier: "PushedOffersView") as! PushedOffersViewController
            navigation.pushViewController(viewController, animated: true)*/
            
            if(launchScreen != nil && splashViewParameters == nil)
            {
                launchScreen.dismiss(animated: true, completion: nil)
            }
            
        }
        else
        {
            var launchScreen : UIViewController!
            var splashViewParameters : SplashViewParametersModel!
            
            if(isNullOrEmpty(string: notification.apk) && Bundle.main.bundleIdentifier! == APKsEnum.RichReach.rawValue && APK != APKsEnum.RichReach.rawValue)
            {
                notification.apk = APKsEnum.RichReach.rawValue
                clientID = ClientIDs.RichReach.rawValue
                businessID = BusinessIDs.RichReach.rawValue
            }
            
            if(!isNullOrEmpty(string: notification.apk) && APK != notification.apk)
            {
                var status = statusDB.getStatus(apk: notification.apk)
                
                if(status != nil && (status?.isAPKSaved)!)
                {
                    let LaunchScreenStoryBoard = UIStoryboard(name: "OverlaySplashScreen", bundle: nil)
                    
                    switch notification.apk {
                    case APKsEnum.RichReach.rawValue:
                        let LaunchScreenStoryBoard2 = UIStoryboard(name: "RichReachLaunchScreen", bundle: nil)
                        launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
                    case APKsEnum.BeautyLine.rawValue :
                        let LaunchScreenStoryBoard2 = UIStoryboard(name: "BeautyLineLaunchScreen", bundle: nil)
                        launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
                    case APKsEnum.HollandAndBarrett.rawValue :
                        let LaunchScreenStoryBoard2 = UIStoryboard(name: "HollandAndBarrettLaunchScreen", bundle: nil)
                        launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
                    default:
                        let LaunchScreenStoryBoard2 = UIStoryboard(name: "RichReachLaunchScreen", bundle: nil)
                        launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
                    }
                    
                    navigation.present(launchScreen, animated: true, completion: nil)
                    
                    APK = notification.apk
                    
                    if(APK == APKsEnum.BeautyLine.rawValue)
                    {
                        clientID = ClientIDs.BeautyLine.rawValue
                        businessID = BusinessIDs.BeautyLine.rawValue
                    }
                    
                    let initializer = APKInitializer()
                    
                    LeftDrawerViewController.leftDrawerGroupTabs.removeAll()
                    LeftDrawerViewController.leftDrawerGroupTabsID.removeAll()
                    
                    APKInitializer.setProperties()
                    
                    if(APK != Bundle.main.bundleIdentifier!)
                    {
                        LeftDrawerViewController.leftDrawerGroupTabs.append("BACK TO RICHREACH")
                        LeftDrawerViewController.leftDrawerGroupTabsID.append(-1)
                    }
                    
                    currentViewController2.viewDidLoad()
                    
                    leftDrawer.viewDidLoad()
                    leftDrawer.tableView.reloadData()
                    leftDrawer.selectTab(tabString: leftDrawer.leftDrawerTabsList[0].name)
                    
                    if(selectedTab.isChild && selectedTab.showAtTabbar)
                    {
                        CustomTabbarViewController.currentIndex = 0
                    }
                    
                    currentViewController2.showView(tab: selectedTab, index: 0)
                    
                    func finishRunnable()
                    {
                        launchScreen.dismiss(animated: true, completion: nil)
                    }
                    
                    splashViewParameters = parameterizationDatabase.getSplashViewParameters()
                    
                    if(splashViewParameters != nil)
                    {
                        let LaunchScreenStoryBoard = UIStoryboard(name: "OverlaySplashScreen", bundle: nil)
                        let launchScreen2 =  LaunchScreenStoryBoard.instantiateViewController(withIdentifier: "OverlaySplashView") as! OverlaySplashViewController
                        launchScreen2.splashViewParameters = splashViewParameters
                        launchScreen2.finishedRunnable = finishRunnable
                        launchScreen.present(launchScreen2, animated: true, completion: nil)
                    }
                }
            }
            
            let PushedOffersStoryBoard = UIStoryboard(name: "NotificationView2", bundle: nil)
            let viewController = PushedOffersStoryBoard.instantiateViewController(withIdentifier: "NotificationView") as! NotificationsViewController2
            
            //let PushedOffersStoryBoard = UIStoryboard(name: "PushedOffersView", bundle: nil)
            //let viewController = PushedOffersStoryBoard.instantiateViewController(withIdentifier: "PushedOffersView") as! PushedOffersViewController
            
            if(navigation != nil)
            {
                isViewPushed = true
                navigation.pushViewController(viewController, animated: true)
            }
            else
            {
                isViewPushed = true
                currentViewController2.navigationController?.pushViewController(viewController, animated: true)
            }
            
            if(launchScreen != nil && splashViewParameters == nil)
            {
                launchScreen.dismiss(animated: true, completion: nil)
            }
        }
        
        AppDelegate.isAppRunning = true
    }
    
    func displaySplashScreen(notification : Notification, window : inout UIWindow)
    {
        var launchScreen : UIViewController!
        //let LaunchScreenStoryBoard = UIStoryboard(name: "OverlaySplashScreen", bundle: nil)
        
        switch APK {
        case APKsEnum.RichReach.rawValue:
            let LaunchScreenStoryBoard2 = UIStoryboard(name: "RichReachLaunchScreen", bundle: nil)
            launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
        case APKsEnum.BeautyLine.rawValue :
            let LaunchScreenStoryBoard2 = UIStoryboard(name: "BeautyLineLaunchScreen", bundle: nil)
            launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
        case APKsEnum.HollandAndBarrett.rawValue :
            let LaunchScreenStoryBoard2 = UIStoryboard(name: "HollandAndBarrettLaunchScreen", bundle: nil)
            launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
        default:
            let LaunchScreenStoryBoard2 = UIStoryboard(name: "RichReachLaunchScreen", bundle: nil)
            launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
        }
        
        if(wasAppClosed)
        {
            Window = UIWindow(frame: UIScreen.main.bounds)
            Window.rootViewController = launchScreen
            window = Window
            Window.makeKeyAndVisible()
        }
        else
        {
            navigation.present(launchScreen, animated: true, completion: nil)
        }
        
        AppDelegate.isAppRunning = true
    }
    
    /// Displays RichReach application at app store.
    ///
    /// - Parameter window: The application window.
    func displayAppOnAppStore(window : UIWindow)
    {
        if(!AppDelegate.isAppRunning)
        {
            //LeftDrawerViewController.selectItem2(tabString: LeftDrawerTabsString.Offers.rawValue)
            
            let MainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
            let viewController = MainStoryBoard.instantiateViewController(withIdentifier: "PreferredOffersViewController") as! PreferredOffersViewController
            window.rootViewController = viewController
            window.makeKeyAndVisible()
            
            AppDelegate.isAppRunning = true
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            //restartApp = false
            UIApplication.shared.openURL(NSURL(string: NSLocalizedString("RichReachAppStoreLink", comment: ""))! as URL)
        })
    
    }
    
    /// Returns the current vissible view controller.
    ///
    /// - Parameter window: The application window.
    /// - Returns: he current vissible view controller.
    func getCurrentViewController(window : UIWindow) -> UIViewController
    {
        var currentViewController = window.rootViewController
        
        while (currentViewController?.presentedViewController != nil)
        {
            currentViewController = currentViewController?.presentedViewController
        }
        
        return currentViewController!
    }
    
    /// Notifies server that notification is been delivered.
    ///
    /// - Parameter notification: The notification.
    func notifyServerAboutNotificationDelivery(notification : Notification)
    {
        DispatchQueue.global(qos: .background).async {
            APNSApi.notifyServerAboutDelivery(campaignID: notification.campaignID)
        }
    }
    
    /// This function is been called when user select yes at bottom drawer.
    func yesRaised() {
        yesAction()
    }
    
    /// This function is been called when user select no at bottom drawer.
    func noRaised() {
        noAction()
    }
}
