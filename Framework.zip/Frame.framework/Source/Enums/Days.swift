//
//  Days.swift
//  RichReach2
//
//  Created by Eumbrella on 28/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

enum Days : String
{
    case M = "Monday"
    case T = "Tuesday"
    case W = "Wednesday"
    case TH = "Thursday"
    case F = "Friday"
    case S = "Saturday"
    case SU = "Sunday"
}
