//
//  TextModel.swift
//  RichReach2
//
//  Created by Eumbrella on 18/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Holds information about text.
class TextModel : Codable
{
    var title : String!
    var description : String!
    
    var titleFont : String!
    var titleSize : Int!
    var titleColor : String!
    
    var descriptionFont : String!
    var descriptionSize : Int!
    var descriptionColor : String!
    
    var splitterColor : String!
    var backgroundColor : String!
    
    var isTitleCentered = false
    var descriptionAlignmentType : AlignmentType! = .Left
    
    var showBarcode = false
    
    private enum CodingKeys : String, CodingKey {
        case title = "Title"
        case description = "TextDescription"
        case titleFont = "TitleFont"
        case titleSize = "TitleSize"
        case titleColor = "TitleColor"
        case descriptionFont = "DescriptionFont"
        case descriptionSize = "DescriptionSize"
        case descriptionColor = "DescriptionColor"
        case splitterColor = "SplitterColor"
        case backgroundColor = "BackgroundColor"
        case isTitleCentered = "IsTitleCentered"
        case descriptionAlignmentType = "DescriptionAlignmentType"
    }
}
