//
//  ContactUsInfoModel.swift
//  RichReach2
//
//  Created by Eumbrella on 08/11/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class ContactUsInfoModel : Codable
{
    var info : String!
    var type : Int!
    
    private enum CodingKeys : String, CodingKey {
        case info = "Info"
        case type = "InfoType"
    }
}
