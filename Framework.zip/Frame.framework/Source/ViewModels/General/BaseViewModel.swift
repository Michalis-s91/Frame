//
//  BaseViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 14/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// BaseViewModel is the base of some view models.
class BaseViewModel {
    var ID : Int64 = 0
    var title : String = ""
    var isLoading : Bool!
}
