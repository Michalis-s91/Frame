//
//  ViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 08/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import QuartzCore
import Reachability

var leftDrawer : LeftDrawerViewController!
var rightDrawer : RightDrawerViewController!
var leftDrawerGesture : UIPanGestureRecognizer!

typealias Runnable = () -> ()
typealias RunnableWithThrow = () throws -> ()
var yesAction : Runnable!
var noAction : Runnable!
var navigation : UINavigationController! = UINavigationController()
var navigationBarItem : UINavigationItem! = UINavigationItem()
var offset : CGFloat!
var navigationHeight : CGFloat!
var bottomOffeset : CGFloat!
var viewHeight : CGFloat! = 0.0

var selectedTab : Tab!
var tabIndex : Int! = 0 

var separatorHeight : Int!
var separatorColor : String!
var borderWidth : Int! = 0
var borderColor : String!
var viewTopPadding : Int!
var titleTopPadding : CGFloat!

var centerBarButtonItemGlobal : UIBarButtonItem!
var leftDrawerBarButtonItem : UIBarButtonItem!

var categoriesChilds : [ExpandableListChildModel] = []
var brandsChilds : [ExpandableListChildModel] = []

var reachability: Reachability!
var areParametersDownloading = false
var waitingViewController : WaitingViewController!
var currentViewController2 : ViewController!
var numberOfNotifications = 0
var numberOfGeneralNotifications = 0
var numberOfPromotionNotifications = 0
var categoryExpandableListItem : ExpandableListItemModel! = ExpandableListItemModel()
var brandExpandableListItem : ExpandableListItemModel! = ExpandableListItemModel()
var defaultTabID : Int!
var isViewPushed = false
var stack = tabsStack()


/// Is the general view controller. The most of view controlles inherit from this view controller.
class ViewController: UIViewController, YesEventHandler, NoEventHandler {
    
    @IBOutlet weak var navigationBar: UINavigationItem!
    @IBOutlet weak var leftDrawerBarItem: UIBarButtonItem!
    @IBOutlet var panGesture: UIPanGestureRecognizer!
    @IBOutlet var container: UIView?
    @IBOutlet var item: UIBarButtonItem!
    @IBOutlet var centerBarButtonItem: UIBarButtonItem!
    
    @IBAction func logoClicked() {
        
    //go to Home tab
    /* if(leftDrawer != nil)
        {
            let defaultTabId = parameterizationDatabase.getTheme(apk: APK)?.defaultTabID
            
            if (selectedTab.id != defaultTabId){
                for t in leftDrawer.leftDrawerTabsList{
                    if (t.id == defaultTabId){
                        showView(tab:t, index : 0)
                    }
                }
            }
        }
    */
        
    //go back
        let defaultTabId = parameterizationDatabase.getTheme(apk: APK)?.defaultTabID
        
        if (selectedTab.id != defaultTabId){
            stack.pop()
            self.navigationController?.popViewController(animated: true)
            if(!stack.tabs.isEmpty){
                selectedTab = stack.tabs.last
            }else{
                for t in leftDrawer.leftDrawerTabsList{
                    if (t.id == defaultTabId){
                        selectedTab = t
                    }
                }
            }
        }
    }
    
    var notAvailableView : NotAvailableViewController!
    var socialMedia : [SocialMediaModel]!
    var locationOfBeganTap: CGPoint!
    var currentViewController : ViewController!
    var previousViewController : ViewController!
    var previousTabPosition : Int!
    static var previousTab = LeftDrawerTabsType.Offers.rawValue
    static var displayWhiteLabelPartner : Bool!
    static var viewDidAppear = false
    static var viewDidAppear2 = false
    var tabbar2 : CustomTabbarViewController!
    var dialog : CustomToastDialog!
    var taskTemp : WebApiTask!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        leftDrawerGesture = panGesture
        currentViewController = self
        currentViewController2 = self
        previousTabPosition = 0
        
        //if(offset == nil)
        //{
            if(self.navigationController != nil)
            {
                //DispatchQueue.main.async(execute: {() -> Void in
                    offset = self.navigationController!.navigationBar.frame.size.height + UIApplication.shared.statusBarFrame.height
                    navigationHeight = self.navigationController!.navigationBar.frame.size.height
                //})
            }
            else
            {
                if(offset == nil)
                {
                    offset = 64
                }
                
                if(navigationHeight == nil)
                {
                    navigationHeight = 44
                }
            }
        //}
        
        if(statusModel.isAPKSaved)
        {
            let data = parameterizationDatabase.getLeftDrawerImage(apk: APK)
            
            if(data != nil)
            {
                self.navigationItem.leftBarButtonItem?.image = UIImage(data: data!)?.resizeImage(28, opaque: false) //41.5 for richreach
            }
            
            
            /*else if(leftDrawerImageName != nil && ViewController.leftDrawerImageDownloaded == false)
             {
             if let url = URL(string: leftDrawerImageName) {
             downloadLeftDrawerImage(url: url)
             }
             }*/
            
            leftDrawerBarButtonItem = self.navigationItem.leftBarButtonItem
            
            if(self.centerBarButtonItem != nil)
            {
                centerBarButtonItemGlobal = self.centerBarButtonItem
            }
            
            
            let data2 = parameterizationDatabase.getNavImage(apk: APK)
            
            if(data2 != nil)
            {
                if(self.centerBarButtonItem != nil && APK != APKsEnum.RichReach.rawValue)
                {
                    centerBarButtonItem.isEnabled = false
                    
                    var image = UIImage(data: data2!)
                    
                    var aspectRatio = (image?.size.width)! / (image?.size.height)!
                    var width = aspectRatio * navigationHeight
                    
                    
                    let suggestImage  = UIImage(data: data2!)?.resizeImage2( width, navigationHeight, opaque: false).withRenderingMode(.alwaysOriginal)
            
                    let suggestButton = UIButton()
                    suggestButton.frame = CGRect(x: UIScreen.main.bounds.size.width/2  - (width/2) - 65 , y: 0, width: aspectRatio*navigationHeight, height: navigationHeight)
                    suggestButton.setBackgroundImage(suggestImage, for: .normal)
                    suggestButton.setBackgroundImage(suggestImage, for: .normal)
                    suggestButton.setBackgroundImage(suggestImage, for: .highlighted)
                    suggestButton.setBackgroundImage(suggestImage, for: .focused)
                    suggestButton.setBackgroundImage(suggestImage, for: .selected)
                    //suggestButton.addTarget(self, action: "logoClicked", for: UIControlEvents.touchUpInside) //!!!!LogoClicked action!!!!
                    let suggestButtonContainer = UIView(frame: suggestButton.frame)
                    suggestButtonContainer.addSubview(suggestButton)
                    let suggestButtonItem  = UIBarButtonItem(customView: suggestButtonContainer)
                    
                    if(navigationItem.leftBarButtonItems?.count == 1)
                    {
                        navigationItem.leftBarButtonItems![0] = suggestButtonItem
                    }
                    else if(navigationItem.leftBarButtonItems?.count == 2)
                    {
                        navigationItem.leftBarButtonItems![1] = suggestButtonItem
                    }
                    
                }
            }
            
            let MainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
            
            tabbar2 = MainStoryBoard.instantiateViewController(withIdentifier: "Tabbar2") as? CustomTabbarViewController
            tabbar2.view.frame = CGRect(x: 0, y: self.view.frame.height, width: UIScreen.main.bounds.size.width, height: 50 )
            
            
            if (leftDrawer == nil)
            {
                leftDrawer = MainStoryBoard.instantiateViewController(withIdentifier: "LeftDrawerViewController") as? LeftDrawerViewController
                if #available(iOS 11.0, *) {
                    leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.safeAreaLayoutGuide.layoutFrame.size.height)
                } else {
                    leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.frame.size.height)
                }
            }
            
            if (rightDrawer == nil)
            {
                rightDrawer = MainStoryBoard.instantiateViewController(withIdentifier: "RightDrawerViewController") as? RightDrawerViewController
                rightDrawer.view.frame = CGRect(x: UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
            }
            
            navigationController?.navigationBar.tintColor = Colors.navigationBarTintColor
            navigationController?.navigationBar.barTintColor = Colors.colorPrimary
            navigationController?.navigationBar.isTranslucent = false
            
            let appUser = localDatabase.getAppUser()
            
            if (appUser != nil && localDatabase.isAPKRegistered(bussinessID: clientID) && !(appUser?.isUserRegisteredToAPNS)! && apkUserPreferences.acceptNotifications)
            {
                AppDelegate.registerForPushNotifications(application: appApplication)
            }
        
            //if(self.navigationController != nil)
            //{
            //    navigation = self.navigationController
            //}
        }
    }
    
    
    
    @objc func onNotificationsClick (_ sender : UITapGestureRecognizer) {
        showNotifications()
    }
    
    @objc func onBarcodeClick (sender:UITapGestureRecognizer) {
        if(leftDrawer != nil && leftDrawer.leftDrawerTabsList != nil)
        {
            for t in leftDrawer.leftDrawerTabsList
            {
                if(t.tabType == TabType.Barcode.rawValue)
                {
                    leftDrawer.selectTab(tabString: t.name)
                    self.showView(tab: t, index: 0)
                    break
                }
            }
        }
    }
    
    
    func loadBrandsAndCategories()
    {
        DispatchQueue.global(qos: .background).async {
            var id = 0
            
            //sleep(2)
            
            for t in leftDrawer.leftDrawerTabsList
            {
                if(t.tabType == TabType.ProductFinder.rawValue)
                {
                    id = t.id
                    break
                }
            }
            
            let expandableListView = viewsDB.getExpandableListView(tabID: id)
            
            var list : [ExpandableListParentModel]!
            
            if(expandableListView != nil)
            {
                list = viewsDB.getExpandableListParents(expandableListViewID: expandableListView!.id)
            }
           
            if(list != nil)
            {
                for c in list!
                {
                    if(c.type == ExpandableListItemType.Category.rawValue)
                    {
                        categoryExpandableListItem = ExpandableListItemModel()
                        categoryExpandableListItem.type = ExpandableListItemType.Parent.rawValue
                        categoryExpandableListItem.parentModel = c //ExpandableListParentModel()
                        //categoryExpandableListItem.parentModel.hasAlternatingStyles = false
                        categoryExpandableListItem.isExpanded = false
                        
                        DispatchQueue.global(qos: .background).async {
                            self.loadCategoriest(item: categoryExpandableListItem)
                        }
                        
                    }
                    else if(c.type == ExpandableListItemType.Brand.rawValue)
                    {
                        brandExpandableListItem = ExpandableListItemModel()
                        brandExpandableListItem.type = ExpandableListItemType.Parent.rawValue
                        brandExpandableListItem.parentModel = c //ExpandableListParentModel()
                        //brandExpandableListItem.parentModel.hasAlternatingStyles = true
                        brandExpandableListItem.isExpanded = false
                        
                        DispatchQueue.global(qos: .background).async {
                            self.loadBrandst(item : brandExpandableListItem)
                        }
                    }
                }
            }
        }
        
    }
        
    override func viewWillAppear(_ animated: Bool) {
        //if(APK != Bundle.main.bundleIdentifier)
        //{
            //localDatabase.copyAppUser()
        //}
        
        if(statusModel.isAPKSaved)
        {
            currentViewController2 = self
            
            if(localDatabase.isAPKRegistered(bussinessID: clientID) && !isViewPushed && selectedTab.tabType != TabType.Notifications.rawValue && (APK == APKsEnum.BeautyLine.rawValue || APK == APKsEnum.Test.rawValue))
            {
                var viewDidAppear = ViewController.viewDidAppear
                DispatchQueue.global(qos: .background).async {
                    let appUser = localDatabase.getAppUser()
                    
                    if(appUser != nil && appUser?.phoneNumber != nil)
                    {
                        if(!viewDidAppear)
                        {
                            let phoneNumber = appUser?.phoneNumber
                            var notificationsCountersInfo = NotificationsWebApi.getNotificationsCountersInfo(userPhone: phoneNumber)
                            
                            if(notificationsCountersInfo != nil)
                            {
                                numberOfGeneralNotifications = notificationsCountersInfo!.unseenCampaigns
                                numberOfPromotionNotifications = notificationsCountersInfo!.unseenCoupons
                                numberOfNotifications = notificationsCountersInfo!.allUnseen
                            }
                        }
                        
                        DispatchQueue.main.async(execute: {() -> Void in
                            if(APK == Bundle.main.bundleIdentifier!)
                            {
                                UIApplication.shared.applicationIconBadgeNumber = numberOfNotifications
                            }
                            
                            //var a = selectedTab
                            leftDrawer.tableView.reloadData()
                            leftDrawer.selectTab(tabString: leftDrawer.highlightedTabString)
                            
                            //if(numberOfNotifications > 0 )
                            //{
                                let bell = UIBarButtonItem(badge: "\(numberOfNotifications)", title: "", target: self, action: #selector(self.onNotificationsClick))
                                bell.badgedButton?.setImage(UIImage(named: "ic_left_drawer_notifications"), for: .normal)
                                
                                if(currentViewController2.navigationItem != nil && currentViewController2.navigationItem.rightBarButtonItems == nil)
                                {
                                    currentViewController2.navigationItem.rightBarButtonItem = bell
                                }
                                else
                                {
                                    if(self.navigationItem != nil && self.navigationItem.rightBarButtonItems != nil && (self.navigationItem.rightBarButtonItems?.count)! > 0 && self.navigationItem.rightBarButtonItems![0].badgedButton == nil)
                                    {
                                        currentViewController2.navigationItem.rightBarButtonItems = [self.navigationItem.rightBarButtonItems![0] , bell]
                                    }
                                    else
                                    {
                                        currentViewController2.navigationItem.rightBarButtonItems = [bell]
                                    }
                                }
                                
                            //}
                        })
                    }
                }
            }
            
            /*if(selectedTab != nil && selectedTab.id == defaultTabID && localDatabase.isAPKVerified(bussinessID: clientID))
            {
                let card = UIBarButtonItem(image: UIImage(named: "ic_scan_barcode"), style: .plain, target: self, action: #selector(onBarcodeClick))
                self.navigationItem.rightBarButtonItem = card
            }*/
            
            if(navigation != nil)
            {
                navigation.navigationBar.barStyle = UIBarStyle.black
            }
            else
            {
                self.navigationController?.navigationBar.barStyle = UIBarStyle.black
            }
            
            if(!ViewController.viewDidAppear)
            {                
                if(syncModel.hasUpdateOnStore && !syncModel.isUpdateCritical)
                {
                    appDelegate.presentUpdateAlert(viewController: self)
                }
                
                ViewController.viewDidAppear = true
                
                let signupBonus = parameterizationDatabase.getSignupBonus()
                var showSignupBonus = false
                
                if(signupBonus != nil)
                {
                    var currentDate = Date()
                    currentDate.addTimeInterval(60 * 60 * 2)
                    
                    if((signupBonus?.startDate!)! <= currentDate && currentDate <= (signupBonus?.endDate!)!)
                    {
                        showSignupBonus = true
                    }
                }
                
                if(!(localDatabase.isAPKRegistered(bussinessID: clientID))! && !localDatabase.isAPKBlocked(bussinessID: clientID) && !syncModel.isUpdateCritical )
                {
                    let s = ShowRegistrationDialog()
                    s.viewController = self
                    
                    s.dialogTitle =  NSLocalizedString("registrationRequest", comment: "")
                    
                    if(showSignupBonus)
                    {
                        s.showImage = true
                        s.image = signupBonus?.imageData
                        s.imageUrl = signupBonus?.image
                        s.dialogMessage = ""
                        s.showRegistrationDialog()
                    }
                    else if(APK == APKsEnum.RichReach.rawValue)
                    {
                        s.showImage = false
                        s.dialogMessage = "Please register in order to access ALL RichReach functions!"
                        s.showRegistrationDialog()
                    }
                }

            }
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if(!ViewController.viewDidAppear2)
        {
            ViewController.viewDidAppear2 = true
            
            if(statusModel.areProductsSaved)
            {
                loadBrandsAndCategories()
            }
        }
        
        if(statusModel.isAPKSaved)
        {
            self.view.window?.backgroundColor = UIColor.white
            
            let topPadding : Int!  = parameterizationDatabase.getTheme(apk: APK).topPadding == nil ? 0 : parameterizationDatabase.getTheme(apk: APK).topPadding
            
            if(AppDelegate.isPotraitOrientation)
            {
                self.view.frame.origin.y = offset + CGFloat(topPadding)
                self.view.frame.size.height = viewHeight - CGFloat(topPadding)
            }
            else
            {
                if(self.navigationController != nil)
                {
                    self.view.frame.origin.y = self.navigationController!.navigationBar.frame.size.height + UIApplication.shared.statusBarFrame.height + CGFloat(topPadding)
                    self.view.frame.size.height =  UIScreen.main.bounds.size.height - (self.navigationController!.navigationBar.frame.size.height + UIApplication.shared.statusBarFrame.height) - CGFloat(topPadding)
                }
                else
                {
                    self.view.frame.origin.y = offset + CGFloat(topPadding)
                    self.view.frame.size.height = UIScreen.main.bounds.size.height - CGFloat(topPadding)
                }
                /*self.view.frame.origin.y = self.navigationController!.navigationBar.frame.size.height + UIApplication.shared.statusBarFrame.height + CGFloat(topPadding)
                 self.view.frame.size.height =  UIScreen.main.bounds.size.height - (self.navigationController!.navigationBar.frame.size.height + UIApplication.shared.statusBarFrame.height) - CGFloat(topPadding)*/
            }
            
            /*self.view.layoutIfNeeded()
             let MainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
             leftDrawer = MainStoryBoard.instantiateViewController(withIdentifier: "LeftDrawerViewController") as! LeftDrawerViewController
             if #available(iOS 11.0, *) {
             leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.safeAreaLayoutGuide.layoutFrame.size.height)
             } else {
             // Fallback on earlier versions
             }
             leftDrawer.view.layoutIfNeeded()
             */
            
            
            //if #available(iOS 11.0, *) {
            //    leftDrawer.view.frame.size.height = self.view.safeAreaLayoutGuide.layoutFrame.size.height
            //} else {
            //    leftDrawer.view.frame.size.height = self.view.frame.height
            //}
            
        }

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    @IBAction func panPerformed(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    @IBAction func leftDrawerBarButtonPressed(_ sender: UIBarButtonItem) {
        showHideLeftDrawer()
    }
    
    var rightDrawerItems : [RightDrawerItem] = []
    
    @IBAction func rightDrawerBarButtonPressed(_ sender: UIBarButtonItem) {
        showHideRightDrawer(rightDraweritems: rightDrawerItems)
    }
    
    
    var it = 0
    var itemTempt : ExpandableListItemModel!
    var productMenut : [ProductMenuModel]!
    var parentsProductMenut : [ProductMenuModel]! = []
    var productMenuRelationst : [ProductMenuRelationModel]!
    var productst : [ProductModel]!
    var productst2 : [ProductModel]!
    var areProductsLoadingt = false
    
    func loadCategoriest(item : ExpandableListItemModel, threadID : Int = 0)
    {
        var childs : [ExpandableListChildModel] = []
        
        if((productst == nil || productst.count == 0) && (!areProductsLoadingt))
        {
            areProductsLoadingt = true
            
            productst2 = productsDB.getProducts()
            productst = productst2
            areProductsLoadingt = false
        }
        else
        {
            while(areProductsLoadingt)
            {
                sleep(2)
            }
        }
        
        if(productMenut == nil || productMenut.count == 0)
        {
            productMenut = productsDB.getProductMenu()
        }
        
        if(productMenuRelationst == nil || productMenuRelationst.count == 0)
        {
            productMenuRelationst = productsDB.getProductMenuRelations()
        }
        
        calculateSubCategoriest()
        
        self.itemTempt = item
        let parent : ExpandableListParentModel! = item.parentModel
        
        it = 0
        
        if(parentsProductMenut != nil)
        {
            for p in parentsProductMenut!
            {
                /*if(!isActivityActive(viewController: self.currentUIViewController) /*&& self.threadID != threadID*/)
                {
                    return
                }*/
                
                let e = ExpandableListChildModel()
                
                if(item.parentModel.hasAlternatingStyles)
                {
                    if(it % 2 == 0)
                    {
                        p.textSize = parent.firstStyle.textSize
                        p.textColor = parent.firstStyle.textColor
                        p.font = parent.firstStyle.font
                        p.backgroundColor = parent.firstStyle.backgroundColor
                        p.tintColor = parent.firstStyle.tintColor
                    }
                    else
                    {
                        p.textSize = parent.secondStyle.textSize
                        p.textColor = parent.secondStyle.textColor
                        p.font = parent.secondStyle.font
                        p.backgroundColor = parent.secondStyle.backgroundColor
                        p.tintColor = parent.secondStyle.tintColor
                    }
                }
                else if(parent.firstStyle != nil)
                {
                    p.textSize = parent.firstStyle.textSize
                    p.textColor = parent.firstStyle.textColor
                    p.font = parent.firstStyle.font
                    p.backgroundColor = parent.firstStyle.backgroundColor
                    p.tintColor = parent.firstStyle.tintColor
                }
                else
                {
                    p.font = "Roboto-Regular"
                    p.textColor = "#456712"
                    p.textSize = 16
                    p.backgroundColor = "ffffff"
                    p.tintColor = "#000000"
                }
                
                it += 1
                
                
                
                if(p.childCategories == nil || p.childCategories.count == 0)
                {
                    var productMenuRelationsTemp : [ProductMenuRelationModel] = []
                    
                    for j in 0..<productMenuRelationst.count
                    {
                        if(productMenuRelationst[j].menuStructureID == p.id)
                        {
                            productMenuRelationsTemp.append(productMenuRelationst[j])
                        }
                    }
                    
                    p.products = []
                    
                    if(productMenuRelationsTemp != nil)
                    {
                        for j in 0..<productMenuRelationsTemp.count
                        {
                            switch productMenuRelationsTemp[j].typeData {
                            case 0:
                                let relatedCode =  Int64(productMenuRelationsTemp[j].relatedCode)
                                for i in 0..<productst2.count
                                {
                                    if(productst2[i].itemNo == relatedCode)
                                    {
                                        p.products.append(productst2[i])
                                        break
                                    }
                                }
                            case 1:
                                let relatedCode =  productMenuRelationsTemp[j].relatedCode
                                for i in 0..<productst2.count
                                {
                                    if(productst2[i].commonItemNo == relatedCode)
                                    {
                                        p.products.append(productst2[i])
                                    }
                                }
                            case 2:
                                let relatedCode =  Int64(productMenuRelationsTemp[j].relatedCode)
                                for i in 0..<productst2.count
                                {
                                    if(productst2[i].categoryCode == relatedCode)
                                    {
                                        p.products.append(productst2[i])
                                    }
                                }
                            default:
                                break
                            }
                        }
                        
                        p.products = Array(Set(p.products))
                    }
                }
                
                e.type = ExpandableListItemType.Category2.rawValue
                e.categoryModel2 = p
                
                
                if(p.childCategories != nil && p.childCategories.count > 0)
                {
                    print(p.childCategories.count)
                    for c in p.childCategories
                    {
                        findSubcategoriest(category: c)
                    }
                    
                    var j = 0
                    for _ in 0..<p.childCategories.count
                    {
                        if((p.childCategories[j].childCategories == nil || p.childCategories[j].childCategories.count == 0) && (p.childCategories[j].products == nil || p.childCategories[j].products.count == 0))
                        {
                            p.childCategories.remove(at: j)
                        }
                        else
                        {
                            j += 1
                        }
                    }
                }
                
                
                if((p.childCategories != nil && p.childCategories.count > 0) || (p.products != nil && p.products.count > 0))
                {
                    childs.append(e)
                }
            }
        }
        
        parent.childs = childs
        
        DispatchQueue.main.async(execute: {() -> Void in
            if(selectedTab.tabType == TabType.ProductFinder.rawValue)
            {
                guard let view = currentViewController2 as? ExpandableListViewController
                else
                {
                    return
                }
                
                view.expandableListTableView.reloadData()
                view.areCategoriesLoaded2 = true
            }
        })
    }
    
    var brandst : [CategoryModel] = []
    func loadBrandst(item : ExpandableListItemModel, threadID : Int = 0)
    {
        /*if(products == nil || products.count == 0 /*|| self.threadID > 0*/)
         {
         products = productsDB.getProducts()
         }*/
        
        if((productst2 == nil || productst2.count == 0) && (!areProductsLoadingt))
        {
            areProductsLoadingt = true
            productst = productsDB.getProducts()
            productst2 = productst
            areProductsLoadingt = false
        }
        else
        {
            while(areProductsLoadingt)
            {
                sleep(2)
            }
        }
        
        brandst = productsDB.getBrands()
        calculateSubCategories2t()
        
        var childs : [ExpandableListChildModel] = []
        let parent : ExpandableListParentModel! = item.parentModel
        var i = 0
        
        for c in brandst
        {
            /*if(!isActivityActive(viewController: self.currentUIViewController) /*|| self.threadID != threadID*/)
            {
                return
            }*/
            
            let e = ExpandableListChildModel()
            
            if(item.parentModel.hasAlternatingStyles)
            {
                if(i % 2 == 0)
                {
                    c.textSize = parent.firstStyle.textSize
                    c.textColor = parent.firstStyle.textColor
                    c.font = parent.firstStyle.font
                    c.backgroundColor = parent.firstStyle.backgroundColor
                    c.tintColor = parent.firstStyle.tintColor
                }
                else
                {
                    c.textSize = parent.secondStyle.textSize
                    c.textColor = parent.secondStyle.textColor
                    c.font = parent.secondStyle.font
                    c.backgroundColor = parent.secondStyle.backgroundColor
                    c.tintColor = parent.secondStyle.tintColor
                }
            }
            else if(parent.firstStyle != nil)
            {
                c.textSize = parent.firstStyle.textSize
                c.textColor = parent.firstStyle.textColor
                c.font = parent.firstStyle.font
                c.backgroundColor = parent.firstStyle.backgroundColor
                c.tintColor = parent.firstStyle.tintColor
            }
            else
            {
                c.font = "Roboto-Regular"
                c.textColor = "#456712"
                c.textSize = 16
                c.backgroundColor = "ffffff"
                c.tintColor = "#000000"
            }
            
            
            c.products = []
            
            for i in 0..<productst.count
            {
                if(productst[i].manufacturerCode == c.code)
                {
                    c.products.append(productst[i])
                }
            }
            
            //c.products = productsDB.getProducts(manufacturerName : c.code)
            
            for p in c.products
            {
                p.brand = c
            }
            
            e.type = ExpandableListItemType.Category.rawValue
            e.categoryModel = c
            
            if(c.level == 0 && c.products.count > 0 && !isNullOrEmpty(string: c.name))
            {
                childs.append(e)
                i += 1
            }
        }
        
        parent.childs = childs
        
        DispatchQueue.main.async(execute: {() -> Void in
            if(selectedTab.tabType == TabType.ProductFinder.rawValue)
            {
                guard let view = currentViewController2 as? ExpandableListViewController
                    else
                {
                    return
                }
                
                view.expandableListTableView.reloadData()
                view.areBrandsLoaded2 = true
            }
        })
    }
    
    func calculateSubCategories2t()
    {
        for c in brandst
        {
            c.childCategories = []
            
            for c2 in brandst
            {
                if(c2.parentCategoryID != nil && c2.parentCategoryID == c.id)
                {
                    c.childCategories.append(c2)
                    c2.parentCategory = c
                }
            }
        }
        
        for c in brandst
        {
            c.level = 0
            
            if(c.parentCategory != nil)
            {
                var parent : CategoryModel! = c.parentCategory
                while parent != nil
                {
                    c.level = c.level + 1
                    parent = parent.parentCategory
                }
            }
        }
    }
    
    func calculateSubCategoriest()
    {
        for p in productMenut
        {
            p.childCategories = []
            
            if(p.parentID == 0)
            {
                parentsProductMenut.append(p)
            }
            
            for p2 in productMenut
            {
                if(p2.parentID != nil && p2.parentID == p.id)
                {
                    p.childCategories.append(p2)
                    p2.parentCategory = p
                }
            }
        }
        
        for p in productMenut
        {
            p.level = 0
            
            if(p.parentCategory != nil)
            {
                var parent : ProductMenuModel! = p.parentCategory
                while parent != nil
                {
                    p.level = p.level + 1
                    parent = parent.parentCategory
                }
            }
        }
    
    }
    
    func findSubcategoriest(category : ProductMenuModel)
    {
        let e = ExpandableListChildModel()
        
        let parent : ExpandableListParentModel! = itemTempt.parentModel
        
        if(itemTempt.parentModel.hasAlternatingStyles)
        {
            if(it % 2 == 0)
            {
                category.textSize = parent.firstStyle.textSize
                category.textColor = parent.firstStyle.textColor
                category.font = parent.firstStyle.font
                category.backgroundColor = parent.firstStyle.backgroundColor
                category.tintColor = parent.firstStyle.tintColor
            }
            else
            {
                category.textSize = parent.secondStyle.textSize
                category.textColor = parent.secondStyle.textColor
                category.font = parent.secondStyle.font
                category.backgroundColor = parent.secondStyle.backgroundColor
                category.tintColor = parent.secondStyle.tintColor
            }
        }
        else if(parent.firstStyle != nil)
        {
            category.textSize = parent.firstStyle.textSize
            category.textColor = parent.firstStyle.textColor
            category.font = parent.firstStyle.font
            category.backgroundColor = parent.firstStyle.backgroundColor
            category.tintColor = parent.firstStyle.tintColor
        }
        else
        {
            category.font = "Roboto-Regular"
            category.textColor = "#000000"
            category.textSize = 16
            category.backgroundColor = "ffffff"
            category.tintColor = "#000000"
        }
        
        if(category.childCategories == nil || category.childCategories.count == 0)
        {
            var productMenuRelationsTemp : [ProductMenuRelationModel] = []
            
            for i in 0..<productMenuRelationst.count
            {
                if(productMenuRelationst[i].menuStructureID == category.id)
                {
                    productMenuRelationsTemp.append(productMenuRelationst[i])
                }
            }
            
            category.products = []
            
            if(productMenuRelationsTemp != nil)
            {
                for j in 0..<productMenuRelationsTemp.count
                {
                    switch productMenuRelationsTemp[j].typeData {
                    case 0:
                        let relatedCode =  Int64(productMenuRelationsTemp[j].relatedCode)
                        for i in 0..<productst2.count
                        {
                            if(productst2[i].itemNo == relatedCode)
                            {
                                category.products.append(productst2[i])
                                break
                            }
                        }
                    case 1:
                        let relatedCode =  productMenuRelationsTemp[j].relatedCode
                        for i in 0..<productst2.count
                        {
                            if(productst2[i].commonItemNo == relatedCode)
                            {
                                category.products.append(productst2[i])
                            }
                        }
                    case 2:
                        let relatedCode =  Int64(productMenuRelationsTemp[j].relatedCode)
                        for i in 0..<productst2.count
                        {
                            if(productst2[i].categoryCode == relatedCode)
                            {
                                category.products.append(productst2[i])
                            }
                        }
                    default:
                        break
                    }
                }
                
                category.products = Array(Set(category.products))
            }
            
        }
        
        e.type = ExpandableListItemType.Category2.rawValue
        e.categoryModel2 = category
        
        
        let categories = category.childCategories
        if(categories != nil && (categories?.count)! > 0)
        {
            //childs.append(e)
            
            for c in categories!
            {
                findSubcategoriest(category: c)
            }
            
            var j = 0
            let count : Int! = category.childCategories?.count
            for _ in 0..<count
            {
                if((category.childCategories[j].childCategories == nil || category.childCategories[j].childCategories.count == 0) && (category.childCategories[j].products == nil || category.childCategories[j].products.count == 0))
                {
                    category.childCategories.remove(at: j)
                }
                else
                {
                    j += 1
                }
            }
        }
    }
    
    
    
    
    /// Checks app launch counts. If launch counts are equal or less than 3 then the left drawer is been shown.
    func checkAppLaunchCount()
    {
        let appLaunchCount = UserDefaults.standard.integer(forKey: "launchCount")
        
        if(appLaunchCount <= 2)
        {
            let rowToSelect:NSIndexPath = NSIndexPath(row: 0, section: 0)
            leftDrawer.tableView.selectRow(at: rowToSelect as IndexPath, animated: true, scrollPosition: UITableViewScrollPosition.none)
            showHideLeftDrawer()
        }
    }

    
    /// Download navifation image and save it to local database.
    ///
    /// - Parameter url: The url of navigation image.
    func downloadNavImage(url: URL) {
        getDataFromUrl(url: url) { data, response, error in
            guard let data = data, error == nil else { return }
            DispatchQueue.main.async() {
                if(self.centerBarButtonItem != nil)
                {
                    self.centerBarButtonItem.isEnabled = false
                    print(UIScreen.main.bounds.size.width)
                    
                    if(AppDelegate.isPotraitOrientation)
                    {
                        self.centerBarButtonItem.image =  UIImage(data: data)?.resizeImage(UIScreen.main.bounds.size.width/3, opaque: false).withRenderingMode(.alwaysOriginal)
                        let insets = UIEdgeInsets(top: 0.0, left: (UIScreen.main.bounds.size.width - (self.centerBarButtonItem.image?.size.width)!)/2 - 28, bottom: 0.0, right: 0.0)
                        self.centerBarButtonItem.imageInsets = insets
                    }
                    else
                    {
                        self.centerBarButtonItem.image =  UIImage(data: data)?.resizeImage(UIScreen.main.bounds.size.width/3, opaque: false).withRenderingMode(.alwaysOriginal)
                        let insets = UIEdgeInsets(top: 0.0, left: (UIScreen.main.bounds.size.height - (self.centerBarButtonItem.image?.size.height)!)/2 - 28, bottom: 0.0, right: 0.0)
                        self.centerBarButtonItem.imageInsets = insets
                    }
                }
                parameterizationDatabase.insertNavImage(str: data)
            }
        }
    }
    
    
    /// Pan gesture recognitier checks the pan attributes and decides to show left drawer, hide right drawer or do nothing.
    ///
    /// - Parameter sender: The pan gesture recognizer.
    func panGestureRecognitier(_ sender: UIPanGestureRecognizer){
        let currentLocation = sender.location(in: view)
        
        if (sender.state == .began)
        {
            self.locationOfBeganTap = sender.location(in: view)
        }
        else if (sender.state == .changed)
        {
            let trasnlation = sender.translation(in: sender.view)
            
            if (currentLocation.x > self.locationOfBeganTap.x)
            {
                if (locationOfBeganTap.x < 30 && AppDelegate.showLeftDrawer)
                {
                    if (trasnlation.x < UIScreen.main.bounds.size.width - leftDrawer.spaceBetweenTableScreen)
                    {
                        UIView.animate(withDuration: 0) {
                        if #available(iOS 11.0, *)
                        {
                                leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width + (currentLocation.x - self.locationOfBeganTap.x) + leftDrawer.spaceBetweenTableScreen , y: 0, width: UIScreen.main.bounds.size.width, height: self.view.safeAreaLayoutGuide.layoutFrame.size.height)
                            
                        }
                        else
                        {
                                leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width + (currentLocation.x - self.locationOfBeganTap.x) + leftDrawer.spaceBetweenTableScreen , y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
                        }
                            self.addChildViewController(leftDrawer)
                            self.view.addSubview(leftDrawer.view)
                        }
                    }
                    else
                    {
                        UIView.animate(withDuration: 0) {
                            if #available(iOS 11.0, *) {
                                
                                leftDrawer.view.frame = CGRect(x: 0 , y: 0, width: UIScreen.main.bounds.size.width, height:self.view.safeAreaLayoutGuide.layoutFrame.size.height)
                            } else {
                                leftDrawer.view.frame = CGRect(x: 0 , y: 0, width: UIScreen.main.bounds.size.width, height: self.view.frame.size.height)
                            }
                            
                            //leftDrawer.view.frame = CGRect(x: 0 , y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
                            self.addChildViewController(leftDrawer)
                            self.view.addSubview(leftDrawer.view)
                        }
                    }
                }
            }
            else
            {
                if (locationOfBeganTap.x < (UIScreen.main.bounds.size.width - leftDrawer.spaceBetweenTableScreen + 30) && !AppDelegate.showLeftDrawer)
                {
                    UIView.animate(withDuration: 0, animations: {
                        if #available(iOS 11.0, *) {
                            
                            leftDrawer.view.frame = CGRect(x: -(self.locationOfBeganTap.x - currentLocation.x), y: 0, width: UIScreen.main.bounds.size.width, height: self.view.safeAreaLayoutGuide.layoutFrame.size.height)
                        } else {
                           leftDrawer.view.frame = CGRect(x: -(self.locationOfBeganTap.x - currentLocation.x), y: 0, width: UIScreen.main.bounds.size.width, height: self.view.frame.size.height)
                        }
                        
                        //leftDrawer.view.frame = CGRect(x: -(self.locationOfBeganTap.x - currentLocation.x), y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
                    }) { _ in
                        self.addChildViewController(leftDrawer)
                        self.view.addSubview(leftDrawer.view)
                    }
                }
            }
        }
        else if (sender.state == .ended)
        {
            if (currentLocation.x > self.locationOfBeganTap.x)
            {
                if (locationOfBeganTap.x < 30)
                {
                    if (currentLocation.x > 60)
                    {
                        UIView.animate(withDuration: 0.1) {
                            if #available(iOS 11.0, *) {
                                leftDrawer.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.safeAreaLayoutGuide.layoutFrame.size.height)
                            } else {
                               leftDrawer.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.frame.height)
                            }
                            
                            //leftDrawer.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
                            self.addChildViewController(leftDrawer)
                            self.view.addSubview(leftDrawer.view)
                            
                            if(navigationBarItem.rightBarButtonItems != nil)
                            {
                                for r in navigationBarItem.rightBarButtonItems!
                                {
                                    r.isEnabled = false
                                    r.tintColor = UIColor.clear
                                }
                            }
                            
                            AppDelegate.showLeftDrawer = false
                        }
                    }
                    else
                    {
                        if(AppDelegate.showLeftDrawer){
                            hideLeftDrawer()
                        }
                    }
                }
            }
            else
            {
                if (locationOfBeganTap.x < (UIScreen.main.bounds.size.width - leftDrawer.spaceBetweenTableScreen) &&  currentLocation.x < 60)
                {   
                    //leftDrawer.colapseTabs(selectTabFlag: false, selectedTab: 0)
                    
                    if(navigationBarItem.rightBarButtonItems != nil)
                    {
                        for r in navigationBarItem.rightBarButtonItems!
                        {
                            r.isEnabled = true
                            r.tintColor = Colors.navigationBarTintColor
                        }
                    }
                    
                    AppDelegate.showLeftDrawer = true
                    //leftDrawer.colapseTabs(selectTabFlag: false, selectedTab: 0)
                    //leftDrawer.selectTab(tabString: leftDrawer.currentTab)
                    leftDrawer.hideLeftDrawer()
                }
                else
                {
                    if(!AppDelegate.showLeftDrawer){
                        showLeftDrawer()
                    }
                }
            }
        }
    }
    
    
    /// Shows tab bar.
    ///
    /// - Parameters:
    ///   - index: The index of selected tab.
    ///   - tabs: The tabs of tab bar.
    func showTabbar(index : Int, tabs : [Tab])
    {
        UIView.animate(withDuration: 0.0) {
            if(self.tabbar2.views.count == 0)
            {
                self.tabbar2.setTabBar(tabs: tabs)
            }
            
            
            //self.tabbar2.view.frame = CGRect(x: 0, y: self.view.frame.size.height - 50, width: UIScreen.main.bounds.size.width, height: 50 )
            
            if #available(iOS 11.0, *) {
                self.tabbar2.view.frame = CGRect(x: 0, y: self.view.safeAreaLayoutGuide.layoutFrame.size.height - 50, width: UIScreen.main.bounds.size.width, height: 50 )
                //self.tabbar2.view.frame = CGRect(x: 0, y: viewHeight - 50, width: UIScreen.main.bounds.size.width, height: 50 )
            } else {
                self.tabbar2.view.frame = CGRect(x: 0, y: self.view.frame.size.height - 50, width: UIScreen.main.bounds.size.width, height: 50 )
            }
            
            self.tabbar2.setSelectedTab(index: index)
            self.addChildViewController(self.tabbar2)
            self.view.addSubview(self.tabbar2.view)
        }
    }
    
    /*override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        if #available(iOS 11.0, *) {
            viewHeight = self.view.frame.size.height - view.safeAreaInsets.bottom
        } else {
            // Fallback on earlier versions
        }
    }*/
    
    /// Checks if we have to hide or show the left drawer, and calls the correspond function.
    func showHideLeftDrawer()  {
        if (AppDelegate.showLeftDrawer)
        {
            if #available(iOS 11.0, *) {
                leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.safeAreaLayoutGuide.layoutFrame.size.height )
            }
            else
            {
                leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.frame.height)
            }
            
            //leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.frame.height)
            
            showLeftDrawer()
        }
        else
        {
            hideLeftDrawer()
        }
    }
    
    
    /// Show left drawer.
    func showLeftDrawer(){
        UIView.animate(withDuration: 0.7) {
            
            if #available(iOS 11.0, *)
            {
                print(self.view.safeAreaLayoutGuide.layoutFrame.size.height)
                leftDrawer.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.safeAreaLayoutGuide.layoutFrame.size.height)
            }
            else
            {
                if(AppDelegate.isPotraitOrientation)
                {
                    leftDrawer.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.frame.height)
                }
                else
                {
                    leftDrawer.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
                    leftDrawer.view.frame.size.height = UIScreen.main.bounds.size.height - UIApplication.shared.statusBarFrame.height - (self.navigationController?.navigationBar.frame.size.height)!
                }
            }
            
            //leftDrawer.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.frame.height )
            if(leftDrawer != nil)
            {
                self.addChildViewController(leftDrawer)
                self.view.addSubview(leftDrawer.view)
                
                AppDelegate.showLeftDrawer = false
            }
        }
        
        if(navigationBarItem.rightBarButtonItems != nil)
        {
            for r in navigationBarItem.rightBarButtonItems!
            {
                r.isEnabled = false
                r.tintColor = UIColor.clear
            }
        }
    }
    
    
    /// Hide left drawer.
    func hideLeftDrawer(){
        UIView.animate(withDuration: 0.7, animations: {
            
            if #available(iOS 11.0, *) {
                leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.safeAreaLayoutGuide.layoutFrame.size.height)
            }
            else
            {
                leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.frame.height)
            }
            
        //leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.frame.height)
        }) { _ in
            leftDrawer.view.removeFromSuperview()
        }
        
        if(navigationBarItem.rightBarButtonItems != nil)
        {
            for r in navigationBarItem.rightBarButtonItems!
            {
                r.isEnabled = true
                r.tintColor = Colors.navigationBarTintColor
            }
        }
        
        AppDelegate.showLeftDrawer = true
        
        //leftDrawer.colapseTabs(selectTabFlag: false, selectedTab: 0)
        //leftDrawer.selectTab(tabString: leftDrawer.currentTab)
    }
    
    /// Checks if we have to hide or show the right drawer, and calls the correspond function.
    ///
    /// - Parameter rightDraweritems: The items of right drawer.
    func showHideRightDrawer(rightDraweritems : [RightDrawerItem])
    {
        if(AppDelegate.showRightDrawer)
        {
            showRightDrawer(rightDrawerItems: rightDrawerItems)
        }
        else
        {
            hideRightDrawer()
        }
    }
    
    
    /// Shows right drawer.
    ///
    /// - Parameter rightDrawerItems: The items of right drawer.
    func showRightDrawer(rightDrawerItems : [RightDrawerItem])
    {
        rightDrawer.view.layer.zPosition = 1
        
        UIView.animate(withDuration: 0.6) {
            rightDrawer.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.frame.height )
            
            rightDrawer.items = rightDrawerItems
            
            self.addChildViewController(rightDrawer)
            self.view.addSubview(rightDrawer.view)
            
            navigationBarItem.leftBarButtonItem?.isEnabled = false
            navigationBarItem.leftBarButtonItem?.tintColor = UIColor.clear
            
            AppDelegate.showRightDrawer = false
        }
    }
    
    
    /// Hides right drawer.
    func hideRightDrawer()
    {
        navigationBarItem.leftBarButtonItem?.isEnabled = true
        
        UIView.animate(withDuration: 0.6, animations: {
            rightDrawer.view.frame = CGRect(x: UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.frame.height)
            navigationBarItem.leftBarButtonItem?.tintColor = Colors.navigationBarTintColor
        }) { _ in
            rightDrawer.view.removeFromSuperview()
        }
        
        AppDelegate.showRightDrawer = true
    }
    
    
    /// This function is been called when user select a tab at left drawer and shows the view of corresponding tab.
    ///
    /// - Parameters:
    ///   - tab: The selected tab.
    ///   - index: The index of selected tab.
    func showView(tab : Tab, index : Int, isEmbeded : Bool = false, showingEmbeded : Bool = false) -> Bool
    {
        //isViewPushed = false
        previousViewController = currentViewController
        
        var tabString = tab.name
        
        if(!tab.isChild || !tab.showAtTabbar)
        {
            CustomTabbarViewController.navigationControllers.removeAll()
            CustomTabbarViewController.tabBarTabs.removeAll()
            if(self.tabbar2 != nil)
            {
                self.tabbar2.views.removeAll()
            }
            
            CustomTabbarViewController.currentIndex = -1
        }
        
        if(tab.isChild)
        {
            var exists = false
            
            for t in CustomTabbarViewController.tabBarTabs
            {
                if (t.id == tab.id)
                {
                    exists = true
                    break
                }
            }
            
            if(exists)
            {
                ViewController.previousTab = tab.type
                
                if(tabbar2 != nil)
                {
                    tabbar2.showView(index: index)
                    setBorder(tab : tab)
                    selectedTab = tab
                }
                
                if(!AppDelegate.showLeftDrawer)
                {
                    hideLeftDrawer()
                }
                
                return true
            }
            else
            {
                CustomTabbarViewController.navigationControllers.removeAll()
                if(self.tabbar2 != nil)
                {
                    self.tabbar2.views.removeAll()
                }
                
                CustomTabbarViewController.currentIndex = -1
            }
        }
        
        if(!AppDelegate.isPotraitOrientation)
        {
            switch UIDevice.current.orientation{
            case .portrait:
                AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.portrait, andRotateTo: UIInterfaceOrientation.landscapeLeft)
            case .portraitUpsideDown:
                AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.portrait, andRotateTo: UIInterfaceOrientation.portrait)
            case .landscapeLeft:
                AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.portrait, andRotateTo: UIInterfaceOrientation.portrait)
            case .landscapeRight:
                AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.portrait, andRotateTo: UIInterfaceOrientation.portrait)
            default:
                AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.portrait, andRotateTo: UIInterfaceOrientation.portrait)
            }
            AppDelegate.isPotraitOrientation = true
        }
        
        switch tab.type {
        case LeftDrawerTabsType.Offers.rawValue:
            let MainStoryBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            currentViewController = MainStoryBoard.instantiateViewController(withIdentifier: "PreferredOffersViewController") as! PreferredOffersViewController
            leftDrawer.selectTab(tabString: LeftDrawerTabsString.Offers.rawValue)
        case LeftDrawerTabsType.Loyalty.rawValue:
            let MainStoryBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            currentViewController = MainStoryBoard.instantiateViewController(withIdentifier: "AllPartnersViewController") as! AllPartnersViewController
            AllPartnersView.displayLoyaltyPartnersOnly = true
        case LeftDrawerTabsType.Notifications.rawValue:
            //let NotificationsStoryBoard: UIStoryboard = UIStoryboard(name: "NotificationsView", bundle: nil)
            //currentViewController = NotificationsStoryBoard.instantiateViewController(withIdentifier: "NotificationsViewController") as! NotificationsViewController
            let PushedOffersStoryBoard = UIStoryboard(name: "NotificationView2", bundle: nil)
            currentViewController = PushedOffersStoryBoard.instantiateViewController(withIdentifier: "NotificationView") as! NotificationsViewController2
        case LeftDrawerTabsType.HelpAndSupport.rawValue:
            let HelpAndSupportStoryBoard: UIStoryboard = UIStoryboard(name: "HelpAndSupportView", bundle: nil)
            currentViewController =  HelpAndSupportStoryBoard.instantiateViewController(withIdentifier: "HelpAndSupportView") as! HelpAndSupportViewController
        case LeftDrawerTabsType.Profile.rawValue:
            var appUser = localDatabase.getAppUser()
            if(appUser != nil && (appUser?.hasVerifiedPhoneNumber)!)
            {
                let UserProfileStoryBoard: UIStoryboard = UIStoryboard(name: "UserProfileView", bundle: nil)
                currentViewController =  UserProfileStoryBoard.instantiateViewController(withIdentifier: "UserProfileViewController") as! UserProfileViewController
            }
            else
            {
                let UserProfileStoryBoard: UIStoryboard = UIStoryboard(name: "UserProfileView", bundle: nil)
                currentViewController =  UserProfileStoryBoard.instantiateViewController(withIdentifier: "SignnInViewController") as! SignInViewController
            }
            previousViewController = currentViewController
            
            
        case LeftDrawerTabsType.Barcode.rawValue:
            let BarcodeStoryBoard: UIStoryboard = UIStoryboard(name: "BarcodeView", bundle: nil)
            currentViewController = BarcodeStoryBoard.instantiateViewController(withIdentifier: "BarcodeView") as! BarcodeViewController
        case LeftDrawerTabsType.About.rawValue:
            let AboutStoryBoard: UIStoryboard = UIStoryboard(name: "AboutView", bundle: nil)
            currentViewController = AboutStoryBoard.instantiateViewController(withIdentifier: "AboutView") as! AboutViewController
        case LeftDrawerTabsType.BeautyLineUnderConstruction.rawValue:
            let GeneralViewStoryBoard: UIStoryboard = UIStoryboard(name: "GeneralInformationView" , bundle: nil)
            currentViewController = GeneralViewStoryBoard.instantiateInitialViewController() as! GeneralInformationViewController
            separatorHeight = tab.separatorHeight
            separatorColor = tab.separatorColor
            
        case LeftDrawerTabsType.GeneralView.rawValue:
            let GeneralViewStoryBoard: UIStoryboard = UIStoryboard(name: "GeneralInformationView" , bundle: nil)
            currentViewController = GeneralViewStoryBoard.instantiateInitialViewController() as! GeneralInformationViewController
            separatorHeight = tab.separatorHeight
            separatorColor = tab.separatorColor
        case LeftDrawerTabsType.BenefitsCard.rawValue:
            var barcodeView = viewsDB.getBarcodeView()
            /*switch barcodeView?.prototype
            {
            case 1 :
                
            }*/
            let BarcodeStoryBoard2: UIStoryboard = UIStoryboard(name: "BarcodeView2" , bundle: nil)
            currentViewController = BarcodeStoryBoard2.instantiateInitialViewController() as! BarcodeViewController2
        case LeftDrawerTabsType.ExpandableList.rawValue:
            let ExpandableListStoryBoard: UIStoryboard = UIStoryboard(name: "ExpandableListView" , bundle: nil)
            currentViewController = ExpandableListStoryBoard.instantiateInitialViewController() as! ExpandableListViewController
            separatorHeight = tab.separatorHeight
            separatorColor = tab.separatorColor
            
            if(separatorHeight == nil)
            {
                separatorHeight = 0
                separatorColor = "#00000000"
            }
            
        case LeftDrawerTabsType.DirectLink.rawValue:
            //restartApp = false
            UIApplication.shared.openURL(NSURL(string: tab.link)! as URL)
            leftDrawer.selectTab(tabString: leftDrawer.previousTab)
            leftDrawer.currentTab = leftDrawer.previousTab
            return true
        case LeftDrawerTabsType.BarcodeScan.rawValue:
            let ExpandableListStoryBoard: UIStoryboard = UIStoryboard(name: "ExpandableListView" , bundle: nil)
            currentViewController = ExpandableListStoryBoard.instantiateInitialViewController() as! ExpandableListViewController
            separatorHeight = tab.separatorHeight
            separatorColor = tab.separatorColor
            
            if(separatorHeight == nil)
            {
                separatorHeight = 0
                separatorColor = "#00000000"
            }
        case LeftDrawerTabsType.ContactUs.rawValue:
            let ContactUsStoryBoard: UIStoryboard = UIStoryboard(name: "ContactUsView" , bundle: nil)
            currentViewController = ContactUsStoryBoard.instantiateInitialViewController() as! ContactUsViewController
            separatorHeight = tab.separatorHeight
            separatorColor = tab.separatorColor
        case LeftDrawerTabsType.Feedback.rawValue:
            let ContactUsStoryBoard: UIStoryboard = UIStoryboard(name: "ContactUsView" , bundle: nil)
            var currentViewControllerTemp = ContactUsStoryBoard.instantiateInitialViewController() as! ContactUsViewController
            currentViewControllerTemp.isFeedback = true
            currentViewController = currentViewControllerTemp
            separatorHeight = tab.separatorHeight
            separatorColor = tab.separatorColor
        case LeftDrawerTabsType.LoyaltyStatement.rawValue:
            let LoyaltyStatementStoryBoard: UIStoryboard = UIStoryboard(name: "LoyaltyStatementView2" , bundle: nil)
            currentViewController = LoyaltyStatementStoryBoard.instantiateInitialViewController() as! LoyaltyStatementViewController2
        case LeftDrawerTabsType.Profile2.rawValue:
            if(localDatabase.isAPKBlocked(bussinessID: clientID)!)
            {
                let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
                let dialog = sb.instantiateInitialViewController()! as! MessageDialog
                currentViewController.present(dialog,animated:true)
                dialog.setDialogView(title: NSLocalizedString("blockedTitle", comment: ""), description: NSLocalizedString("blockedDescription", comment: ""), buttonName: NSLocalizedString("Ok", comment: ""), dismissWhenClickOutside : false)
                return true
            }
            else
            {
                let ProfileStoryBoard: UIStoryboard = UIStoryboard(name: "UserProfileView2" , bundle: nil)
                currentViewController = ProfileStoryBoard.instantiateInitialViewController() as! UserProfileViewController2
            }
            
            previousViewController = currentViewController
        case LeftDrawerTabsType.PromotionNotifications.rawValue:
            let PromotionsStoryBoard: UIStoryboard = UIStoryboard(name: "PromotionsNotificationView" , bundle: nil)
            currentViewController = PromotionsStoryBoard.instantiateInitialViewController() as! PromotionsNotificationViewController
        case LeftDrawerTabsType.Preferred.rawValue:
            let MainStoryBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            currentViewController = MainStoryBoard.instantiateViewController(withIdentifier: "PreferredOffersViewController") as! PreferredOffersViewController
            //leftDrawer.selectTab(tabString: LeftDrawerTabsString.Offers.rawValue)
            tabString = "Offers"
        case LeftDrawerTabsType.Businesses.rawValue:
            let MainStoryBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            currentViewController = MainStoryBoard.instantiateViewController(withIdentifier: "AllPartnersViewController") as! AllPartnersViewController
            AllPartnersView.displayLoyaltyPartnersOnly = false
        case LeftDrawerTabsType.WishList.rawValue:
            let MainStoryBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            currentViewController = MainStoryBoard.instantiateViewController(withIdentifier: "WishListViewController") as! WishListViewController
        case LeftDrawerTabsType.History.rawValue:
            let MainStoryBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            currentViewController = MainStoryBoard.instantiateViewController(withIdentifier: "OptInHistoryViewController") as! OptInHistoryViewController
        case LeftDrawerTabsType.Settings.rawValue:
            let OffersSettingsStoryBoard: UIStoryboard = UIStoryboard(name: "OffersSettingsView", bundle: nil)
            currentViewController =  OffersSettingsStoryBoard.instantiateViewController(withIdentifier: "OffersSettingsView") as! OffersSettingsViewController
        case LeftDrawerTabsType.Blog.rawValue:
            let OffersSettingsStoryBoard: UIStoryboard = UIStoryboard(name: "BlogView", bundle: nil)
            currentViewController =  OffersSettingsStoryBoard.instantiateViewController(withIdentifier: "BlogView") as! BlogViewController
        default:
            let UnderConstructionStoryBoard: UIStoryboard = UIStoryboard(name: "UnderConstructionView", bundle: nil)
            currentViewController = UnderConstructionStoryBoard.instantiateInitialViewController() as! UnderConstructionViewController
        }
        
        if(wasAppClosed)
        {
            wasAppClosed = false
        }
        
        if(separatorHeight == nil)
        {
            separatorHeight = 0
        }
        
        if ( ViewController.previousTab == LeftDrawerTabsType.Profile2.rawValue && tab.type != LeftDrawerTabsType.Profile2.rawValue)
        {
            let userProfileViewController = previousViewController as? UserProfileViewController2
            if(userProfileViewController != nil && userProfileViewController!.areUnsavedChanges)
            {
                let sb = UIStoryboard(name:"YesNoMessageDialog",bundle:nil)
                let dialog = sb.instantiateInitialViewController() as! YesNoMessageDialog
                self.present(dialog,animated:true)
                dialog.setDialogView(title: NSLocalizedString("unsavedData", comment: ""), message: NSLocalizedString("unsavedDataMessage", comment: ""), yesButtonName: NSLocalizedString("Yes", comment: ""), noButtonName: NSLocalizedString("No", comment: ""))
                
                func yesRaised()
                {
                    self.navigationController?.pushViewController(currentViewController, animated: true)
                    currentViewController2 = currentViewController
                    //numberOfEmbededViews += 1
                    leftDrawer.selectTab(tabString: leftDrawer.currentTab!)
                    selectedTab = tab
                    tabIndex = index
                    //checkForTabBar(tab : tab, index: index)
                    ViewController.previousTab = tab.type
                    setBorder(tab: tab)
                }
                
                func noRaised()
                {
                    currentViewController = previousViewController
                    leftDrawer.selectTab(tabString: leftDrawer.previousTab)
                    leftDrawer.currentTab = leftDrawer.previousTab
                }
                
                yesAction = yesRaised
                noAction = noRaised
                
                dialog.yesRaised = self
                dialog.noRaised = self
                
                hideLeftDrawer()
                return true
            }
            else
            {
                self.navigationController?.pushViewController(currentViewController, animated: true)
                currentViewController2 = currentViewController
                //numberOfEmbededViews += 1
                ViewController.previousTab = tab.type
                selectedTab = tab
                tabIndex = index
                //checkForTabBar(tab : tab, index: index)
            }
        }
        else if ( ViewController.previousTab == LeftDrawerTabsType.Profile.rawValue && tab.type != LeftDrawerTabsType.Profile.rawValue)
        {
            let userProfileViewController = previousViewController as? UserProfileViewController
            if(userProfileViewController != nil && !(userProfileViewController?.viewModel.isUserProfileInformationUpToDate())!)
            {
                let sb = UIStoryboard(name:"YesNoMessageDialog",bundle:nil)
                let dialog = sb.instantiateInitialViewController() as! YesNoMessageDialog
                self.present(dialog,animated:true)
                dialog.setDialogView(title: NSLocalizedString("unsavedData", comment: ""), message: NSLocalizedString("unsavedDataMessage", comment: ""), yesButtonName: NSLocalizedString("Yes", comment: ""), noButtonName: NSLocalizedString("No", comment: ""))
                
                func yesRaised()
                {
                    self.navigationController?.pushViewController(currentViewController, animated: true)
                    currentViewController2 = currentViewController
                    //numberOfEmbededViews += 1
                    leftDrawer.selectTab(tabString: leftDrawer.currentTab!)
                    selectedTab = tab
                    tabIndex = index
                    //checkForTabBar(tab : tab, index: index)
                    ViewController.previousTab = tab.type
                    setBorder(tab: tab)
                }
                
                func noRaised()
                {
                    leftDrawer.selectTab(tabString: leftDrawer.previousTab)
                    leftDrawer.currentTab = leftDrawer.previousTab
                }
                
                yesAction = yesRaised
                noAction = noRaised
                
                dialog.yesRaised = self
                dialog.noRaised = self
                
                hideLeftDrawer()
                return true
            }
            else
            {
                self.navigationController?.pushViewController(currentViewController, animated: true)
                currentViewController2 = currentViewController
                //numberOfEmbededViews += 1
                ViewController.previousTab = tab.type
                selectedTab = tab
                tabIndex = index
                //checkForTabBar(tab : tab, index: index)
            }
        }
        else
        {
            if(isEmbeded)
            {
                currentViewController.navigationItem.leftBarButtonItems?.removeAll()// leftBarButtonItem = nil
                //self.previousViewController.navigationController?.pushViewController(currentViewController, animated: true)
            }

            if(wasAppClosed)
            {
                self.navigationController?.pushViewController(currentViewController, animated: true)
                //wasAppClosed = false
            }
            else
            {
                if(navigation != nil && !showingEmbeded)
                {
                     navigation?.pushViewController(currentViewController, animated: true)
                }
                else
                {
                    self.navigationController?.pushViewController(currentViewController, animated: true)
                }
            }
            
            currentViewController2 = currentViewController

            ViewController.previousTab = tab.type!
            selectedTab = tab
            tabIndex = index
            //checkForTabBar(tab : tab, index: index)
        }
        
        setBorder(tab : tab)
        if(!AppDelegate.showLeftDrawer)
        {
            hideLeftDrawer()
        }
        
        return true
    }
    
    /*func popViews()
    {
        var nav : UINavigationController! = self.navigationController
        
        for _ in 0..<numberOfEmbededViews
        {
            var view = nav.popViewController(animated: false)
            nav = view?.navigationController
        }
        
        numberOfEmbededViews = 0
    }*/
    
    func setBorder(tab : Tab)
    {
        borderColor = tab.borderColor
        
        if(tab.borderSize == nil)
        {
            borderWidth = 0
        }
        else
        {
            borderWidth = tab.borderSize
        }
    }
    
    /// Checks if we have to show tab bar. If we have to then the tab bar is been displayed.
    ///
    /// - Parameters:
    ///   - tab: The selected tab.
    ///   - index: The index of selected tab.
    func checkForTabBar(tab : Tab, index : Int)
    {
        if(tab.isChild && tab.showAtTabbar)
        {
            var tabs : [Tab] = []
            
            for r in leftDrawer.relations
            {
                if(r.parentID == tab.parentID && r.child.showAtTabbar && r.child.isVissible)
                {
                    tabs.append(r.child)
                }
            }
            
            if(CustomTabbarViewController.navigationControllers.count == 0)
            {
                for r in leftDrawer.relations
                {
                    if(r.parentID == tab.parentID && r.child.showAtTabbar && r.child.isVissible)
                    {
                        var view : UINavigationController!
                        let MainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
                        
                        switch (r.child.type)
                        {
                        case LeftDrawerTabsType.Preferred.rawValue :
                            view = MainStoryBoard.instantiateViewController(withIdentifier: "PreferredOffersNavigationController") as? UINavigationController
                            CustomTabbarViewController.navigationControllers.append(view)
                            CustomTabbarViewController.isViewShowed.append(false)
                        case LeftDrawerTabsType.Businesses.rawValue :
                            view = MainStoryBoard.instantiateViewController(withIdentifier: "AllPartnersNavigationController") as? UINavigationController
                            CustomTabbarViewController.navigationControllers.append(view)
                            CustomTabbarViewController.isViewShowed.append(false)
                        case LeftDrawerTabsType.WishList.rawValue :
                            view = MainStoryBoard.instantiateViewController(withIdentifier: "WishListNavigationController") as? UINavigationController
                            CustomTabbarViewController.navigationControllers.append(view)
                            CustomTabbarViewController.isViewShowed.append(false)
                        case LeftDrawerTabsType.History.rawValue :
                            view = MainStoryBoard.instantiateViewController(withIdentifier: "OptInHistoryNavigationController") as? UINavigationController
                            CustomTabbarViewController.navigationControllers.append(view)
                            CustomTabbarViewController.isViewShowed.append(false)
                        case LeftDrawerTabsType.Settings.rawValue :
                            let StoryBoard = UIStoryboard(name: "OffersSettingsView", bundle: nil)
                            view = StoryBoard.instantiateViewController(withIdentifier: "OffersSettingsNavigationController") as? UINavigationController
                            CustomTabbarViewController.navigationControllers.append(view)
                            CustomTabbarViewController.isViewShowed.append(false)
                        default:
                            break
                        }
                    }
                }
            }
            
            showTabbar(index: index, tabs: tabs)
        }
    }
    
    func showViewIndicator()
    {
        
    }
    
    func hideViewIndicator()
    {
        
    }
    
    /// This function is been called when user clicks on yes at message dialog.
    func yesRaised() {
        yesAction()
    }
    
    /// This function is been called when user clicks on no at message dialog.
    func noRaised() {
        noAction()
    }
    
}
