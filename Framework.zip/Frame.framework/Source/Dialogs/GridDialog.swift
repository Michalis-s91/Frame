//
//  GridDialog.swift
//  RichReach2
//
//  Created by Eumbrella on 26/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// GridDialog is used to display a grid of buttons.
class GridDialog: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var gridDialogView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var splitter: UIView!
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var dialogView: UIView!
    @IBOutlet var tableView: UITableView!
    
    @IBOutlet weak var tableViewHeight: NSLayoutConstraint!
    
    var years : [Int] = []
    static var delegate : ModalViewControllerDelegate?
    static var viewController : GridDialog!
    static var selectedYear : Int!
    var delegate : ModalViewControllerDelegate?
    var titleText : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        GridDialog.selectedYear = nil
        GridDialog.viewController = self
        
        dialogView.sizeToFit()
        titleLabel.sizeToFit()
        titleLabel.numberOfLines = 0
        
        titleLabel.textColor = Colors.dialogTextColor
        splitter.backgroundColor = Colors.dialogLineColor
        
        titleLabel.text = titleText
        titleLabel.font = UIFont (name: FontsAndSizes.dialogFont, size: CGFloat(FontsAndSizes.dialogTextSize))
        
        tableView.delegate = self
        tableView.dataSource = self
        
        let onBackgroundClick = UITapGestureRecognizer(target: self, action: #selector(GridDialog.onBackgroundClick(sender:)))
        backgroundView.isUserInteractionEnabled = true
        backgroundView.addGestureRecognizer(onBackgroundClick)
        // Do any additional setup after loading the view.
    }
    
    
    override func viewDidLayoutSubviews() {
        tableView.frame = CGRect(x: tableView.frame.origin.x, y: tableView.frame.origin.y, width: tableView.frame.size.width, height: tableView.contentSize.height)
        tableViewHeight.constant = tableView.frame.height
        titleLabel.text = titleText
        if ((tableView.frame.height + 25 + titleLabel.frame.size.height) > (UIScreen.main.bounds.size.height - 60))
        {
            tableViewHeight.constant = UIScreen.main.bounds.size.height - 85 - titleLabel.frame.size.height
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
        roundCorners([.topLeft,.topRight], radius: 10, view: dialogView)
        UIView.animate(withDuration: 0.3, animations: {
            self.gridDialogView.backgroundColor = Colors.dialogsBackgroundColor
            
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height
        }, completion: nil)
        self.dialogView.isHidden = false
        tableView.scrollToRow(at: IndexPath(row: years.count/5 - 1, section: 0), at: .bottom, animated: true)
    }
    
    @objc func onBackgroundClick(sender:UITapGestureRecognizer) {
        GridDialog.dismissDialog()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return years.count/5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "grid_cell") as! GridViewCell
        let index = indexPath.row
        
        //set the cell view
        cell.button1.setTitle(String(years[index * 5]), for: .normal)
        cell.button2.setTitle(String(years[(index * 5) + 1]), for: .normal)
        cell.button3.setTitle(String(years[(index * 5) + 2]), for: .normal)
        cell.button4.setTitle(String(years[(index * 5) + 3]), for: .normal)
        cell.button5.setTitle(String(years[(index * 5) + 4]), for: .normal)
        
        cell.button1.setTitleColor(UIColor.black, for: .normal)
        cell.button2.setTitleColor(UIColor.black, for: .normal)
        cell.button3.setTitleColor(UIColor.black, for: .normal)
        cell.button4.setTitleColor(UIColor.black, for: .normal)
        cell.button5.setTitleColor(UIColor.black, for: .normal)
        
        cell.button1.layer.borderWidth = 0.3
        cell.button2.layer.borderWidth = 0.3
        cell.button3.layer.borderWidth = 0.3
        cell.button4.layer.borderWidth = 0.3
        cell.button5.layer.borderWidth = 0.3
        
        cell.button1.layer.borderColor = Colors.lightGray.cgColor
        cell.button2.layer.borderColor = Colors.lightGray.cgColor
        cell.button3.layer.borderColor = Colors.lightGray.cgColor
        cell.button4.layer.borderColor = Colors.lightGray.cgColor
        cell.button5.layer.borderColor = Colors.lightGray.cgColor
        
        cell.button1.tag = years[index * 5]
        cell.button2.tag = years[(index * 5) + 1]
        cell.button3.tag = years[(index * 5) + 2]
        cell.button4.tag = years[(index * 5) + 3]
        cell.button5.tag = years[(index * 5) + 4]
        
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
        
        cell.button1.setBackgroundImage(imageWithColor(color: Colors.dialogSelectionColor), for: .highlighted)
        cell.button2.setBackgroundImage(imageWithColor(color: Colors.dialogSelectionColor), for: .highlighted)
        cell.button3.setBackgroundImage(imageWithColor(color: Colors.dialogSelectionColor), for: .highlighted)
        cell.button4.setBackgroundImage(imageWithColor(color: Colors.dialogSelectionColor), for: .highlighted)
        cell.button5.setBackgroundImage(imageWithColor(color: Colors.dialogSelectionColor), for: .highlighted)
        
        cell.button1.setBackgroundImage(imageWithColor(color: Colors.dialogSelectionColor), for: .focused)
        cell.button2.setBackgroundImage(imageWithColor(color: Colors.dialogSelectionColor), for: .focused)
        cell.button3.setBackgroundImage(imageWithColor(color: Colors.dialogSelectionColor), for: .focused)
        cell.button4.setBackgroundImage(imageWithColor(color: Colors.dialogSelectionColor), for: .focused)
        cell.button5.setBackgroundImage(imageWithColor(color: Colors.dialogSelectionColor), for: .focused)
        
        
        return cell
    }
    
    /// Set the dialog.
    ///
    /// - Parameters:
    ///   - title: The title description
    ///   - years: The available years.
    func setDialogView(title: String, years: [Int])
    {
        titleText = title
        self.years = years
    }
    
    /// Dismiss dialog with animation.
    static func dismissDialog(){
        UIView.animate(withDuration: 0.3, animations: {
            viewController.gridDialogView.backgroundColor = UIColor.init(red: 1,
                                                               green: 1,
                                                               blue: 1,
                                                               alpha: 0)
            
            viewController.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
        }, completion: {(finished: Bool) in
            viewController.dismiss(animated: true,completion: nil)
        })
        GridDialog.delegate?.dismissed()
    }
    
}
