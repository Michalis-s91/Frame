//
//  AreEqual.swift
//  RichReach2
//
//  Created by Eumbrella on 27/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/**
 * Checks if object1 is equal with object2.
 * @param object1 The first object.
 * @param object2 The second object.
 * @return True if both objects are null or equal, otherwise false.
 */
func areEqual(object1 : AnyObject! ,object2 : AnyObject!) -> Bool
{
    if (object1 == nil && object2 == nil)
    {
        return true
    }
    else if ((object1 == nil && object2 != nil) || (object1 != nil && object2 == nil) || !(object1.isEqual(object2) ))
    {
        return false
    }
    else
    {
        return true
    }
}
