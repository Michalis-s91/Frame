//
//  ProductsWepApi.swift
//  RichReach2
//
//  Created by Eumbrella on 16/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Web api for getting products, barcodes, product categories and brands.
class ProductsWepApi
{
    
    /// Post requset for getting products.
    ///
    /// - Parameter pageNo: The page number.
    /// - Returns: The prodcurs.
    static func getProducts(pageNo : Int!) -> [ProductModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post2(url: "http://www.eumbrellacorp.com/webapi/eOrderingApi/GetRRProductsDataForLocal?ClientID=" + (String(clientID)  ?? "")  + "&PageNo=" + (String(pageNo)  ?? ""),params:  "")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let products = try decoder.decode(Products.self, from : (response.data(using: .utf8))!)
                
                return products.productsList
            }
        }
        catch
        {
            print(error)
            return nil
        }
        
        return []
    }
    
    static func getChangedProducts(pageNo : Int!) -> [ProductModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            var newDate : String!
            
            print(statusModel.lastProductsSyncDate)
            if(!isNullOrEmpty(string: statusModel.lastProductsSyncDate))
            {
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss,SSS" //Your date format
                dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00") //Current time zone
                //according to date format your date string
                guard let date = dateFormatter.date(from: statusModel.lastProductsSyncDate) else {
                    return nil
                }
                
                dateFormatter.dateFormat = "dd/MM/yyyy"
                newDate = dateFormatter.string(from: date)
            }
            
            print("http://www.eumbrellacorp.com/webapi/eOrderingApi/GetRRProductsDataForLocalFromDate?ClientID=\(String(clientID)  ?? "")&PageNo= \(String(pageNo)  ?? "")&StartDate=\(newDate ?? "")")
            
            try httpRequest.post2(url: "http://www.eumbrellacorp.com/webapi/eOrderingApi/GetRRProductsDataForLocalFromDate?ClientID=\(String(clientID)  ?? "")&PageNo=\(String(pageNo)  ?? "")&StartDate=\(newDate ?? "")",params:  "")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let products = try decoder.decode(Products.self, from : (response.data(using: .utf8))!)
                
                return products.productsList
            }
        }
        catch
        {
            print(error)
            return nil
        }
        
        return []
    }
    
    /// Post requset for getting barcodes.
    ///
    /// - Parameter pageNo: The page number.
    /// - Returns: The barcodes.
    static func getBarcodes(pageNo : Int!) -> [BarcodeModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post2(url: "http://www.eumbrellacorp.com/webapi/eOrderingApi/GetRRProductsBarcodeForLocal?ClientID=" + String(clientID) + "&PageNo=" + String(pageNo),params:  "")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let barcodes = try decoder.decode(Barcodes.self, from : (response.data(using: .utf8))!)
                
                for b in barcodes.barcodesList
                {
                    b.barcode = isNullOrEmpty(string: b.barcode) ?  b.barcode : b.barcode.replacingOccurrences(of: " ", with: "")
                }
                
                return barcodes.barcodesList
            }
        }
        catch
        {
            print(error)
            return nil
        }
        
        return []
    }
    
    
    /// Post requset for getting categories.
    ///
    /// - Returns: The categories.
    static func getCategories() -> [CategoryModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://www.eumbrellacorp.com/webapi/eOrderingApi/GetBusinessProductCategories?ClientID=" + String(clientID) + "&Mobile=" + String(99159915) ,params:  "")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let categories = try decoder.decode(Categories.self, from : (response.data(using: .utf8))!)
                
                
                /*categories.hasAlternatingStyles = true
                
                categories.firstStyle = CategoryStyleModel()
                categories.secondStyle = CategoryStyleModel()
                
                categories.firstStyle.backgroundColor = "#ffffff"
                categories.firstStyle.font = "Roboto-Light"
                categories.firstStyle.textSize = 14
                categories.firstStyle.textColor = "#000000"
                categories.firstStyle.tintColor = "#000000"
                
                categories.secondStyle.backgroundColor = "#ff0000"
                categories.secondStyle.font = "Roboto-Light"
                categories.secondStyle.textSize = 14
                categories.secondStyle.textColor = "#000000"
                categories.secondStyle.tintColor = "#000000"
                
                if(categories.hasAlternatingStyles)
                {
                    var i = 0
                    for c in categories.categoriesList
                    {
                        if(i % 2 == 0)
                        {
                            c.textSize = categories.firstStyle.textSize
                            c.textColor = categories.firstStyle.textColor
                            c.font = categories.firstStyle.font
                            c.backgroundColor = categories.firstStyle.backgroundColor
                            c.tintColor = categories.firstStyle.tintColor
                        }
                        else
                        {
                            c.textSize = categories.secondStyle.textSize
                            c.textColor = categories.secondStyle.textColor
                            c.font = categories.secondStyle.font
                            c.backgroundColor = categories.secondStyle.backgroundColor
                            c.tintColor = categories.secondStyle.tintColor
                        }
                        
                        i += 1
                        
                    }
                }*/
                
                
                return categories.categoriesList
            }
        }
        catch
        {
            print(error)
        }
        
        return nil
    }
    
    
    /// Post requset for getting brands.
    ///
    /// - Returns: The brands
    static func getBrands() -> [CategoryModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://www.eumbrellacorp.com/webapi/eOrderingApi/GetBrandsList?ClientID=" + String(clientID) ,params:  "")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let categories = try decoder.decode(Categories.self, from : (response.data(using: .utf8))!)
                
                return categories.categoriesList
            }
        }
        catch
        {
            print(error)
        }
        
        return nil
    }
    
    /// Post requset for getting product menu.
    ///
    /// - Returns: The product menu
    static func getProductMenu() throws -> [ProductMenuModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://www.eumbrellacorp.com/webapi/eorderingapi/GetRRProductMenuForLocal?ClientID=" + String(clientID) ,params:  "")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let productMenu = try decoder.decode(ProductMenu.self, from : (response.data(using: .utf8))!)
                
                return productMenu.productMenuList
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    /// Post requset for getting product menu relations.
    ///
    /// - Returns: The product menu relations
    static func getProductMenuRelations() throws -> [ProductMenuRelationModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://www.eumbrellacorp.com/webapi/eorderingapi/GetRRProductMenuRelationsForLocal?ClientID=" + String(clientID) ,params:  "")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let productMenuRelations = try decoder.decode(ProductMenuRelations.self, from : (response.data(using: .utf8))!)
                
                return productMenuRelations.productMenuRelationsList
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
}

/// Helper class for deserialisation.
class Products : Codable
{
    var productsList : [ProductModel]!
    
    private enum CodingKeys : String, CodingKey {
        case productsList = "RRProductsDataInfoList"
    }
}

class Barcodes : Codable
{
    var barcodesList : [BarcodeModel]!
    
    private enum CodingKeys : String, CodingKey {
        case barcodesList = "RRProductsBarcodeInfoList"
    }
}

class Categories : Codable
{
    var categoriesList : [CategoryModel]!
    
    private enum CodingKeys : String, CodingKey {
        case categoriesList = "CategoriesList"
    }
}

class ProductMenu : Codable
{
    var productMenuList : [ProductMenuModel]!
    
    private enum CodingKeys : String, CodingKey {
        case productMenuList = "RRProductsDataInfoList"
    }
}

class ProductMenuRelations : Codable
{
    var productMenuRelationsList : [ProductMenuRelationModel]!
    
    private enum CodingKeys : String, CodingKey {
        case productMenuRelationsList = "RRProductsDataInfoList"
    }
}
