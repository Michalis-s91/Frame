//
//  UserProfileViewController2.swift
//  RichReach2
//
//  Created by Eumbrella on 26/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import Kingfisher
import CoreLocation
import UserNotifications

var loadingNotificationsFromProfile = false

class UserProfileViewController2 : ViewController,UITextFieldDelegate, ModalViewControllerDelegate, UITableViewDelegate , UITableViewDataSource, CLLocationManagerDelegate
{
    @IBOutlet var profileTableView: UITableView!
    @IBOutlet var missingDataLabel: UILabel!
    @IBOutlet var backgroundImage: UIImageView!
    @IBOutlet var indicator: UIActivityIndicatorView!
    @IBOutlet var customerServiceView: UIView!
    
    //@IBOutlet var phoneNumberLabel: UILabel!
    @IBOutlet var phoneNumberLabel: UILabel!
    @IBOutlet var messageLabel: UILabel!
    @IBOutlet var retryButton: UIButton!
    
    var typesDialog : TableDialog!
    var visibleItems : [UserProfileCellModel] = []
    var items : [UserProfileCellModel] = []
    var lock = NSObject()
    var lock2 = NSObject()
    var selectedTitle = "Mrs."
    var titleField : UITextField!
    var selectedDropdownType : Int!
    var submitButtonPressed = false
    var appUser = localDatabase.getAppUser()
    var isRegistered = true
    var areSubmittedInfoCorrect = true
    var viewModel : UserProfileViewModel2!
    //var fields : [FieldModel]! = []
    var birthDate : String!
    
    var statusTextDialog : DescriptionTextFieldDialog!
    var descriptionDialog : DescriptionDialog!
    var messageDialog : MessageDialog!
    var datePickerDialog : DatePickerDialog!
    
    var verificationFields : [FieldModel] = []
    var vissibleVerificationField : FieldModel!
    var numberOfMissingData = 0
    var numberOfAllFields = 0
    var isStatusTextDialogDisplayed = false
    
    var checkBoxGroups : [CheckBoxGroup]! = []
    var checkBoxes : [CheckBoxModel] = []
    var textFields : [TextFieldModel] = []
    //let locationManager = CLLocationManager()
    var isUserProfileSynced = false
    var isEditingField = false
    var editingFieldView : EditingFieldViewController!
    var areUnsavedChanges = false
    
    class TextFieldModel
    {
        init (textField : UITextField!, type : Int!)
        {
            self.textField = textField
            self.type = type
        }
        var textField : UITextField!
        var type : Int!
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        restartApp = false
        self.prepare(for:  UIStoryboardSegue(identifier: "a",source: UIViewController() ,destination: UIViewController()), sender: nil)
        
        if(viewModel == nil)
        {
            viewModel = UserProfileViewModel2()
            viewModel.viewController = self
        }
        
        DispatchQueue.global(qos: .background).async {
            self.setView()
        }
        
        hideCustomerServiceView()
        
        registerForKeyboardNotifications()
        
        profileTableView.tableFooterView = UIView()
        profileTableView.rowHeight = UITableViewAutomaticDimension
        profileTableView.delegate = self
        profileTableView.dataSource = self
        
        hideKeyboardWhenTappedAround()
        
        NotificationCenter.default.addObserver(self, selector:#selector(viewCameActive), name: NSNotification.Name.UIApplicationWillEnterForeground, object: nil)
        
        if(isEditingField)
        {
            self.navigationItem.leftBarButtonItem?.image = UIImage(named: "ic_back")
        }
        
        /*if(selectedTab.hasBackgroundImage)
         {
         let data = parameterizationDatabase.getBackgroundImage(apk: APK)
         
         if(data != nil)
         {
         backgroundImage.image = UIImage(data: data!)
         }
         }*/
        
        //profileTableView.backgroundView = UIImageView(image:  UIImage(data: data!))
        
        /*let image = UIImage(data: data!)
        let iv = UIImageView(image: image)
        iv.contentMode = .scaleAspectFit
        iv.layer.frame = CGRect(x: 0, y: 0, width: 500, height: 1000)
        let tableViewBackgroundView = UIView()
        tableViewBackgroundView.addSubview(iv)
        tableViewBackgroundView.frame = CGRect(x: 0, y: 0, width: 500, height: 1000)
        self.profileTableView.backgroundView = tableViewBackgroundView
        //let image = UIImage(data: data!)?.resizeImage(CGFloat(1000), opaque: false)
        //self.profileTableView.backgroundColor = UIColor(patternImage: image!)
        //self.profileTableView.backgroundView?.backgroundColor =  UIColor(patternImage: UIImage(data: data!)!)*/
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        restartApp = true
        
        apkUserPreferences = parameterizationDatabase.getAPKUserPreferences(apk: APK)
        
        if(apkUserPreferences == nil)
        {
            apkUserPreferences = APKUserPreferences()
        }
    }
    
    func setMissingData()
    {
        DispatchQueue.main.async(execute: {() -> Void in
            self.missingDataLabel.text = String(format: "%.2f", (Double(self.numberOfMissingData)/Double(self.numberOfAllFields)) * 100.0)
        })
    }
    
    func setView()
    {
        
        
        if(localDatabase.isAPKVerified(clientID: clientID)!)
        {
            checkBoxGroups = viewsDB.getCheckBoxGroups()
            viewModel.acceptNews = localDatabase.getAcceptNews(bussinessID: clientID)
            
            let itemsTemp = userProfileDB.getVerificationView()
            if(itemsTemp != nil)
            {
                for i in itemsTemp!
                {
                    if(i.type == UserProfileCellType.Field.rawValue)
                    {
                        let field = i.fields[0]
                        //field.fieldStyle.asteriskColor = "#00000000"
                        
                        if(field.type == UserProfileFieldType.Phoneumber.rawValue && !isNullOrEmpty(string: appUser?.phoneNumber))
                        {
                            field.value = appUser?.phoneNumber
                            
                            if(appUser?.hasVerifiedPhoneNumber)!
                            {
                                field.isVerified = true
                            }
                            else
                            {
                                isRegistered = false
                            }
                        }
                        else if(field.type == UserProfileFieldType.Email.rawValue && !isNullOrEmpty(string: appUser?.emailAddress))
                        {
                            field.value = appUser?.emailAddress
                            
                            if(appUser?.hasVerifiedEmailAddress)!
                            {
                                field.isVerified = true
                            }
                            else if (appUser?.needEmailVerification == nil || appUser!.needEmailVerification)
                            {
                                isRegistered = false
                            }
                        }
                        
                        verificationFields.append(field)
                    }
                }
            }
            
            if(isRegistered)
            {
                //isRegistered = true
                
                visibleItems = userProfileDB.getUserProfileView()
                setUserProfileView()
                setMissingData()
            }
            else
            {
                //isRegistered = false
                
                localDatabase.deleteRegisteredAPK()
                
                if(loadVerificationView())
                {
                    loadUserData()
                    return
                }
                
                if(!isRegistered)
                {
                    checkSubmitedInfo(showDialogs: false)
                }
                
                viewModel.fields = verificationFields
            }
        }
        else
        {
            isRegistered = false
            
            if(loadVerificationView())
            {
                loadUserData()
                return
            }
            
            if(!isRegistered)
            {
                checkSubmitedInfo(showDialogs: false)
            }
            
            viewModel.fields = verificationFields
        }
        
        items = visibleItems
        
        for v in visibleItems
        {
            if(v.type == UserProfileCellType.Title.rawValue && v.title.isSection && !v.title.isSectionExpanded)
            {
                var index = 0
                for i in visibleItems
                {
                    if(i.type == UserProfileCellType.Title.rawValue && i.title.id == v.title.id)
                    {
                        index += 1
                        while(true)
                        {
                            if(index >= visibleItems.count || (visibleItems[index].type == UserProfileCellType.Title.rawValue && visibleItems[index].title.isSection) || index == visibleItems.count || visibleItems[index].type == UserProfileCellType.Button.rawValue)
                            {
                                break
                            }
                            else
                            {
                                visibleItems.remove(at: index)
                            }
                        }
                        
                        break
                    }
                    
                    index += 1
                }
            }
        }
        
        if(localDatabase.isAPKRegistered(bussinessID: clientID))
        {
            syncUserProfile()
        }
        else
        {
            isUserProfileSynced = true
            DispatchQueue.main.async(execute: {() -> Void in
                self.indicator.stopAnimating()
                self.profileTableView.reloadData()
            })
            
            if(localDatabase.isAPKVerified(clientID: clientID))
            {
                self.displayMessageDialogView(title: NSLocalizedString("completeRegistration", comment: ""), message: NSLocalizedString("completeRegistrationMessage", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""),dismissWhenClickOutside: false)
            }
        }
    }
    
    func setUserProfileView()
    {
        var index = 0
        //var isRegistered = localDatabase.isAPKRegistered(bussinessID: clientID)
        
        for i in visibleItems
        {
            if((appUser!.isLoyaltyUser != nil && appUser!.isLoyaltyUser) &&  i.shouldHideOnUpdateProfileView)
            {
                visibleItems.remove(at: index)
                continue
            }
            
            if(i.fields != nil)
            {
                for f in i.fields
                {
                    for v in verificationFields
                    {
                        if(v.type == f.type)
                        {
                            if((f.type == UserProfileFieldType.Phoneumber.rawValue && appUser!.hasVerifiedPhoneNumber) || (f.type == UserProfileFieldType.Email.rawValue && appUser!.hasVerifiedEmailAddress))
                            {
                                f.isVerified = true
                            }
                        }
                    }
                    
                    switch f.type
                    {
                    case  UserProfileFieldType.Phoneumber.rawValue :
                        f.value = appUser?.phoneNumber
                    case  UserProfileFieldType.Email.rawValue :
                        f.value = appUser?.emailAddress
                    case  UserProfileFieldType.Title.rawValue :
                        if(appUser?.titleID != nil && f.dropDownItemsModel.count > ((appUser?.titleID)! + 1))
                        {
                            f.value = f.dropDownItemsModel[(appUser?.titleID)! == 0 ? 0 : (appUser?.titleID)! - 1].textStr
                        }
                        else
                        {
                            if(isNullOrEmpty(string: f.placeHolder) || appUser?.gender != nil)
                            {
                                f.value = isNullOrEmpty(string: appUser?.title) ? (appUser?.gender == 0 ? "Mr." : "Ms.") : appUser?.title
                            }
                        }
                    case  UserProfileFieldType.Name.rawValue :
                        f.value = appUser?.name
                    case  UserProfileFieldType.Surname.rawValue :
                        f.value = appUser?.surname
                    case  UserProfileFieldType.Gender.rawValue :
                        if(appUser?.gender != nil) //&& isNullOrEmpty(string: f.placeHolder) )
                        {
                            f.value = appUser?.gender == 0 ? "Male" : "Female"
                        }
                    case  UserProfileFieldType.Birthday.rawValue :
                        f.value = appUser?.birthDate
                    case  UserProfileFieldType.Address1.rawValue :
                        f.value = appUser?.homeAddress
                    case  UserProfileFieldType.Address2.rawValue :
                        f.value = appUser?.homeAddress2
                    case  UserProfileFieldType.HouseNo.rawValue :
                        f.value = appUser?.houseNo
                    case  UserProfileFieldType.City.rawValue :
                        f.value = appUser?.city
                    case  UserProfileFieldType.PostCode.rawValue :
                        f.value = appUser?.postCode
                    case  UserProfileFieldType.District.rawValue :
                        f.value = appUser?.province
                    case  UserProfileFieldType.Country.rawValue :
                        f.value = appUser?.country
                    case  UserProfileFieldType.CommunicationLanguage.rawValue :
                        f.value = appUser?.communicationLanguage
                    case  UserProfileFieldType.ReferredName.rawValue :
                        f.value = appUser?.referedName
                    case  UserProfileFieldType.FlatHouseName.rawValue :
                        f.value = appUser?.flatHouseName
                    default :
                        break
                    }
                    
                    numberOfAllFields += 1
                    
                    if(isNullOrEmpty(string: f.value))
                    {
                        numberOfMissingData += 1
                    }
                }
            }
            else if(i.type == UserProfileCellType.CheckBox.rawValue)
            {
                /*if(i.checkBox.isRequired)
                {
                    i.checkBox.isChecked = true
                }*/
                
                checkBoxes.append(i.checkBox)
            }
            
            index += 1
        }
    }
    
    func hideItemsOnUpdate()
    {
        var index = 0
        for i in self.items
        {
            if(i.shouldHideOnUpdateProfileView)
            {
                self.items.remove(at: index)
                continue
            }
            
            index += 1
        }
        
        visibleItems = items
    }
    
    func loadVerificationView() -> Bool
    {
        var itemsTemp = userProfileDB.getVerificationView()
        var isFieldAdded = false
        var index = 0
        appUser = localDatabase.getAppUser()
        
        if(itemsTemp != nil)
        {
            for i in itemsTemp!
            {
                if(i.type == UserProfileCellType.Field.rawValue)
                {
                    let field = i.fields[0]
                    
                    if(!isFieldAdded)
                    {
                        if(field.type == UserProfileFieldType.Phoneumber.rawValue )
                        {
                            if(appUser?.hasVerifiedPhoneNumber == nil || !(appUser?.hasVerifiedPhoneNumber)!)
                            {
                                if( index != 0 && itemsTemp![index - 1].type == UserProfileCellType.Title.rawValue)
                                {
                                    visibleItems.append(itemsTemp![index - 1])
                                }
                                
                                 visibleItems.append(i)
                                
                                if(!isNullOrEmpty(string: appUser?.phoneNumber))
                                {
                                    field.value = appUser?.phoneNumber
                                    
                                    /*if(appUser?.isPending)!
                                    {
                                        var cell = UserProfileCellModel()
                                        cell.type = UserProfileCellType.AlreadyReceived.rawValue
                                        items.append(cell)
                                    }*/
                                }
                                
                                vissibleVerificationField = i.fields[0]
                                
                                isFieldAdded = true
                            }
                            else if(appUser!.phoneNumberCount != nil && appUser!.phoneNumberCount <= 1)
                            {
                                if(appUser!.phoneNumberCount == 1 && appUser!.emailAddressCount != nil && appUser!.emailAddressCount <= 1)
                                {
                                    loadUserData()
                                    return false
                                }
                            }
                            else
                            {
                                showCustomerServiceView()
                                //checkPhoneNumberOrEmailCount()
                            }
                        }
                        else if(field.type == UserProfileFieldType.Email.rawValue)
                        {
                            if(appUser?.hasVerifiedEmailAddress == nil || !(appUser?.hasVerifiedEmailAddress)!)
                            {
                                if( index != 0 && itemsTemp![index - 1].type == UserProfileCellType.Title.rawValue)
                                {
                                    visibleItems.append(itemsTemp![index - 1])
                                }
                                
                                visibleItems.append(i)
                                
                                if(!isNullOrEmpty(string: appUser?.emailAddress))
                                {
                                    field.value = appUser?.emailAddress
                                    
                                    /*if(appUser?.isPendingEmail)!
                                     {
                                     var cell = UserProfileCellModel()
                                     cell.type = UserProfileCellType.AlreadyReceived.rawValue
                                     items.append(cell)
                                     }*/
                                }
                            }
                            else if((appUser!.phoneNumberCount != nil && appUser!.emailAddressCount != nil) && (appUser!.phoneNumberCount == 0 && appUser!.emailAddressCount > 1))
                            {
                                showCustomerServiceView()
                            }
                            
                            vissibleVerificationField = i.fields[0]
                            isFieldAdded = true
                        }
                    }
                    
                    verificationFields.append(field)
                }
                else if(i.type == UserProfileCellType.CheckBox.rawValue && !localDatabase.isAPKAccepted(bussinessID: clientID))
                {
                    if(itemsTemp![index - 1].type != UserProfileCellType.CheckBox.rawValue || Bundle.main.bundleIdentifier! == APKsEnum.RichReach.rawValue)
                    {
                        /*if(i.checkBox.isRequired)
                        {
                            i.checkBox.isChecked = true
                        }*/
                        
                        visibleItems.append(i)
                    }
                }
                else if(i.type == UserProfileCellType.Button.rawValue)
                {
                    visibleItems.append(i)
                }
                else if(i.type == UserProfileCellType.Title.rawValue && (itemsTemp![index + 1].type != UserProfileCellType.Field.rawValue) )
                {
                    if(visibleItems.count == 0)
                    {
                        i.title.title = ""
                    }
                    
                    visibleItems.append(i)
                }
                index += 1
            }
        }
        
        if(!isFieldAdded && localDatabase.isAPKAccepted(bussinessID: clientID))
        {
            visibleItems.removeAll()
            return true
        }

        items = visibleItems
        return false
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    var viewIsDisplayed = false
    
    override func viewDidLayoutSubviews() {
        if(viewIsDisplayed)
        {
            super.viewDidAppear(true)
        }
    }
    
    override  func viewWillAppear(_ animated: Bool) {
       
        
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        self.profileTableView.removeObserver(self, forKeyPath: "contentSize")
        super.viewWillDisappear(true)
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?){
        if(selectedTab.hasBackgroundImage)
        {
            if(keyPath == "contentSize"){
                
                if let newvalue = change?[.newKey]{
                    let newsize  = newvalue as! CGSize
                    
                    previousContentSize = newsize.height
                    setBackgroundImage()
                }
            }
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        //profileTableView.reloadData()
        viewIsDisplayed = true
        
        super.viewWillAppear(animated)
        self.profileTableView.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        
        if(isEditingField)
        {
            if(editingFieldView.isEditSuccessFull)
            {
                appUser = localDatabase.getAppUser()
                
                setView()
                
                if(localDatabase.isAPKRegistered(bussinessID: clientID))
                {
                    buttonClicked()
                }
            }
            
            isEditingField = false
        }
        
        /*DispatchQueue.main.async(execute: {() -> Void in
            self.profileTableView.layoutIfNeeded()
            let data = parameterizationDatabase.getBackgroundImage(apk: APK)
            //let image = UIImage(named: "Edit profile background.png")?.resizeImage2(UIScreen.main.bounds.size.width, (self.profileTableView.contentSize.height + 20), opaque: false)
            let image = UIImage(named: "Edit profile background.png")?.resizeImage2(UIScreen.main.bounds.size.width, (self.profileTableView.contentSize.height + 20), opaque: false)
            //   ?.resizeImage2(UIScreen.main.bounds.size.width, (self.profileTableView.contentSize.height + 20), opaque: false)
            //UIImage(data: data!)?.resizeImage((self.profileTableView.contentSize.height + 20), opaque: false)
            self.profileTableView.backgroundColor = UIColor(patternImage: image!)
        })*/
    }
    
    @objc func viewCameActive(){
        DispatchQueue.global(qos: .background).async {
            if(isActivityActive(viewController: self))
            {
                DispatchQueue.main.async(execute: {() -> Void in
                    self.syncUserProfile()
                    restartApp = false
                })
            }
        }
    }

    func syncUserProfile(showDialog : Bool = false)
    {
        DispatchQueue.global(qos: .background).async {
            if(localDatabase.isAPKRegistered(bussinessID: clientID))
            {
                if(!showDialog && NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
                {
                    self.viewModel.checkIfUserExists(items : self.visibleItems, timeout: 5)
                    DispatchQueue.main.async(execute: {() -> Void in
                        self.indicator.stopAnimating()
                        self.profileTableView.reloadData()
                        self.isUserProfileSynced = true
                    })
                }
                else
                {
                    func yesRaised()
                    {
                        if(NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
                        {
                            self.viewModel.checkIfUserExists(items : self.visibleItems,timeout: 5)
                            DispatchQueue.main.async(execute: {() -> Void in
                                self.indicator.stopAnimating()
                                self.profileTableView.reloadData()
                                self.isUserProfileSynced = true

                                self.displayMessageDialogView(title: "Succeed", message: "Profile informations synced succeed.", closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                            })
                        }
                        else
                        {
                            
                            let sb = UIStoryboard(name:"YesNoMessageDialog",bundle:nil)
                            let dialog = sb.instantiateInitialViewController() as! YesNoMessageDialog
                            self.present(dialog,animated:true)
                            dialog.setDialogView(title: "Unable to sync data", message: "Please activate your Internet and synchronise.", yesButtonName: NSLocalizedString("Sync now", comment: ""), noButtonName: NSLocalizedString("Don't sync", comment: ""))
                            
                            yesAction = yesRaised
                            noAction = noRaised
                            
                            dialog.yesRaised = self
                            dialog.noRaised = self
                            
                        }
                        
                        //syncUserProfile(showDialog: true)
                    }
                    
                    func noRaised()
                    {
                        DispatchQueue.main.async(execute: {() -> Void in
                            self.indicator.stopAnimating()
                            self.profileTableView.reloadData()
                        })
                    }
                    
                    
                    let sb = UIStoryboard(name:"YesNoMessageDialog",bundle:nil)
                    let dialog = sb.instantiateInitialViewController() as! YesNoMessageDialog
                    DispatchQueue.main.async(execute: {() -> Void in
                        self.present(dialog,animated:true)
                        dialog.setDialogView(title: "Unable to sync data", message: "Please activate your Internet and synchronise.", yesButtonName: NSLocalizedString("Sync now", comment: ""), noButtonName: NSLocalizedString("Don't sync", comment: ""))
                    })
                    
                    yesAction = yesRaised
                    noAction = noRaised
                    
                    dialog.yesRaised = self
                    dialog.noRaised = self
                    
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return visibleItems.count
    }
    
    func setBackgroundImage()
    {

        //previousContentSize = self.profileTableView.contentSize.height
        endReached = true
        let data = parameterizationDatabase.getBackgroundImage(apk: APK)
        //let image = UIImage(named: "Edit profile background.png")?.resizeImage2(UIScreen.main.bounds.size.width, (self.profileTableView.contentSize.height + 20), opaque: false)
        let image : UIImage
        
        if(isRegistered)
        {
            image = (UIImage(named: "Edit profile background.png")?.resizeImage2(UIScreen.main.bounds.size.width, self.previousContentSize, opaque: false))!
            self.profileTableView.backgroundColor = UIColor(patternImage: image)
        }
        else
        {
            if(data != nil)
            {
                image = UIImage(data: data!)?.resizeImage2(UIScreen.main.bounds.size.width, self.previousContentSize, opaque: false) == nil ? UIImage() : (UIImage(data: data!)?.resizeImage2(UIScreen.main.bounds.size.width, self.previousContentSize, opaque: false))!
                self.backgroundImage.image = image
            }
        }
    }
    
    var previousContentSize : CGFloat = 0.0
    var endReached = false
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let height = scrollView.frame.size.height
        let contentYoffset = scrollView.contentOffset.y
        let distanceFromBottom = scrollView.contentSize.height - contentYoffset
        if (distanceFromBottom < height && !endReached)
        {
            //setBackgroundImage()
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let item = visibleItems[indexPath.row]
        //cell.inputTextField.addTarget(self, action: #selector(myTargetFunction), for: UIControlEvents.touchUpInside)
        
        if(previousContentSize < self.profileTableView.contentSize.height)
        {
            //setBackgroundImage()
        }
        
        switch item.type {
        case UserProfileCellType.Field.rawValue:
            if(item.fields.count == 1)
            {
                let cell : SingleViewCell
                let field = item.fields[0]
                
                if(isRegistered)
                {
                    cell = tableView.dequeueReusableCell(withIdentifier: "single_cell") as! SingleViewCell
                    
                    if(!isNullOrEmpty(string: item.backgroundColor ))
                    {
                        cell.cellBackground.backgroundColor = UIColor(item.backgroundColor)
                    }
                    else
                    {
                        cell.cellBackground.backgroundColor = UIColor.clear
                    }
                }
                else
                {
                    cell = tableView.dequeueReusableCell(withIdentifier: "verify_cell") as! VerifyViewCell
                    
                    var isPending = true
                    
                    switch field.type
                    {
                    case UserProfileFieldType.Phoneumber.rawValue:
                        let appUser = localDatabase.getAppUser()
                        if(!(appUser?.isPending)!)
                        {
                            isPending = false
                        }
                    case UserProfileFieldType.Email.rawValue:
                        let appUser = localDatabase.getAppUser()
                        if(!(appUser?.isPendingEmail)!)
                        {
                            isPending = false
                        }
                    default:
                        break
                    }
                    
                    if(field.isVerified)
                    {
                        cell.resendButtonHeight.constant = 0
                        cell.verifyButtonHeight.constant = 0
                        
                        cell.verifyButton.setTitle("", for: .normal)
                        cell.resendButton.setTitle("", for: .normal)
                        cell.codeTextField.text = ""
                        cell.codeTextField.placeholder = ""
                        cell.textFieldBorder1.backgroundColor = UIColor.clear
                        cell.textFieldBorder2.backgroundColor = UIColor.clear
                        cell.textFieldBorder3.backgroundColor = UIColor.clear
                    }
                    else
                    {
                        cell.inputTextField.isEnabled = true
                        if(areSubmittedInfoCorrect && !isNullOrEmpty(string: vissibleVerificationField.value) && isPending)
                        {
                            if(field.type == UserProfileFieldType.Phoneumber.rawValue)
                            {
                                cell.resendButtonHeight.constant = 0
                            }
                            else
                            {
                                cell.resendButtonHeight.constant = 0 //30
                                cell.resendButton.setTitle("", for: .normal)//setTitle("resend verification code", for: .normal)
                                cell.resendButtonWidth.constant = (cell.resendButton.title(for: .normal)! as NSString).size(withAttributes: [NSAttributedStringKey.font: UIFont (name: "CharpentierSansPro-Demi", size: CGFloat(18))]).width + 30
                                cell.resendButton.titleLabel?.attributedText = NSAttributedString(string: cell.resendButton.title(for: .normal)!, attributes: [.underlineStyle: NSUnderlineStyle.styleSingle.rawValue])
                            }
                            
                            if(field.type == UserProfileFieldType.Phoneumber.rawValue)
                            {
                                cell.enterCodeLabel.text = "We will soon send you a 4-digit verification code via SMS. If you already have one please enter it below."
                            }
                            else
                            {
                                cell.enterCodeLabel.text = "We will soon send you a 4-digit verification code to your inbox. If you already have one please enter it below."
                            }
                            cell.enterCodeLabel.textColor = UIColor(field.fieldStyle.labelTextColor)
                            cell.enterCodeLabel.font = UIFont(name: field.fieldStyle.labelFont, size: CGFloat(field.fieldStyle.labelTextSize))
                            
                            cell.verifyButtonHeight.constant = 30
                            cell.verifyButton.setTitle("enter the 4-digit code here", for: .normal)
                            
                            
                            cell.verifyButtonWidth.constant = (cell.verifyButton.title(for: .normal)! as NSString).size(withAttributes: [NSAttributedStringKey.font: UIFont (name: "CharpentierSansPro-Demi", size: CGFloat(18))]).width + 30
                            
                            
                            //cell.textFieldBorder1.backgroundColor = UIColor(field.fieldStyle.borderColor)
                            //cell.textFieldBorder2.backgroundColor = UIColor(field.fieldStyle.borderColor)
                            //cell.textFieldBorder3.backgroundColor = UIColor(field.fieldStyle.borderColor)
                            
                            /*cell.codeTextField.font = UIFont(name: field.fieldStyle.textFont, size: CGFloat(field.fieldStyle.textTextSize))
                            cell.codeTextField.textColor = UIColor(field.fieldStyle.textTextColor)
                            cell.codeTextField.layer.borderColor = UIColor(field.fieldStyle.borderColor).cgColor
                            cell.codeTextField.layer.borderWidth = 1.0
                            cell.codeTextField.placeholder = "Enter verification code"
                            cell.codeTextField.backgroundColor = UIColor.clear
                            cell.codeTextField.text = field.verificationCode
                            cell.codeTextField.tag = field.type
                            cell.codeTextField.addTarget(self, action: #selector(verificationTextFieldDidChange(_:)), for: .editingChanged)*/
                            
                            
                            cell.verifyButton.layer.borderColor = UIColor(field.fieldStyle.borderColor).cgColor //UIColor(field.fieldStyle.borderColor).cgColor
                            cell.verifyButton.layer.borderWidth = 1.0
                            cell.verifyButton.titleLabel?.font = UIFont(name: field.fieldStyle.labelFont, size: CGFloat(field.fieldStyle.labelTextSize))
                            cell.verifyButton.setTitleColor(UIColor(field.fieldStyle.labelTextColor), for: .normal)//setTitleColor(UIColor(field.fieldStyle.borderColor), for: .normal)
                            cell.verifyButton.backgroundColor = UIColor.clear
                            
                            cell.resendButton.layer.borderColor = UIColor("#00000000").cgColor //UIColor(field.fieldStyle.borderColor).cgColor
                            cell.resendButton.layer.borderWidth = 0.0
                            cell.resendButton.titleLabel?.font = UIFont(name: "CharpentierSansPro-Demi", size: CGFloat(18)) //UIFont(name: field.fieldStyle.textFont, size: CGFloat(field.fieldStyle.textTextSize))
                            cell.resendButton.setTitleColor(UIColor("#1D2D51"), for: .normal)//(UIColor(field.fieldStyle.borderColor), for: .normal)
                            cell.resendButton.backgroundColor = UIColor.clear
                            
                            cell.verifyButton.tag = field.type
                            cell.verifyButton.addTarget(self, action: #selector(onClickAlreadyRegistered(_:)), for: .touchUpInside)
                            
                            cell.resendButton.tag = field.type
                            cell.resendButton.addTarget(self, action: #selector(resendClick(_:)), for: .touchUpInside)
                        }
                        else
                        {
                            cell.resendButtonHeight.constant = 0
                            cell.verifyButtonHeight.constant = 0
                            cell.verifyButton.setTitle("", for: .normal)
                            cell.resendButton.setTitle("", for: .normal)
                            cell.enterCodeLabel.text = ""
                        }
                    }
                }
                
    
                if(!item.isFullWidth)
                {
                    cell.textFieldTrailing.constant = (UIScreen.main.bounds.size.width - 20) / 2
                }
                else
                {
                    cell.textFieldTrailing.constant = 0
                }
                
                setField(field: field, fieldStyle : field.fieldStyle, label: cell.label, inputTextField: &cell.inputTextField, requiredLabel: cell.requiredLabel, dropDownImage : cell.dropDownImage, drowDownImageWidth : cell.dropDownImageWidth, rowIndex: indexPath.row)
                
                cell.selectionStyle = .none
                return cell
            }
            else if(item.fields.count == 2)
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "double_cell") as! DoubleViewCell
                
                let field1 = item.fields[0]
                let field2 = item.fields[1]
                
                setField(field: field1, fieldStyle : field1.fieldStyle, label: cell.firstLabel, inputTextField: &cell.firstInputTextField, requiredLabel: cell.firstRequiredLabel,  dropDownImage : cell.firstDropDownImage, drowDownImageWidth : cell.firstDropDownImageWidth, rowIndex: indexPath.row)
                setField(field: field2, fieldStyle : field2.fieldStyle, label: cell.secondLabel, inputTextField: &cell.secondInputTextField, requiredLabel: cell.secondRequiredLabel, dropDownImage : cell.secondDropDownImage, drowDownImageWidth : cell.secondDropDownImageWidth, rowIndex: indexPath.row)
                
                cell.firstLabelWidth.constant = cell.firstInputTextField.frame.size.width - 10
                cell.secondLabelWidth.constant = cell.firstInputTextField.frame.size.width - 10
                
                if(!isNullOrEmpty(string: item.backgroundColor ))
                {
                    cell.cellBackground.backgroundColor = UIColor(item.backgroundColor)
                }
                else
                {
                    cell.cellBackground.backgroundColor = UIColor.clear
                }
                
                cell.selectionStyle = .none
                return cell
            }
        case UserProfileCellType.Button.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "button_cell") as! ButtonViewCell
            let button : ButtonModel! = item.button
            
            cell.button.setTitle(button.name, for: .normal)
            if(localDatabase.isAPKRegistered(bussinessID: clientID))
            {
                cell.button.setTitle("Update", for: .normal)
            }
            else if(localDatabase.isAPKVerified(clientID: clientID))
            {
                cell.button.setTitle("Submit", for: .normal)
            }
            
            cell.button.titleLabel?.font = UIFont (name: (button?.font)!, size: CGFloat(button.textSize))
            cell.button.setTitleColor(UIColor(button.textColor), for: .normal)
            cell.button.backgroundColor = UIColor(correctHexString(string: button.backgroundColor))
            
            //cell.buttonWidth.constant = (button.name as NSString).size(withAttributes: [NSAttributedStringKey.font: UIFont (name: (button?.font)!, size: CGFloat(button.textSize))]).width + 30
            
            cell.button.layer.cornerRadius = CGFloat(button.cornerRadius)
            cell.buttonWidth.constant = CGFloat(button.width)
            cell.buttonHeight.constant = CGFloat(button.height)
            
            cell.button.addTarget(self, action: #selector(self.buttonClicked), for: .touchUpInside)
            
            cell.button.layer.borderWidth = CGFloat(button.borderWidth)
            cell.button.layer.borderColor = UIColor(button.borderColor).cgColor
            
            
            if(!isNullOrEmpty(string: item.backgroundColor ))
            {
                cell.cellBackground.backgroundColor = UIColor(item.backgroundColor)
            }
            else
            {
                cell.cellBackground.backgroundColor = UIColor.clear
            }
            
            cell.selectionStyle = .none
            return cell
        case UserProfileCellType.Title.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "title_cell") as! InformationTitleViewCell
            let title : TitleModel! = item.title
            
            cell.title = title
            cell.viewController = self
            
            if(title != nil)
            {
                var font = UIFont (name: (title.titleFont)!, size: CGFloat((title.titleSize)!))
                cell.titleLabel.text = title.title == nil ? "" : title.title
                cell.titleLabel.font = font
                cell.titleLabel.textColor = UIColor((title.titleColor)!)
                cell.titleLabel.backgroundColor = UIColor((title.titleBackgroundColor)!)
                
                if(title.splitterColor != nil)
                {
                    cell.splitter.backgroundColor = UIColor(title.splitterColor)
                }
                
                if(title.isTitleCentered != nil && !title.isTitleCentered)
                {
                    cell.titleLabel.textAlignment = .left
                }
                else
                {
                    cell.titleLabel.textAlignment = .center
                }
                
                cell.titleHeight.constant = title.title.height(withConstrainedWidth: cell.titleLabel.frame.size.width, font: font!) + 20
                
                /*if((title.isSection != nil && title.isSection) || !isRegistered)
                {
                    cell.titleHeight.constant = title.title.height(withConstrainedWidth: cell.titleLabel.frame.size.width, font: font!) + 20
                }
                else
                {
                    cell.titleHeight.constant = title.title.height(withConstrainedWidth: cell.titleLabel.frame.size.width, font: font!)
                }*/
            }
            
            if(!isNullOrEmpty(string: item.backgroundColor ))
            {
                cell.cellBackground.backgroundColor = UIColor(item.backgroundColor)
            }
            else
            {
                cell.cellBackground.backgroundColor = UIColor.clear
            }
            
            cell.selectionStyle = .none
            return cell
        case UserProfileCellType.RadioButton.rawValue:
            //objc_sync_enter(lock2)
            let cell = tableView.dequeueReusableCell(withIdentifier: "radio_cell") as! RadioButtonViewCell
            let radioButton : RadioButtonModel! = item.radioButton
            //let imageWidth = cell.radioImage.frame.size.width
            
            cell.viewModel = self.viewModel
        
            cell.radioModel = radioButton
            
            cell.awakeFromNib()
            
            if(!isNullOrEmpty(string: radioButton.name) )
            {
                cell.radioLabel.text = radioButton.name
                
                cell.radioLabel.textColor = UIColor(radioButton.nameTextColor)
                cell.radioLabel.font = UIFont (name: (radioButton.nameFont)!, size: CGFloat((radioButton.nameTextSize)!))
            }
            else
            {
                cell.radioImage.image = viewsDB.getImage(url: radioButton.imageUrl)
                //let url = URL(string: percentEncode(s: (radioButton.imageUrl)!))
                //cell.radioImage.kf.setImage(with: url)
            }
         
            
            cell.selectionStyle = .none
            //objc_sync_exit(lock2)
            return cell
        case UserProfileCellType.CheckBox.rawValue:
            var cell = tableView.dequeueReusableCell(withIdentifier: "checkbox_image_cell") as! CheckBoxViewCell
            var checkBoxModel : CheckBoxModel! = item.checkBox
            
            if(!isNullOrEmpty(string: item.checkBox.imageUrl) )
            {
                cell = tableView.dequeueReusableCell(withIdentifier: "checkbox_image_cell") as! CheckBoxViewCell
            }
            else
            {
                cell = tableView.dequeueReusableCell(withIdentifier: "checkbox_label_cell") as! CheckBoxViewCell
            }
            
            cell.checkBoxModel = item.checkBox
            cell.viewController = self
            cell.viewController2 = self
            cell.selectionStyle = .none
            cell.viewModel = self.viewModel
            
            if(!isNullOrEmpty(string: item.backgroundColor ))
            {
                cell.cellBackground.backgroundColor = UIColor(item.backgroundColor)
            }
            else
            {
                cell.cellBackground.backgroundColor = UIColor.clear
            }
            
            let maxWidth = (UIScreen.main.bounds.size.width - 30 - (tableView.separatorInset.left * 2))
            var contentWidth = maxWidth * CGFloat((checkBoxModel?.imageWidthPercentage)!) / CGFloat(100.0)
            
            cell.itemlWidth.constant = contentWidth
            
            if(!isNullOrEmpty(string: checkBoxModel!.imageUrl))
            {
                cell.checkBoxImage.image = checkBoxModel!.image
                
                if(checkBoxModel?.imageWidthPercentage == 0)
                {
                    let imageWidth = CGFloat(1.0 / checkBoxModel!.imageAspectRatio) * cell.checkBoxImage.frame.size.height
                    if( imageWidth <= maxWidth )
                    {
                        cell.itemlWidth.constant =  imageWidth
                        contentWidth = imageWidth
                    }
                    else
                    {
                        cell.itemlWidth.constant = maxWidth
                        contentWidth = maxWidth
                    }
                }
                
                var imageHeight =  CGFloat(checkBoxModel!.imageAspectRatio) * CGFloat(contentWidth)
                if(imageHeight <= 90)
                {
                    cell.imageHeight.constant = imageHeight
                }
                else
                {
                    cell.imageHeight.constant = 90
                }
                //imageHeight.constant = (self.frame.size.width - 30) *  CGFloat(checkBoxModel.imageAspectRatio)
            }
            else
            {
                let font = UIFont(name: checkBoxModel!.textFont, size: CGFloat(checkBoxModel!.textSize))
                cell.label.text = (checkBoxModel?.isRequired != nil && (checkBoxModel?.isRequired)!) ? "\(checkBoxModel!.text ?? "") *" : checkBoxModel!.text
                cell.label.textColor = UIColor(checkBoxModel!.textColor)
                cell.label.font = font
                
                if(checkBoxModel?.imageWidthPercentage == 0)
                {
                    let textWidth = (checkBoxModel!.text as NSString).size(withAttributes: [NSAttributedStringKey.font: font]).width + 5
                    if(textWidth <= maxWidth )
                    {
                        cell.itemlWidth.constant =  textWidth
                        contentWidth = textWidth
                    }
                    else
                    {
                        cell.itemlWidth.constant = maxWidth
                        contentWidth = maxWidth
                    }
                }
                
                //checkBoxImage.image = UIImage()
                //imageHeight.constant = 0
            }
            
            if(!isNullOrEmpty(string: checkBoxModel!.link))
            {
                cell.label.attributedText = NSAttributedString(string: cell.label.text!, attributes: [.underlineStyle: NSUnderlineStyle.styleSingle.rawValue])
            }
            
            if(cell.itemCenter != nil)
            {
                if(checkBoxModel!.alignment == CheckBoxAlignment.Center.rawValue)
                {
                    cell.itemCenter.isActive = true
                }
                else
                {
                    cell.itemCenter.isActive = false
                }
            }
            else if(cell.itemCenterStrong != nil)
            {
                if(checkBoxModel!.alignment == CheckBoxAlignment.Center.rawValue)
                {
                    cell.itemCenterStrong.isActive = true
                }
                else
                {
                    cell.itemCenterStrong.isActive = false
                }
            }
            
            
            cell.itemLeading.priority = .defaultHigh
            cell.itemTrailing.priority = .defaultHigh
            cell.checkBoxLeading1.priority = .defaultHigh
            cell.checkBoxTrailing2.priority = .defaultHigh
            if(cell.label != nil)
            {
                cell.label.textAlignment = .left
            }
            
            if(submitButtonPressed && checkBoxModel.isRequired && !checkBoxModel.isChecked)
            {
                cell.checkBox.icon = UIImage(named: "ic_unchecked")!.imageWithColor(color1 : UIColor("#ff0000"))
                cell.checkBox.iconSelected = UIImage(named: "ic_checked")!.imageWithColor(color1 : UIColor(checkBoxModel.tintColor))
                
                cell.checkBox2.icon = UIImage(named: "ic_unchecked")!.imageWithColor(color1 : UIColor("#ff0000"))
                cell.checkBox2.iconSelected = UIImage(named: "ic_checked")!.imageWithColor(color1 : UIColor(checkBoxModel.tintColor))
            }
            else
            {
                cell.checkBox.icon = UIImage(named: "ic_unchecked")!.imageWithColor(color1 : UIColor(checkBoxModel.tintColor))
                cell.checkBox.iconSelected = UIImage(named: "ic_checked")!.imageWithColor(color1 : UIColor(checkBoxModel.tintColor))
                
                cell.checkBox2.icon = UIImage(named: "ic_unchecked")!.imageWithColor(color1 : UIColor(checkBoxModel.tintColor))
                cell.checkBox2.iconSelected = UIImage(named: "ic_checked")!.imageWithColor(color1 : UIColor(checkBoxModel.tintColor))
            }
            
            
            if(checkBoxModel!.isCheckBoxOnTheLeft)
            {
                cell.checkBoxWidth.constant = 25
                cell.checkBoxWidth2.constant = 0
                cell.itemTrailing.constant = 0
                cell.itemLeading.constant = 5
                
                
                switch checkBoxModel!.alignment {
                case CheckBoxAlignment.Left.rawValue:
                    //if(!isNullOrEmpty(string: checkBoxModel?.imageUrl))
                    //{
                        cell.itemTrailing.priority = .defaultLow
                    //}
                    break
                case CheckBoxAlignment.Center.rawValue:
                    cell.checkBoxLeading1.priority = .defaultLow
                    cell.itemTrailing.priority = .defaultLow
                    
                    if(cell.itemCenter != nil)
                    {
                        cell.itemCenter.isActive = true
                    }
                    
                    if(cell.label != nil)
                    {
                        cell.label.textAlignment = .center
                    }
                    
                    //itemCenter.priority = .defaultHigh
                    //labelWidth.priority = .defaultLow
                    //let xConstraint = NSLayoutConstraint(item: label, attribute: .centerX, relatedBy: .equal, toItem: self, attribute: .centerX, multiplier: 1, constant: 0)
                    //label.addConstraint(xConstraint)
                    break
                case CheckBoxAlignment.Right.rawValue:
                    cell.checkBoxLeading1.priority = .defaultLow
                    break
                default:
                    break
                    //labelCenter = xConstraint
                }
                
                if(!checkBoxModel!.isCheckBoxNearText)
                {
                    cell.itemLeading.priority = .defaultLow
                    cell.itemTrailing.priority = .defaultHigh
                }
                
                if(cell.itemlWidth.constant >= maxWidth)
                {
                    cell.checkBoxLeading1.priority = .defaultHigh
                    cell.itemTrailing.priority = .defaultHigh
                    cell.itemLeading.priority = .defaultHigh
                }
            }
            else
            {
                
                cell.checkBoxWidth.constant = 0
                cell.checkBoxWidth2.constant = 25
                cell.itemTrailing.constant = 5
                cell.itemLeading.constant = 0
                
                switch checkBoxModel!.alignment {
                case CheckBoxAlignment.Left.rawValue:
                    cell.checkBoxTrailing2.priority = .defaultLow
                    break
                case CheckBoxAlignment.Center.rawValue:
                    cell.checkBoxTrailing2.priority = .defaultLow
                    cell.itemLeading.priority = .defaultLow
                    
                    if(cell.itemCenter != nil)
                    {
                        cell.itemCenter.isActive = true
                    }
                    
                    if(cell.label != nil)
                    {
                        cell.label.textAlignment = .center
                    }
                    //itemCenter.priority = .defaultHigh
                    //labelWidth.priority = .defaultLow
                    //let xConstraint = NSLayoutConstraint(item: label, attribute: .centerX, relatedBy: .equal, toItem: self, attribute: .centerX, multiplier: 1, constant: 0)
                    //label.addConstraint(xConstraint)
                    break
                case CheckBoxAlignment.Right.rawValue:
                    cell.itemLeading.priority = .defaultLow
                    break
                default:
                    break
                    //labelCenter = xConstraint
                }
                
                if(!checkBoxModel!.isCheckBoxNearText)
                {
                    cell.checkBoxTrailing2.priority = .defaultHigh
                    cell.itemLeading.priority = .defaultHigh
                    cell.itemTrailing.priority = .defaultLow
                }
                
                if(cell.itemlWidth.constant >= maxWidth)
                {
                    cell.checkBoxTrailing2.priority = .defaultHigh
                    cell.itemTrailing.priority = .defaultHigh
                    cell.itemLeading.priority = .defaultHigh
                }
            }
            
            
            
            cell.layoutIfNeeded()
            return cell
            //let xConstraint = NSLayoutConstraint(item: cell.label, attribute: .centerX, relatedBy: .equal, toItem: cell, attribute: .centerX, multiplier: 1, constant: 0)
            //cell.label.addConstraint(xConstraint)
            
            //cell.labelCenter.isActive = true
            //cell.labelCenter.isActive = false

            
        case UserProfileCellType.AlreadyReceived.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "already_received_cell") as! AlreadyReceivedViewCell
            
            let onClickAlreadyRegistered = UITapGestureRecognizer(target: self, action: #selector(UserProfileViewController2.onClickAlreadyRegistered))
            cell.label.isUserInteractionEnabled = true
            cell.label.addGestureRecognizer(onClickAlreadyRegistered)
            
            cell.label.textColor = UIColor("#1D2D51")
            cell.label.font = UIFont (name: "CharpentierSansPro-Gros", size: CGFloat(15))
            
            cell.selectionStyle = .none
            return cell
        case UserProfileCellType.Switch.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "switch_cell") as! SwitchViewCell
            
            var switchModel : SwitchModel! = item.switchModel
            
            cell.titleLabel.text = switchModel.title
            cell.descriptionLabel.text = switchModel.description
            
            cell.titleLabel.textColor = UIColor(switchModel.fieldStyle.labelTextColor)
            cell.titleLabel.font = UIFont (name: switchModel.fieldStyle.labelFont, size: CGFloat(switchModel.fieldStyle.labelTextSize))
            
            cell.descriptionLabel.textColor = UIColor(switchModel.fieldStyle.textTextColor)
            cell.descriptionLabel.font = UIFont (name: switchModel.fieldStyle.textFont, size: CGFloat(switchModel.fieldStyle.textTextSize))
            
            cell.switchView.onTintColor = UIColor(switchModel.fieldStyle.tintColor)
            
            if(!isUserProfileSynced)
            {
                cell.switchView.addTarget(self, action: #selector(switchClick), for: UIControl.Event.touchUpInside)
            }
            else
            {
                cell.switchView.tag = switchModel.acceptType
                cell.switchView.addTarget(self, action: #selector(switchChanged), for: UIControl.Event.valueChanged)
            }

            if(!isNullOrEmpty(string: item.backgroundColor ))
            {
                cell.cellBackground.backgroundColor = UIColor(item.backgroundColor)
            }
            else
            {
                cell.cellBackground.backgroundColor = UIColor.clear
            }
            
            switch(switchModel.acceptType)
            {
            case SwitchAcceptType.Notifications.rawValue:
                if((apkUserPreferences?.acceptNotifications)!)
                {
                    cell.switchView.isOn = true
                    switchModel.isOn = true
                }
                else
                {
                    cell.switchView.isOn = false
                    switchModel.isOn = false
                }
                break
            case SwitchAcceptType.LocationTracking.rawValue:
                if((apkUserPreferences?.acceptLocation)!)
                {
                    cell.switchView.isOn = true
                    switchModel.isOn = true
                }
                else
                {
                    cell.switchView.isOn = false
                    switchModel.isOn = false
                }
                break
            default:
                break
            }
            
            cell.selectionStyle = .none
            return cell
        default:
            return UITableViewCell()
        }
        
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    @objc func switchClick(mySwitch: UISwitch) {
        if(!isUserProfileSynced)
        {
            mySwitch.setOn(!mySwitch.isOn, animated: false)
            syncUserProfile(showDialog: true)
            return
        }
    }
    
    @objc func switchChanged(mySwitch: UISwitch) {
        /*let value = mySwitch.isOn
        
        switch(mySwitch.tag)
        {
        case SwitchAcceptType.Notifications.rawValue:
            if(value)
            {
                AppDelegate.registerForPushNotifications(application: appApplication)
                
                if #available(iOS 10.0, *) {
                    let current = UNUserNotificationCenter.current()
                    current.getNotificationSettings(completionHandler: { settings in
                        
                        switch settings.authorizationStatus {
                        case .notDetermined:
                            break
                        case .denied:
                            let settingsUrl = URL(string: UIApplicationOpenSettingsURLString)
                            if let url = settingsUrl {
                                UIApplication.shared.openURL(url)
                            }
                        case .authorized:
                            break
                        default:
                            break
                        }
                        
                    })
                } else {
                    // Fallback on earlier versions
                    if UIApplication.shared.isRegisteredForRemoteNotifications {
                        print("APNS-YES")
                    } else {
                        let settingsUrl = URL(string: UIApplicationOpenSettingsURLString)
                        if let url = settingsUrl {
                            UIApplication.shared.openURL(url)
                        }
                    }
                }
         
                apkUserPreferences?.acceptNotifications = true
                
            }
            else
            {
                apkUserPreferences?.acceptNotifications = false
            }
            break
        case SwitchAcceptType.LocationTracking.rawValue:
            if(value)
            {
                apkUserPreferences?.acceptLocation = true
                appDelegate.locationManager.requestAlwaysAuthorization()
                
                if CLLocationManager.locationServicesEnabled() {
                    switch CLLocationManager.authorizationStatus() {
                    case  .denied:
                        let settingsUrl = URL(string: UIApplicationOpenSettingsURLString)
                        if let url = settingsUrl {
                            UIApplication.shared.openURL(url)
                        }
                    default:
                        //appDelegate.locationManager.startUpdatingLocation()
                        appDelegate.locationManager.delegate = appDelegate
                        
                        appDelegate.locationManager.desiredAccuracy = kCLLocationAccuracyBest
                        appDelegate.locationManager.distanceFilter = 1 //0
                        appDelegate.locationManager.allowsBackgroundLocationUpdates = true // 1
                        appDelegate.locationManager.startUpdatingLocation()  // 2
                        
                        break
                    }
                } else {
                    let settingsUrl = URL(string: UIApplicationOpenSettingsURLString)
                    if let url = settingsUrl {
                        UIApplication.shared.openURL(url)
                    }
                }
            }
            else
            {
                apkUserPreferences?.acceptLocation = false
                appDelegate.locationManager.stopUpdatingLocation()
                appDelegate.locationManager.stopMonitoringVisits()
                appDelegate.locationManager.stopMonitoringSignificantLocationChanges()
            }
            break
        default:
            break
        }
        
        parameterizationDatabase.insertAPKUserPreferences(apkUserPreferences: apkUserPreferences!)*/
        
        if(!isUserProfileSynced)
        {
            return
        }
        
        areUnsavedChanges = true
        let value = mySwitch.isOn
        
        switch(mySwitch.tag)
        {
        case SwitchAcceptType.Notifications.rawValue:
            if(value)
            {
                AppDelegate.registerForPushNotifications(application: appApplication)
                apkUserPreferences?.acceptNotifications = true
                
                if #available(iOS 10.0, *) {
                    let current = UNUserNotificationCenter.current()
                    current.getNotificationSettings(completionHandler: { settings in
                        
                        switch settings.authorizationStatus {
                        case .notDetermined:
                            break
                        case .denied:
                            let settingsUrl = URL(string: UIApplicationOpenSettingsURLString)
                            if let url = settingsUrl {
                                DispatchQueue.main.async(execute: {() -> Void in
                                    UIApplication.shared.openURL(url)
                                })
                            }
                        case .authorized:
                            break
                        default:
                            break
                        }
                        
                    })
                } else {
                    // Fallback on earlier versions
                    if UIApplication.shared.isRegisteredForRemoteNotifications {
                        print("APNS-YES")
                    } else {
                        let settingsUrl = URL(string: UIApplicationOpenSettingsURLString)
                        if let url = settingsUrl {
                            DispatchQueue.main.async(execute: {() -> Void in
                                UIApplication.shared.openURL(url)
                            })
                        }
                    }
                }
            }
            else
            {
                apkUserPreferences?.acceptLocation = true
            }
            
            break
        case SwitchAcceptType.LocationTracking.rawValue:
            if(value)
            {
                apkUserPreferences?.acceptLocation = true
                appDelegate.locationManager.requestAlwaysAuthorization()
                
                if CLLocationManager.locationServicesEnabled() {
                    switch CLLocationManager.authorizationStatus() {
                    case  .denied:
                        let settingsUrl = URL(string: UIApplicationOpenSettingsURLString)
                        if let url = settingsUrl {
                            DispatchQueue.main.async(execute: {() -> Void in
                                UIApplication.shared.openURL(url)
                            })
                        }
                    default:
                        break
                    }
                } else {
                    let settingsUrl = URL(string: UIApplicationOpenSettingsURLString)
                    if let url = settingsUrl {
                        DispatchQueue.main.async(execute: {() -> Void in
                            UIApplication.shared.openURL(url)
                        })
                    }
                }
                
                AppDelegate.registerForPushNotifications(application: appApplication)
            }
            else
            {
                apkUserPreferences?.acceptLocation = false
                appDelegate.locationManager.stopUpdatingLocation()
                appDelegate.locationManager.stopMonitoringVisits()
                appDelegate.locationManager.stopMonitoringSignificantLocationChanges()
            }
            break
        default:
            break
        }
        
    }
    
    func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
        if (status == CLAuthorizationStatus.denied) {
            print()
        } else if (status == CLAuthorizationStatus.authorizedAlways) {
            print()
        }
    }
        
    @objc func onClickAlreadyRegistered(_ button: UIButton) {
        DispatchQueue.main.async(execute: {() -> Void in
            let sb = UIStoryboard(name:"DescriptionTextFieldDialog",bundle:nil)
            self.statusTextDialog = sb.instantiateInitialViewController()! as? DescriptionTextFieldDialog
            self.statusTextDialog.dismissWhenClickOutside = false
            self.statusTextDialog.userProfile = self
            self.present(self.statusTextDialog,animated:true)
            self.statusTextDialog.buttonRunnable = self.verifyUser
            self.statusTextDialog.setDialogView(title: NSLocalizedString("registrationStatus", comment: ""), description: NSLocalizedString("enterCode", comment: ""))
            self.isStatusTextDialogDisplayed = true
        })
    }
    
    /// Verifies whether the verification code is valid or not.
    ///
    /// - Parameter verificationCodeTemp: The verification code.
    func verifyUser()
    {
        let field : FieldModel! = vissibleVerificationField
        field.verificationCode = statusTextDialog.inputText
        
        if (!isNullOrEmpty(string: field.verificationCode))
        {
            if (field.verificationCode?.count == 4)
            {
                displayDescriptionDialog(title: NSLocalizedString("registrationStatus", comment: ""), description: NSLocalizedString("yourVerificationCodeIs", comment: "") + " " + field.verificationCode! + ".\n" + NSLocalizedString("pleaseWaitWhileVerifying", comment: ""))
                
                
                if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
                {
                    DispatchQueue.global(qos: .background).async {
                        /*switch button.tag {
                         case UserProfileFieldType.Phoneumber.rawValue:
                         self.verifyPhoneNumber(field : field)
                         case UserProfileFieldType.Email.rawValue:
                         self.verifyEmaiAddress(field : field)
                         default:
                         break
                         }*/
                        
                        self.verifyField(field : field)
                        
                        if(field.isVerified)
                        {
                            /*
                            else if(field.type == UserProfileFieldType.Phoneumber.rawValue && self.viewModel.serverResponse.phoneNumberCount == 1 && self.viewModel.serverResponse.emailAddressCount <= 1)
                            {
                                
                            }
                            else*/
                            if(field.type == UserProfileFieldType.Phoneumber.rawValue && self.viewModel.serverResponse.phoneNumberCount > 1)
                            {
                                self.showCustomerServiceView()
                                return
                            }
                            else if(field.type == UserProfileFieldType.Phoneumber.rawValue && self.viewModel.serverResponse.phoneNumberCount == 1 && self.viewModel.serverResponse.emailAddressCount > 1)
                            {
                                DispatchQueue.main.async(execute: {() -> Void in
                                    self.visibleItems.removeAll()
                                    self.items.removeAll()
                                    self.loadVerificationView()
                                    self.profileTableView.reloadData()
                                    self.profileTableView.beginUpdates()
                                    self.profileTableView.endUpdates()
                                })
                                return
                            }
                            else if(field.type == UserProfileFieldType.Phoneumber.rawValue && self.viewModel.serverResponse.phoneNumberCount == 0)
                            {
                                DispatchQueue.main.async(execute: {() -> Void in
                                    self.visibleItems.removeAll()
                                    self.items.removeAll()
                                    self.loadVerificationView()
                                    self.profileTableView.reloadData()
                                    self.profileTableView.beginUpdates()
                                    self.profileTableView.endUpdates()
                                })
                                return
                            }
                            else if(field.type == UserProfileFieldType.Email.rawValue && self.appUser?.phoneNumberCount == 0 && self.viewModel.serverResponse.emailAddressCount > 1)
                            {
                                self.showCustomerServiceView()
                                return
                            }
                            /*else
                            {
                                let appUser = localDatabase.getAppUser()
                                if((self.viewModel.verificationType == 1 && (appUser?.hasVerifiedPhoneNumber)!) || (self.viewModel.verificationType == 2 && (appUser?.hasVerifiedEmailAddress)!) || (self.viewModel.verificationType == 3 && (appUser?.hasVerifiedPhoneNumber)! && (appUser?.hasVerifiedEmailAddress)!))
                                {
                                    
                                }
                                else
                                {
                                    DispatchQueue.main.async(execute: {() -> Void in
                                        self.visibleItems.removeAll()
                                        self.items.removeAll()
                                        self.loadVerificationView()
                                        self.profileTableView.reloadData()
                                        self.profileTableView.beginUpdates()
                                        self.profileTableView.endUpdates()
                                    })
                                    return
                                }
                            }*/
                        }
                        else
                        {
                            DispatchQueue.main.async(execute: {() -> Void in
                                self.visibleItems.removeAll()
                                self.items.removeAll()
                                self.loadVerificationView()
                                self.profileTableView.reloadData()
                                self.profileTableView.beginUpdates()
                                self.profileTableView.endUpdates()
                            })
                            return
                        }
                        
                        let appUser = localDatabase.getAppUser()
                        if (!(appUser?.isUserRegisteredToAPNS)!)
                        {
                            //AppDelegate.registerForPushNotifications(application: appApplication)
                        }
                        
                        //sleep(2)
                        
                        /*DispatchQueue.main.async(execute: {() -> Void in
                            self.messageDialog.dismissDialog()
                        })
                        
                        while(!MessageDialog.dialogDisappeared)
                        {
                            
                        }*/
                        
                        self.submitButtonPressed = false
                        self.loadUserData()
                    }
                }
                else
                {
                    DispatchQueue.global(qos: .background).async {
                        self.dismissDescriptionDialog()
                        
                        while(!DescriptionDialog.dialogDisappeared)
                        {
                            
                        }
                        
                        sleep(1)
                        
                        DispatchQueue.main.async(execute: {() -> Void in
                            self.displayMessageDialogView(title: NSLocalizedString("noInternetConnection", comment: ""), message: NSLocalizedString("internetConnectionIsRequiredDuringRegistration", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                        })
                    }
                }
            }
            else
            {
                displayMessageDialogView(title: NSLocalizedString("verificationFailedTitle", comment: ""), message: NSLocalizedString("invalidVerificationCode", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
            }
        }
        else
        {
            displayMessageDialogView(title: NSLocalizedString("verificationFailedTitle", comment: ""), message: NSLocalizedString("verificationCodeCannotBeEmpty", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
        }
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    func editField(field : FieldModel) {
        func yesRaised()
        {
            let editFieldStoryBoard: UIStoryboard = UIStoryboard(name: "UserProfileView2", bundle: nil)
            editingFieldView = editFieldStoryBoard.instantiateViewController(withIdentifier: "EdittingFieldViewController") as! EditingFieldViewController
            editingFieldView.isEditingField = true
            editingFieldView.editingField = field
            isEditingField = true
            self.navigationController?.pushViewController(editingFieldView, animated: true)
        }
        
        func noRaised()
        {
        }
        
        
        let sb = UIStoryboard(name:"YesNoMessageDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController() as! YesNoMessageDialog
        DispatchQueue.main.async(execute: {() -> Void in
            self.present(dialog,animated:true)
            dialog.setDialogView(title: "Change email address", message: "In order to change your email address you have to verify the new one. Do you want to proceed with email address change?", yesButtonName: "Yes", noButtonName: "No")
        })
        
        yesAction = yesRaised
        noAction = noRaised
        
        dialog.yesRaised = self
        dialog.noRaised = self
        
    }
    
    func setField(field : FieldModel, fieldStyle : FieldStyleModel , label : UILabel, inputTextField : inout UITextField, requiredLabel : UILabel, dropDownImage : UIImageView, drowDownImageWidth : NSLayoutConstraint, rowIndex : Int )
    {
        /*var found = false
        
        for t in textFields
        {
            if(t.type == field.type)
            {
                found = true
                break
            }
        }
        
        if(!found && !field.isVerified)
        {
            textFields.append(TextFieldModel(textField: inputTextField,type : field.type))
        }*/
        

        
            /*if(field.type == UserProfileFieldType.Email.rawValue)
            {
                inputTextField.isEnabled = true
                inputTextField.textColor = UIColor(fieldStyle.textTextColor)
                let onClick2 = UITapGestureRecognizer(target: self, action: #selector(UserProfileViewController2.editField))
                editFieldLabel.addGestureRecognizer(onClick2)
                editFieldLabel.isUserInteractionEnabled = true
                editFieldLabel.text = "To change your email click here"
            }
            else
            {*/
            
            
            //}
        if(field.isVerified && field.type == UserProfileFieldType.Phoneumber.rawValue)
        {
            inputTextField.isEnabled = false
            inputTextField.textColor = UIColor.lightGray
        }
        else
        {
            inputTextField.isEnabled = true
            label.text = field.labelName
            inputTextField.textColor = UIColor(fieldStyle.textTextColor)
            inputTextField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
            inputTextField.delegate = self
            
        }
        
        if(field.isVerified)
        {
            label.text = field.labelName
        }
        
        label.textColor = UIColor(fieldStyle.labelTextColor)
        label.font = UIFont(name: fieldStyle.labelFont, size: CGFloat( fieldStyle.labelTextSize))
        
        inputTextField.tag = field.type
        inputTextField.font = UIFont(name: fieldStyle.textFont, size: CGFloat( fieldStyle.textTextSize))
        

        //let onClick2 = UITapGestureRecognizer(target: self, action: #selector(UserProfileViewController2.setActiveTextField))
        //inputTextField.addGestureRecognizer(onClick2)
        //inputTextField.isUserInteractionEnabled = true
        //inputTextField.delegate = self as UITextFieldDelegate
        
        
        if(field.isDropDown)
        {
            //let onClick2 = UITapGestureRecognizer(target: self, action: #selector(UserProfileViewController2.showDropDown))
            //inputTextField.addGestureRecognizer(onClick2)
            
            if(!isNullOrEmpty(string: field.value))
            {
                inputTextField.text = field.value
                for i in 0..<field.dropDownItemsModel.count
                {
                    if(field.dropDownItemsModel[i].textStr == field.value)
                    {
                        field.selectedDropDownItem = i
                    }
                }
                
                field.value = inputTextField.text
            }
            else
            {
                if(!isNullOrEmpty(string: field.placeHolder))
                {
                    inputTextField.text = field.placeHolder
                }
                else
                {
                    inputTextField.text = field.dropDownItemsModel[field.selectedDropDownItem].textStr
                    field.value = inputTextField.text
                }
            }
            
            drowDownImageWidth.constant = 15
            dropDownImage.image = UIImage(named: "ic_left_drawer_collapse")?.withRenderingMode(.alwaysTemplate)
            dropDownImage.tintColor = UIColor(fieldStyle.tintColor)
        }
        else
        {
            //inputTextField.removeGestureRecognizer(onClick2)
            //inputTextField.isUserInteractionEnabled = true
            //inputTextField.delegate = self

            //let onClick = UITapGestureRecognizer(target: self, action: #selector(UserProfileViewController2.setActiveTextField))
                
            if(field.type == UserProfileFieldType.Birthday.rawValue)
            {
                
                //onClick.view?.tag = field.type
                //inputTextField.isUserInteractionEnabled = true
                //inputTextField.addGestureRecognizer(onClick)
            }
            else
            {
                //inputTextField.removeGestureRecognizer(onClick)
            }
            
            
            //inputTextField.addTarget(self, action: #selector(UserProfileViewController2.setActiveTextField), for: UIControlEvents.editingDidBegin) //addGestureRecognizer(onClick)
            inputTextField.tag = field.type
            
            
            drowDownImageWidth.constant = 0
            if(field.placeHolder != nil)
            {
                inputTextField.placeholder = field.placeHolder
            }
            else
            {
                inputTextField.placeholder = ""
            }
            
            if(field.value == nil)
            {
                inputTextField.text = ""
            }
            else
            {
                inputTextField.text = field.value
            }
            
            switch field.inputType
            {
            case InputType.Text.rawValue:
                inputTextField.keyboardType = .default
                inputTextField.autocapitalizationType = .sentences
            case InputType.Number.rawValue:
                inputTextField.keyboardType = .numberPad
                //inputTextField.addDoneButtonToKeyboard(myAction:  #selector(inputTextField.resignFirstResponder))
                //inputTextField.addDoneCancelToolbar(onDone: (target: self, action: #selector(doneButtonTappedForMyNumericTextField(_:))))
            case InputType.Phone.rawValue:
                inputTextField.keyboardType = .phonePad
                //inputTextField.addDoneButtonToKeyboard(myAction:  #selector(inputTextField.resignFirstResponder))
                //inputTextField.addDoneCancelToolbar(onDone: (target: self, action: #selector(doneButtonTappedForMyNumericTextField(_:))))
            case InputType.Email.rawValue:
                inputTextField.keyboardType = .emailAddress
            case InputType.Date.rawValue:
                inputTextField.keyboardType = .default
            case InputType.TextOnly.rawValue:
                inputTextField.keyboardType = .default
            default :
                inputTextField.keyboardType = .default
            }
            
            inputTextField.autocorrectionType = .no
        }
        
        
        if(field.isRequirement)
        {
            requiredLabel.text = "*"
            requiredLabel.textColor = UIColor(fieldStyle.asteriskColor)
        }
        else
        {
            requiredLabel.text = ""
        }
        
        if(fieldStyle.borderStyle == BorderStyle.Full.rawValue)
        {
            inputTextField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 5, height: inputTextField.frame.height))
            inputTextField.leftViewMode = .always
        }
        else
        {
            inputTextField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: inputTextField.frame.height))
            inputTextField.leftViewMode = .always
        }
        
        setFieldBorder(field: field, textField: inputTextField)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        for i in visibleItems
        {
            if(i.fields != nil)
            {
                for f in i.fields
                {
                    if(f.type == textField.tag)
                    {
                        switch f.inputType
                        {
                        case InputType.Text.rawValue:
                            return true
                        case InputType.Number.rawValue:
                            return string.rangeOfCharacter(from: CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")) == nil
                        case InputType.Phone.rawValue:
                            return string.rangeOfCharacter(from: CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")) == nil
                        case InputType.Email.rawValue:
                            return true
                        case InputType.Date.rawValue:
                            return true
                        case InputType.TextOnly.rawValue:
                            return string.rangeOfCharacter(from: CharacterSet(charactersIn: "0123456789")) == nil
                        default :
                            return true
                        }
                    }
                }
            }
        }
        
        return true
    }
    /*@objc func doneButtonTappedForMyNumericTextField(_ textField: UITextField) {
        var index = 0
        for t in textFields
        {
            if(t.type == textField.tag)
            {
                break
            }
            
            index += 1
        }
        
        index += 1
        //textField.resignFirstResponder()
        
        if(index > 0 && index < textFields.count)
        {
            textFields[index].textField.becomeFirstResponder()
        }
    }*/
    
    
    func dismissed() {
        if(localDatabase.isAPKBlocked(bussinessID: clientID))
        {
            var tabFound = false
            for t in leftDrawer.leftDrawerTabsList
            {
                if(t.tabType == TabType.HelpAndSupport.rawValue)
                {
                    leftDrawer.selectTab(tabString: t.name)
                    self.showView(tab: t, index: 0)
                    tabFound = true
                    break
                }
            }
            
            if(!tabFound)
            {
                leftDrawer.viewDidLoad()
                leftDrawer.selectTab(tabString: selectedTab.name)
                self.showView(tab: selectedTab, index: 0)
            }
        }
        else
        {
            var index = 0
            for i in visibleItems
            {
                if(i.fields != nil)
                {
                    var fieldIndex = 0
                    for f in i.fields
                    {
                        if(f.type == selectedDropdownType && profileTableView != nil)
                        {
                            if(isNullOrEmpty(string: f.value))
                            {
                                numberOfMissingData -= 1
                                setMissingData()
                            }
                            
                            if(f.value != f.dropDownItemsModel[typesDialog.selectedTypeInt].textStr)
                            {
                                areUnsavedChanges = true
                            }
                            
                            f.selectedDropDownItem = typesDialog.selectedTypeInt
                            f.value =  f.dropDownItemsModel[typesDialog.selectedTypeInt].textStr
                            
                            
                            
                            if(!isNullOrEmpty(string: f.value))
                            {
                                f.isValueEmpty = false
                            }
                            
                            let indexPath = IndexPath(item: index, section: 0)
                            if(i.fields.count == 1)
                            {
                                let cell = profileTableView.cellForRow(at: indexPath) as? SingleViewCell
                                
                                if(cell != nil)
                                {
                                    cell!.inputTextField.text = f.value
                                    setFieldBorder(field: f, textField: cell!.inputTextField)
                                }
                            }
                            else
                            {
                                let cell = profileTableView.cellForRow(at: indexPath) as? DoubleViewCell
                                
                                if(cell != nil)
                                {
                                    if(fieldIndex == 0)
                                    {
                                        cell!.firstInputTextField.text = f.value
                                        setFieldBorder(field: f, textField: cell!.firstInputTextField)
                                    }
                                    else
                                    {
                                        cell!.secondInputTextField.text = f.value
                                        setFieldBorder(field: f, textField: cell!.secondInputTextField)
                                    }
                                }
                            }
                            
                            
                            //profileTableView.reloadRows(at: [indexPath], with: .none)
                            //profileTableView.reloadData()
                            return
                        }
                        fieldIndex += 1
                    }
                }
                index += 1
            }
        }
        
    }
    
    func displayDescriptionDialog(title: String, description: String ){
        if(isStatusTextDialogDisplayed)
        {
            let sb = UIStoryboard(name:"DescriptionDialog",bundle:nil)
            let dialog = sb.instantiateInitialViewController()!
            let dialogViewController = dialog as! DescriptionDialog
            descriptionDialog = dialogViewController
            descriptionDialog.dismissWhenClickOutside = false
            statusTextDialog.present(dialog,animated:true)
            dialogViewController.setDialogView(title: title, description: description)
        }
        else
        {
            let sb = UIStoryboard(name:"DescriptionDialog",bundle:nil)
            let dialog = sb.instantiateInitialViewController()!
            let dialogViewController = dialog as! DescriptionDialog
            descriptionDialog = dialogViewController
            descriptionDialog.dismissWhenClickOutside = false
            self.present(dialog,animated:true)
            dialogViewController.setDialogView(title: title, description: description)
        }
    }
    
    @objc private func buttonClicked() {
        
        if(!isUserProfileSynced)
        {
            syncUserProfile(showDialog: true)
            return
        }
        
        if(!NetworkHelper.isReachable() || !NetworkHelper.isNetworkAvailable())
        {
            self.displayMessageDialogView(title: NSLocalizedString("noInternetConnection", comment: ""), message: NSLocalizedString("internetRequired", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
            return
        }
        
        var foundEmptyField = false
        var notAcceptedTerms = false
        var areAllFieldsVerified = true
        var areAllFieldsValid = true
        var checkBoxValidationTitle : String!
        var checkBoxValidationMessage : String!
        var isOverEighteen = true
        submitButtonPressed = true
        
        for i in items
        {
            if(i.type == UserProfileCellType.Field.rawValue)
            {
                for f in i.fields
                {
                    if(!isNullOrEmpty(string: f.value))
                    {
                        f.value = f.value.trimmingCharacters(in: .whitespacesAndNewlines)
                    }
                        
                    if(isNullOrEmpty(string: f.value) && f.isRequirement)
                    {
                        f.isValueEmpty = true
                        foundEmptyField = true
                    }
                    else
                    {
                        f.isValueEmpty = false
                        
                        if(f.type == UserProfileFieldType.Birthday.rawValue)
                        {
                            if(!isNullOrEmpty(string: f.value))
                            {
                                let ageComponents = f.value.components(separatedBy: "/")
                                
                                if(ageComponents.count > 2)
                                {
                                    let dateDOB = Calendar.current.date(from: DateComponents(year:
                                        Int(ageComponents[2]), month: Int(ageComponents[1]), day:
                                        Int(ageComponents[0])))!

                                    print(dateDOB.age)
                                    if(dateDOB.age < 18)
                                    {
                                        isOverEighteen = false
                                    }
                                }
                                else
                                {
                                    for j in items
                                    {
                                        if(j.type == UserProfileCellType.CheckBox.rawValue)
                                        {
                                            if(j.checkBox.connectionID != nil && j.checkBox.connectionID == 6 && !j.checkBox.isChecked)
                                            {
                                                isOverEighteen = false
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                for j in items
                                {
                                    if(j.type == UserProfileCellType.CheckBox.rawValue)
                                    {
                                        if(j.checkBox.connectionID != nil && j.checkBox.connectionID == 6 && !j.checkBox.isChecked)
                                        {
                                            isOverEighteen = false
                                        }
                                    }
                                }
                            }
                        }
                        
                    }
                    
                    if(!f.isVerified)
                    {
                        areAllFieldsVerified = false
                    }
                    
                    //if(f.type == UserProfileFieldType.Email.rawValue)
                    //{
                        if(!f.isValid)
                        {
                            areAllFieldsValid = false
                        }
                    //}
                }
            }
            else if(i.type == UserProfileCellType.CheckBox.rawValue)
            {
                if(i.checkBox.isRequired && !i.checkBox.isChecked)
                {
                    notAcceptedTerms = true
                }
                
                for group in checkBoxGroups
                {
                    var isCheckedAtLeastOne = false
                    for item in group.checkBoxItemsList
                    {
                        if(!isCheckedAtLeastOne)
                        {
                            if(item == i.id1 && i.checkBox.isChecked)
                            {
                                for r in group.checkBoxRelationsList
                                {
                                    for g in checkBoxGroups
                                    {
                                        if(g.groupID == r.groupID)
                                        {
                                            for i in g.checkBoxItemsList
                                            {
                                                for c in checkBoxes
                                                {
                                                    if(c.id == i && c.isChecked)
                                                    {
                                                        isCheckedAtLeastOne = true
                                                        break
                                                    }
                                                }
                                            }
                                            
                                            if(!isCheckedAtLeastOne)
                                            {
                                                checkBoxValidationTitle = r.validationFailedHeader
                                                checkBoxValidationMessage = r.validationFailedMessage
                                            }
                                        }
                                    }
                                }
                                
                            }
                        }
                    }
                }
            }
        }
        
        if(foundEmptyField)
        {
            self.profileTableView.reloadData()
            displayDescriptionDialog(title: "Missing Information", description:"Please enter all information required")
        }
        else if(!areAllFieldsValid)
        {
            //self.displayMessageDialogView(title: NSLocalizedString("invalidInformation", comment: ""), message: NSLocalizedString("pleaseEnterValidEmailAddress", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
            self.displayMessageDialogView(title: NSLocalizedString("invalidInformation", comment: ""), message: NSLocalizedString("pleaseEnterValidInformation", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
        }
        else if (notAcceptedTerms)
        {
            self.profileTableView.reloadData()
            displayDescriptionDialog(title: "Unchecked checkboxes", description:"Please check all required checkboxes")
        }
        else if(!isNullOrEmpty(string: checkBoxValidationMessage))
        {
            displayDescriptionDialog(title: checkBoxValidationTitle, description: checkBoxValidationMessage)
        }
        else if(!isOverEighteen)
        {
             displayDescriptionDialog(title: "Age validation", description: "You have to be over 18 years old")
        }
        else
        {
            if(isRegistered)
            {
                let sb = UIStoryboard(name:"DescriptionDialog",bundle:nil)
                let dialog = sb.instantiateInitialViewController()!
                let dialogViewController = dialog as! DescriptionDialog
                self.descriptionDialog = dialogViewController
                self.descriptionDialog.dismissWhenClickOutside = false
                dialogViewController.setDialogView(title: "Please wait", description: "Please wait while we are submitting your request.")
                self.present(dialog,animated:true,completion: nil)
                
                DispatchQueue.global(qos: .background).async {
                    
                    if(NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
                    {
                        var updatedAppUser : AppUser! = localDatabase.getAppUser()
                        
                        updatedAppUser.isAdult = isOverEighteen
                        
                        for i in self.items
                        {
                            if(i.fields != nil)
                            {
                                for f in i.fields
                                {
                                    for v in self.verificationFields
                                    {
                                        if(v.type == f.type)
                                        {
                                            f.isVerified = true
                                        }
                                    }
                                    
                                    switch f.type
                                    {
                                    case  UserProfileFieldType.Phoneumber.rawValue :
                                        updatedAppUser.phoneNumber = f.value
                                    case  UserProfileFieldType.Email.rawValue :
                                        updatedAppUser.emailAddress = f.value
                                    case  UserProfileFieldType.Title.rawValue :
                                        updatedAppUser.title = f.value
                                        updatedAppUser.titleID = f.selectedDropDownItem + 1
                                        updatedAppUser.gender =  isTitleMale(titleID: updatedAppUser.titleID) ? UserGender.Male.rawValue : UserGender.Female.rawValue   //f.value == "Mr." || f.value == "Mrs." ? 0 : 1
                                    case  UserProfileFieldType.Name.rawValue :
                                        updatedAppUser.name = f.value
                                    case  UserProfileFieldType.Surname.rawValue :
                                        updatedAppUser.surname = f.value
                                    case  UserProfileFieldType.Gender.rawValue :
                                        updatedAppUser.gender = f.selectedDropDownItem == 0 ? UserGender.Female.rawValue : UserGender.Male.rawValue
                                        
                                        if(updatedAppUser.titleID == nil)
                                        {
                                            if(updatedAppUser.gender == UserGender.Male.rawValue)
                                            {
                                                updatedAppUser.titleID = UserTitle.Mr.rawValue
                                            }
                                            else
                                            {
                                                updatedAppUser.titleID = UserTitle.Ms.rawValue
                                            }
                                        }
                                        else
                                        {
                                            if(updatedAppUser.gender == UserGender.Male.rawValue)
                                            {
                                                updatedAppUser.titleID = UserTitle.Mr.rawValue
                                            }
                                            else
                                            {
                                                if(!isTitleFemale(titleID: updatedAppUser.titleID))
                                                {
                                                    updatedAppUser.titleID = UserTitle.Ms.rawValue
                                                }
                                            }
                                        }
                                    case  UserProfileFieldType.Birthday.rawValue :
                                        updatedAppUser.birthDate = f.value
                                    case  UserProfileFieldType.Address1.rawValue :
                                        updatedAppUser.homeAddress = f.value
                                    case  UserProfileFieldType.Address2.rawValue :
                                        updatedAppUser.homeAddress2 = f.value
                                    case  UserProfileFieldType.HouseNo.rawValue :
                                        updatedAppUser.houseNo = f.value
                                    case  UserProfileFieldType.City.rawValue :
                                        updatedAppUser.city = f.value
                                    case  UserProfileFieldType.PostCode.rawValue :
                                        updatedAppUser.postCode = f.value
                                    case  UserProfileFieldType.District.rawValue :
                                        updatedAppUser.province = f.value
                                    case  UserProfileFieldType.Country.rawValue :
                                        updatedAppUser.country = f.value
                                    case  UserProfileFieldType.CommunicationLanguage.rawValue :
                                        updatedAppUser.communicationLanguage = f.value
                                        updatedAppUser.languageID = f.selectedDropDownItem + 1//Int(f.dropDownItemsModel[f.selectedDropDownItem].id)
                                    case  UserProfileFieldType.ReferredName.rawValue :
                                        updatedAppUser.referedName = f.value
                                    case  UserProfileFieldType.FlatHouseName.rawValue :
                                        updatedAppUser.flatHouseName = f.value
                                    default :
                                        break
                                    }
                                }
                            }
                            else if(i.type == UserProfileCellType.Switch.rawValue)
                            {
                                switch(i.switchModel.acceptType)
                                {
                                case SwitchAcceptType.Notifications.rawValue:
                                    break
                                case SwitchAcceptType.LocationTracking.rawValue:
                                    setLocationService()
                                    break
                                default:
                                    break
                                }
                            }
                            else if(i.type == UserProfileCellType.CheckBox.rawValue)
                            {
                                if(i.checkBox.connectionID != nil)
                                {
                                    switch(i.checkBox.connectionID)
                                    {
                                    case CheckBoxConnectionID.IsAdult.rawValue:
                                        if(i.checkBox.isChecked)
                                        {
                                            updatedAppUser.isAdult = true
                                        }
                                        else
                                        {
                                            updatedAppUser.isAdult = false
                                        }
                                    case CheckBoxConnectionID.ReceiveSms.rawValue:
                                        if(i.checkBox.isChecked)
                                        {
                                            updatedAppUser.shouldReceiveSms = true
                                        }
                                        else
                                        {
                                            updatedAppUser.shouldReceiveSms = false
                                        }
                                    case CheckBoxConnectionID.ReceiveEmail.rawValue:
                                        if(i.checkBox.isChecked)
                                        {
                                            updatedAppUser.shouldReceiveEmail = true
                                        }
                                        else
                                        {
                                            updatedAppUser.shouldReceiveEmail = false
                                        }
                                    case CheckBoxConnectionID.ReceiveCardSMS.rawValue:
                                        if(i.checkBox.isChecked)
                                        {
                                            updatedAppUser.shouldReceiveLoyaltyCardNumberBySMS = true
                                        }
                                        else
                                        {
                                            updatedAppUser.shouldReceiveLoyaltyCardNumberBySMS = false
                                        }
                                    default:
                                        break
                                    }
                                }
                            }
                        }
                        
                        parameterizationDatabase.insertAPKUserPreferences(apkUserPreferences: apkUserPreferences!)
                        viewsDB.setCheckBoxesCheckedFlag(checkBoxes: self.checkBoxes)
                        
                        var updateUserProfileOutputData : UpdateUserProfileOutputData!
                        
                        do
                        {
                            updateUserProfileOutputData = try UserProfileWebApi.updateUserProfile2(userProfile: updatedAppUser, acceptNews: self.viewModel.acceptNews, udpateAcceptNews: self.viewModel.areAcceptNewsChanged, isNewRegistration : !localDatabase.isAPKRegistered(bussinessID: clientID))
                        }
                        catch
                        {
                           
                        }
                        
                        DispatchQueue.main.async(execute: {() -> Void in
                            self.dismissDescriptionDialog()
                        })
                        
                        while(!DescriptionDialog.dialogDisappeared)
                        {
                            
                        }
                        
                        if(updateUserProfileOutputData == nil)
                        {
                            DispatchQueue.main.async(execute: {() -> Void in
                                self.displayMessageDialogView(title: "Error occurred", message: "Something went wrong. Please try again later.", closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                            })
                        }
                        else if(!updateUserProfileOutputData.isOperationSuccessful)
                        {
                            DispatchQueue.main.async(execute: {() -> Void in
                                self.displayMessageDialogView(title: updateUserProfileOutputData.reponseHeader, message: updateUserProfileOutputData.responseBody, closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                            })
                        }
                        else
                        {
                            self.areUnsavedChanges = false
                            updatedAppUser.isLoyaltyUser = true
                            
                            if(!localDatabase.isAPKRegistered(bussinessID: clientID))
                            {
                                localDatabase.insertRegisteredAPK(bussinessID: clientID)
                                
                                self.hideItemsOnUpdate()
                                //setUserProfileView()
                                
                                DispatchQueue.main.async(execute: {() -> Void in
                                    self.profileTableView.reloadData()
                                    
                                    func yesRaised()
                                    {
                                        for t in leftDrawer.leftDrawerTabsList
                                        {
                                            if(t.type == LeftDrawerTabsType.PromotionNotifications.rawValue)
                                            {
                                                leftDrawer.selectTab(tabString: t.name)
                                                self.showView(tab: t, index: 0)
                                                break
                                            }
                                        }
                                    }
                                    
                                    func noRaised()
                                    {
                                    }
                                    
                                    
                                    if(updateUserProfileOutputData.hasActiveCoupon)
                                    {
                                        let sb = UIStoryboard(name:"YesNoMessageDialog",bundle:nil)
                                        let dialog = sb.instantiateInitialViewController() as! YesNoMessageDialog
                                        DispatchQueue.main.async(execute: {() -> Void in
                                            self.present(dialog,animated:true)
                                            dialog.setDialogView(title: updateUserProfileOutputData.reponseHeader, message: updateUserProfileOutputData.responseBody, yesButtonName: "View now", noButtonName: "View later")
                                            //self.displayMessageDialogView(title: updateUserProfileOutputData.reponseHeader, message: updateUserProfileOutputData.responseBody, closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                                        })
                                        
                                        yesAction = yesRaised
                                        noAction = noRaised
                                        
                                        dialog.yesRaised = self
                                        dialog.noRaised = self
                                    }
                                    else
                                    {
                                        DispatchQueue.main.async(execute: {() -> Void in
                                            self.displayMessageDialogView(title: updateUserProfileOutputData.reponseHeader, message: updateUserProfileOutputData.responseBody, closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                                        })
                                    }
                                    
                                    DispatchQueue.global(qos: .background).async {
                                        let appUser = localDatabase.getAppUser()
                                        
                                        if(appUser != nil && appUser?.phoneNumber != nil)
                                        {
                                            let phoneNumber = appUser?.phoneNumber
                                            var notificationsCountersInfo = NotificationsWebApi.getNotificationsCountersInfo(userPhone: phoneNumber)
                                            
                                            if(notificationsCountersInfo != nil)
                                            {
                                                numberOfGeneralNotifications = notificationsCountersInfo!.unseenCampaigns
                                                numberOfPromotionNotifications = notificationsCountersInfo!.unseenCoupons
                                                numberOfNotifications = notificationsCountersInfo!.allUnseen
                                            }
                                            
                                            DispatchQueue.main.async(execute: {() -> Void in
                                                if(APK == Bundle.main.bundleIdentifier! || APK == APKsEnum.Test.rawValue)
                                                {
                                                    UIApplication.shared.applicationIconBadgeNumber = numberOfNotifications
                                                }
                                                
                                                leftDrawer.tableView.reloadData()
                                                leftDrawer.selectTab(tabString: leftDrawer.currentTab)
                                                
                                                if(localDatabase.isAPKRegistered(bussinessID: clientID))
                                                {
                                                    let notifications = UIBarButtonItem(badge: "\(numberOfNotifications)", title: "", target: self, action: #selector(ViewController.onNotificationsClick))
                                                    notifications.badgedButton?.setImage(UIImage(named: "ic_left_drawer_notifications"), for: .normal)
                                                    currentViewController2.navigationItem.rightBarButtonItem = notifications
                                                }
                                            })
                                            
                                            APKChanger.getPointsStatementAndBalance()
                                            
                                            let pointsBalance = UserProfileWebApi.getUserPointsBalance(clientID: clientID, phoneNumber: localDatabase.getAppUser()?.phoneNumber)
                                            loyaltyDB.insertPoitsBalance(pointsBalance: pointsBalance)
                                          
                                            do
                                            {
                                                try APKChanger.getProximityOffers()
                                            }catch
                                            {}
                                                
                                        }
                                    }
                                })
                            }
                            else
                            {
                                DispatchQueue.main.async(execute: {() -> Void in
                                    self.displayMessageDialogView(title: updateUserProfileOutputData.reponseHeader, message: updateUserProfileOutputData.responseBody, closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                                })
                            }
                            
                            localDatabase.updateAppUser(appUser: updatedAppUser)
                            localDatabase.updateAcceptNews(bussinessID: clientID, acceptNews: self.viewModel.acceptNews)
                            
                            self.appUser = updatedAppUser
                        }
                    }
                    else
                    {
                        let toast = CustomToast()
                        toast.setToast(viewController: self, message: NSLocalizedString("internetIsRequired", comment: ""))
                        toast.show()
                    }
                    
                }
            }
            else
            {
                if(areAllFieldsVerified)
                {
                    if(!localDatabase.isAPKAccepted(bussinessID: clientID))
                    {
                        localDatabase.insertAcceptedAPK(bussinessID: clientID)
                    }
                    
                    DispatchQueue.global(qos: .background).async {
                        self.loadUserData()
                    }
                }
                else
                {
                    checkSubmitedInfo()
                    
                    if(areSubmittedInfoCorrect)
                    {
                        if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
                        {
                            self.displayConfirmDialog()
                        }
                        else
                        {
                            self.displayMessageDialogView(title: NSLocalizedString("noInternetConnection", comment: ""), message: NSLocalizedString("internetConnectionIsRequiredDuringRegistration", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                        }
                    }
                }
            }
        }
    }
    
    func checkSubmitedInfo(showDialogs : Bool = true)
    {
        areSubmittedInfoCorrect = true
        //var message : String = ""
        
        
        if(vissibleVerificationField != nil && !vissibleVerificationField.isVerified)
        {
            if(isNullOrEmpty(string: vissibleVerificationField.value))
            {
                areSubmittedInfoCorrect = false
                if(!showDialogs)
                {
                    return
                }
            }
            
            switch vissibleVerificationField.type
            {
            case UserProfileFieldType.Phoneumber.rawValue:
                if(vissibleVerificationField.value.isNumeric)
                {
                    if(vissibleVerificationField.value?.count == 8)
                    {
                        if(!(vissibleVerificationField.value?.starts(with: "9"))!)
                        {
                            areSubmittedInfoCorrect = false
                            
                            self.displayMessageDialogView(title: NSLocalizedString("invalidInformation", comment: ""), message: NSLocalizedString("telephoneFormatNotValidCY", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                            //message = message + NSLocalizedString("telephoneFormatNotValidCY", comment: "") + ". "
                            
                            return
                        }
                    }
                    else
                    {
                        areSubmittedInfoCorrect = false
                        
                        
                        self.displayMessageDialogView(title: NSLocalizedString("invalidInformation", comment: ""), message: NSLocalizedString("telephoneLengthNotValidCY", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                        //message = message + NSLocalizedString("telephoneLengthNotValidCY", comment: "") + ". "
                        
                        return
                    }
                }
                else
                {
                    areSubmittedInfoCorrect = false
                    self.displayMessageDialogView(title: NSLocalizedString("invalidInformation", comment: ""), message: NSLocalizedString("telephoneFormatNotValidCY", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                    //message = message + NSLocalizedString("telephoneFormatNotValidCY", comment: "") + ". "
                    
                    return
                }
                
            case UserProfileFieldType.Email.rawValue:
                if(!isEmailAddressValid(address: vissibleVerificationField.value))
                {
                    areSubmittedInfoCorrect = false
                    
                    self.displayMessageDialogView(title: NSLocalizedString("invalidInformation", comment: ""), message: NSLocalizedString("pleaseEnterValidEmailAddress", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                    //showDialog(title: "Invalid email", description: NSLocalizedString("pleaseEnterValidEmailAddress", comment: ""))
                    //message = message + NSLocalizedString("pleaseEnterValidEmailAddress", comment: "") + ". "
                    return
                }
            default:
                break
            }
        }
        
        
        
        /*if(!areSubmittedInfoCorrect)
         {
         self.displayMessageDialogView(title: "Invalid inforamtion", message: message, closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
         }*/
    }
    
    /// Displays a message to the user using our message dialog view design.
    ///
    /// - Parameters:
    ///   - title: The dialog's title.
    ///   - message: The message to be displayed.
    ///   - closeDialogButtonText: The close dialog button text.
    func displayMessageDialogView(title : String,message : String, closeDialogButtonText : String,dismissWhenClickOutside : Bool = true )
    {
        DispatchQueue.main.async(execute: {() -> Void in
            if(!DescriptionTextFieldDialog.dialogDisappeared)
            {
                let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
                let dialog = sb.instantiateInitialViewController()! as! MessageDialog
                self.messageDialog = dialog
                self.statusTextDialog.present(dialog,animated:true)
                dialog.setDialogView(title: title, description:message, buttonName: closeDialogButtonText, dismissWhenClickOutside: true)
            }
            else
            {
                let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
                let dialog = sb.instantiateInitialViewController()! as! MessageDialog
                self.messageDialog = dialog
                self.present(dialog,animated:true)
                dialog.setDialogView(title: title, description:message, buttonName: closeDialogButtonText, dismissWhenClickOutside: dismissWhenClickOutside)
            }
        })
    }
    
    func dismissDescriptionDialog()
    {
        DispatchQueue.main.async(execute: {() -> Void in
            self.descriptionDialog.dismissDialog()
        })
    }
    
    func dismissStatusTextDialogView()
    {
        DispatchQueue.main.async(execute: {() -> Void in
            do
            {
                self.isStatusTextDialogDisplayed = false
                self.statusTextDialog.dismissDialog()
            }
            catch
            {
                
            }
        })
    }
    
    /// Displays a dialog that asks user to confirm his/her telephone number.
    ///
    /// - Parameter telephoneNumber: The user's telephone number.
    func displayConfirmDialog()
    {
        var nonVerifiedFields = 0
        for f in verificationFields
        {
            if (!f.isVerified)
            {
                nonVerifiedFields += 1
            }
        }
    
        func yesRaised()
        {
            if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
            {
                if(vissibleVerificationField.value == "99367677")
                {
                    //showDialog(title: NSLocalizedString("registrationStatus", comment: ""), description: NSLocalizedString("submittingDetailsPleaseWait", comment: ""))
                    
                    var appUser = localDatabase.getAppUser()
                    
                    if(appUser == nil)
                    {
                        appUser = AppUser()
                        localDatabase.addAppUser(appUser: appUser!)
                    }
                    
                    appUser?.phoneNumber = vissibleVerificationField.value
                    appUser?.emailAddress = "soteris.93@gmail.com"
                    appUser?.hasVerifiedEmailAddress = true
                    appUser?.isPending = false
                    appUser?.hasVerifiedPhoneNumber = true
                    localDatabase.updateAppUser(appUser: appUser!)//addAPKAppUser(clientID : clientID , appUser : appUser!) //updateAppUser(appUser: appUser!)
                    
                    localDatabase.insertAcceptedAPK(bussinessID: clientID)
                    localDatabase.insertVerifiedAPK(bussinessID: clientID, isBlocked: false)
                    localDatabase.insertRegisteredAPK(bussinessID: clientID)
                    
                    localDatabase.insertVerifiedAPK(bussinessID: ClientIDs.RichReach.rawValue , isBlocked: false)
                    localDatabase.insertRegisteredAPK(bussinessID: ClientIDs.RichReach.rawValue)
                    
                    DispatchQueue.global(qos: .background).async {
                        self.viewModel.loadUserOptins()
                        self.viewModel.loadUserProfileInformation()
                        self.viewModel.loadUserDefaultOptions()
                        
                        APKChanger.getPointsStatementAndBalance()
                        
                        let pointsBalance = UserProfileWebApi.getUserPointsBalance(clientID: clientID, phoneNumber: localDatabase.getAppUser()?.phoneNumber)
                        loyaltyDB.insertPoitsBalance(pointsBalance: pointsBalance)
                    }
                    
                    
                    let acceptNews = AcceptNewsModel()
                    
                    acceptNews.acceptNews1 = 1
                    acceptNews.acceptNews2 = 1
                    /*acceptNews.acceptNews3 = userInformations.acceptNews3
                    acceptNews.acceptNews4 = userInformations.acceptNews4
                    acceptNews.acceptNews5 = userInformations.acceptNews5
                    acceptNews.acceptNews6 = userInformations.acceptNews6
                    acceptNews.acceptNews7 = userInformations.acceptNews7
                    acceptNews.acceptNews8 = userInformations.acceptNews8*/
                    
                    localDatabase.insertAcceptNews(bussinessID: clientID, acceptedNews: acceptNews)
                    viewModel.acceptNews = acceptNews
                    
                    self.isRegistered = true
                    self.visibleItems = userProfileDB.getUserProfileView()
                    appUser = localDatabase.getAppUser()
                    
                    apkUserPreferences = parameterizationDatabase.getAPKUserPreferences(apk: APK)
                    
                    if(apkUserPreferences == nil)
                    {
                        apkUserPreferences = APKUserPreferences()
                    }
                    
                    for i in self.visibleItems
                    {
                        if(i.fields != nil)
                        {
                            for f in i.fields
                            {
                                for v in verificationFields
                                {
                                    if(v.type == f.type)
                                    {
                                        f.isVerified = true
                                    }
                                }
                                
                                switch f.type
                                {
                                case  UserProfileFieldType.Phoneumber.rawValue :
                                    f.value = appUser?.phoneNumber
                                case  UserProfileFieldType.Email.rawValue :
                                    f.value = appUser?.emailAddress
                                case  UserProfileFieldType.Title.rawValue :
                                    //f.value = appUser?.
                                    break
                                case  UserProfileFieldType.Name.rawValue :
                                    f.value = appUser?.name
                                case  UserProfileFieldType.Surname.rawValue :
                                    f.value = appUser?.surname
                                case  UserProfileFieldType.Gender.rawValue :
                                    f.value = appUser?.gender == 0 ? "Male" : "Female"
                                case  UserProfileFieldType.Birthday.rawValue :
                                    f.value = appUser?.birthDate
                                case  UserProfileFieldType.Address1.rawValue :
                                    f.value = appUser?.homeAddress
                                case  UserProfileFieldType.Address2.rawValue :
                                    f.value = appUser?.homeAddress2
                                case  UserProfileFieldType.HouseNo.rawValue :
                                    f.value = appUser?.houseNo
                                case  UserProfileFieldType.City.rawValue :
                                    f.value = appUser?.city
                                case  UserProfileFieldType.PostCode.rawValue :
                                    f.value = appUser?.postCode
                                case  UserProfileFieldType.District.rawValue :
                                    f.value = appUser?.province
                                case  UserProfileFieldType.Country.rawValue :
                                    f.value = appUser?.country
                                case  UserProfileFieldType.CommunicationLanguage.rawValue :
                                    f.value = appUser?.communicationLanguage
                                case  UserProfileFieldType.ReferredName.rawValue :
                                    f.value = appUser?.referedName
                                case  UserProfileFieldType.FlatHouseName.rawValue :
                                    f.value = appUser?.flatHouseName
                                default :
                                    break
                                }
                            }
                        }
                    }
                    
                    self.profileTableView.reloadData()
                    /*DispatchQueue.main.async(execute: {() -> Void in
                        self.viewDidLoad()
                        self.viewWillAppear(true)
                        self.viewDidAppear(true)
                    })*/
                }
                else
                {
                    displayDescriptionDialog(title: NSLocalizedString("registrationStatus", comment: ""), description: NSLocalizedString("submittingDetailsPleaseWait", comment: ""))
                    
                    //var verificationFields : [FieldModel]
                    viewModel.fields = verificationFields
                    viewModel.vissibleField = vissibleVerificationField
                    
                    if(vissibleVerificationField.type == UserProfileFieldType.Phoneumber.rawValue && localDatabase.isPhoneNumberVerified(phoneNumber: vissibleVerificationField.value))
                    {
                        DispatchQueue.global(qos: .background).async {
                            //self.viewModel.registerUser()
                            var appUserTemp = localDatabase.getAppUser()
                            
                            self.viewModel.quickRegistration(appUser : appUserTemp!)
                            
                            localDatabase.insertAcceptedAPK(bussinessID: clientID)
                            
                            if(appUserTemp == nil)
                            {
                                appUserTemp = AppUser()
                            }
                        
                            appUserTemp?.phoneNumberCount =  UserProfileWebApi.getBusinessPhoneNumberCount(phoneNumber: appUserTemp?.phoneNumber)
                            appUserTemp?.emailAddressCount = UserProfileWebApi.getBusinessPhoneNumberEmailAddressCount(phoneNumber: appUserTemp?.phoneNumber)
                            
                            DispatchQueue.main.async(execute: {() -> Void in
                                self.dismissDescriptionDialog()
                            })
                            
                            while(!DescriptionDialog.dialogDisappeared)
                            {
                                
                            }
                            
                            if(appUserTemp?.phoneNumberCount == nil || appUserTemp?.emailAddressCount == nil)
                            {
                                appUserTemp?.hasVerifiedPhoneNumber = false
                                localDatabase.updateAppUser(appUser: appUserTemp!)
                                
                                DispatchQueue.main.async(execute: {() -> Void in
                                    let toast = CustomToast()
                                    toast.setToast(viewController: self, message: NSLocalizedString("somethingWentWrong", comment: ""))
                                    toast.show()
                                })
                                
                                return
                            }
                            
                            self.appUser = appUserTemp
                            localDatabase.updateAppUser(appUser: appUserTemp!)
                            
                            if(appUserTemp!.phoneNumberCount > 1)
                            {
                                self.showCustomerServiceView()
                                return
                            }
                            else if(appUserTemp?.phoneNumberCount == 1 && appUserTemp!.emailAddressCount > 1)
                            {
                                DispatchQueue.main.async(execute: {() -> Void in
                                    self.visibleItems.removeAll()
                                    self.items.removeAll()
                                    self.loadVerificationView()
                                    self.profileTableView.reloadData()
                                    self.profileTableView.beginUpdates()
                                    self.profileTableView.endUpdates()
                                })
                            }
                            else if(appUserTemp?.phoneNumberCount == 0)
                            {
                                DispatchQueue.main.async(execute: {() -> Void in
                                    self.visibleItems.removeAll()
                                    self.items.removeAll()
                                    self.loadVerificationView()
                                    self.profileTableView.reloadData()
                                    self.profileTableView.beginUpdates()
                                    self.profileTableView.endUpdates()
                                })
                            }
                            else
                            {
                                self.loadUserData()
                            }
                        }
                    }
                    else if(vissibleVerificationField.type == UserProfileFieldType.Email.rawValue && localDatabase.isEmailAddressVerified(emailAddress: vissibleVerificationField.value))
                    {
                        DispatchQueue.global(qos: .background).async {
                            var appUserTemp = localDatabase.getAppUser()
                                                        
                            localDatabase.insertAcceptedAPK(bussinessID: clientID)
                            
                            if(appUserTemp == nil)
                            {
                                appUserTemp = AppUser()
                            }
                            
                            
                            appUserTemp?.emailAddressCount = UserProfileWebApi.getBusinessPhoneNumberEmailAddressCount(phoneNumber: appUserTemp?.phoneNumber)
                            
                            DispatchQueue.main.async(execute: {() -> Void in
                                self.dismissDescriptionDialog()
                            })
                            
                            while(!DescriptionDialog.dialogDisappeared)
                            {
                                
                            }
                            
                            if(appUserTemp?.emailAddressCount == nil)
                            {
                                appUserTemp?.hasVerifiedEmailAddress = false
                                localDatabase.updateAppUser(appUser: appUserTemp!)
                                
                                DispatchQueue.main.async(execute: {() -> Void in
                                    let toast = CustomToast()
                                    toast.setToast(viewController: self, message: NSLocalizedString("somethingWentWrong", comment: ""))
                                    toast.show()
                                })
                                
                                return
                            }
                            
                            localDatabase.updateAppUser(appUser: appUserTemp!)
                            
                            self.appUser = appUserTemp
                            
                            if(appUserTemp!.phoneNumberCount == 0 && appUserTemp!.emailAddressCount > 1)
                            {
                                self.showCustomerServiceView()
                                return
                            }
                            else
                            {
                                self.loadUserData()
                            }
                        }
                    }
                    else if(viewModel.registerUser())
                    {
                        DispatchQueue.global(qos: .background).async {
                            sleep(2)
                            
                            DispatchQueue.main.async(execute: {() -> Void in
                                self.dismissDescriptionDialog()
                            })
                            
                            while(!DescriptionDialog.dialogDisappeared)
                            {
                                
                            }
                            
                            if(!isActivityActive(viewController: self))
                            {
                                return
                            }
                            
                            //DispatchQueue.main.async(execute: {() -> Void in
                            //    self.displayDescriptionDialog(title: NSLocalizedString("registrationStatus", comment: ""), description: NSLocalizedString("makingIncomingCall", comment: ""))
                            //})
                            
                            DispatchQueue.main.async(execute: {() -> Void in
                                if(!localDatabase.isAPKAccepted(bussinessID: clientID))
                                {
                                    localDatabase.insertAcceptedAPK(bussinessID: clientID)
                                    self.visibleItems.removeAll()
                                    self.loadVerificationView()
                                    /*self.profileTableView.reloadData()
                                     self.profileTableView.beginUpdates()
                                     self.profileTableView.endUpdates()*/
                                }
                                
                                self.profileTableView.reloadData()
                                self.profileTableView.beginUpdates()
                                self.profileTableView.endUpdates()
                            })
                            
                            /*sleep(6)
                             
                             if(!isActivityActive(viewController: self))
                             {
                             return
                             }*/
                            
                            self.proceedToVerificationProcess()
                        }
                    }
                    else
                    {
                        DispatchQueue.global(qos: .background).async {
                            sleep(2)
                            
                            DispatchQueue.main.async(execute: {() -> Void in
                                self.dismissDescriptionDialog()
                            })
                            
                            while(!DescriptionDialog.dialogDisappeared)
                            {
                                
                            }
                            
                            if(!isActivityActive(viewController: self))
                            {
                                return
                            }
                            
                            if(self.vissibleVerificationField.type == UserProfileFieldType.Email.rawValue && (APK == APKsEnum.BeautyLine.rawValue || APK == APKsEnum.Test.rawValue))
                            {
                                if(self.viewModel.emailValidationStatus != nil)
                                {
                                    if(self.viewModel.emailValidationStatus.doesEmailBelongToAnotherUser)
                                    {
                                        self.displayMessageDialogView(title: "Email Validation", message: "\(self.viewModel.emailValidationStatus.validationResponse ?? "") \(NSLocalizedString("registrationAttemptsMessageBeautyLine", comment: ""))", closeDialogButtonText: "Ok")
                                    }
                                    else
                                    {
                                        self.displayMessageDialogView(title: "Email Validation", message: "\(self.viewModel.emailValidationStatus.validationResponse)", closeDialogButtonText: "Ok")
                                    }
                                }
                                else
                                {
                                    self.displayMessageDialogView(title: "Registration Failed", message: "Registration failed. Please try again", closeDialogButtonText: "Ok")
                                }
                            }
                            else
                            {
                                self.displayMessageDialogView(title: "Registration Failed", message: "Registration failed. Please try again", closeDialogButtonText: "Ok")
                            }
                        }
                    }
                }
                
                //}
            }
            else
            {
                DispatchQueue.global(qos: .background).async {
                    
                    while(!YesNoMessageDialog.dialogDisappeared)
                    {
                        /* wait for dialog to disappeared */
                    }
                    
                    DispatchQueue.main.async(execute: {() -> Void in
                        self.displayMessageDialogView(title: NSLocalizedString("noInternetConnection", comment: ""), message: NSLocalizedString("internetConnectionIsRequiredDuringRegistration", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                    })
                }
            }
        }
        
        func noRaised()
        {
        }
        
        if(nonVerifiedFields > 0)
        {
            let sb = UIStoryboard(name:"YesNoMessageDialog",bundle:nil)
            let dialog = sb.instantiateInitialViewController() as! YesNoMessageDialog
            self.present(dialog,animated:true)
            var verificationFields : [FieldModel] = []
            verificationFields.append(vissibleVerificationField)
            dialog.setDialogView(title: NSLocalizedString("buttonVerify", comment: ""), message: ParameterizedStrings.confirmInputData(fields: verificationFields,nonVerifiedFields : nonVerifiedFields), yesButtonName: NSLocalizedString("Yes", comment: ""), noButtonName: NSLocalizedString("No", comment: ""))
            //var appUser : AppUser!
            
            yesAction = yesRaised
            noAction = noRaised
            
            dialog.yesRaised = self
            dialog.noRaised = self
        }
        else
        {
            yesRaised()
        }

    }
    
    /// Proceeds to the verification process.
    func proceedToVerificationProcess()
    {
        DispatchQueue.global(qos: .background).async {
            sleep(2)
            self.dismissDescriptionDialog()
            
            while(!DescriptionDialog.dialogDisappeared)
            {
                
            }
            
            self.getVerificationCode()
        }
        
    }
    
    func verifyField(field : FieldModel)
    {
        viewModel.registrationSourceType = RegistrationSourceTypeEnum.RichReachIphone.rawValue
        
        do
        {
            self.viewModel.fields = verificationFields
            self.viewModel.verifyVerificationCode(field : field)
            let verificationMessage = self.viewModel.verificationMessage
            
            if(field.isVerified)
            {
                sleep(2)
                
                self.dismissDescriptionDialog()
                self.dismissStatusTextDialogView()
                
                while(!DescriptionTextFieldDialog.dialogDisappeared || !DescriptionDialog.dialogDisappeared)
                {
                    
                }
                
                DispatchQueue.main.async(execute: {() -> Void in
                    //self.displayMessageDialogView(title: NSLocalizedString("verificationSucceedTitle", comment: ""), message: "Verification for \(field.labelName.lowercased()) is succeed.", closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                    
                    
                    //self.profileTableView.reloadData()
                    //self.profileTableView.beginUpdates()
                    //self.profileTableView.endUpdates()
                })
                
                switch field.type {
                case UserProfileFieldType.Phoneumber.rawValue:
                    if (!(self.appUser?.isUserRegisteredToAPNS)! && Bundle.main.bundleIdentifier! == APKsEnum.RichReach.rawValue)
                    {
                        //AppDelegate.registerForPushNotifications(application: appApplication)
                    }
                    
                default:
                    break
                }
            }
            else if(verificationMessage != nil)
            {
                sleep(2)
                
                self.dismissDescriptionDialog()
                
                while(!DescriptionDialog.dialogDisappeared)
                {
                    
                }
                
                DispatchQueue.main.async(execute: {() -> Void in
                    self.displayMessageDialogView(title: NSLocalizedString("verificationFailedTitle", comment: ""), message: verificationMessage!, closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                })
            }
        }
        catch
        {
            //updateStatusDialogViewMessage(messageTemp: NSLocalizedString("verificationFailed", comment: ""))
        }
    }
    
    func loadUserData()
    {
        DispatchQueue.main.async(execute: {() -> Void in
            
            let sb = UIStoryboard(name:"DescriptionDialog",bundle:nil)
            let dialog = sb.instantiateInitialViewController()!
            let dialogViewController = dialog as! DescriptionDialog
            self.descriptionDialog = dialogViewController
            self.descriptionDialog.dismissWhenClickOutside = false
            
            dialogViewController.setDialogView(title: "Please wait", description: "Checking your contact details...")
            
            self.present(dialog,animated:true,completion: { () in
                DispatchQueue.global(qos: .background).async {
                    self.visibleItems = userProfileDB.getUserProfileView()
                    self.viewModel.checkIfUserExists(items : self.visibleItems,timeout: 60)
                    
                    apkUserPreferences = parameterizationDatabase.getAPKUserPreferences(apk: APK)
                    
                    if(apkUserPreferences == nil)
                    {
                        apkUserPreferences = APKUserPreferences()
                    }
                    
                    localDatabase.insertVerifiedAPK(bussinessID: clientID, isBlocked : self.viewModel.isBlocked )
                    
                    DispatchQueue.main.async(execute: {() -> Void in
                        self.indicator.stopAnimating()
                    })
                    
                    if(self.viewModel.isBlocked)
                    {
                        DispatchQueue.global(qos: .background).async {
                            sleep(1)
                            
                            DispatchQueue.main.async(execute: {() -> Void in
                                self.descriptionDialog.dismissDialog()
                            })
                            
                            while(!DescriptionDialog.dialogDisappeared)
                            {
                                
                            }
                            
                            //DispatchQueue.main.async(execute: {() -> Void in
                                self.displayMessageDialogView(title: NSLocalizedString("blockedTitle", comment: ""), message: NSLocalizedString("blockedDescription", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""), dismissWhenClickOutside : false)
                                while(self.messageDialog == nil)
                                {}
                            DispatchQueue.main.async(execute: {() -> Void in
                                self.messageDialog.delegate = self
                            })
                        }
                    }
                    else
                    {
                        //sleep(1)
                        self.isRegistered = true
                        
                        self.viewModel.acceptNews = localDatabase.getAcceptNews(bussinessID: clientID)
                        self.appUser = localDatabase.getAppUser()
                        //self.setUserProfileView()
                        self.setView()
                        
                        DispatchQueue.main.async(execute: {() -> Void in
                            self.descriptionDialog.dismissDialog()
                            self.profileTableView.reloadData()
                            
                            DispatchQueue.main.async(execute: {() -> Void in
                                self.profileTableView.reloadData()
                            })
                            
                            self.hideCustomerServiceView()
                            
                            if(localDatabase.isAPKRegistered(bussinessID: clientID))
                            {
                                DispatchQueue.global(qos: .background).async {
                                    let appUser = localDatabase.getAppUser()
                                    
                                    if(appUser != nil && appUser?.phoneNumber != nil)
                                    {
                                        let phoneNumber = appUser?.phoneNumber
                                        
                                        
                                        while(!DescriptionDialog.dialogDisappeared)
                                        {
                                            
                                        }
                                        
                                        func yesRaised()
                                        {
                                            for t in leftDrawer.leftDrawerTabsList
                                            {
                                                if(t.type == LeftDrawerTabsType.PromotionNotifications.rawValue)
                                                {
                                                    leftDrawer.selectTab(tabString: t.name)
                                                    self.showView(tab: t, index: 0)
                                                    break
                                                }
                                            }
                                        }
                                        
                                        func noRaised()
                                        {
                                            
                                        }
                                        
                                        var numOfActiveCoupons = 0
                                        
                                        if(self.viewModel.serverResponse == nil)
                                        {
                                            numOfActiveCoupons = NotificationsWebApi.getUserActiveCouponsCount(userPhone: phoneNumber)
                                        }
                                        
                                        if((self.viewModel.serverResponse != nil && self.viewModel.serverResponse.numOfActiveCoupons > 0) || numOfActiveCoupons > 0)
                                        {
                                            let sb = UIStoryboard(name:"YesNoMessageDialog",bundle:nil)
                                            let dialog = sb.instantiateInitialViewController() as! YesNoMessageDialog
                                            DispatchQueue.main.async(execute: {() -> Void in
                                                self.present(dialog,animated:true)
                                                dialog.setDialogView(title: "Vouchers", message: "Your registration is completed. You have earned a voucher.", yesButtonName: "View now", noButtonName: "View later")
                                            })
                                            
                                            yesAction = yesRaised
                                            noAction = noRaised
                                            
                                            dialog.yesRaised = self
                                            dialog.noRaised = self
                                        }
                                        else
                                        {
                                            DispatchQueue.main.async(execute: {() -> Void in
                                                self.displayMessageDialogView(title: "Succeed", message: "Your registration is completed.", closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                                            })
                                        }
                                        
                                        /*var numberOfCoupons = 0
                                         
                                         do
                                         {
                                         numberOfCoupons = try NotificationsWebApi.getPromotionNotificationOffers(userPhone: phoneNumber!).count
                                         }
                                         catch
                                         {}
                                         
                                         if(numberOfCoupons > 0)
                                         {
                                         let sb = UIStoryboard(name:"YesNoMessageDialog",bundle:nil)
                                         let dialog = sb.instantiateInitialViewController() as! YesNoMessageDialog
                                         DispatchQueue.main.async(execute: {() -> Void in
                                         self.present(dialog,animated:true)
                                         dialog.setDialogView(title: "Vouchers", message: "Your registration is completed. You have earned a voucher.", yesButtonName: "View now", noButtonName: "View later")
                                         })
                                         
                                         
                                         yesAction = yesRaised
                                         noAction = noRaised
                                         
                                         dialog.yesRaised = self
                                         dialog.noRaised = self
                                         }
                                         else
                                         {
                                         DispatchQueue.main.async(execute: {() -> Void in
                                         self.displayMessageDialogView(title: "Succeed", message: "Your registration is completed.", closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                                         })
                                         }*/
                                        
                                        var notificationsCountersInfo = NotificationsWebApi.getNotificationsCountersInfo(userPhone: phoneNumber)
                                        
                                        if(notificationsCountersInfo != nil)
                                        {
                                            numberOfGeneralNotifications = notificationsCountersInfo!.unseenCampaigns
                                            numberOfPromotionNotifications = notificationsCountersInfo!.unseenCoupons
                                            numberOfNotifications = notificationsCountersInfo!.allUnseen
                                        }
                                        
                                        DispatchQueue.main.async(execute: {() -> Void in
                                            if(APK == Bundle.main.bundleIdentifier || APK == APKsEnum.Test.rawValue)
                                            {
                                                UIApplication.shared.applicationIconBadgeNumber = numberOfNotifications
                                            }
                                            
                                            leftDrawer.tableView.reloadData()
                                            leftDrawer.selectTab(tabString: leftDrawer.currentTab)
                                            
                                            if(localDatabase.isAPKRegistered(bussinessID: clientID))
                                            {
                                                let notifications = UIBarButtonItem(badge: "\(numberOfNotifications)", title: "", target: self, action: #selector(ViewController.onNotificationsClick))
                                                notifications.badgedButton?.setImage(UIImage(named: "ic_left_drawer_notifications"), for: .normal)
                                                currentViewController2.navigationItem.rightBarButtonItem = notifications
                                                
                                            }
                                        })
                                        
                                        APKChanger.getPointsStatementAndBalance()
                                        
                                        let pointsBalance = UserProfileWebApi.getUserPointsBalance(clientID: clientID, phoneNumber: localDatabase.getAppUser()?.phoneNumber)
                                        loyaltyDB.insertPoitsBalance(pointsBalance: pointsBalance)
                                    }
                                }
                            }
                            else
                            {
                                DispatchQueue.global(qos: .background).async {
                                    while(!DescriptionDialog.dialogDisappeared)
                                    {
                                        
                                    }
                                    
                                    self.displayMessageDialogView(title: NSLocalizedString("completeRegistration", comment: ""), message: NSLocalizedString("completeRegistrationMessage", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""),dismissWhenClickOutside: false)
                                }
                            }
                        })
                    }
                }
            })
        })
            
        /*DispatchQueue.main.async(execute: {() -> Void in
            self.displayDescriptionDialog(title: "Configuration", description: "Please wait while we configuring your data")
        })
        
        self.items = userProfileDB.getUserProfileView()
        self.viewModel.checkIfUserExists(items : self.items)
        
        localDatabase.insertVerifiedAPK(bussinessID: clientID, isBlocked : viewModel.isBlocked )
        
        if(viewModel.isBlocked)
        {
            sleep(1)
            
            DispatchQueue.main.async(execute: {() -> Void in
                self.messageDialog.dismissDialog()
            })
            
            while(!self.messageDialog.isBeingDismissed)
            {
                
            }
        
            self.displayMessageDialogView(title: NSLocalizedString("blockedTitle", comment: ""), message: NSLocalizedString("blockedDescription", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""), dismissWhenClickOutside : false)
            self.messageDialog.delegate = self
        }
        else
        {
            //sleep(1)
            
            self.isRegistered = true
            
            viewModel.acceptNews = localDatabase.getAcceptNews(bussinessID: clientID)
            appUser = localDatabase.getAppUser()
            
            for i in self.items
            {
                if(i.fields != nil)
                {
                    for f in i.fields
                    {
                        for v in verificationFields
                        {
                            if(v.type == f.type)
                            {
                                f.isVerified = true
                            }
                        }
                        
                        switch f.type
                        {
                        case  UserProfileFieldType.Phoneumber.rawValue :
                            f.value = appUser?.phoneNumber
                        case  UserProfileFieldType.Email.rawValue :
                            f.value = appUser?.emailAddress
                        case  UserProfileFieldType.Title.rawValue :
                            //f.value = appUser?.
                            break
                        case  UserProfileFieldType.Name.rawValue :
                            f.value = appUser?.name
                        case  UserProfileFieldType.Surname.rawValue :
                            f.value = appUser?.surname
                        case  UserProfileFieldType.Gender.rawValue :
                            f.value = appUser?.gender == 0 ? "Male" : "Female"
                        case  UserProfileFieldType.Birthday.rawValue :
                            f.value = appUser?.birthDate
                        case  UserProfileFieldType.Address1.rawValue :
                            f.value = appUser?.homeAddress
                        case  UserProfileFieldType.Address2.rawValue :
                            f.value = appUser?.homeAddress2
                        case  UserProfileFieldType.City.rawValue :
                            f.value = appUser?.city
                        case  UserProfileFieldType.PostCode.rawValue :
                            f.value = appUser?.postCode
                        case  UserProfileFieldType.District.rawValue :
                            f.value = appUser?.province
                        case  UserProfileFieldType.Country.rawValue :
                            f.value = appUser?.country
                        default :
                            break
                        }
                    }
                }
            }
            
            
            
            DispatchQueue.main.async(execute: {() -> Void in
                self.descriptionDialog.dismissDialog()
                self.profileTableView.reloadData()
            })
        }*/
    }
    
    
    @objc func resendClick(_ button: UIButton) {
        var field : FieldModel!
        
        for f in verificationFields
        {
            if(f.type == button.tag)
            {
                field = f
                break
            }
        }
        
        displayDescriptionDialog(title: NSLocalizedString("registrationStatus", comment: ""), description: "Sending verification code to your \(field.labelName.lowercased()).")
        
        do
        {
            let appUser = localDatabase.getAppUser()
            var serverResponse : String! = ""
            
            switch field.type
            {
            case  UserProfileFieldType.Phoneumber.rawValue :
                if(appMode == AppModeType.Release.rawValue)
                {
                    serverResponse = try RegistrationWebApi.getVerificationCodeViaSMS(phoneNumber: (appUser?.phoneNumber)!, prefix: "357", carrier: (appUser?.networkOperator)!, deviceID: (appUser?.deviceID)!, applicationLanguage: "en")
                }
                else
                {
                    serverResponse = try RegistrationWebApi.getVerificationCodeViaIncomingCall(phoneNumber: (appUser?.phoneNumber)!, prefix: "357", carrier: (appUser?.networkOperator)!, deviceID: (appUser?.deviceID)!, applicationLanguage: "en")
                    getVerificationCodeViaSMS()
                }
            case  UserProfileFieldType.Email.rawValue :
                serverResponse = try RegistrationWebApi.getVerificationCodeViaEmail(phoneNumber: (appUser?.phoneNumber)!, email: (appUser?.emailAddress == nil ? "" : appUser?.emailAddress)!, prefix: "357", carrier: (appUser?.networkOperator)!, deviceID: (appUser?.deviceID)!, applicationLanguage: "en")
            default:
                break
            }
            
            let registrationMaxAttemptsReachedStr = NSLocalizedString("registrationMaxAttemptsReached", comment: "")
            
            let shouldDisplayMaxAttemptsDialogView = (!isNullOrEmpty(string: serverResponse)) && (serverResponse?.contains(registrationMaxAttemptsReachedStr))!
            
            if(shouldDisplayMaxAttemptsDialogView)
            {
                self.descriptionDialog.dismissDialog()
                
                DispatchQueue.global(qos: .background).async {
                    while(!DescriptionDialog.dialogDisappeared)
                    {
                        
                    }
                    
                    DispatchQueue.main.async(execute: {() -> Void in
                        self.displayRegistrationMaxAttemptsDialog()
                    })
                }
            }
        }
        catch
        {
            
            self.descriptionDialog.dismissDialog()

            DispatchQueue.global(qos: .background).async {
                while(!DescriptionDialog.dialogDisappeared)
                {
                    
                }
                
                self.displayFailureDialog()
            }
        }
        
        
    }
    
    func getVerificationCodeViaSMS()
    {
        DispatchQueue.main.asyncAfter(deadline: .now() + 60) {
            DispatchQueue.global(qos: .background).async {
                let appUser = localDatabase.getAppUser()
                do
                {
                    //let f = self.vissibleVerificationField
                    
                    if(!(appUser?.hasVerifiedPhoneNumber)!)
                    {
                        var serverResponse : String! = ""
                        
                        serverResponse = try RegistrationWebApi.getVerificationCodeViaSMS(phoneNumber: (appUser?.phoneNumber)!, prefix: "357", carrier: (appUser?.networkOperator)!, deviceID: (appUser?.deviceID)!, applicationLanguage: "en")
                        
                        if(!isActivityActive(viewController: self))
                        {
                            return
                        }
                        
                        let registrationMaxAttemptsReachedStr = NSLocalizedString("registrationMaxAttemptsReached", comment: "")
                        
                        let shouldDisplayMaxAttemptsDialogView = (!isNullOrEmpty(string: serverResponse)) && (serverResponse?.contains(registrationMaxAttemptsReachedStr))!
                        
                        if(shouldDisplayMaxAttemptsDialogView)
                        {
                            DispatchQueue.main.async(execute: {() -> Void in
                                self.descriptionDialog.dismissDialog()
                            })
                            
                            while(!DescriptionDialog.dialogDisappeared)
                            {
                                
                            }
                            
                            DispatchQueue.main.async(execute: {() -> Void in
                                self.displayRegistrationMaxAttemptsDialog()
                            })
                        }
                        else
                        {
                            DispatchQueue.main.async(execute: {() -> Void in
                                if(self.statusTextDialog != nil && self.isStatusTextDialogDisplayed)
                                {
                                    self.statusTextDialog.updateDescription(newDescription : NSLocalizedString("callVerificationFailed", comment: "") )
                                }
                                else
                                {
                                    let sb = UIStoryboard(name:"DescriptionTextFieldDialog",bundle:nil)
                                    self.statusTextDialog = sb.instantiateInitialViewController()! as? DescriptionTextFieldDialog
                                    self.statusTextDialog.dismissWhenClickOutside = false
                                    self.statusTextDialog.userProfile = self
                                    self.present(self.statusTextDialog,animated:true)
                                    self.statusTextDialog.buttonRunnable = self.verifyUser
                                    self.statusTextDialog.setDialogView(title: NSLocalizedString("registrationStatus", comment: ""), description: NSLocalizedString("callVerificationFailed", comment: ""))
                                    self.isStatusTextDialogDisplayed = true
                                }
                            })
                        }
                    }
                    
                    appUser?.hasUserReceivedRegistrationVerificationCode = true
                    localDatabase.updateAppUser(appUser: appUser!)
                    
                }
                catch
                {
                    DispatchQueue.main.async(execute: {() -> Void in
                        self.descriptionDialog.dismissDialog()
                    })
                    
                    while(!DescriptionDialog.dialogDisappeared)
                    {
                        
                    }
                    
                    self.displayFailureDialog()
                }
            }
        }
    }
    
    /// Contacts the server to make a request to get verification codes.
    func getVerificationCode()
    {
        do
        {
            let appUser = localDatabase.getAppUser()
            
            //for f in verificationFields
            //{
            let f = vissibleVerificationField
            
            if(f != nil && !(f?.isVerified)!)
            {
                var serverResponse : String! = ""
                
                switch f?.type
                {
                case  UserProfileFieldType.Phoneumber.rawValue :
                    
                    if(appMode == AppModeType.Release.rawValue)
                    {
                        serverResponse = try RegistrationWebApi.getVerificationCodeViaSMS(phoneNumber: (appUser?.phoneNumber)!, prefix: "357", carrier: (appUser?.networkOperator)!, deviceID: (appUser?.deviceID)!, applicationLanguage: "en")
                    }
                    else
                    {
                        serverResponse = try RegistrationWebApi.getVerificationCodeViaIncomingCall(phoneNumber: (appUser?.phoneNumber)!, prefix: "357", carrier: (appUser?.networkOperator)!, deviceID: (appUser?.deviceID)!, applicationLanguage: "en")
                        getVerificationCodeViaSMS()
                    }
                case  UserProfileFieldType.Email.rawValue :
                    serverResponse = try RegistrationWebApi.getVerificationCodeViaEmail(phoneNumber: (appUser?.phoneNumber)!, email: (appUser?.emailAddress == nil ? "" : appUser?.emailAddress)!, prefix: "357", carrier: (appUser?.networkOperator)!, deviceID: (appUser?.deviceID)!, applicationLanguage: "en")
                default:
                    break
                }
                
                let registrationMaxAttemptsReachedStr = NSLocalizedString("registrationMaxAttemptsReached", comment: "")
                
                let shouldDisplayMaxAttemptsDialogView = (!isNullOrEmpty(string: serverResponse)) && (serverResponse?.contains(registrationMaxAttemptsReachedStr))!
                
                if(shouldDisplayMaxAttemptsDialogView)
                {
                    DispatchQueue.main.async(execute: {() -> Void in
                        self.descriptionDialog.dismissDialog()
                    })
                    
                    while(!DescriptionDialog.dialogDisappeared)
                    {
                        
                    }
                    
                    DispatchQueue.main.async(execute: {() -> Void in
                        self.displayRegistrationMaxAttemptsDialog()
                    })
                }
                else
                {
                    DispatchQueue.main.async(execute: {() -> Void in
                        let sb = UIStoryboard(name:"DescriptionTextFieldDialog",bundle:nil)
                        self.statusTextDialog = sb.instantiateInitialViewController()! as? DescriptionTextFieldDialog
                        self.statusTextDialog.dismissWhenClickOutside = false
                        self.statusTextDialog.userProfile = self
                        self.present(self.statusTextDialog,animated:true)
                        self.statusTextDialog.buttonRunnable = self.verifyUser
                        
                        if(self.vissibleVerificationField.type == UserProfileFieldType.Phoneumber.rawValue)
                        {
                            self.statusTextDialog.setDialogView(title: NSLocalizedString("registrationStatus", comment: ""), description: NSLocalizedString("makingIncomingCall", comment: ""))
                        }
                        else
                        {
                            self.statusTextDialog.setDialogView(title: NSLocalizedString("registrationStatus", comment: ""), description: "Your code will be sent to your \(self.vissibleVerificationField.labelName.lowercased() ?? "") soon. Please check your inbox and enter the code below.")
                        }
                        
                        self.isStatusTextDialogDisplayed = true
                    })
                }
            }
            //}
            
            appUser?.hasUserReceivedRegistrationVerificationCode = true
            localDatabase.updateAppUser(appUser: appUser!)
            
        }
        catch
        {
            DispatchQueue.main.async(execute: {() -> Void in
                self.descriptionDialog.dismissDialog()
            })
            
            while(!DescriptionDialog.dialogDisappeared)
            {
                
            }
            
            displayFailureDialog()
        }
    }
    
    
    /// Displays the RegistrationMaxAttemptsDialogView.
    func displayRegistrationMaxAttemptsDialog()
    {
        let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController()!
        let dialogViewController = dialog as! MessageDialog
        self.present(dialog,animated:true)
        if(APK == APKsEnum.BeautyLine.rawValue || APK == APKsEnum.Test.rawValue)
        {
            dialogViewController.setDialogView(title:NSLocalizedString("registrationAttemptsTitle", comment: "") , description: NSLocalizedString("registrationAttemptsMessageBeautyLine", comment: "") , buttonName: NSLocalizedString("Ok", comment: ""), dismissWhenClickOutside: false)
        }
        else
        {
            dialogViewController.setDialogView(title:NSLocalizedString("registrationAttemptsTitle", comment: "") , description: NSLocalizedString("registrationAttemptsMessage", comment: "") , buttonName: NSLocalizedString("Ok", comment: ""), dismissWhenClickOutside: false)
        }
    }
    
    func displayFailureDialog()
    {
        DispatchQueue.main.async(execute: {() -> Void in
            let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
            let dialog = sb.instantiateInitialViewController()!
            let dialogViewController = dialog as! MessageDialog
            self.present(dialog,animated:true)
            dialogViewController.setDialogView(title:"Status" , description: NSLocalizedString("somethingWentWrong", comment: "") , buttonName: NSLocalizedString("Ok", comment: ""), dismissWhenClickOutside: false)
        })
    }

    /*@objc func verificationTextFieldDidChange(_ textField: UITextField) {
        /*for i in items
        {
            if(i.fields != nil)
            {
                for f in i.fields
                {
                    if(f.type == textField.tag)
                    {
                        f.verificationCode = textField.text
                        return
                    }
                }
            }
        }*/
        vissibleVerificationField.verificationCode = textField.text
    }*/
    
    
    @objc func textFieldDidChange(_ textField: UITextField) {
        
        if(isRegistered)
        {
            areUnsavedChanges = true
        }
        
        for i in visibleItems
        {
            if(i.fields != nil)
            {
                for f in i.fields
                {
                    if(f.type == textField.tag)
                    {
                        if(isNullOrEmpty(string: f.value) && !isNullOrEmpty(string: textField.text))
                        {
                            numberOfMissingData -= 1
                            setMissingData()
                        }
                        else if(!isNullOrEmpty(string: f.value) && isNullOrEmpty(string: textField.text))
                        {
                            numberOfMissingData += 1
                            setMissingData()
                        }
                        
                        f.value = textField.text
                        if(submitButtonPressed && f.isRequirement)
                        {
                            if(isNullOrEmpty(string: f.value) )
                            {
                                f.isValueEmpty = true
                            }
                            else
                            {
                                f.isValueEmpty = false
                            }
                            
                            setFieldBorder(field: f, textField: textField)
                            /*if(isNullOrEmpty(string: f.value) )
                            {
                                if(f.borderStyle == 1)
                                {
                                    textField.layer.borderColor = UIColor.red.cgColor
                                    textField.layer.borderWidth = 1.0
                                }
                                else if(f.borderStyle == 2)
                                {
                                    //line.backgroundColor = UIColor.red
                                }
                                
                                f.isValueEmpty = true
                            }
                            else
                            {
                                if(f.borderStyle == 1)
                                {
                                    textField.layer.borderColor = UIColor(f.fieldStyle.borderColor).cgColor
                                    textField.layer.borderWidth = 1.0
                                }
                                else if(f.borderStyle == 2)
                                {
                                    //line.backgroundColor = UIColor(f.fieldStyle.borderColor)
                                }
                                
                                f.isValueEmpty = false
                            }*/
                        }
                        
                        return
                    }
                }
            }
        }
    }
    
    /*@objc func showDropDown(sender: UITapGestureRecognizer) {
        for i in visibleItems
        {
            if(i.fields != nil)
            {
                for f in i.fields
                {
                    if(f.type == sender.view?.tag)
                    {
                        if(f.isDropDown)
                        {
                            let sb = UIStoryboard(name:"TableDialog",bundle:nil)
                            let dialog = sb.instantiateInitialViewController()!
                            typesDialog = dialog as? TableDialog
                            self.present(dialog,animated:true)
                            typesDialog.delegate = self
                            
                            selectedDropdownType = f.type
                            typesDialog.setDialogView(title: f.labelName , types: f.dropDownItemsModel , selectedType: f.dropDownItemsModel[f.selectedDropDownItem].textStr, selectedTypeInt : f.selectedDropDownItem)
                            return
                        }
                        else
                        {
                            sender.removeTarget(self, action:  #selector(UserProfileViewController2.showDropDown))
                            let textFieldTemp = UITextField()
                            textFieldTemp.tag = f.type
                            textFieldDidBeginEditing(textFieldTemp)
                            //profileTableView.reloadData()
                            return
                        }
                    }
                }
            }
        }
        
    }*/
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if(!isUserProfileSynced)
        {
            syncUserProfile(showDialog: true)
            return false
        }
        else
        {
            var i = 0
            var isFound = false
            var field : FieldModel!
            
            for item in visibleItems
            {
                if(item.fields != nil)
                {
                    for f in item.fields
                    {
                        if(f.type == textField.tag)
                        {
                            field = f
                            isFound = true
                            break
                        }
                    }
                }
                
                if(isFound)
                {
                    break
                }
                
                i += 1
            }
            
            if(isRegistered && field.type == UserProfileFieldType.Email.rawValue)
            {
                textField.resignFirstResponder()
                editField(field : field)
                
                return false
            }
            
            if(field.isDropDown)
            {
                textField.resignFirstResponder()
                let sb = UIStoryboard(name:"TableDialog",bundle:nil)
                let dialog = sb.instantiateInitialViewController()!
                typesDialog = dialog as? TableDialog
                self.present(dialog,animated:true)
                typesDialog.delegate = self
                
                selectedDropdownType = field.type
                typesDialog.setDialogView(title: field.labelName , types: field.dropDownItemsModel , selectedType: field.dropDownItemsModel.count > field.selectedDropDownItem ? field.dropDownItemsModel[field.selectedDropDownItem].textStr : "" , selectedTypeInt : field.selectedDropDownItem)
                
                return false
            }
            else if(textField.tag == UserProfileFieldType.Birthday.rawValue)
            {
                func updateBirthdate()
                {
                    if(isNullOrEmpty(string: field.value))
                    {
                        numberOfMissingData -= 1
                        setMissingData()
                    }
                    
                    areUnsavedChanges = true
                    
                    print(datePickerDialog.date)
                    field.isValueEmpty = false
                    field.value = datePickerDialog.date
                    profileTableView.reloadData()
                }
                
                let sb = UIStoryboard(name:"DatePickerDialog",bundle:nil)
                datePickerDialog = sb.instantiateInitialViewController()!  as? DatePickerDialog
                datePickerDialog.isYearRequired = false
                self.present(datePickerDialog,animated:true)
                datePickerDialog.delegate = self
                let model = UserProfileViewModel()
                model.birthDate = field.value
                datePickerDialog.setDialogView(title : "Date" , userProfileViewModel: model)
                datePickerDialog.runnable = updateBirthdate
                
                return false
            }
            else
            {
                return true
            }
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        var i = 0
        var isFound = false
        var field : FieldModel!
        
        for item in visibleItems
        {
            if(item.fields != nil)
            {
                for f in item.fields
                {
                    if(f.type == textField.tag)
                    {
                        field = f
                        isFound = true
                        break
                    }
                }
            }
            
            if(isFound)
            {
                break
            }
            
            i += 1
        }
        
        /*if(textField.tag == UserProfileFieldType.Birthday.rawValue)
        {
            func updateBirthdate()
            {
                print(datePickerDialog.date)
                field.value = datePickerDialog.date
                profileTableView.reloadData()
            }
            
            let sb = UIStoryboard(name:"DatePickerDialog",bundle:nil)
            datePickerDialog = sb.instantiateInitialViewController()!  as? DatePickerDialog
            self.present(datePickerDialog,animated:true)
            datePickerDialog.delegate = self
            let model = UserProfileViewModel()
            model.birthDate = field.value
            datePickerDialog.setDialogView(title : "Date" , userProfileViewModel: model)
            datePickerDialog.runnable = updateBirthdate
        }
        else
        {*/
        
        
        if(field.isDropDown)
        {
            if(activeTextField2 != nil)
            {
                activeTextField2.resignFirstResponder()
                activeTextField2.endEditing(true)
            }

            activeView = nil
            activeTextField2 = nil
        }
        /*else if(field.type == UserProfileFieldType.Birthday.rawValue)
        {
            func updateBirthdate()
            {
                print(datePickerDialog.date)
                field.isValueEmpty = false
                field.value = datePickerDialog.date
                profileTableView.reloadData()
            }
            
            let sb = UIStoryboard(name:"DatePickerDialog",bundle:nil)
            datePickerDialog = sb.instantiateInitialViewController()!  as? DatePickerDialog
            self.present(datePickerDialog,animated:true)
            datePickerDialog.delegate = self
            let model = UserProfileViewModel()
            model.birthDate = field.value
            datePickerDialog.setDialogView(title : "Date" , userProfileViewModel: model)
            datePickerDialog.runnable = updateBirthdate

        }*/
        else
        {
            activeView = profileTableView.cellForRow(at: IndexPath(row: i, section: 0))
            activeTextField2 = textField
            activeTextField2.becomeFirstResponder()
        }
        //}
    }
    
    override func touchesBegan( _ touches: Set<UITouch>, with event: UIEvent?){
        view.endEditing(true)
        super.touchesBegan(touches, with: event)
    }
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        var i = 0
        var isFound = false
        var field : FieldModel!
        
        for item in visibleItems
        {
            if(item.fields != nil)
            {
                for f in item.fields
                {
                    if(f.type == textField.tag)
                    {
                        field = f
                        isFound = true
                        break
                    }
                }
            }
            
            if(isFound)
            {
                break
            }
            
            i += 1
        }
        
        if(field != nil && !field.isDropDown)
        {
            switch field.inputType {
            case InputType.Email.rawValue:
                if(!isNullOrEmpty(string: textField.text) && !isEmailAddressValid(address: textField.text!))
                {
                    field.isValid = false
                }
                else
                {
                    field.isValid = true
                }
            default:
                break
            }
            
            setFieldBorder(field : field, textField: textField)
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        /*var index = 0
        for t in textFields
        {
            if(t.type == textField.tag)
            {
                break
            }
            
            index += 1
        }
        
        index += 1
        textField.resignFirstResponder()
        
        if(index > 0 && index < textFields.count)
        {
            textFields[index].textField.becomeFirstResponder()
        }*/
        
        textField.resignFirstResponder()
        return false
    }
    
    func setFieldBorder(field : FieldModel, textField : UITextField)
    {
        textField.layer.borderWidth = 0.0

        if((field.isValueEmpty && field.isRequirement) || !field.isValid)
        {
            switch(field.fieldStyle.borderStyle)
            {
            case BorderStyle.Full.rawValue:
                textField.layer.borderColor = UIColor.red.cgColor
                textField.layer.borderWidth = 1.0
                break
            case BorderStyle.SingleLine.rawValue:
                let border = CALayer()
                let width = CGFloat(1.0)
                border.borderColor = UIColor.red.cgColor
    
                border.frame = CGRect(x: 0, y: textField.frame.size.height - width, width: textField.frame.size.width * 2, height: textField.frame.size.height)
                
                border.borderWidth = width
                textField.layer.addSublayer(border)
                textField.layer.masksToBounds = true
                break
            case BorderStyle.NoBorder.rawValue:
                textField.layer.borderWidth = 0.0
                break
            default:
                textField.layer.borderColor = UIColor.red.cgColor
                textField.layer.borderWidth = 1.0
            }
        }
        else
        {
            switch(field.fieldStyle.borderStyle)
            {
            case BorderStyle.Full.rawValue:
                textField.layer.borderColor = UIColor(field.fieldStyle.borderColor).cgColor
                textField.layer.borderWidth = 1.0
                break
            case BorderStyle.SingleLine.rawValue:
                let border = CALayer()
                let width = CGFloat(1.0)
                border.borderColor = UIColor(field.fieldStyle.borderColor).cgColor
                border.frame = CGRect(x: 0, y: textField.frame.size.height - width, width: textField.frame.size.width * 2, height: textField.frame.size.height)
                
                border.borderWidth = width
                textField.layer.addSublayer(border)
                textField.layer.masksToBounds = true
                break
            case BorderStyle.NoBorder.rawValue:
                textField.layer.borderWidth = 0.0
                break
            default:
                textField.layer.borderColor = UIColor(field.fieldStyle.borderColor).cgColor
                textField.layer.borderWidth = 1.0
            }
            
        }
    }
    
    /*@objc func setActiveTextField(sender: UITapGestureRecognizer) {
        var i = 0
        var isFound = false
        var field : FieldModel!
        
        for item in visibleItems
        {
            if(item.fields != nil)
            {
                for f in item.fields
                {
                    if(f.type == sender.view?.tag)
                    {
                        field = f
                        isFound = true
                        break
                    }
                }
            }
            
            if(isFound)
            {
                break
            }
            
            i += 1
        }
        
        if(sender.view?.tag == UserProfileFieldType.Birthday.rawValue)
        {
            func updateBirthdate()
            {
                print(datePickerDialog.date)
                field.value = datePickerDialog.date
                profileTableView.reloadData()
            }
            
            let sb = UIStoryboard(name:"DatePickerDialog",bundle:nil)
            datePickerDialog = sb.instantiateInitialViewController()!  as? DatePickerDialog
            self.present(datePickerDialog,animated:true)
            datePickerDialog.delegate = self
            let model = UserProfileViewModel()
            model.birthDate = field.value
            datePickerDialog.setDialogView(title : "Date" , userProfileViewModel: model)
            datePickerDialog.runnable = updateBirthdate
        }
    }*/
    
    var keyBoardHeight : CGFloat = 216.0
    var yOffset : CGFloat!
    var activeView : UIView!
    var activeTextField2 : UITextField!
    
    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: NSNotification.Name.UIKeyboardDidShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    @objc func keyboardWasShown(notification: NSNotification){
        if (self.activeView == nil)
        {
            return
        }

        var keyboardHeight : CGFloat!
        
        if let keyboardFrame: NSValue = notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue {
            let keyboardRectangle = keyboardFrame.cgRectValue
            keyboardHeight = keyboardRectangle.height
        }
        
        yOffset = keyboardHeight - (viewHeight - (activeView.frame.origin.y + activeView.frame.size.height -  self.profileTableView.contentOffset.y))
        
        if(yOffset > 0)
        {
            
            /*UIView.animate(withDuration: 0.3, animations: {
                self.profileTableView.contentOffset = CGPoint(x: 0, y: self.profileTableView.contentOffset.y + self.yOffset)
            }) { _ in
                /*DispatchQueue.main.async(execute: {() -> Void in
                    self.profileTableView.reloadData()
                })*/
                
                /*for i in 0..<self.items.count
                {
                    let item = self.items[i]
                    if(item.radioButton != nil)
                    {
                        let indexPath = IndexPath(item: i, section: 0)
                        var cellRect = self.profileTableView.rectForRow(at: indexPath)
                        cellRect.size.height =  cellRect.size.height
                        let completelyVisible = self.profileTableView.bounds.contains(cellRect)
                        
                        if (completelyVisible) {
                            self.profileTableView.reloadRows(at: [indexPath], with: .none)
                        }
                        
                        //DispatchQueue.main.async(execute: {() -> Void in
                        //    self.profileTableView.reloadRows(at: [indexPath], with: .none)
                        //})
                    }
                }*/

                
            }*/
            
            UIView.animate(withDuration: 0.3) {
                self.profileTableView.contentOffset = CGPoint(x: 0, y: self.profileTableView.contentOffset.y + self.yOffset)
            }
            
        }
    }
    
    func showCustomerServiceView()
    {
        appUser = localDatabase.getAppUser()
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.customerServiceView.isHidden = false
            if(self.appUser!.emailAddressCount > 1)
            {
                self.phoneNumberLabel.text = "Your phone number : \(self.appUser?.phoneNumber ?? "")"
                
                self.messageLabel.text = "Your email (\(self.appUser?.emailAddress ?? "")) is registered in more than one Benefit cards. Please contact customer service at 77771701 (Monday – Sunday: 06:30 – 23:00) or send an email to  customerservice@beautyline.com.cy"
            }
            else
            {
                self.messageLabel.text = "Your phone number (\(self.appUser?.phoneNumber ?? "")) is registered in more than one Benefit cards. Please contact customer service at 77771701 (Monday – Sunday: 06:30 – 23:00) or send an email to customerservice@beautyline.com.cy"
            }
            
            self.phoneNumberLabel.font = UIFont (name: "CharpentierSansPro-Normal", size: CGFloat(19))
            self.phoneNumberLabel.textColor = UIColor("#1D2D51")
            
            self.messageLabel.font = UIFont (name: "CharpentierSansPro-Normal", size: CGFloat(FontsAndSizes.dialogTextSize))
            self.messageLabel.textColor = UIColor("#1D2D51")
            
           
            self.retryButton.titleLabel?.font = UIFont(name: "CharpentierSansPro-Normal", size: CGFloat(18))
            self.retryButton.setTitleColor(UIColor("#ffffff"), for: .normal)//setTitleColor(UIColor(field.fieldStyle.borderColor), for: .normal)
            self.retryButton.backgroundColor = UIColor("#1D2D51")
            self.retryButton.layer.cornerRadius = CGFloat(7.5)
            
            self.retryButton.setTitle("Retry", for: .normal)
            //self.visibleItems.removeAll()
            //self.profileTableView.reloadData()
        })
    }
    
    func hideCustomerServiceView()
    {
        DispatchQueue.main.async(execute: {() -> Void in
            self.customerServiceView.isHidden = true
            self.messageLabel.text = ""
            self.phoneNumberLabel.text = ""
            self.retryButton.setTitle("", for: .normal)
        })
    }
    
    @IBAction func checkFieldCount(_ sender: UIButton) {
        checkPhoneNumberOrEmailCount()
    }
    
    func checkPhoneNumberOrEmailCountRunnable()
    {
        appUser = localDatabase.getAppUser()
        
        var phoneNumberCount : Int!
        var emailCount : Int!
        
        if(appUser!.phoneNumberCount > 1)
        {
            phoneNumberCount = UserProfileWebApi.getBusinessPhoneNumberCount(phoneNumber: appUser?.phoneNumber)
            appUser?.phoneNumberCount = phoneNumberCount
            
            DispatchQueue.main.async(execute: {() -> Void in
                if(phoneNumberCount == nil)
                {
                    let toast = CustomToast()
                    toast.setToast(viewController: self, message: NSLocalizedString("somethingWentWrong", comment: ""), duration: CustomToast.TOAST_LENGTH_LONG)
                    toast.show()
                    //self.showCustomerServiceView()
                }
                else if(phoneNumberCount > 1)
                {
                    let toast = CustomToast()
                    toast.setToast(viewController: self, message: "There is still a problem. Please contact Customer Service and try again.", duration: CustomToast.TOAST_LENGTH_LONG)
                    toast.show()
                    //self.showCustomerServiceView()
                }
                else if (phoneNumberCount == 1)
                {
                    emailCount = UserProfileWebApi.getBusinessPhoneNumberEmailAddressCount(phoneNumber: self.appUser?.phoneNumber)
                    self.appUser?.emailAddressCount = emailCount
                    
                    if(emailCount == nil)
                    {
                        let toast = CustomToast()
                        toast.setToast(viewController: self, message: NSLocalizedString("somethingWentWrong", comment: ""), duration: CustomToast.TOAST_LENGTH_LONG)
                        toast.show()
                        //self.showCustomerServiceView()
                    }
                    else if(emailCount <= 1)
                    {
                        localDatabase.updateAppUser(appUser: self.appUser!)
                        self.loadUserData()
                    }
                    else
                    {
                        localDatabase.updateAppUser(appUser: self.appUser!)
                        self.visibleItems.removeAll()
                        self.setView()
                        self.hideCustomerServiceView()
                    }
                }
                else
                {
                    localDatabase.updateAppUser(appUser: self.appUser!)
                    self.visibleItems.removeAll()
                    self.setView()
                    self.hideCustomerServiceView()
                }
            })
        }
        else
        {
            emailCount = UserProfileWebApi.getBusinessEmailAddressCount(emailAddress: appUser?.emailAddress)
            appUser?.emailAddressCount = emailCount
            
            DispatchQueue.main.async(execute: {() -> Void in
                if(emailCount == nil)
                {
                    let toast = CustomToast()
                    toast.setToast(viewController: self, message: NSLocalizedString("somethingWentWrong", comment: ""), duration: CustomToast.TOAST_LENGTH_LONG)
                    toast.show()
                    //self.showCustomerServiceView()
                }
                else if(emailCount > 1)
                {
                    let toast = CustomToast()
                    toast.setToast(viewController: self, message: "There is still a problem. Please contact customer service and try again.", duration: CustomToast.TOAST_LENGTH_LONG)
                    toast.show()
                    //self.showCustomerServiceView()
                }
                else
                {
                    //emailCount = UserProfileWebApi.getBusinessEmailAddressCount(emailAddress: self.appUser?.emailAddress)
                    self.appUser?.emailAddressCount = emailCount
                    

                    localDatabase.updateAppUser(appUser: self.appUser!)
                    self.loadUserData()
                }
            })
        }
    }
    
    func checkPhoneNumberOrEmailCount()
    {
        var task = WebApiTask(viewController: self, action: checkPhoneNumberOrEmailCountRunnable)
        task.displayToast = true
        task.shouldDisplayNotAvailableView = false
        task.start()
    }
    
    @objc func keyboardWillBeHidden(notification: NSNotification){
        if (activeView == nil)
        {
            return
        }
        
        if(yOffset != nil && yOffset > 0)
        {
            
            /*UIView.animate(withDuration: 0.3, animations: {
                self.profileTableView.contentOffset = CGPoint(x: 0, y: self.profileTableView.contentOffset.y - self.yOffset)
            }) { _ in
                //DispatchQueue.main.async(execute: {() -> Void in
                    
                //})
                //var i = 0
                /*for i in 0..<self.items.count
                {
                    let item = self.items[i]
                    if(item.radioButton != nil)
                    {
                        let indexPath = IndexPath(item: i, section: 0)
                        DispatchQueue.main.async(execute: {() -> Void in
                            self.profileTableView.reloadRows(at: [indexPath], with: .none)
                        })
                    }
                }*/
            }*/
            
            UIView.animate(withDuration: 0.3) {
                self.profileTableView.contentOffset = CGPoint(x: 0, y: self.profileTableView.contentOffset.y - self.yOffset)
            }
        }
        
        activeView = nil
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
}

/*class CustomTextField: UITextField {
    
    var padding : UIEdgeInsets! = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 0)
    
    override open func textRect(forBounds bounds: CGRect) -> CGRect {
        return UIEdgeInsetsInsetRect(bounds, padding)
    }
    
    override open func placeholderRect(forBounds bounds: CGRect) -> CGRect {
        return UIEdgeInsetsInsetRect(bounds, padding)
    }
    
    override open func editingRect(forBounds bounds: CGRect) -> CGRect {
        return UIEdgeInsetsInsetRect(bounds, padding)
    }
}*/
