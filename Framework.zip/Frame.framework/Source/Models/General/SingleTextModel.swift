//
//  SingleTextModel.swift
//  RichReach2
//
//  Created by Eumbrella on 22/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// SingleTextModel is a model that contains only a single text string.
class SingleTextModel
{
    var id : Int64 = 0
    var textStr : String
    
    init(textStr : String) {
        self.textStr = textStr
    }
    
    init(id : Int64, textStr : String) {
        self.id = id
        self.textStr = textStr
    }
}

