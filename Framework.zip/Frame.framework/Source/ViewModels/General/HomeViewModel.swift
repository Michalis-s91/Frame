//
//  HomeViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 15/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// HomeViewModel is the view model associated to the home view.
class GeneralViewModel
{
    var informationsList : [GeneralInformation2]! = []
    
    func loadFromInternet() -> [GeneralInformation2]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetGeneralView",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let informations = try decoder.decode(Informations.self, from : (response.data(using: .utf8))!)
                
                informationsList = informations.informationsList
                
                return informations.informationsList
            }
        }
        catch
        {
            print(error)
        }
        
        return nil
    }
    
    func loadFromLocalDB() -> [GeneralInformation2]!
    {
        do
        {
            var v = GeneralViewModel()
            var pdf = PDFModel()
            
            /*do
            {
                //The URL to Save
                let yourURL = NSURL(string: "http://93.109.209.42/PDF/OurStory.pdf")
                //Create a URL request
                let urlRequest = NSURLRequest(url: yourURL! as URL)
                //get the data
                let theData = try NSURLConnection.sendSynchronousRequest(urlRequest as URLRequest, returning: nil)
                
                //Get the local docs directory and append your local filename.
                var docURL = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)).last as? NSURL
                
                docURL = docURL?.appendingPathComponent( "myFileName.pdf") as! NSURL
                
                //Lastly, write your file to the disk.
                try theData.write(to: docURL as! URL,options : Data.WritingOptions.atomic )//(docURL!, atomically: true)
                
                pdf.numOfPages = 2
                pdf.pdfUrl = docURL?.absoluteString
                
                v.type = 8
                v.id = 1
                v.index = 0
                v.tabID = 1
                v.apk = "test"
                viewsDB.insertView(view: v)
                viewsDB.insertPDF(id: 1, pdf: pdf)
                
                v.type = 3
                v.index = 1
                viewsDB.insertView(view: v)
                
                var text = TextModel()
                text.title = "Title"
                text.description = "Description"
                text.backgroundColor = "#123456"
                text.splitterColor = "#ffffff"
                text.isTitleCentered = true
                text.descriptionFont = "Roboto"
                text.titleFont = "Roboto"
                text.titleSize = 28
                text.descriptionSize = 17
                text.titleColor = "#999999"
                text.descriptionAlignmentType = AlignmentType(rawValue: 1)
                text.descriptionColor = "#777777"
                
                viewsDB.insertText(id: 1, text: text)
                
                var photo = PhotoModel()
                photo.aspectRatio = 0.285
                photo.imageUrl = "http://93.109.209.42/Images/offer4.JPG"
                var button = ButtonModel()
                button.backgroundColor = "#ffffff"
                button.borderColor = "#99ffffff"
                button.name = "Test"
                button.borderWidth = 10
                button.font = "Roboto"
                button.height = 30
                button.width = 80
                button.tabID = 10
                button.textColor = "#000000"
                button.textSize = 20
                
                photo.button = button
                viewsDB.insertPhoto(id: 1, buttonID: 1, titleID: nil, photo: photo)
                
                v.type = 1
                v.index = 2
                viewsDB.insertView(view: v)
                
                var carousel = CarouselModel()
                carousel.hasTitles = false
                carousel.isAutomatic = true
                carousel.isManual = true
                carousel.isScrollingEnabled = true
                carousel.interval = 4
                
                var urls : [UrlModel] = []
                
                var url = UrlModel()
                url.url = "http://93.109.209.42/Images/offer4.JPG"
                url.id = 3
                urls.append(url)
                var url2 = UrlModel()
                url2.url = "http://93.109.209.42/Images/offer4.JPG"
                url2.id = 4
                urls.append(url2)
                var url3 = UrlModel()
                url3.url = "http://93.109.209.42/Images/offer4.JPG"
                url3.id = 5
                urls.append(url3)
                carousel.urls = urls
                viewsDB.insertCarousel(id: 1, carousel: carousel)
                
                v.type = 4
                v.index = 3
                viewsDB.insertView(view: v)
            }
            catch
            {
                print(error)
            }*/
            
            var generalViews = ViewsWebApi.getGeneralViews()
            
            if(generalViews != nil)
            {
                for g in generalViews!
                {
                    var generalView = GeneralViewModel()
                    generalView.apk = APK
                    generalView.index = g.index
                    generalView.type = g.type
                    generalView.id = g.id
                    generalView.tabID = g.tabID
                    
                    viewsDB.insertView(view: generalView)
                    
                    switch (g.type)
                    {
                    case InformationType2.PDF.rawValue:
                        do
                        {
                            let yourURL = NSURL(string: g.pdf.pdfUrl)
                            //Create a URL request
                            let urlRequest = NSURLRequest(url: yourURL! as URL)
                            //get the data
                            let theData = try NSURLConnection.sendSynchronousRequest(urlRequest as URLRequest, returning: nil)
                            
                            //Get the local docs directory and append your local filename.
                            var docURL = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)).last as? NSURL
                            
                            docURL = docURL?.appendingPathComponent( "\(APK)\(g.index)\(g.tabID).pdf") as! NSURL
                            
                            //Lastly, write your file to the disk.
                            try theData.write(to: docURL as! URL,options : Data.WritingOptions.atomic )
                            
                            viewsDB.insertPDF(id: g.id, pdf: g.pdf)
                        }
                        catch
                        {
                            
                        }
                        break
                    case InformationType2.Text.rawValue:
                        
                        viewsDB.insertText(id: g.id, text: g.text)
                        break
                    case InformationType2.Photo.rawValue:
                        
                        viewsDB.insertPhoto(id: g.id, photo: g.photo)
                        break
                    case InformationType2.Carousel.rawValue:
                        viewsDB.insertCarousel(id: g.id, carousel: g.carousel)
                        break
                    case InformationType2.Video.rawValue:
                        viewsDB.insertVideo(id: g.id, video: g.video)
                        break
                    default :
                        break
                    }
                }
            }
            
            return viewsDB.getGenealInformations(tabID: 1)
        }
        catch
        {
            print(error)
        }
        
        return nil
    }
    
}


/// Helper class for deserialisation.
class Informations : Codable
{
    var informationsList : [GeneralInformation2]!
    
    private enum CodingKeys : String, CodingKey {
        case informationsList = "GeneralInformationList"
    }
}
