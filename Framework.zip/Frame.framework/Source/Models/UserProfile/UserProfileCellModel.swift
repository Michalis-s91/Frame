//
//  ProfileCellModel.swift
//  RichReach2
//
//  Created by Eumbrella on 02/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class UserProfileCellModel : Codable
{
    var index : Int!
    var type : Int!
    var isFullWidth : Bool!
    var fields : [FieldModel]!
    var title : TitleModel!
    var button : ButtonModel!
    var radioButton : RadioButtonModel!
    var checkBox : CheckBoxModel!
    var switchModel : SwitchModel!
    var id1 : Int!
    var id2 : Int!
    var backgroundColor : String!
    var shouldHideOnUpdateProfileView : Bool!
    
    private enum CodingKeys : String, CodingKey {
        case index = "CellIndex"
        case type = "CellType"
        case isFullWidth = "IsFullWidth"
        case title = "Title"
        case button = "Button"
        case radioButton = "RadioButton"
        case checkBox = "CheckBox"
        case switchModel = "Switch"
        case id1 = "ID1"
        case id2 = "ID2"
        case backgroundColor = "BackgroundColor"
        case shouldHideOnUpdateProfileView = "ShouldHideOnUpdateProfileView"
    }
}
