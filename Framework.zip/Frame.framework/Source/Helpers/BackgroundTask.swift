//
//  BackgroundTask.swift
//  RichReach2
//
//  Created by Eumbrella on 03/04/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import Foundation

/// Helper class for web api task.
class BackgroundTask {
    private let application: UIApplication
    private static var identifier = UIBackgroundTaskInvalid
    
    init(application: UIApplication) {
        self.application = application
    }
    
    func run(application: UIApplication, handler: (BackgroundTask) -> ()){
        // NOTE: The handler must call end() when it is done
        
        let backgroundTask = BackgroundTask(application: application)
        backgroundTask.begin()
        handler(backgroundTask)
    }
    
    func begin() {
        BackgroundTask.identifier = application.beginBackgroundTask {
            self.end()
        }
        
    }
    
    func end() {
        if (BackgroundTask.identifier != UIBackgroundTaskInvalid) {
            application.endBackgroundTask(BackgroundTask.identifier)
        }
        
        BackgroundTask.identifier = UIBackgroundTaskInvalid
    }
}
