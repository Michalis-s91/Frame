//
//  StoreInformationViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 25/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// StoreInformationViewModel is the view model associated to the store information view.
class StoreInformationViewModel
{
    var informationsList : [GeneralInformation2] = []
    
    /// Constructor. Initialises the properties of class.
    init()
    {

    }
}

