//
//  ExpandableListParentModel.swift
//  RichReach2
//
//  Created by Eumbrella on 07/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class ExpandableListParentModel : Codable
{
    var expandableListViewID : Int!
    var id : Int!
    var name : String!
    var type : Int!
    var childs : [ExpandableListChildModel]! = []
    //var showCount : Bool!
    var image : String!
    
    var backgroundColor : String!
    var font : String!
    var textSize : Int!
    var textColor : String!
    var tintColor : String!
    
    var backgroundImage : String!
    var aspectRatio : Double!
    var isBackgroundImageLoaded = false
    var labelPosition : Int!
    var labelBackgroundColor : String!
    var labelWidth : Int!
    var labelHeight : Int!
    
    var hasAlternatingStyles : Bool!
    var firstStyle : StyleModel!
    var secondStyle : StyleModel!
    
    private enum CodingKeys : String, CodingKey {
        case expandableListViewID = "ExpandableListViewID"
        case id = "ParentID"
        //case apk = "APK"
        case name = "Name"
        case type = "Type"
        case textSize = "NameTextSize"
        case font = "Font"
        case textColor = "TextColor"
        case backgroundColor = "BackgroundColor"
        case tintColor = "TintColor"
        case image = "Image"
        case hasAlternatingStyles = "HasAlternatingStyles"
        case firstStyle = "FirstStyle"
        case secondStyle = "SecondStyle"
        
        case backgroundImage = "BackgroundImage"
        case labelPosition = "LabelPosition"
        case labelBackgroundColor = "LabelBackgroundColor"
        case labelWidth = "LabelWidth"
        case labelHeight = "LabelHeight"
    }
}
