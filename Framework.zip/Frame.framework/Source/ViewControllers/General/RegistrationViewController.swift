//
//  RegistrationViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 16/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Creates registration view.
class RegistrationViewController: UIViewController , YesEventHandler, NoEventHandler{
    func noRaised() {
        noAction()
    }
    
    func yesRaised() {
        yesAction()
    }
    
    
    @IBOutlet var registrationView: UIView!
    @IBOutlet var verificationView: UIView!
    @IBOutlet var privacyPolicyView: UIView!
    
    @IBOutlet var telephoneTextField: UITextField!
    @IBOutlet var submitLabel: UILabel!
    
    @IBOutlet var verificationCodeTextField: UITextField!
    @IBOutlet var verifyLabel: UILabel!
    @IBOutlet var resendLabel: UILabel!
    @IBOutlet var resetLabel: UILabel!
    
    @IBOutlet var termsAndPoliciesLabel: UILabel!
    
    var viewModel : RegistrationViewModel!
    var statusDialogView : DescriptionDialog!
    var verificationCode : String!
    var message : String!
    var verificationMessage : String!
    var registrationVisibility : Int!
    var verificationVisibility : Int!
    var isLoadingParameters = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.hideKeyboardWhenTappedAround()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.backgroundColor = Colors.registrationBackgroundColor
        
        //set registration view
        telephoneTextField.attributedPlaceholder = NSAttributedString(string: NSLocalizedString("hintTelephoneSignup", comment: ""),attributes: [NSAttributedStringKey.foregroundColor: UIColor.white])
        submitLabel = setLabelBorder(label: submitLabel)
        
        //set verification view
        verificationCodeTextField.attributedPlaceholder = NSAttributedString(string: NSLocalizedString("hintVerificationCodeSignup", comment: ""),attributes: [NSAttributedStringKey.foregroundColor: UIColor.white])
        verifyLabel = setLabelBorder(label: verifyLabel)
        resendLabel = setLabelBorder(label: resendLabel)
        
        termsAndPoliciesLabel.attributedText =  NSAttributedString(string: termsAndPoliciesLabel.text!, attributes:[.underlineStyle: NSUnderlineStyle.styleSingle.rawValue])
        
        viewModel = RegistrationViewModel(registrationViewController: self)
        
        setSimData()
        
        let onSubmitClick = UITapGestureRecognizer(target: self, action: #selector(RegistrationViewController.onSubmitClick))
        submitLabel.isUserInteractionEnabled = true
        submitLabel.addGestureRecognizer(onSubmitClick)
        
        let onVerifyClick = UITapGestureRecognizer(target: self, action: #selector(RegistrationViewController.onVerifyClick))
        verifyLabel.isUserInteractionEnabled = true
        verifyLabel.addGestureRecognizer(onVerifyClick)
        
        let onResendClick = UITapGestureRecognizer(target: self, action: #selector(RegistrationViewController.onResendClick))
        resendLabel.isUserInteractionEnabled = true
        resendLabel.addGestureRecognizer(onResendClick)
        
        let onResetClick = UITapGestureRecognizer(target: self, action: #selector(RegistrationViewController.onResetClick))
        resetLabel.isUserInteractionEnabled = true
        resetLabel.addGestureRecognizer(onResetClick)
        
        let onTermsAndPolicyClick = UITapGestureRecognizer(target: self, action: #selector(RegistrationViewController.onTermsAndPolicyClick))
        privacyPolicyView.isUserInteractionEnabled = true
        privacyPolicyView.addGestureRecognizer(onTermsAndPolicyClick)
        
        let sb = UIStoryboard(name:"StatusDialog",bundle:nil)
        self.statusDialogView = sb.instantiateInitialViewController()! as? DescriptionDialog
        self.statusDialogView.dismissWhenClickOutside = false
        //self.present(self.statusDialogView,animated:true)
        //self.statusDialogView.setDialogView(title: NSLocalizedString("status", comment: ""), description: NSLocalizedString("please_Wait_While_Downloading_RichReach_Default", comment: ""))
        //self.statusDialogView.dismissDialog()
    }
    
    @objc func closeKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    @objc func onSubmitClick (sender:UITapGestureRecognizer) {
        
        if(!parameterizationDatabase.isAPKSaved(apk: APK))
        {
            if(!isLoadingParameters)
            {
                isLoadingParameters = true
                
                self.present(self.statusDialogView,animated:true,
                             completion: { () in
                                DispatchQueue.global(qos: .background).async {
                                    if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
                                    {
                                        parameterizationDatabase.createTables()
                                        
                                        let initializer = APKInitializer()
                                        if (initializer.getProperties() == false)
                                        {
                                            //parameterizationDatabase.dropTables()
                                            
                                            DispatchQueue.main.async(execute: {() -> Void in
                                                
                                                func updateText()
                                                {
                                                    self.present(self.statusDialogView,animated:true)
                                                    self.statusDialogView.updateDescription(newDescription: NSLocalizedString("downloadFailed", comment: ""))
                                                    self.isLoadingParameters = false
                                                }
                                                
                                                if(DescriptionDialog.dialogDisappeared)
                                                {
                                                    updateText()
                                                }
                                                else
                                                {
                                                    self.statusDialogView.dismissDialog(runnable : updateText)
                                                }
                                            })
                                        }
                                        else
                                        {
                                            DispatchQueue.main.async(execute: {() -> Void in
                                                func updateText()
                                                {
                                                    self.present(self.statusDialogView,animated:true)
                                                    self.statusDialogView.updateDescription(newDescription: NSLocalizedString("downloadCompleted", comment: ""))
                                                    APKInitializer.setProperties()
                                                    self.isLoadingParameters = false
                                                    
                                                    DispatchQueue.global(qos: .background).async {
                                                        sleep(2)
                                                        DispatchQueue.main.async(execute: {() -> Void in
                                                            self.statusDialogView.dismissDialog(runnable : self.performSubmit)
                                                        })
                                                    }
                                                    
                                                }
                                                
                                                if(DescriptionDialog.dialogDisappeared)
                                                {
                                                    updateText()
                                                }
                                                else
                                                {
                                                    self.statusDialogView.dismissDialog(runnable : updateText)
                                                }
                                            })
                                            
                                        }
                                    }
                                    else
                                    {
                                        DispatchQueue.main.async(execute: {() -> Void in
                                            func updateText()
                                            {
                                                self.present(self.statusDialogView,animated:true)
                                                self.statusDialogView.updateDescription(newDescription: NSLocalizedString("upgradeFailed", comment: ""))
                                                self.isLoadingParameters = false                                             
                                            }
                                            
                                            if(DescriptionDialog.dialogDisappeared)
                                            {
                                                updateText()
                                            }
                                            else
                                            {
                                                self.statusDialogView.dismissDialog(runnable : updateText)
                                            }
                                        })
                                        /*DispatchQueue.main.async(execute: {() -> Void in
                                            self.present(self.statusDialogView,animated:true)
                                            self.statusDialogView.setDialogView(title: NSLocalizedString("syncSatus", comment: ""), description: NSLocalizedString("upgradeFailed", comment: ""))
                                            self.isLoadingParameters = false
                                        })*/
                                    }
                                }
                                
                })
                self.statusDialogView.setDialogView(title: NSLocalizedString("status", comment: ""), description: NSLocalizedString("please_Wait_While_Downloading_RichReach_Default", comment: ""))
            }
        }
        else
       {
           performSubmit()
       }
    }
    
    func performSubmit()
    {
        DispatchQueue.main.async(execute: {() -> Void in
        while(!DescriptionDialog.dialogDisappeared)
        {
            /* wait for dialog to disappeared */
        }
        
        let telephoneNumber = self.telephoneTextField.text
        self.viewModel.phone = telephoneNumber
        self.telephoneTextField.endEditing(true)
        
        if(!isNullOrEmpty(string: telephoneNumber))
        {
            if(telephoneNumber?.count == 8)
            {
                if(telephoneNumber?.starts(with: "9"))!
                {
                    self.displayConfirmTelephoneNumberDialog(telephoneNumber: telephoneNumber!)
                }
                else
                {
                    self.displayMessageDialogView(title: NSLocalizedString("invalidTelephoneNumber", comment: ""), message: NSLocalizedString("telephoneFormatNotValidCY", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                }
            }
            else
            {
                self.displayMessageDialogView(title: NSLocalizedString("invalidTelephoneNumber", comment: ""), message: NSLocalizedString("telephoneLengthNotValidCY", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
            }
        }
        else
        {
            self.displayMessageDialogView(title: NSLocalizedString("invalidTelephoneNumber", comment: ""), message: NSLocalizedString("pleaseEnterTelephoneNumber", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
        }
        })
    }
    
    @objc func onVerifyClick (sender:UITapGestureRecognizer) {
        verificationCodeTextField.endEditing(true)
        verifyUser(verificationCodeTemp: verificationCodeTextField.text!)
    }
    
    @objc func onResendClick (sender:UITapGestureRecognizer) {
        verificationCodeTextField.endEditing(true)
        let statusMessageToDisplay = NSLocalizedString("pleaseWaitForVerificationCodeManualVerification", comment: "")
        
        //self.view.window!.rootViewController?.dismiss(animated: false, completion: nil)
        
        //let sb = UIStoryboard(name:"StatusDialog",bundle:nil)
        //self.statusDialogView = sb.instantiateInitialViewController()! as! DescriptionDialog
        //statusDialogView = dialog as! DescriptionDialog
        self.present(self.statusDialogView,animated:true)
        self.statusDialogView.setDialogView(title: NSLocalizedString("registrationStatus", comment: ""), description: statusMessageToDisplay)
        
        DispatchQueue.global(qos: .background).async {
            self.resendVerificationCode()
        }
    }
    
    @objc func onResetClick (sender:UITapGestureRecognizer) {
        verificationCodeTextField.endEditing(true)
        telephoneTextField.text = ""
        verificationCodeTextField.text = ""
        
        viewModel.resetTelephoneNumber()
    }
    
    @objc func onTermsAndPolicyClick (sender:UITapGestureRecognizer) {
        //restartApp = false
        UIApplication.shared.openURL(NSURL(string: viewModel.termsAndPoliciesLink)! as URL)
    }
    
    /// Set SIM data.
    func setSimData()
    {
        viewModel.networkName = ""
        viewModel.networkISO = "en"
        viewModel.deviceID = UIDevice.current.identifierForVendor!.uuidString
    }
    
    
    /// Set border to given label.
    ///
    /// - Parameter label: The label we want to add border.
    /// - Returns: A new label with border.
    func setLabelBorder(label : UILabel) -> UILabel
    {
        label.layer.cornerRadius = 10
        label.layer.masksToBounds = true
        label.layer.borderColor = UIColor.white.cgColor
        label.layer.borderWidth = 0.7
        
        return label
    }
    
    
    /// Displays a dialog that asks user to confirm his/her telephone number.
    ///
    /// - Parameter telephoneNumber: The user's telephone number.
    func displayConfirmTelephoneNumberDialog(telephoneNumber : String)
    {
        let sb = UIStoryboard(name:"YesNoMessageDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController() as! YesNoMessageDialog
        self.present(dialog,animated:true)
        dialog.setDialogView(title: NSLocalizedString("buttonVerify", comment: ""), message: ParameterizedStrings.confirmPhoneNumber(prefix: "CY", phoneText: telephoneNumber), yesButtonName: NSLocalizedString("Yes", comment: ""), noButtonName: NSLocalizedString("No", comment: ""))
        var appUser : AppUser!
        
        func yesRaised()
        {
            if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
            {
                if(telephoneNumber == "99159915")
                {
                    let appUser = AppUser()
                    appUser.phoneNumber = telephoneNumber
                    appUser.isRegistered = true
                    appUser.isPending = false
                    localDatabase.addAppUser(appUser: appUser)
                    
                    
                    DispatchQueue.global(qos: .background).async {
                        self.loadUserOptins()
                        self.loadUserProfileInformation()
                        self.loadUserDefaultOptions()
                        
                        /*parameterizationDatabase.createTables()
                        
                        let initializer = APKInitializer()
                        if (initializer.getProperties() == false)
                        {
                            parameterizationDatabase.dropTables()
                            let toast = CustomToast(viewController: self, message: NSLocalizedString("errorOccurred", comment: ""), duration: CustomToast.TOAST_LENGTH_SHORT)
                            toast.show()
                        }
                        else
                        {
                            initializer.setProperties()*/
                        while(!YesNoMessageDialog.dialogDisappeared)
                        {
                            /* wait for dialog to disappeared */
                        }
                        
                        DispatchQueue.main.async(execute: {() -> Void in
                            if(localDatabase.getAppUser()?.partnerID == 0)
                            {
                                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                                let mainViewController = storyBoard.instantiateViewController(withIdentifier: "AllPartnersNavigationController") as! UINavigationController
                                self.present(mainViewController, animated: true, completion: nil)
                            }
                            else
                            {
                                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                                let mainViewController = storyBoard.instantiateViewController(withIdentifier: "PreferredOffersNavigationController") as! UINavigationController
                                self.present(mainViewController, animated: true, completion: nil)
                            }
                        })
                        
                        //localDatabase.updateAppUser(appUser: appUser)
                    }
                }
                else
                {
                    registerUser()
                }
            }
            else
            {
                DispatchQueue.global(qos: .background).async {
                    
                    while(!YesNoMessageDialog.dialogDisappeared)
                    {
                        /* wait for dialog to disappeared */
                    }
                    
                    DispatchQueue.main.async(execute: {() -> Void in
                    self.displayMessageDialogView(title: NSLocalizedString("noInternetConnection", comment: ""), message: NSLocalizedString("internetConnectionIsRequiredDuringRegistration", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                    })
                }
            }
        }
        
        func noRaised()
        {
        }
        
        yesAction = yesRaised
        noAction = noRaised
        
        dialog.yesRaised = self
        dialog.noRaised = self
    }
    
    
    /// Registers the user.
    func registerUser()
    {
        DispatchQueue.global(qos: .background).async {
            
            while(!YesNoMessageDialog.dialogDisappeared)
            {
               /* wait for dialog to disappeared */
            }
            
            DispatchQueue.main.async(execute: {() -> Void in
                //let sb = UIStoryboard(name:"StatusDialog",bundle:nil)
                //self.statusDialogView = sb.instantiateInitialViewController()! as! DescriptionDialog
                //statusDialogView = dialog as! DescriptionDialog
                self.present(self.statusDialogView,animated:true)
                self.statusDialogView.setDialogView(title: NSLocalizedString("registrationStatus", comment: ""), description: NSLocalizedString("submittingDetailsPleaseWait", comment: ""))
            })

            do
            {
                self.viewModel.registerUser()
                
                DispatchQueue.main.async(execute: {() -> Void in
                    self.proceedToVerificationProcess()
                })
            }
            catch
            {
                DispatchQueue.main.async(execute: {() -> Void in
                    self.dismissStatusDialogView()
                    self.displayMessageDialogView(title: NSLocalizedString("registrationFailedTitle", comment: ""), message: NSLocalizedString("registrationFailed", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                })
            }
        }
    }
    
    
    /// Displays a message to the user using our message dialog view design.
    ///
    /// - Parameters:
    ///   - title: The dialog's title.
    ///   - message: The message to be displayed.
    ///   - closeDialogButtonText: The close dialog button text.
    func displayMessageDialogView(title : String,message : String, closeDialogButtonText : String)
    {
        let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController()! as! MessageDialog
        self.present(dialog,animated:true)
        dialog.setDialogView(title: title, description:message, buttonName: closeDialogButtonText, dismissWhenClickOutside: true)
    }
    
    
    /// Proceeds to the verification process.
    func proceedToVerificationProcess()
    {
        if(!viewModel.hasUserReceivedRegistrationVerificationCode())
        {
            let statusMessageToDisplay = NSLocalizedString("pleaseWaitForVerificationCodeManualVerification", comment: "")
            
            updateStatusDialogViewMessage(messageTemp: statusMessageToDisplay)
            
            DispatchQueue.global(qos: .background).async {
                self.getVerificationCode()
            }
        }
    }
    
    
    /// Contacts the server to make a request to get an SMS that contains the 4-digit verification code.
    func getVerificationCode()
    {
        do
        {
            viewModel.getVerificationCodePost()
            
            let mServerResponse = viewModel.serverResponse
            let registrationMaxAttemptsReachedStr = NSLocalizedString("registrationMaxAttemptsReached", comment: "")
            
            let shouldDisplayMaxAttemptsDialogView = (!isNullOrEmpty(string: mServerResponse)) && (mServerResponse?.contains(registrationMaxAttemptsReachedStr))!
            
            if(shouldDisplayMaxAttemptsDialogView)
            {
                DispatchQueue.main.async(execute: {() -> Void in
                    self.dismissStatusDialogView()
                })
                
                while(!DescriptionDialog.dialogDisappeared)
                {
                        
                }
                
                DispatchQueue.main.async(execute: {() -> Void in
                  self.displayRegistrationMaxAttemptsDialog()
                })
                
            }
        }
        catch
        {
            
        }
    }
    
    
    /// Indicates if status dialog is vissible or not.
    ///
    /// - Returns: True in case the status dialog is visible, otherwise false.
    func isStatusDialogVisible() -> Bool
    {
        return statusDialogView != nil && statusDialogView.view != nil && !statusDialogView.isBeingDismissed
    }
    
    
    /// Verifies whether the verification code is valid or not.
    ///
    /// - Parameter verificationCodeTemp: The verification code.
    func verifyUser(verificationCodeTemp : String)
    {
        if (!isNullOrEmpty(string: verificationCodeTemp))
        {
            if (verificationCodeTemp.count == 4)
            {
                if(!isStatusDialogVisible())
                {
                    let sb = UIStoryboard(name:"DescriptionDialog",bundle:nil)
                    statusDialogView = sb.instantiateInitialViewController() as? DescriptionDialog
                    let dialog = statusDialogView
                    self.present(statusDialogView,animated:true)
                    dialog?.setDialogView(title: NSLocalizedString("registrationStatus", comment: ""), description: NSLocalizedString("yourVerificationCodeIs", comment: "") + " " + verificationCodeTextField.text! + ".\n" + NSLocalizedString("pleaseWaitWhileVerifying", comment: ""))
                }
                
                if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
                {
                    verificationCode = verificationCodeTemp
                    
                    /*DispatchQueue.main.async(execute: {() -> Void in
                        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let mainViewController = storyBoard.instantiateViewController(withIdentifier: "AllPartnersNavigationController") as! UINavigationController
                        self.present(mainViewController, animated: true, completion: nil)
                    })*/
                    
                    
                    DispatchQueue.global(qos: .background).async {
                        self.verifyVerificationCode(verificationCode: self.verificationCode)
                    }
                }
                else
                {
                    dismissStatusDialogView()
                    displayMessageDialogView(title: NSLocalizedString("noInternetConnection", comment: ""), message: NSLocalizedString("internetConnectionIsRequiredDuringRegistration", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                }
            }
            else
            {
                displayMessageDialogView(title: NSLocalizedString("verificationFailedTitle", comment: ""), message: NSLocalizedString("invalidVerificationCode", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
            }
        }
        else
        {
            displayMessageDialogView(title: NSLocalizedString("verificationFailedTitle", comment: ""), message: NSLocalizedString("verificationCodeCannotBeEmpty", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
        }
    }
    
    
    /// Updates the status dialog view message.
    ///
    /// - Parameter messageTemp: The updated message.
    func updateStatusDialogViewMessage(messageTemp : String)
    {
        message = messageTemp
        DispatchQueue.main.async(execute: {() -> Void in
            if (self.statusDialogView != nil)
            {
                self.statusDialogView.updateDescription(newDescription: self.message)
            }
        })
    }
    
    
    /// Dismisses the registration status dialog view.
    func dismissStatusDialogView()
    {
        DispatchQueue.main.async(execute: {() -> Void in
            do
            {
                self.statusDialogView.dismissDialog()
            }
            catch
            {
                
            }
        })
    }
    
    
    /// Resends the verification code to the user.
    func resendVerificationCode()
    {
        do
        {
            let mServerResponse = viewModel.resendVerificationCode()
            let registrationMaxAttemptsReachedStr = NSLocalizedString("registrationMaxAttemptsReached", comment: "")
            
            let shouldDisplayMaxAttemptsDialogView = (!isNullOrEmpty(string: mServerResponse)) && mServerResponse.contains(registrationMaxAttemptsReachedStr)
            
            if(shouldDisplayMaxAttemptsDialogView)
            {
                DispatchQueue.main.async(execute: {() -> Void in
                    self.dismissStatusDialogView()
                })
                
                while(!DescriptionDialog.dialogDisappeared)
                {
                    
                }
                
                DispatchQueue.main.async(execute: {() -> Void in
                    self.displayRegistrationMaxAttemptsDialog()
                })
                
            }
        }
        catch
        {
            
        }
    }
    
    
    /// Displays the RegistrationMaxAttemptsDialogView.
    func displayRegistrationMaxAttemptsDialog()
    {
        let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController()!
        let dialogViewController = dialog as! MessageDialog
        self.present(dialog,animated:true)
        dialogViewController.setDialogView(title:NSLocalizedString("registrationAttemptsTitle", comment: "") , description: NSLocalizedString("registrationAttemptsMessage", comment: "") , buttonName: NSLocalizedString("Ok", comment: ""), dismissWhenClickOutside: false)
        
        
        //RegistrationMaxAttemptsDialogView dialogFragment = new RegistrationMaxAttemptsDialogView()
        //dialogFragment.show(getFragmentManager(), "dialog_fragment")
    }
    
    
    /// Verifies the verification code that was sent to the user (or the one specified by the user).
    ///
    /// - Parameter verificationCode: The verification code.
    func verifyVerificationCode(verificationCode : String)
    {
        viewModel.verificationCode = verificationCode
        viewModel.registrationSourceType = RegistrationSourceTypeEnum.RichReachIphone.rawValue
        
        do
        {
            viewModel.verifyVerificationCode()
            verificationMessage = viewModel.verificationMessage
            
            if(viewModel.isVerified)
            {
                loadUserOptins()
                loadUserProfileInformation()
                loadUserDefaultOptions()
                
                
                DispatchQueue.main.async(execute: {() -> Void in
                    self.dismissStatusDialogView()
                })
                
                while(!DescriptionDialog.dialogDisappeared)
                {
                    
                }
                
                if(localDatabase.getAppUser()?.partnerID == 0)
                {
                    DispatchQueue.main.async(execute: {() -> Void in
                        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let mainViewController = storyBoard.instantiateViewController(withIdentifier: "AllPartnersNavigationController") as! UINavigationController
                        self.present(mainViewController, animated: true, completion: nil)
                    })
                }
                else
                {
                    DispatchQueue.main.async(execute: {() -> Void in
                        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let mainViewController = storyBoard.instantiateViewController(withIdentifier: "PreferredOffersNavigationController") as! UINavigationController
                        self.present(mainViewController, animated: true, completion: nil)
                    })
                }
                
                
            }
            else if(verificationMessage != nil)
            {
                DispatchQueue.main.async(execute: {() -> Void in
                    self.dismissStatusDialogView()
                })
                
                while(!DescriptionDialog.dialogDisappeared)
                {
                    
                }
                
                DispatchQueue.main.async(execute: {() -> Void in
                    self.displayMessageDialogView(title: NSLocalizedString("verificationFailedTitle", comment: ""), message: self.verificationMessage, closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                })
            }
        }
        catch
        {
            updateStatusDialogViewMessage(messageTemp: NSLocalizedString("verificationFailed", comment: ""))
        }

    }
    
    
    /// Loads the user's optins.
    func loadUserOptins()
    {
        do
        {
            viewModel.loadUserOptins()
        }
        catch
        {
            
        }
    }
    
    
    /// Loads the user's profile information from our server.
    func loadUserProfileInformation()
    {
        do
        {
            let userProfileViewModel = UserProfileViewModel(viewController: nil)
            userProfileViewModel.getUserProfileInformationFromServer()
        }
        catch
        {
            
        }
    }
    
    
    /// Loads the user's default options.
    func loadUserDefaultOptions()
    {
        do
        {
            viewModel.loadUserDefaultOptions()
        }
        catch
        {
            
        }
    }
}
