//
//  SwitchAcceptType.swift
//  RichReach
//
//  Created by Eumbrella on 04/03/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

enum SwitchAcceptType : Int
{
    case Notifications = 1
    case LocationTracking = 2
}
