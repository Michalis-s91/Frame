//
//  Offer.swift
//  RichReach2
//
//  Created by Eumbrella on 06/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Holds information about offers, like the offer id, offer description etc.
class Offer : Codable
{
    var appOfferID : Int!
    var description : String!
    var imageUrl : String!
    var originalPrice : String!
    var offerDescription : String!
    var offerNewPrice : String!
    var isStrikethrough : Bool = false
    var partnerName : String!
    var isPrivate : Bool = false
    var isGeneralOffer : Bool = false
    var isPriceListOffer : Bool = false
    var isNoPriceToShowOffer : Bool = false
    var isSetOffer : Bool = false
    var duration : String!
    var largeImageUrl : String!
    
    init() {}
    
    private enum CodingKeys : String, CodingKey {
        case appOfferID = "ID"
        case description = "Description"
        case offerDescription = "OfferText"
        case partnerName = "PartnerName"

        case originalPrice = "OriginalPriceStr"
        case offerNewPrice = "NewPriceStr"
        case isGeneralOffer = "IsGeneralOffer"
        case isPriceListOffer = "IsPriceListOffer"
        case isNoPriceToShowOffer = "IsNoPriceToShowOffer"
        case isSetOffer = "IsSetOffer"
        case isStrikethrough = "IsStrikethrough"
        case imageUrl = "ImageUrl"
        case largeImageUrl = "LargeImageUrl"
        case duration = "Duration"
    }
}
