//
//  OfferInfoFacebookViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 16/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// OfferInfoTitleViewCell set the cell wich has facebook link for information table
class OfferInfoFacebookViewCell: UITableViewCell {

    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var websiteLabel: UILabel!
    @IBOutlet var websiteText: UITextView!
    @IBOutlet var splitter: UIView!
    @IBOutlet var facebookImage: UIImageView!
    
    var facebookPage : String!
    var facebookPageID : String!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        let facebookImage = UIImage(named: "ic_facebook_empty")?.withRenderingMode(.alwaysTemplate)
        self.facebookImage.tintColor = Colors.bckg_main_color_new
        self.facebookImage.image = facebookImage
        
        titleLabel.font = UIFont.boldSystemFont(ofSize: 15.0)
        titleLabel.textColor = Colors.sectionTextColor
        splitter.backgroundColor = Colors.sectionTextUnderlineColor
        
        let onWebsiteClick = UITapGestureRecognizer(target: self, action: #selector(OfferInfoFacebookViewCell.onWebsiteClick))
        websiteText.isUserInteractionEnabled = true
        websiteText.addGestureRecognizer(onWebsiteClick)
        
        let onFacebookClick = UITapGestureRecognizer(target: self, action: #selector(OfferInfoFacebookViewCell.onFacebookClick))
        self.facebookImage.isUserInteractionEnabled = true
        self.facebookImage.addGestureRecognizer(onFacebookClick)
        
        let padding = websiteText.textContainer.lineFragmentPadding
        websiteText.textContainerInset = UIEdgeInsetsMake(0, -padding, 0, -padding)
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @objc func onWebsiteClick(sender:UITapGestureRecognizer) {
        //restartApp = false
        UIApplication.shared.openURL(NSURL(string: websiteLabel.text!)! as URL)
    }

    @objc func onFacebookClick(sender:UITapGestureRecognizer) {
        //restartApp = false
        UIApplication.shared.openURL(NSURL(string: "fb://profile/" + facebookPageID)! as URL)

    }
}
