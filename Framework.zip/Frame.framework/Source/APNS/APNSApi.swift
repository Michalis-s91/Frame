//
//  APNSApi.swift
//  RichReach2
//
//  Created by Eumbrella on 27/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// Web api for APNS. Sends requests for GCM registration to app server for iOS and notifies server when app receives notifications.
class APNSApi
{
    
    /// Registers user to our push notification server for iOS.
    ///
    /// - Parameters:
    ///   - userPhone: The user's telephone number.
    ///   - token: The device token id.
    /// - Throws: error
    static func sendGCMRegistrationToAppServerIOS(userPhone : String!, token : String!) throws
    {
        do
        {
            let httpRequest = HttpRequest()
            
            if(Bundle.main.bundleIdentifier! == APKsEnum.RichReach.rawValue)
            {
                try httpRequest.post(url: "\(ApiUrlDefaults.REGISTRATION_URL)AssignTokenToUser/",params:"&PhoneNumber=\(userPhone ?? "")&Token=\(token ?? ""))&PhoneType=2")
            }
            else
            {
                try httpRequest.post(url: "\(ApiUrlDefaults.REGISTRATION_URL)AssignTokenToUser/",params:"&PhoneNumber=\(userPhone ?? "")&Token=\(token ?? "")&ApkID=\(businessID!)&PhoneType=2")
            }
        }
        catch
        {
            throw Errors.error
        }
    }
    
    /// Notifies server that notification is been delivered.
    ///
    /// - Parameter campaignID:  The campaing ID.
    /// - Returns: The message "Notification error." when error occurredm otherwise nil.
    static func notifyServerAboutDelivery(campaignID : Int64) -> String!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "\(ApiUrlDefaults.REGISTRATION_URL)PostPushNotificationDelivery/",params:"&TelephoneNumber=\(localDatabase.getAppUser()?.phoneNumber ?? "")&CampaignID=\(campaignID)")
        }
        catch
        {
            return "Notification error."
        }
        return nil
    }
}
