//
//  TitleModel.swift
//  RichReach2
//
//  Created by Eumbrella on 24/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Holds information about title.
class TitleModel : Codable
{
    var id : Int!
    var title : String!
    var titleSize : Int!
    var titleFont : String!
    var titleColor : String!
    var titleBackgroundColor : String!
    var isTitleCentered : Bool!
    var splitterColor : String!
    var topPadding : Int!
    
    var isSection : Bool! = true
    var isSectionExpanded :  Bool! = true
    
    private enum CodingKeys : String, CodingKey {
        case id = "Id"
        case title = "Title"
        case titleSize = "TitleSize"
        case titleFont = "TitleFont"
        case titleColor = "TitleColor"
        case titleBackgroundColor = "BackgroundColor"
        case isTitleCentered = "IsTitleCentered"
        case splitterColor = "SplitterColor"
        case topPadding = "TopPadding"
        case isSection = "IsSection"
        case isSectionExpanded = "IsSectionExpanded"
    }
}
