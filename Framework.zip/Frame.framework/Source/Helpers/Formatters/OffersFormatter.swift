//
//  OffersFormatter.swift
//  RichReach2
//
//  Created by Eumbrella on 05/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Formatter for offers, it unpacked partners, unpacked opt in history, unpacked partner information, unpacked partner
/// offers, unpacked combo offer items and unpacked white label partner.
class OffersFormatter
{
    private static let  START_CHAR : Character = "["
    private static let END_CHAR : Character = "]"
    private static let SPLIT_CHAR : Character = "|"
    private static let PARAMETER_SPLIT_CHAR : Character = ","
    private static let PARAMETER_SPLIT_PLUS_CHAR : Character = "+"
    
    /// Get as input a string, un-pack it and returns a list of partners.
    ///
    /// - Parameter packageString: The input string.
    /// - Returns: A list of partners.
    /// - Throws: error
    static func unPackLoyaltyPartners(packageString : String) throws -> [PartnerModel]!
    {
        do
        {
            if(!packageString.contains(SPLIT_CHAR))
            {
                return nil
            }
            
            var partnersList : [PartnerModel] = []
            let startIndex = packageString.index(of: START_CHAR)
            let endIndex = packageString.index(of: END_CHAR)
            
            if(startIndex == nil || endIndex == nil)
            {
                throw Errors.error
            }
            
            let substring = packageString[startIndex! + 1..<endIndex!]
            let tokens = substring.split(separator: SPLIT_CHAR, omittingEmptySubsequences: false)
            
            for t in tokens
            {
                if (!isNullOrEmpty(string: String(t)))
                {
                    var subTokens = t.split(separator: PARAMETER_SPLIT_CHAR, omittingEmptySubsequences: false)
                    let alphaDateTime = subTokens[5]
                    
                    var currentPoints : String
                    
                    if(isNullOrEmpty(string: String(subTokens[6])))
                    {
                        currentPoints = ""
                    }
                    else
                    {
                        currentPoints = String(subTokens[6]) + " points"
                    }
                    
                    var hasOrderingEnabled = false
                    
                    if (!isNullOrEmpty(string: String(subTokens[7])))
                    {
                        var hasOrderingEnabledValue = 0
                        hasOrderingEnabledValue = Int(String(subTokens[7]))!
                        
                        if (hasOrderingEnabledValue > 0)
                        {
                            hasOrderingEnabled = true
                        }
                    }
                    
                    var optInDate : Date!
                    if(isNullOrEmpty(string: String(subTokens[5])))
                    {
                        optInDate = nil
                    }
                    else
                    {
                        optInDate = unStringDate(alphaDateTime : String(alphaDateTime))
                    }
                    
                    
                    var partnerModel = PartnerModel()
                    partnerModel.partnerID = (Int(subTokens[0]))!
                    partnerModel.name = String(subTokens[1])
                    partnerModel.imageUri = String(subTokens[2])
                    
                    if(subTokens[3] == "1")
                    {
                        partnerModel.IsFavourite = true
                    }
                    else
                    {
                        partnerModel.IsFavourite = false
                    }
                    
                    if(subTokens[4] == "1")
                    {
                        partnerModel.isRoot = true
                    }
                    else
                    {
                        partnerModel.isRoot = false
                    }
                    
                    if(!isNullOrEmpty(string: String(subTokens[5])))
                    {
                        partnerModel.optInDate = optInDate
                    }
                    else
                    {
                        //Date()
                    }
                    
                    partnerModel.loyaltyPoints = currentPoints
                    
                    let isLoyalty = isNullOrEmpty(string: currentPoints) || currentPoints == "" ? false : true
                    partnerModel.isLoyalty = isLoyalty
                    //partnerModel.item7.item2 = hasOrderingEnabled
                    
                    setOptInType(partner : &partnerModel)
                    
                    partnersList.append(partnerModel)
                }
                
            }
            
            return partnersList
        }
        catch
        {
            
        }
        
        return nil
    }
    
    /// Get as input a string, un-pack it and returns a list of partners.
    ///
    /// - Parameter packageString: The input string.
    /// - Returns: A list of partners.
    /// - Throws: error
    static func unPackAllPartners(packageString : String) throws -> [PartnerModel]!
    {
        do
        {
            if(!packageString.contains(SPLIT_CHAR))
            {
                return nil
            }
            
            var partnersList : [PartnerModel] = []
            let startIndex = packageString.index(of: START_CHAR)
            let endIndex = packageString.index(of: END_CHAR)
            
            if(startIndex == nil || endIndex == nil)
            {
                throw Errors.error
            }
            
            let substring = packageString[startIndex! + 1..<endIndex!]
            let tokens = substring.split(separator: SPLIT_CHAR, omittingEmptySubsequences: false)
            
            for t in tokens
            {
                if (!isNullOrEmpty(string: String(t)))
                {
                    var subTokens = t.split(separator: PARAMETER_SPLIT_CHAR, omittingEmptySubsequences: false)
                    let alphaDateTime = subTokens[5]
                    
                    var currentPoints : String
                    
                    if(isNullOrEmpty(string: String(subTokens[6])))
                    {
                        currentPoints = ""
                    }
                    else
                    {
                        currentPoints = String(subTokens[6]) + " points"
                    }
                    
                    var hasOrderingEnabled = false
                    
                    if (!isNullOrEmpty(string: String(subTokens[7])))
                    {
                        var hasOrderingEnabledValue = 0
                        hasOrderingEnabledValue = Int(String(subTokens[7]))!
                        
                        if (hasOrderingEnabledValue > 0)
                        {
                            hasOrderingEnabled = true
                        }
                    }
                    
                    var optInDate : Date!
                    if(isNullOrEmpty(string: String(subTokens[5])))
                    {
                        optInDate = nil
                    }
                    else
                    {
                        optInDate = unStringDate(alphaDateTime : String(alphaDateTime))
                    }
                    
                    
                    var partnerModel = PartnerModel()
                    partnerModel.partnerID = (Int(subTokens[0]))!
                    partnerModel.name = String(subTokens[1])
                    partnerModel.imageUri = String(subTokens[2])
                    
                    if(subTokens[3] == "1")
                    {
                        partnerModel.IsFavourite = true
                    }
                    else
                    {
                        partnerModel.IsFavourite = false
                    }
                    
                    if(subTokens[4] == "1")
                    {
                        partnerModel.isRoot = true
                    }
                    else
                    {
                        partnerModel.isRoot = false
                    }
                    
                    if(!isNullOrEmpty(string: String(subTokens[5])))
                    {
                        partnerModel.optInDate = optInDate
                    }
                    else
                    {
                        //Date()
                    }
                    
                    partnerModel.loyaltyPoints = currentPoints
                    
                    let isLoyalty = isNullOrEmpty(string: currentPoints) || currentPoints == "" ? false : true
                    partnerModel.isLoyalty = isLoyalty
                    //partnerModel.item7.item2 = hasOrderingEnabled
                    
                    partnerModel.industryID = (Int(subTokens[8]))!
                    partnerModel.industryName = String(subTokens[9])
                    partnerModel.apkCode = String(subTokens[10])
                    
                    if(subTokens[11] == "1")
                    {
                        partnerModel.isEmbeded = true
                    }
                    else
                    {
                        partnerModel.isEmbeded = false
                    }
                    
                    if(subTokens[12] == "1")
                    {
                        partnerModel.isUserEmbededAppTester = true
                    }
                    else
                    {
                        partnerModel.isUserEmbededAppTester = false
                    }
                    
                    if(subTokens[13] == "1")
                    {
                        partnerModel.isBranded = true
                    }
                    else
                    {
                        partnerModel.isBranded = false
                    }
                    
                    partnerModel.administratorID = (Int64(subTokens[14]))!
                    
                    setOptInType(partner : &partnerModel)
                    
                    partnersList.append(partnerModel)
                }
                
            }
            
            return partnersList
        }
        catch
        {
            
        }
        
        return nil
    }
    
    /// Gets as input a string and convert string to Date.
    ///
    /// - Parameter alphaDateTime: The input string.
    /// - Returns: The converted date.
    static func unStringDate(alphaDateTime : String) -> Date
    {
        var numDate : Date!
        if (isNullOrEmpty(string: alphaDateTime))
        {
            return numDate
        }
        
        var dateTimeArray = alphaDateTime.split(separator: " ")
        let alphaDate = String(dateTimeArray[0])
        let alphaTime = dateTimeArray.count == 1 ? "00:00" : String(dateTimeArray[1])
        
        var alphaDateArray = alphaDate.split(separator: "/")
        if (alphaDateArray.count == 3)
        {
            var aYear : Int = Int(alphaDateArray[2])!
            if (aYear < 100)
            {
                aYear = aYear + 2000
            }
            
            var alphaTimeArray = alphaTime.split(separator: ":")
            let aHour = Int(alphaTimeArray[0])
            let aMinutes = Int(alphaTimeArray[1])
            
            let calendar = Calendar.current
            var components = calendar.dateComponents([.hour, .minute, .month, .year, .day, .second, .weekOfMonth], from: Date())
            components.year = aYear
            components.month = (Int(alphaDateArray[1]))! - 1
            components.day = Int(alphaDateArray[0])
            components.hour = aHour
            components.minute = aMinutes
            components.second = 0
            
            numDate = calendar.date(from: components)
        }
        
        return numDate
    }
    
    /// Sets opt in type (if is root, favourite or none).
    ///
    /// - Parameter partner: The partner model.
    private static func setOptInType(partner : inout PartnerModel)
    {
        if (partner.isRoot)
        {
            partner.optInType = NSLocalizedString("OptInTypePreferred", comment: "")
        }
        else if (partner.IsFavourite)
        {
            partner.optInType = NSLocalizedString("OptInTypeFavourite", comment: "")
        }
        else
        {
            partner.optInType = NSLocalizedString("OptInTypeNone", comment: "")
        }
    }
    
    /// Get as input a string, un-pack it and returns a list of optin history objects.
    ///
    /// - Parameter packageString: The input string.
    /// - Returns: A list of optin history objects.
    /// - Throws: error
    static func unPackOptInHistory(packageString : String) throws -> [OptInHistoryModel]!
    {
        do
        {
            var optInHistoryList : [OptInHistoryModel] = []
            let startIndex = packageString.index(of: START_CHAR)
            let endIndex = packageString.index(of: END_CHAR)
            
            if(startIndex == nil || endIndex == nil)
            {
                throw Errors.error
            }
            
            let substring = packageString[startIndex! + 1..<endIndex!]
            
            let tokens = substring.split(separator: SPLIT_CHAR)
            
            for t in tokens
            {
                if (!isNullOrEmpty(string: String(t)))
                {
                    var subTokens = t.split(separator : PARAMETER_SPLIT_CHAR, omittingEmptySubsequences: true)
                    optInHistoryList.append( OptInHistoryModel(name: String(subTokens[0]), timeStamp: String(subTokens[1]), isFavourite: subTokens[2] == "True" ? true : false))
                }
            }
            
            return optInHistoryList
            
        }
        catch
        {
        }
        
        return nil
    }
    
    /// Get as input a string, un-pack it and returns a list of partner data objects.
    ///
    /// - Parameter packageString: The input string.
    /// - Returns: A list of partner data objects.
    static func unPackPartnerInformation(packageString : String) -> [PartnersInformation]!
    {
        do
        {
            var tupleList : [PartnersInformation] = []
            let startIndex = packageString.index(of: START_CHAR)
            let endIndex = packageString.index(of: END_CHAR)
            
            if(startIndex == nil || endIndex == nil)
            {
                throw Errors.error
            }
            
            let substring = packageString[startIndex! + 1..<endIndex!]
            let tokens = substring.split(separator: SPLIT_CHAR)
            
            for t in tokens
            {
                if (!isNullOrEmpty(string: String(t)))
                {
                    var subTokens = t.split(separator : PARAMETER_SPLIT_PLUS_CHAR, omittingEmptySubsequences: false)
                    var partnerData : PartnersInformation
                    
                    if(subTokens.count == 5)
                    {
                        partnerData = PartnersInformation(item1: String(subTokens[0]), item2: String(subTokens[1]), item3: String(subTokens[2]), item4: String(subTokens[3]), item5: String(subTokens[4]))
                    }
                    else if(subTokens.count == 3)
                    {
                        partnerData = PartnersInformation(item1: String(subTokens[0]), item2: String(subTokens[1]), item3: String(subTokens[2]))
                    }
                    else if(subTokens.count == 2)
                    {
                        partnerData = PartnersInformation(item1: String(subTokens[0]), item2: String(subTokens[1]))
                    }
                    else
                    {
                        partnerData = PartnersInformation(item1: String(subTokens[0]), item2: String(subTokens[1]), item3: String(subTokens[2]), item4: String(subTokens[3]), item5: String(subTokens[4]), item6: String(subTokens[5]))
                    }
                    
                    tupleList.append(partnerData)
                }
            }
            
            return tupleList
        }
        catch
        {
            
        }
        
        return nil
    }
    
    /// Get as input a string, un-pack it and returns a list of offers data objects.
    ///
    /// - Parameters:
    ///   - packageString: The input string.
    ///   - localDB: The local database.
    /// - Returns: A list of offers data objects.
    /// - Throws: error
    static func unPackPartnerOffers(packageString : String, localDB : Database) throws -> [OfferModel]!
    {
        do
        {
            if(!packageString.contains(SPLIT_CHAR))
            {
                return nil
            }
            
            var tupleList : [OfferModel] = []
            let startIndex = packageString.index(of: START_CHAR)
            let endIndex = packageString.index(of: END_CHAR)
            
            if(startIndex == nil || endIndex == nil)
            {
                throw Errors.error
            }
            
            let substring = packageString[startIndex! + 1..<endIndex!]
            let tokens = substring.split(separator: SPLIT_CHAR)
            
            for t in tokens
            {
                if (!isNullOrEmpty(string: String(t)))
                {
                    var subTokens = t.split(separator : PARAMETER_SPLIT_CHAR, omittingEmptySubsequences: false)
                    let offerModel = OfferModel()
                    
                    offerModel.Description = String(subTokens[0])
                    offerModel.imageUrl = String(subTokens[1])
                    offerModel.originalPrice = String(subTokens[2])
                    offerModel.offerDescription = String(subTokens[3])
                    offerModel.offerNewPrice = String(subTokens[4])
                    offerModel.isStrikethrough = subTokens[5] == "1" ? true : false
                    offerModel.appOfferID = (subTokens[6] as NSString).integerValue
                    offerModel.partnerName = String(subTokens[7])
                    offerModel.isPrivate = subTokens[8] == "1" ? true : false
                    offerModel.isItemWatched = (localDB.isFavouriteOffer( offerID: offerModel.appOfferID))
                    
                    let offerType = Int(subTokens[9])
                    
                    if (offerType == OfferTypeEnum.GeneralOffer.rawValue)
                    {
                        offerModel.isGeneralOffer = true
                    }
                    else
                    {
                        offerModel.isGeneralOffer = false
                    }
                    
                    if (offerType == OfferTypeEnum.PriceListOffer.rawValue)
                    {
                        offerModel.isPriceListOffer = true
                    }
                    else
                    {
                        offerModel.isPriceListOffer = false
                    }
                    
                    if (offerType == OfferTypeEnum.SetOffer.rawValue)
                    {
                        offerModel.isSetOffer = true
                    }
                    else
                    {
                        offerModel.isSetOffer = false
                    }
                    
                    if (offerType == OfferTypeEnum.NoPriceToShow.rawValue)
                    {
                        offerModel.isNoPriceToShowOffer = true
                    }
                    else
                    {
                        offerModel.isNoPriceToShowOffer = false
                    }
                    
                    offerModel.duration = String(subTokens[10])
                    
                    if (subTokens.count > 11)
                    {
                        offerModel.largeImageUrl = String(subTokens[11])
                    }
                    else
                    {
                        offerModel.largeImageUrl = nil
                    }
                    
                    tupleList.append(offerModel)
                }
            }
            
            return tupleList
        }
        catch
        {

        }
        
        return nil
    }
    
    /// Get as input a string, un-pack it and returns a PartnerTuple object.
    ///
    /// - Parameter packageString: The input string.
    /// - Returns: A PartnerTuple object.
    /// - Throws: error
    static func unPackWhiteLabelPartner(packageString : String) throws -> PartnerTuple!
    {
        do
        {
            var tuplePartner : PartnerTuple
            let startIndex = packageString.index(of: OffersFormatter.START_CHAR)
            let endIndex = packageString.index(of: OffersFormatter.END_CHAR)
            
            if(startIndex == nil || endIndex == nil)
            {
                throw Errors.error
            }
            
            let substring = packageString[startIndex! + 1..<endIndex!]
            var tokens = substring.split(separator: OffersFormatter.PARAMETER_SPLIT_CHAR)
            tuplePartner = PartnerTuple(item1: Int(String(tokens[0]))!,item2: String(tokens[1]),item3: String(tokens[2]),item4: String(tokens[3]))
            return tuplePartner
        }
        catch
        {
            
        }
        
        return nil
    }

    /// Get as input a string, un-pack it and returns a list of OfferItemModel objects.
    ///
    /// - Parameter packageString: The input string.
    /// - Returns: A list of OfferItemModel objects.
    /// - Throws: error
    static func unPackComboOfferItems(packageString : String) throws -> [OfferItemModel]!
    {
        do
        {
            if(!packageString.contains(SPLIT_CHAR))
            {
                return nil
            }
            
            var tupleList : [OfferItemModel] = []
            let startIndex = packageString.index(of: START_CHAR)
            let endIndex = packageString.index(of: END_CHAR)
            
            if(startIndex == nil || endIndex == nil)
            {
                throw Errors.error
            }
            
            let substring = packageString[startIndex! + 1..<endIndex!]
            let tokens = substring.split(separator: SPLIT_CHAR)
            
            for t in tokens
            {
                if (!isNullOrEmpty(string: String(t)))
                {
                    var subTokens = t.split(separator : PARAMETER_SPLIT_CHAR, omittingEmptySubsequences: false)
                    let offerItemModel = OfferItemModel()
                    offerItemModel.itemID = Int(String(subTokens[0]))
                    offerItemModel.name = String(subTokens[1])
                    offerItemModel.imageUrl = String(subTokens[2])
                    
                    tupleList.append(offerItemModel)
                }
            }
            
            return tupleList
        }
        catch
        {
            
        }
        
        return nil
    }
}



