//
//  EmailValidationStatus.swift
//  RichReach
//
//  Created by Eumbrella on 25/04/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

class EmailValidationStatus : Codable
{
    var isSuccessful : Bool!
    var doesEmailBelongToAnotherUser : Bool!
    var validationResponse : String!
    
    private enum CodingKeys : String, CodingKey {
        case isSuccessful = "IsSuccessful"
        case doesEmailBelongToAnotherUser = "DoesEmailBelongToAnotherUser"
        case validationResponse = "ValidationResponse"
    }
}
