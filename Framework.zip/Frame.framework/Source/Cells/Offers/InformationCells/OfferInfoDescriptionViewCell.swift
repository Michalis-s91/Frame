//
//  OfferInfoLabel.swift
//  RichReach2
//
//  Created by Eumbrella on 09/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// OfferInfoDescriptionViewCell set the cell wich has title and description for information table
class OfferInfoDescriptionViewCell: UITableViewCell {

    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var splitter: UIView!
    @IBOutlet var descriptionLabel: UILabel!
    @IBOutlet var descriptionText: UITextView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        titleLabel.font = UIFont.boldSystemFont(ofSize: 15.0)
        titleLabel.textColor = Colors.sectionTextColor
        splitter.backgroundColor = Colors.sectionTextUnderlineColor
        
        let padding = descriptionText.textContainer.lineFragmentPadding
        descriptionText.textContainerInset = UIEdgeInsetsMake(0, -padding, 0, -padding)
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
