//
//  CustomerBrandStores.swift
//  RichReach2
//
//  Created by Eumbrella on 09/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// The following class is for the GetOrderProductInformation API call.
class CustomerBrandStores
{
    //@SerializedName("StoreOfferForAppID")
    var storeOfferForAppID : Int!
    //@SerializedName("AddressID")
    var addressID : Int!
    //@SerializedName("Quantity")
    var quantity : Int!
    //@SerializedName("IsOutOfStock")
    var isOutOfStock : Int!
    //@SerializedName("IsAvailable")
    var isAvailable : Int!
    //@SerializedName("Description")
    var description : String!
    //@SerializedName("Address")
    var address : String!
    //@SerializedName("ContactPhone")
    var contactPhone : String!
    //@SerializedName("Longitude")
    var longitude : String!
    //@SerializedName("Latitude")
    var latitude : String!
}
