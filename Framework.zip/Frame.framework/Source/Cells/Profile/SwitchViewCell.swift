//
//  SwitchViewCell.swift
//  RichReach
//
//  Created by Eumbrella on 25/02/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

class SwitchViewCell: UITableViewCell {
    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var descriptionLabel: UILabel!
    @IBOutlet var switchView: UISwitch!
    @IBOutlet var cellBackground: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
