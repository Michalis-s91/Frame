//
//  SearchViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 18/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import Kingfisher

class SearchViewController: ViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var searchTextField: UITextField!
    @IBOutlet var resultsLabel: UILabel!
    @IBOutlet var productsLoadingLabel: UILabel!
    @IBOutlet var listTableView: UITableView!
    @IBOutlet var closeImage: UIImageView!
    @IBOutlet var closeImageClickView: UIView!
    @IBOutlet var searchImage: UIImageView!
    @IBOutlet var activityIndicator: UIActivityIndicatorView!
    @IBOutlet var line: UIView!
    @IBOutlet var indicatorView: UIView!
    @IBOutlet var activityIndicator2: UIActivityIndicatorView!
    
    @IBOutlet var indicatorViewWidth: NSLayoutConstraint!
    
    var products : [ProductModel]! = []
    var allProducts : [ProductModel]! = []
    var barcodes : [String] = []
    var allBarcodes : [BarcodeModel]! = []
    var lock = NSObject()
    var task : LocalTask!
    var isProductSelected = false
    let serialQueue = DispatchQueue(label: "com.test.mySerialQueue")
    
    var generalSearchView : GeneralSearchView!
    var isEmbeded = false
    var timer = Timer()
    var searchText : String!
    
    static var isViewDissapeared = false
    
    override func viewDidLoad() {
        SearchViewController.isViewDissapeared = false
        
        if(!isEmbeded)
        {
            super.viewDidLoad()
        }
        
        generalSearchView = viewsDB.getGeneralSearchView()
        
        indicatorViewWidth.constant = 0
        
        self.prepare(for:  UIStoryboardSegue(identifier: "a",source: UIViewController() ,destination: UIViewController()), sender: nil)
        
        activityIndicator.startAnimating()
        let task = LocalTask(viewController : self, action : loadAllProductsAsync, displayToast : true, toastMessage : NSLocalizedString("waitMessage", comment: ""))
        task.start()
        
        //allBarcodes = productsDB.getBarcodes()
        
        listTableView.rowHeight = UITableViewAutomaticDimension
        listTableView.tableFooterView = UIView()
        listTableView.delegate = self
        listTableView.dataSource = self
        
        searchTextField.addTarget(self, action: #selector(textFieldDidChange(_:isFromRefresh:)), for: .editingChanged)
        
        searchTextField.textColor = UIColor(generalSearchView.searchTextColor)
        searchTextField.font = UIFont(name: generalSearchView.searchFont, size: CGFloat(generalSearchView.searchTextSize))
        
        resultsLabel.textColor = UIColor(generalSearchView.searchTextColor)
        resultsLabel.font = UIFont(name: generalSearchView.searchFont, size: CGFloat(generalSearchView.searchTextSize))
        
        productsLoadingLabel.textColor = UIColor(generalSearchView.searchTextColor)
        productsLoadingLabel.font = UIFont(name: generalSearchView.searchFont, size: CGFloat(generalSearchView.searchTextSize))
        
        line.backgroundColor = UIColor(generalSearchView.tintColor)
        
        closeImage.image = UIImage(named: "ic_dialog_close")?.withRenderingMode(.alwaysTemplate)
        closeImage.tintColor = UIColor(generalSearchView.tintColor)
        
        //searchImage.image = UIImage(named: "ic_search")?.withRenderingMode(.alwaysTemplate)
        searchImage.image = UIImage(named: "")?.withRenderingMode(.alwaysTemplate)
        searchImage.tintColor = UIColor(generalSearchView.tintColor)
        self.searchImage.transform = CGAffineTransform(rotationAngle: (270.0 * CGFloat(Double.pi)) / 180.0)

        let onImageClick = UITapGestureRecognizer(target: self, action: #selector(SearchViewController.onCloseImageClick))
        closeImageClickView.isUserInteractionEnabled = true
        closeImageClickView.addGestureRecognizer(onImageClick)
        
        let onSearchClick = UITapGestureRecognizer(target: self, action: #selector(SearchViewController.onSearchClick))
        searchImage.isUserInteractionEnabled = true
        searchImage.addGestureRecognizer(onSearchClick)
        
        hideKeyboardWhenTappedAround()
        
        self.navigationItem.leftBarButtonItem?.image = UIImage(named: "ic_back")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if(isEmbeded)
        {
            isViewPushed = true
        }
        super.viewWillAppear(animated)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return products.count
    }
    
    override func viewDidAppear(_ animated: Bool) {
        isProductSelected = false
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        SearchViewController.isViewDissapeared = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        KingfisherManager.shared.cache.clearMemoryCache()
        KingfisherManager.shared.cache.clearDiskCache()
        KingfisherManager.shared.cache.cleanExpiredDiskCache()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
        
        /*let data2 = parameterizationDatabase.getNavImage(apk: APK)
        
        if(data2 != nil)
        {
            let suggestImage  = UIImage(data: data2!)?.resizeImage2(UIScreen.main.bounds.size.width/3, navigationHeight, opaque: false).withRenderingMode(.alwaysOriginal)
            let suggestButton = UIButton()
            suggestButton.frame = CGRect(x: UIScreen.main.bounds.size.width/2  - UIScreen.main.bounds.size.width/6 - 60 , y: 0, width: UIScreen.main.bounds.size.width/3, height: navigationHeight)
            suggestButton.setBackgroundImage(suggestImage, for: .normal)
            suggestButton.setBackgroundImage(suggestImage, for: .normal)
            suggestButton.setBackgroundImage(suggestImage, for: .highlighted)
            suggestButton.setBackgroundImage(suggestImage, for: .focused)
            suggestButton.setBackgroundImage(suggestImage, for: .selected)
            let suggestButtonContainer = UIView(frame: suggestButton.frame)
            suggestButtonContainer.addSubview(suggestButton)
            let suggestButtonItem  = UIBarButtonItem(customView: suggestButtonContainer)
            
            if(self.navigationController?.navigationItem.leftBarButtonItems?.count == 1)
            {
                self.navigationController?.navigationItem.leftBarButtonItems![0] = suggestButtonItem
            }
            else if(self.navigationController?.navigationItem.leftBarButtonItems?.count == 2)
            {
                self.navigationController?.navigationItem.leftBarButtonItems![1] = suggestButtonItem
            }
        }*/
    }
    
    func loadAllProductsAsync()
    {
        self.allProducts = productsDB.getProducts(sortProducts : true)
        self.products = self.allProducts
        
        if(self.products == nil || self.products.count == 0)
        {
            let emptyProduct : ProductModel! = ProductModel()
            self.products.append(emptyProduct)
        }
        
        if(!isActivityActive(viewController: self))
        {
            return
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            if(self.products == nil || self.products.count == 0)
            {
                self.resultsLabel.text = "Results (0)"
            }
            else
            {
                self.resultsLabel.text = "Results (\(self.allProducts.count))"
            }
            
            if(statusDB.getStatus(apk: APK) != nil && !statusDB.getStatus(apk: APK)!.areProductsSaved)
            {
                self.productsLoadingLabel.text = NSLocalizedString("productLoading", comment: "")
                self.startTimer()
            }
            
            
            self.listTableView.reloadData()
            self.activityIndicator.removeFromSuperview()
        })
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if(products.count > 0)
        {
            let item = products[indexPath.row]
            
            if(products.count == 1 && isNullOrEmpty(string: item.webDescription))
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "search_cell_no_available") as! SearchNotAvailableViewCell

                if(!isNullOrEmpty(string: searchTextField.text) && ((searchTextField.text!.lowercased().range(of: ("dior")) != nil) || (searchTextField.text!.lowercased().range(of: ("chanel")) != nil)))
                {
                    cell.label.text = "Information about \(searchTextField.text ?? "") products is not available yet"
                }
                else if(self.allProducts != nil && self.allProducts.count > 0)
                {
                    cell.label.text = "Information about \(searchTextField.text ?? "") is not available"
                }
                else
                {
                    cell.label.text = "No available items"
                }
                    
                cell.selectionStyle = .none
                return cell
            }
            else
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "search_cell") as! SearchViewCell
                cell.productLabel.text =  "\(String(item.searchPoints)) \(item.manufacturerName!) \(item.webDescription!)"
                
                if(item.webDescription == nil)
                {
                    cell.productImageHeight.constant = 0
                }
                else
                {
                    cell.productImageHeight.constant = 50
                    
                    
                    if(!isNullOrEmpty(string : item.imageA))
                    {
                        let url = URL(string: percentEncode(s: item.imageA))
                        //cell.productImage.kf.setImage(with: url )
                        
                        cell.productImage.kf.setImage(with: url, completionHandler: {
                            (image, error, cacheType, imageUrl) in
                            // image: Image? `nil` means failed
                            // error: NSError? non-`nil` means failed
                            // cacheType: CacheType
                            //                  .none - Just downloaded
                            //                  .memory - Got from memory cache
                            //                  .disk - Got from disk cache
                            // imageUrl: URL of the image
                            
                            /*if(SearchViewController.isViewDissapeared)
                            {
                                return
                            }
                            
                            if let index = tableView.indexPathsForVisibleRows?.first?.row {
                                if((indexPath.row > (index - 15)) && (indexPath.row < (index + 15)))
                                {
                                    cell.productImage.kf.setImage(with: url )
                                }
                            }*/
                            
                            
                            /*var cellRect = self.listTableView.rectForRow(at: indexPath)
                            cellRect.size.height =  cellRect.size.height
                            let completelyVisible = self.listTableView.bounds.contains(cellRect)
                            
                            if (completelyVisible) {
                               cell.productImage.kf.setImage(with: url )
                            }*/
                        })
                    }
                    else if(!isNullOrEmpty(string : item.imageB))
                    {
                        let url = URL(string: percentEncode(s: item.imageB))
                        cell.productImage.kf.setImage(with: url )
                    }
                }
                
                cell.productLabel.textColor = UIColor(generalSearchView.itemTextColor)
                cell.productLabel.font = UIFont(name: generalSearchView.itemFont, size: CGFloat(generalSearchView.itemTextSize))
                cell.backgroundColor = UIColor(generalSearchView.itemBackgroundColor)
                
                cell.selectionStyle = .none
                return cell
            }
        }
        
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var item = products[indexPath.row]
            
        if(item.itemNo != nil && !isProductSelected)
        {
            isProductSelected = true
            //removeSpecialcharacters(product : &item)
            
            DispatchQueue.main.async(execute: {() -> Void in
                let productView = showProductView(productModel: item, viewController : self)
                self.navigationController?.pushViewController(productView, animated: true)
            })
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(products.count == 1 && products[0].webDescription == nil)
        {
            return tableView.frame.size.height
        }
        else
        {
            return UITableViewAutomaticDimension
        }
    }
    
    var previousTextSize = 0
    var previousWords = 0
    @objc func textFieldDidChange(_ textField: UITextField, isFromRefresh : Bool = false) {
        //self.indicatorViewWidth.constant = UIScreen.main.bounds.size.width
        //self.activityIndicator2.startAnimating()
        
        if(!isFromRefresh)
        {
            self.resultsLabel.text =  " "//"Results ()"
        }
        
        var allProductsTemp = allProducts
        let text = textField.text
        searchText = textField.text?.condenseWhitespace()
        
        if(isNullOrEmpty(string: text))
        {
            self.products = self.allProducts
            
            if(self.products == nil || self.products.count == 0)
            {
                self.resultsLabel.text = "Results (0)"
                let emptyProduct : ProductModel! = ProductModel()
                self.products.append(emptyProduct)
            }
            else
            {
                self.resultsLabel.text = "Results (\(self.products.count))"
            }
            
            self.listTableView.reloadData()
            self.listTableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: false)
            self.indicatorViewWidth.constant = 0
            self.activityIndicator2.stopAnimating()
            
            return
        }
        
        DispatchQueue.global(qos: .background).async {
            var shouldExit = false
            let words = self.searchText.split(separator: " ")
            
            var productsTemp : [ProductModel]! = []
            self.previousTextSize = (text?.count)!
            self.previousWords = (text?.count)!
            var isFirstWord = true
            
            for w in words
            {
                var word : String! = String(w)
                
                if(String(word)[word.count - 1] == " ")
                {
                    word.removeLast()
                }
                else if (String(word)[0] == " ")
                {
                   word.removeFirst()
                }
                
                if(isFirstWord)
                {
                    for i in 0..<allProductsTemp!.count
                    {
                        let p = allProductsTemp![i]
     
                        if(i % 1000 == 0)
                        {
                            DispatchQueue.main.async(execute: {() -> Void in
                                if(self.searchTextField.text != text)
                                {
                                    shouldExit = true
                                    return
                                }
                                
                                self.products.removeAll()
                                self.products = productsTemp

                                
                                self.indicatorViewWidth.constant = 0
                                self.activityIndicator2.stopAnimating()
                                
                                self.reload(tableView: self.listTableView, isFromRefresh: isFromRefresh)
                            })
                            
                            if(shouldExit)
                            {
                                return
                            }
                        }
                        
                        if(String(word).isNumeric && String(p.itemNo).lowercased().range(of: (word)) != nil)
                        {
                            productsTemp.append(p)
                        }
                        else if(
                            ((p.webDescription != nil && p.webDescription.count != 0 && p.webDescription.lowercased().range(of: (word)) != nil))
                                //|| (!isNullOrEmpty(string: p.barcode) && p.barcode.lowercased().range(of: (text)!) != nil)
                                //|| (!isNullOrEmpty(string: p.productDescription) && p.productDescription.lowercased().range(of: (text)!) != nil)
                                || ( p.manufacturerName != nil && p.manufacturerName.count != 0 && p.manufacturerName.lowercased().range(of: (word)) != nil)
                                //|| (String(p.itemNo).lowercased().range(of: (word)) != nil))
                                || (p.ingredientsText != nil && p.ingredientsText.count != 0 && p.ingredientsText.lowercased().range(of: (word)) != nil)
                            //|| (!isNullOrEmpty(string: p.overViewText) && p.overViewText.lowercased().range(of: (word)) != nil)
                            //|| (!isNullOrEmpty(string: p.howToUseText) && p.howToUseText.lowercased().range(of: (word)) != nil)
                            /*|| (self.barcodes.contains(String(p.itemNo)))*/
                            )
                        {
                            productsTemp.append(p)
                        }
                    }
                }
                else
                {
                    var productsTemp2 : [ProductModel]! = []
                    
                    for i in 0..<productsTemp!.count
                    {
                        let p = productsTemp![i]
                        
                        if(i % 1000 == 0)
                        {
                            DispatchQueue.main.async(execute: {() -> Void in
                                if(self.searchTextField.text != text)
                                {
                                    shouldExit = true
                                    return
                                }
                                
                                self.products.removeAll()
                                self.products = productsTemp2
                                
                                
                                self.indicatorViewWidth.constant = 0
                                self.activityIndicator2.stopAnimating()
                                
                                self.reload(tableView: self.listTableView, isFromRefresh: isFromRefresh)
                            })
                            
                            if(shouldExit)
                            {
                                return
                            }
                        }
                        
                        if(String(word).isNumeric && String(p.itemNo).lowercased().range(of: (word)) != nil)
                        {
                            productsTemp2.append(p)
                        }
                        else if(
                            ((p.webDescription != nil && p.webDescription.count != 0 && p.webDescription.lowercased().range(of: (word)) != nil))
                                //|| (!isNullOrEmpty(string: p.barcode) && p.barcode.lowercased().range(of: (text)!) != nil)
                                //|| (!isNullOrEmpty(string: p.productDescription) && p.productDescription.lowercased().range(of: (text)!) != nil)
                                || ( p.manufacturerName != nil && p.manufacturerName.count != 0 && p.manufacturerName.lowercased().range(of: (word)) != nil)
                                //|| (String(p.itemNo).lowercased().range(of: (word)) != nil))
                                || (p.ingredientsText != nil && p.ingredientsText.count != 0 && p.ingredientsText.lowercased().range(of: (word)) != nil)
                            //|| (!isNullOrEmpty(string: p.overViewText) && p.overViewText.lowercased().range(of: (word)) != nil)
                            //|| (!isNullOrEmpty(string: p.howToUseText) && p.howToUseText.lowercased().range(of: (word)) != nil)
                            /*|| (self.barcodes.contains(String(p.itemNo)))*/
                            )
                        {
                            productsTemp2.append(p)
                        }
                    }
                    
                    productsTemp = productsTemp2
                }
                
                if(isFirstWord)
                {
                    isFirstWord = false
                }
            }
            
            if(!isActivityActive(viewController: self))
            {
                return
            }
            
            
            //productsTemp = Array(Set(productsTemp))
            
            //var shouldReturn  = false6
            DispatchQueue.main.async(execute: {() -> Void in
                if(self.searchTextField.text != text)
                {
                    return
                }
                
                var productsTemp3 = productsTemp.clone()
                
                
                if(productsTemp3 != nil && productsTemp3.count > 0)
                {
                    for p in productsTemp3
                    {
                        if let range : [Range<String.Index>]! = String(p.itemNo).ranges(of: "\\b\(self.searchText!)\\b", options: [.regularExpression, .caseInsensitive])
                        {
                            if(range!.count > 0)
                            {
                                p.searchPoints = p.searchPoints + 10
                            }
                        }
                        
                        if let range : [Range<String.Index>]! = p.webDescription.ranges(of: "\\b\(self.searchText!)\\b", options: [.regularExpression, .caseInsensitive])
                        {
                            if(range!.count > 0)
                            {
                                p.searchPoints = p.searchPoints + 10
                                
                                var endIndex = p.webDescription.index(of: "\\b\(self.searchText!)\\b", options: [.regularExpression, .caseInsensitive])
                                var startIndex = p.webDescription.startIndex
                                var c = p.webDescription.count
                                var b = p.webDescription.distance(from: p.webDescription.startIndex, to: endIndex!)
                                var points = Double(Double(p.webDescription.count - p.webDescription.distance(from: p.webDescription.startIndex, to: endIndex!)) / Double(p.webDescription.count)) * 5.0
                                p.searchPoints = p.searchPoints + Int(points)
                            }
                        }
                        
                        if let range : [Range<String.Index>]! = p.manufacturerName.ranges(of: "\\b\(self.searchText!)\\b", options: [.regularExpression, .caseInsensitive])
                        {
                            if(range!.count > 0)
                            {
                                p.searchPoints = p.searchPoints + 10
                            }
                        }
                        
                        if let range : [Range<String.Index>]! = p.ingredientsText.ranges(of: "\\b\(self.searchText!)\\b", options: [.regularExpression, .caseInsensitive])
                        {
                            if(range!.count > 0)
                            {
                                p.searchPoints = p.searchPoints + 10
                            }
                        }
                        
                        
                        for w in words
                        {
                            var word : String! = String(w)
                            
                            if(String(word).isNumeric && String(p.itemNo).lowercased().range(of: (word)) != nil)
                            {
                                if let range : [Range<String.Index>]! = String(p.itemNo).ranges(of: "\\b\(word!)\\b", options: [.regularExpression, .caseInsensitive])
                                {
                                    if(range!.count > 0)
                                    {
                                        p.searchPoints = p.searchPoints + 20
                                    }
                                    else
                                    {
                                        p.searchPoints = p.searchPoints + 10
                                    }
                                }
                                
                            }
                            else if(p.webDescription != nil && p.webDescription.count != 0 && p.webDescription.lowercased().range(of: (word)) != nil)
                            {
                                if let range : [Range<String.Index>]! = p.webDescription.ranges(of: "\\b\(word!)\\b", options: [.regularExpression, .caseInsensitive])
                                {
                                    if(range!.count > 0)
                                    {
                                        p.searchPoints = p.searchPoints + 6
                                    }
                                    else
                                    {
                                        p.searchPoints = p.searchPoints + 3
                                    }
                                }
                            }
                            else if (p.manufacturerName != nil && p.manufacturerName.count != 0 && p.manufacturerName.lowercased().range(of: (word)) != nil)
                            {
                                if let range : [Range<String.Index>]! = p.manufacturerName.ranges(of: "\\b\(word!)\\b", options: [.regularExpression, .caseInsensitive])
                                {
                                    if(range!.count > 0)
                                    {
                                        p.searchPoints = p.searchPoints + 4
                                    }
                                    else
                                    {
                                        p.searchPoints = p.searchPoints + 2
                                    }
                                }
                            }
                            else if(p.ingredientsText != nil && p.ingredientsText.count != 0 && p.ingredientsText.lowercased().range(of: (word)) != nil)
                            {
                                if let range : [Range<String.Index>]! = p.ingredientsText.ranges(of: "\\b\(word!)\\b", options: [.regularExpression, .caseInsensitive])
                                {
                                    if(range!.count > 0)
                                    {
                                        p.searchPoints = p.searchPoints + 2
                                    }
                                    else
                                    {
                                        p.searchPoints = p.searchPoints + 1
                                    }
                                }
                            }
                        }
                    }
                    
                    productsTemp3 = productsTemp3.sorted(by: { $0.searchPoints > $1.searchPoints })
                }
                
                self.products.removeAll()
                self.products = productsTemp3
                
                if(self.products == nil || self.products.count == 0)
                {
                    self.resultsLabel.text = "Results (0)"
                    let emptyProduct : ProductModel! = ProductModel()
                    self.products.append(emptyProduct)
                }
                else
                {
                    self.resultsLabel.text = "Results (\(self.products.count))"
                }
                
                self.indicatorViewWidth.constant = 0
                self.activityIndicator2.stopAnimating()
                

                self.reload(tableView: self.listTableView, isFromRefresh: isFromRefresh)

            })
        }
    }
    
    func startTimer()
    {
        self.timer = Timer.scheduledTimer(timeInterval: TimeInterval(5), target: self,   selector: (#selector(SearchViewController.updateTimer)), userInfo: nil, repeats: true)
    }
    
    func stopTimer()
    {
        DispatchQueue.main.async(execute: {() -> Void in
            self.timer.invalidate()
            self.productsLoadingLabel.text = ""
        })
    }
    
    func reload(tableView: UITableView, isFromRefresh : Bool) {
        if(isFromRefresh)
        {
            let contentOffset = tableView.contentOffset
            tableView.reloadData()
            tableView.layoutIfNeeded()
            tableView.setContentOffset(contentOffset, animated: false)
        }
        else
        {
            tableView.reloadData()
            tableView.layoutIfNeeded()
            tableView.setContentOffset(CGPoint(x: CGFloat(0), y: CGFloat(0)), animated: false)
        }
    }
    
    @objc func updateTimer(){
        DispatchQueue.global(qos: .background).async {
            self.allProducts = productsDB.getProducts(sortProducts : true)
            
            if(isNullOrEmpty(string: self.searchText))
            {
                self.products = self.allProducts
                
                if(self.products == nil || self.products.count == 0)
                {
                    let emptyProduct : ProductModel! = ProductModel()
                    self.products.append(emptyProduct)
                }
                
                if(!isActivityActive(viewController: self))
                {
                    return
                }
                
                DispatchQueue.main.async(execute: {() -> Void in
                    if(self.products == nil || self.products.count == 0)
                    {
                        self.resultsLabel.text = "Results (0)"
                    }
                    else
                    {
                        self.resultsLabel.text = "Results (\(self.allProducts.count))"
                    }
                    
                    
                    self.reload(tableView: self.listTableView, isFromRefresh: true)
                    self.activityIndicator.removeFromSuperview()
                })
            }
            else
            {
                DispatchQueue.main.async(execute: {() -> Void in
                    self.textFieldDidChange(self.searchTextField, isFromRefresh: true)
                })
            }
            
            if(statusDB.getStatus(apk: APK) != nil && statusDB.getStatus(apk: APK)!.areProductsSaved)
            {
                self.stopTimer()
            }
            
        }
    }
    
    func showIndicator()
    {
        
    }
    
    @objc func onCloseImageClick(sender:UITapGestureRecognizer) {
        if(!isNullOrEmpty(string: self.resultsLabel.text))
        {
            searchTextField.text = ""
            self.products = self.allProducts
            
            
            if(self.products == nil || self.products.count == 0)
            {
                self.resultsLabel.text = "Results (0)"
                let emptyProduct : ProductModel! = ProductModel()
                self.products.append(emptyProduct)
            }
            else
            {
                self.resultsLabel.text = "Results (\(self.products.count))"
            }
            
            self.listTableView.reloadData()
            self.listTableView.scrollToRow(at: IndexPath(item: 0, section: 0), at: .top, animated: false)
            self.indicatorViewWidth.constant = 0
            self.activityIndicator2.stopAnimating()
        }
    }
    
    @objc func onSearchClick(sender:UITapGestureRecognizer) {
        /*if(!isNullOrEmpty(string: searchTextField.text))
        {
            self.resultsLabel.text = "Results ()"
            self.indicatorViewWidth.constant = UIScreen.main.bounds.size.width
            self.activityIndicator2.startAnimating()
            let text = searchTextField.text
            
            DispatchQueue.global(qos: .background).async {
                //self.barcodes.removeAll()
                let words = text?.lowercased().split(separator: " ")
                
                var productsTemp : [ProductModel]! = []
                
                
                self.previousTextSize = (text?.count)!
                self.previousWords = (words?.count)!
                for word in words!
                {
                    for p in self.allProducts
                    {
                        if(
                            ((!isNullOrEmpty(string: p.webDescription) && p.webDescription.lowercased().range(of: (word)) != nil))
                                //|| (!isNullOrEmpty(string: p.barcode) && p.barcode.lowercased().range(of: (text)!) != nil)
                                //|| (!isNullOrEmpty(string: p.productDescription) && p.productDescription.lowercased().range(of: (text)!) != nil)
                                || (!isNullOrEmpty(string: p.manufacturerName) && p.manufacturerName.lowercased().range(of: (word)) != nil)
                                || (String(p.itemNo).lowercased().range(of: (word)) != nil))
                            || (!isNullOrEmpty(string: p.ingredientsText) && p.ingredientsText.lowercased().range(of: (word)) != nil)
                            || (!isNullOrEmpty(string: p.overViewText) && p.overViewText.lowercased().range(of: (word)) != nil)
                            || (!isNullOrEmpty(string: p.howToUseText) && p.howToUseText.lowercased().range(of: (word)) != nil)
                            /*|| (self.barcodes.contains(String(p.itemNo)))*/
                        {
                            productsTemp.append(p)
                        }
                    }
                }
                
                
                
                self.products = Array(Set(productsTemp))
                
                
                DispatchQueue.main.async(execute: {() -> Void in
                    if(self.searchTextField.text != text)
                    {
                        return
                    }
                    
                    if(self.products == nil || self.products.count == 0)
                    {
                        self.resultsLabel.text = "Results (0)"
                        let emptyProduct : ProductModel! = ProductModel()
                        self.products.append(emptyProduct)
                    }
                    else
                    {
                        self.resultsLabel.text = "Results (\(self.products.count))"
                    }
                    
                    self.indicatorViewWidth.constant = 0
                    self.activityIndicator2.stopAnimating()
                    
                    self.listTableView.reloadData()
                })
            }
            
        }
        else
        {
            self.products = self.allProducts
            
            if(self.products == nil || self.products.count == 0)
            {
                self.resultsLabel.text = "Results (0)"
                let emptyProduct : ProductModel! = ProductModel()
                self.products.append(emptyProduct)
            }
            else
            {
                self.resultsLabel.text = "Results (\(self.products.count))"
            }
            
            self.indicatorViewWidth.constant = 0
            self.activityIndicator2.stopAnimating()
            
            self.listTableView.reloadData()
        }*/
    }
    
    
    
    @IBAction func backPressed(_ sender: UIBarButtonItem) {
        isViewPushed = false
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func displayHelpDialog(_ sender: UIBarButtonItem) {
        let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController()! as! MessageDialog
        self.present(dialog,animated:true)
        dialog.setDialogView(title: NSLocalizedString("searchHelpDialogTitle", comment: ""), description: NSLocalizedString("searchHelpDialogMessage", comment: ""), buttonName: NSLocalizedString("ok", comment: ""), dismissWhenClickOutside: true)
    }
    
    
}
