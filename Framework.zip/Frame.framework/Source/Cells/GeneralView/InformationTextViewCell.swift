//
//  InformationTextViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 18/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// InformationTextViewCell is a cell that is been used for showing text with title.
class InformationTextViewCell2: InformationTextViewCell {
    //@IBOutlet var imageHeight: NSLayoutConstraint!
    //@IBOutlet var imageWidth: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        let padding = descriptionText.textContainer.lineFragmentPadding
        descriptionText.textContainerInset = UIEdgeInsetsMake(0, -padding, 0, -padding)
        // Configure the view for the selected state
    }

}

class InformationTextViewCell: UITableViewCell {
    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var splitter: UIView!
    @IBOutlet var descriptionText: UITextView!
    @IBOutlet var imageText: UIImageView!
    
    @IBOutlet var titleWidth: NSLayoutConstraint!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        let padding = descriptionText.textContainer.lineFragmentPadding
        descriptionText.textContainerInset = UIEdgeInsetsMake(0, -padding, 0, -padding)
        // Configure the view for the selected state
    }
    
}
