//
//  PartnerCodeVerificationEnum.swift
//  RichReach2
//
//  Created by Eumbrella on 21/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// PartnerCodeVerificationEnum is used to partner code verification type (e.g. UserNotFound).
enum PartnerCodeVerificationEnum : Int
{
    case UserNotFound = -1
    case WrongPartnerCode = -2
    case ServiceAccessError = -3
}
