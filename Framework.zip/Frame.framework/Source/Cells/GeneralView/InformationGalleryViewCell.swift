//
//  InformationGalleryViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 17/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class InformationCarouselViewCell: UITableViewCell, UIScrollViewDelegate {
    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var previousImage: UIImageView!
    @IBOutlet var nextImage: UIImageView!
    @IBOutlet var imageGallery: UIScrollView!
    @IBOutlet var previousView: UIView!
    @IBOutlet var nextView: UIView!
    
    var urls : [String]!
    var titles : [String]!
    var currentIndex = 0
    var isImagePressed = false
    
    var duration : Int = 0
    var interval : Int = 4
    var timer = Timer()
    
    var isManual : Bool! = true
    var isAutomatic : Bool! = true
    var isScrollingEnabled : Bool! = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.imageGallery.delegate = self
        //previousView.isHidden = true
        
        let image = UIImage(named: "ic_left_drawer_expand")?.withRenderingMode(.alwaysTemplate)
        previousImage.image = image
        nextImage.image = image
        
        previousImage.tintColor = UIColor.white
        nextImage.tintColor = UIColor.white
        
        roundCorners(.allCorners, radius: 10, view: previousView)
        roundCorners(.allCorners, radius: 10, view: nextView)
        
        previousView.transform = CGAffineTransform(rotationAngle: CGFloat(-Double.pi))
        
        
        let onPreviousClick = UITapGestureRecognizer(target: self, action: #selector(OfferInfoComboViewCell.onPreviousClick))
        previousImage.isUserInteractionEnabled = true
        previousImage.addGestureRecognizer(onPreviousClick)
        
        let onNextClick = UITapGestureRecognizer(target: self, action: #selector(OfferInfoComboViewCell.onNextClick))
        nextImage.isUserInteractionEnabled = true
        nextImage.addGestureRecognizer(onNextClick)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        if (!isManual)
        {
            previousView.isHidden = true
            nextView.isHidden = true
        }
        
        if(!isScrollingEnabled)
        {
            imageGallery.isScrollEnabled = false
        }
        
        if(isAutomatic)
        {
            timer = Timer.scheduledTimer(timeInterval: TimeInterval(interval), target: self,   selector: (#selector(InformationCarouselViewCell.updateTimer)), userInfo: nil, repeats: true)
        }
    }
    
    @objc func onPreviousClick (sender:UITapGestureRecognizer) {
        isImagePressed = true
        timer.invalidate()
        
        DispatchQueue.global(qos: .background).async {
            sleep(3)
            DispatchQueue.main.async(execute: {() -> Void in
                self.timer = Timer.scheduledTimer(timeInterval: TimeInterval(self.interval), target: self,   selector: (#selector(InformationCarouselViewCell.updateTimer)), userInfo: nil, repeats: true)
            })
        }
        
        if(currentIndex == 0)
        {
            currentIndex = urls.count - 1
        }
        else
        {
            currentIndex -= 1
        }

        self.titleLabel.text = titles[currentIndex]
        UIView.animate(withDuration: 1, animations: {
            self.imageGallery.setContentOffset(CGPoint(x: CGFloat(self.currentIndex) * self.imageGallery.frame.width, y: 0), animated: false)
            //self.carusel.setContentOffset(CGPoint(x: CGFloat((self.duration / self.interval) % self.imagesUrl.count ) * self.carusel.frame.width, y: 0), animated: false)
        })
        
    }
    
    @objc func onNextClick (sender:UITapGestureRecognizer) {
        timer.invalidate()
        
        DispatchQueue.global(qos: .background).async {
            sleep(3)
            DispatchQueue.main.async(execute: {() -> Void in
                self.timer = Timer.scheduledTimer(timeInterval: TimeInterval(self.interval), target: self,   selector: (#selector(InformationCarouselViewCell.updateTimer)), userInfo: nil, repeats: true)
            })
        }
        
        showNextImage()
    }
    
    func showNextImage()
    {
        isImagePressed = true
        
        if(currentIndex == urls.count - 1 )
        {
            currentIndex = 0
        }
        else
        {
            currentIndex += 1
        }
        
        self.titleLabel.text = titles[currentIndex]
        UIView.animate(withDuration: 1, animations: {
            self.imageGallery.setContentOffset(CGPoint(x: CGFloat(self.currentIndex) * self.imageGallery.frame.width, y: 0), animated: false)
            //self.carusel.setContentOffset(CGPoint(x: CGFloat((self.duration / self.interval) % self.imagesUrl.count ) * self.carusel.frame.width, y: 0), animated: false)
        })
        

    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let page = Int(scrollView.contentOffset.x / scrollView.frame.size.width)
        currentIndex = page
        self.titleLabel.text = titles[currentIndex]
    }
    
    func setCarusel()
    {
        DispatchQueue.main.async(execute: {() -> Void in
            self.titleLabel.text = self.titles[0]
            
            for i in 0..<self.urls.count
            {
                let image = self.urls[i]
                let url = URL(string: percentEncode(s: image))
                let imageView : UIImageView = UIImageView()
                imageView.kf.setImage(with: url)
                
                imageView.frame = CGRect(x: CGFloat(i) * self.imageGallery.frame.width , y: 0, width: self.imageGallery.frame.width, height: self.imageGallery.frame.size.height)
                self.imageGallery.addSubview(imageView)
            }
            self.imageGallery.contentSize.width = self.imageGallery.frame.width * CGFloat(self.urls.count)
        })
    }

    @objc func updateTimer(){
        showNextImage()
    }
}

class GalleryItem
{
    var url : String!
    var title : String!
    var isLastItem : Bool! = false
    
    init(title : String, url : String)
    {
        self.url = url
        self.title = title
    }
}
