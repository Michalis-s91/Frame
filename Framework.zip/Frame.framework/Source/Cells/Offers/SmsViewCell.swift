//
//  SmsViewCell.swift
//  RichReach
//
//  Created by Eumbrella on 27/02/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import UIKit

class SmsViewCell: UITableViewCell {

    @IBOutlet var headerLabel: UILabel!
    @IBOutlet var bodyLabel: UILabel!
    @IBOutlet var seenLabel: UILabel!
    
    var tableView : UITableView!
    var offer : OfferModel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        let onClickAlreadyRegistered = UITapGestureRecognizer(target: self, action: #selector(self.onSmsClick))
        bodyLabel.isUserInteractionEnabled = true
        bodyLabel.addGestureRecognizer(onClickAlreadyRegistered)
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @objc func onSmsClick(_ sender:UITapGestureRecognizer) {
        if(bodyLabel.numberOfLines == 0)
        {
            bodyLabel.numberOfLines = 5
        }
        else
        {
            bodyLabel.numberOfLines = 0
        }
        
        offer.isSeen = true
        tableView.reloadData()
        
        DispatchQueue.global(qos: .background).async {
            OfferItemsWebApi.markCampaignAsOpened(campaignID : self.offer.campaignID, phoneNumber : (localDatabase.getAppUser()?.phoneNumber)!)
        }
    }

}
