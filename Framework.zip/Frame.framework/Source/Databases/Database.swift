//
//  Database.swift
//  RichReach2
//
//  Created by Eumbrella on 14/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import SQLite

/// Database is used for creating, updating and accessing the local database and it's tables.
class Database: NSObject {
    
    var database : Connection!
    
    let appUserTable = Table("AppUsers")
    let appUserTable2 = Table("AppUserTable2")
    let partnerTable = Table("Partner")
    let offerTable = Table("Offer")
    let acceptedAPKs = Table("AcceptedAPKsTable")
    let verifiedAPKs = Table("VerifiedAPKsTable")
    let registeredAPKs = Table("RegisteredAPKsTable")
    let acceptNewsTable = Table("AcceptedNewsTable")
    
    let pushNotificationsTable = ("PushNotifications")
    let id = Expression<Int>("id")
    let apk = Expression<String>("apk")
    let data  = Expression<Data>("data")
    
    let clientID = Expression<Int64>("clientID")
    let bussinessID = Expression<Int64>("bussinessID")
    let bussinessIDnew = Expression<Int>("bussinessIDnew")
    let verifiedDate = Expression<String>("verifiedDate")
    let isBlocked = Expression<Bool>("isBlocked")
    let registeredDate = Expression<String>("registeredDate")
    let lastUpdateDate = Expression<String>("lastUpdateDate")
    let confirmDate = Expression<String>("confirmDate")
    let lastConfirmDate = Expression<String>("lastConfirmDate")
    let acceptDate = Expression<String>("acceptDate")
    
    var synchronized = Synchronized()
    var lock = NSObject()
    
    var version = 2
    
    override init(){
        do{
            let documentDirectory = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let fileUrl = documentDirectory.appendingPathComponent("localDatabase").appendingPathExtension("sqlite3")
            self.database = try Connection(fileUrl.path)
        } catch {
            print(error)
        }
    }
    
    /// Checks if database need to be upgraded, and upgrade it if needed.
    func checkForUpgrade()
    {
        createTables()
     
        switch database.userVersion {
        case 0:
            upgradeToVersion1()
        case 1:
            upgradeToVersion2()
        default:
            break
        }
        
        database.userVersion = version
    }
    
    
    func upgradeToVersion1()
    {
        do
        {
            createAppUserTable()
            
            var appUser = getAppUser()

            if(appUser != nil)
            {
                addAppUser(appUser: appUser!)
            }
            //addAPKAppUser(clientID: ClientIDs.BeautyLine.rawValue, appUser: appUser!)
            
        }
        catch
        {
            print(error)
        }
    }
    
    func upgradeToVersion2()
    {
        do
        {
            var appUser = getAppUser()
            
            if(appUser != nil)
            {
                appUser?.isUserRegisteredToAPNS = false
                updateAppUser(appUser: appUser!)
            }
        }
        catch
        {
            print(error)
        }
    }
    
    /// Creates the database tables.
    func createTables()
    {
        //let deleteTable = self.appUserTable.drop()
        
        //Create app users table
        /*let createAppUsersTable = self.appUserTable.create { (table) in
            table.column(self.id, primaryKey: true)
            table.column(self.data)
        }
        
        do {
            //try self.database.run(deleteTable)
        } catch {
            print(error)
        }
        
        do {
            try self.database.run(createAppUsersTable)
            print("Table created")
        } catch {
            print(error)
        }*/
        
        createAppUserTable()
        
        //Create partner table
        let createPartnerTable = self.partnerTable.create { (table) in
            table.column(self.id, primaryKey: true)
            table.column(self.data)
        }
        
        do {
            try self.database.run(createPartnerTable)
            print("Table created")
        } catch {
            print(error)
        }
        
        //Create offers(wish list) table
        let createOfferTable = self.offerTable.create { (table) in
            table.column(self.id, primaryKey: true)
            table.column(self.data)
        }
        
        do {
            try self.database.run(createOfferTable)
            print("Table created")
        } catch {
            print(error)
        }
        
        
        //Create accepted apk's table
        let createAcceptedAPKsTable = self.acceptedAPKs.create { (table) in
            table.column(self.bussinessID, primaryKey: true)
            table.column(self.acceptDate)
        }
        
        do {
            try self.database.run(createAcceptedAPKsTable)
            print("Table created")
        } catch {
            print(error)
        }
        
        //Create registered apk's table
        let createVerifiedAPKsTable = self.verifiedAPKs.create { (table) in
            table.column(self.bussinessID, primaryKey: true)
            table.column(self.verifiedDate)
            table.column(self.confirmDate)
            table.column(self.isBlocked)
        }
        
        do {
            try self.database.run(createVerifiedAPKsTable)
            print("Table created")
        } catch {
            print(error)
        }
        
        //Create registered apk's table
        let createRegisteredAPKsTable = self.registeredAPKs.create { (table) in
            table.column(self.bussinessID, primaryKey: true)
            table.column(self.registeredDate)
            table.column(self.lastUpdateDate)
            table.column(self.lastConfirmDate)
        }
        
        do {
            try self.database.run(createRegisteredAPKsTable)
            print("Table created")
        } catch {
            print(error)
        }
        
        
        let createAcceptedNewsTable = self.acceptNewsTable.create { (table) in
            table.column(self.bussinessID, primaryKey: true)
            table.column(self.data)
        }
        
        do {
            try self.database.run(createAcceptedNewsTable)
            print("Table created")
        } catch {
            print(error)
        }
    }
    
    func createAppUserTable()
    {
        let createAppUsersTable2 = self.appUserTable2.create { (table) in
            table.column(self.bussinessIDnew, primaryKey: true)
            table.column(self.data)
        }
        
        do {
            try self.database.run(createAppUsersTable2)
            print("Table created")
        } catch {
            print(error)
        }
    }
    
    /// Check if database is created and the app user is added in it.
    ///
    /// - Returns: True if there user is saved in the database, otherwise false.
    func isCreated() -> Bool
    {
        objc_sync_enter(lock)
        var isCreated = false
        
        do
        {
            let users = try self.database.prepare(self.appUserTable2)
            
            if (users != nil)
            {
                for user in users {
                    let data = user[self.data]
                    let jsonDecoder = JSONDecoder()
                    let appUser = try jsonDecoder.decode(AppUser.self, from: data)
                    
                    if(appUser == nil)
                    {
                        isCreated = false
                    }
                    else
                    {
                        isCreated = true
                    }
                }
            }
            else
            {
                isCreated = false
            }
        }
        catch
        {
            isCreated = false
        }
        
        objc_sync_exit(lock)
        return isCreated
        
    }
    
    /// Adds the app user to the AppUsers table.
    ///
    /// - Parameter appUser: The app user.
    func addAppUser(appUser : AppUser)
    {
        objc_sync_enter(lock)
        do {
            let jsonEncoder = JSONEncoder()
            let jsonData = try jsonEncoder.encode(appUser)
            //let json = String(data: jsonData, encoding: String.Encoding.utf16)
            
            let insertAppUser = self.appUserTable2.insert(or: .replace,
                                                          self.bussinessIDnew <- businessID,
                                                          self.data <- (jsonData))
            
            try self.database.run(insertAppUser)
            print("App user added")
            
        }
        catch
        {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    
    func getAppUserOld() -> AppUser?
    {
        objc_sync_enter(lock)
        var appUser = AppUser()
        
        do {
            var users : AnySequence<Row>! = try self.database.prepare(self.appUserTable)
            
            for user in users {
                let data = user[self.data]
                let jsonDecoder = JSONDecoder()
                appUser = try jsonDecoder.decode(AppUser.self, from: data)
                users = nil
                objc_sync_exit(lock)
                return appUser
            }
        } catch {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getAppUser() -> AppUser?
    {
        objc_sync_enter(lock)
        var appUser = AppUser()

        do {
            var users = try self.database.prepare(self.appUserTable2.filter(self.bussinessIDnew == businessID))
            
            for user in users {
                let data = user[self.data]
                let jsonDecoder = JSONDecoder()
                appUser = try jsonDecoder.decode(AppUser.self, from: data)
                //users = nil
                objc_sync_exit(lock)
                return appUser
            }
        } catch {
            print(error)
        }
        
        /*do {
            var users = try self.database.prepare(self.appUserTable2)
            
            for user in users {
                let data = user[self.data]
                let jsonDecoder = JSONDecoder()
                var appUserTemp = try jsonDecoder.decode(AppUser.self, from: data)
                
                if(appUserTemp.hasVerifiedPhoneNumber)
                {
                    appUser.phoneNumber = appUserTemp.phoneNumber
                    appUser.hasVerifiedPhoneNumber = true
                    appUser.mobilePhoneVerifiedIPAddress = appUserTemp.mobilePhoneVerifiedIPAddress
                    appUser.mobilePhoneVerifiedDatetime = appUserTemp.mobilePhoneVerifiedDatetime
                }
                //users = nil
                addAppUser(appUser: appUser)
                
                objc_sync_exit(lock)
                return appUser
            }
        } catch {
            print(error)
        }*/
        
        objc_sync_exit(lock)
        
        return nil
    }
    
    func isPhoneNumberVerified(phoneNumber : String) -> Bool
    {
        objc_sync_enter(lock)
        var appUser = AppUser()
        
        do {
            var users = try self.database.prepare(self.appUserTable2)
            
            for user in users {
                let data = user[self.data]
                let jsonDecoder = JSONDecoder()
                appUser = try jsonDecoder.decode(AppUser.self, from: data)

                if(appUser.phoneNumber == phoneNumber && appUser.hasVerifiedPhoneNumber != nil && appUser.hasVerifiedPhoneNumber)
                {
                    objc_sync_exit(lock)
                    
                    var appUserTemp = appUser //getAppUser()
                    //appUserTemp?.phoneNumber = self.vissibleVerificationField.value
                    //appUserTemp?.hasVerifiedPhoneNumber = true
                    //appUserTemp?.mobilePhoneVerifiedIPAddress = appUser.mobilePhoneVerifiedIPAddress
                    //appUserTemp?.mobilePhoneVerifiedDatetime = appUser.mobilePhoneVerifiedDatetime
                    
                    appUserTemp.phoneNumber = appUser.phoneNumber
                    appUserTemp.hasVerifiedEmailAddress = false
                    appUserTemp.emailAddress = nil
                    
                    updateAppUser(appUser: appUserTemp)
                    return true
                }
            }
        } catch {
            print(error)
        }
        
        objc_sync_exit(lock)
        return false
    }
    
    func isEmailAddressVerified(emailAddress : String) -> Bool
    {
        objc_sync_enter(lock)
        var appUser = AppUser()
        
        do {
            var users = try self.database.prepare(self.appUserTable2)
            
            for user in users {
                let data = user[self.data]
                let jsonDecoder = JSONDecoder()
                appUser = try jsonDecoder.decode(AppUser.self, from: data)

                if(appUser.emailAddress == emailAddress && appUser.hasVerifiedEmailAddress != nil && appUser.hasVerifiedEmailAddress)
                {
                    objc_sync_exit(lock)
                    
                    var appUserTemp = getAppUser()
                    appUserTemp?.hasVerifiedEmailAddress = true
                    appUserTemp?.emailVerifiedIPAddress = appUser.emailVerifiedIPAddress
                    appUserTemp?.emailVerifiedDatetime = appUser.emailVerifiedDatetime
                    
                    appUserTemp?.emailAddress = appUser.emailAddress
                    
                    updateAppUser(appUser: appUserTemp!)
                    return true
                }
            }
        } catch {
            print(error)
        }
        
        objc_sync_exit(lock)
        return false
    }
    
    /*func copyAppUser()
    {
        objc_sync_enter(lock)
        var appUser = AppUser()
        
        do {
            var users = try self.database.prepare(self.appUserTable2.filter(self.bussinessIDnew == businessID))
            
            for user in users {
                let data = user[self.data]
                let jsonDecoder = JSONDecoder()
                appUser = try jsonDecoder.decode(AppUser.self, from: data)
                //users = nil
                if(!isNullOrEmpty(string: appUser.phoneNumber))
                {
                    objc_sync_exit(lock)
                    return
                }
            }
        } catch {
            print(error)
        }
        
        do {
            var users = try self.database.prepare(self.appUserTable2)
            
            for user in users
            {
                if((businessID == BusinessIDs.RichReach.rawValue && user[self.bussinessIDnew] != businessID) || (businessID != BusinessIDs.RichReach.rawValue && user[self.bussinessIDnew] == BusinessIDs.RichReach.rawValue) )
                {
                    let data = user[self.data]
                    let jsonDecoder = JSONDecoder()
                    var appUserTemp = try jsonDecoder.decode(AppUser.self, from: data)
                    
                    if(appUserTemp.hasVerifiedPhoneNumber)
                    {
                        DispatchQueue.global(qos: .background).async {
                            appUserTemp.phoneNumberCount =  UserProfileWebApi.getBusinessPhoneNumberCount(phoneNumber: appUserTemp.phoneNumber)
                            appUserTemp.emailAddressCount = UserProfileWebApi.getBusinessPhoneNumberEmailAddressCount(phoneNumber: appUserTemp.phoneNumber)
                            self.updateAppUser(appUser: appUserTemp)
                        }
                    }
                }
            }
        } catch {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        return
    }*/
    
    func isAPKAccepted(bussinessID : Int64) -> Bool!
    {
        objc_sync_enter(lock)
        
        do {
            let acceptededAPKs = try self.database.prepare(self.acceptedAPKs.filter(self.bussinessID == bussinessID))
            
            for v in acceptededAPKs {
                objc_sync_exit(lock)
                if(v[self.acceptDate] != "")
                {
                    return true
                }
                else
                {
                    return false
                }
            }
        } catch {
            print(error)
        }
        
        objc_sync_exit(lock)
        return false
    }
    
    func isAPKVerified(clientID : Int64) -> Bool!
    {
        print("in user profile")
        objc_sync_enter(lock)
        print("in user profile")
        
        do {
            let verifiedAPKs = try self.database.prepare(self.verifiedAPKs.filter(self.bussinessID == clientID))
            
            for v in verifiedAPKs {
                objc_sync_exit(lock)
                if(v[self.verifiedDate] != "")
                {
                    return true
                }
                else
                {
                    return false
                }
            }
        } catch {
            print(error)
        }
        
        objc_sync_exit(lock)
        return false
    }
    
    func deleteRegisteredAPK()
    {
        objc_sync_enter(lock)
        do{
            try self.database.run(self.verifiedAPKs.filter(self.bussinessID == clientID ).delete())
            try self.database.run(self.registeredAPKs.filter(self.bussinessID == clientID ).delete())
            
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    func isAPKPending(bussinessID : Int64) -> Bool!
    {
        objc_sync_enter(lock)
        
        do {
            let verifiedAPKs = try self.database.prepare(self.verifiedAPKs.filter(self.bussinessID == bussinessID))
            
            for _ in verifiedAPKs {
                objc_sync_exit(lock)
                return true
            }
        } catch {
            print(error)
        }
        
        objc_sync_exit(lock)
        return false
    }
    
    func isAPKBlocked(bussinessID : Int64) -> Bool!
    {
        objc_sync_enter(lock)
        
        do {
            let verifiedAPKs = try self.database.prepare(self.verifiedAPKs.filter(self.bussinessID == bussinessID))
            
            for v in verifiedAPKs {
                objc_sync_exit(lock)
                return v[self.isBlocked]
            }
        } catch {
            print(error)
        }
        
        objc_sync_exit(lock)
        return false
    }
    
    func isAPKRegistered(bussinessID : Int64) -> Bool!
    {
        objc_sync_enter(lock)
        
        do {
            let registeredAPKs = try self.database.prepare(self.registeredAPKs.filter(self.bussinessID == bussinessID))
            
            for _ in registeredAPKs {
                objc_sync_exit(lock)
                return true
            }
        } catch {
            print(error)
        }
        
        objc_sync_exit(lock)
        return false
    }
    
    /// Updates the app user.
    ///
    /// - Parameter appUser: The app user.
    func updateAppUser (appUser: AppUser)
    {
        objc_sync_enter(lock)
        var user : Table!
        do{
            let jsonEncoder = JSONEncoder()
            let jsonData = try jsonEncoder.encode(appUser)
            
             user = self.appUserTable2.filter(self.bussinessIDnew == businessID )
            let updateAppUser = user.update(self.data <- jsonData)
            
            try self.database.run(updateAppUser)
            print("App user updated")
        } catch {
            print(error)
        }
        
        user = nil
        objc_sync_exit(lock)
    }
    
    /*func updateAPKAppUser (clientID : Int64, appUser: AppUser)
    {
        objc_sync_enter(lock)
        var user : Table!
        do{
            let jsonEncoder = JSONEncoder()
            let jsonData = try jsonEncoder.encode(appUser)
            
            user = self.appUserTable2.filter(self.clientID == clientID )
            let updateAppUser = user.update(self.data <- jsonData)
            
            try self.database.run(updateAppUser)
            print("App user updated")
        } catch {
            print(error)
        }
        
        user = nil
        objc_sync_exit(lock)
    }*/
    
    /// Deletes the app user from the local database.
    func deleteAppUser()
    {
        objc_sync_enter(lock)
        let user = self.appUserTable.filter(self.id == 0 )
        let deleteAppUser = user.delete()
        
        do{
            try self.database.run(deleteAppUser)
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    /// Adds the app user to the AppUsers table.
    ///
    /// - Parameter appUser: The app user.
    func insertAcceptNews(bussinessID : Int64, acceptedNews : AcceptNewsModel)
    {
        objc_sync_enter(lock)
        do {
            let jsonEncoder = JSONEncoder()
            let jsonData = try jsonEncoder.encode(acceptedNews)
            //let json = String(data: jsonData, encoding: String.Encoding.utf16)
            
            let insertAppUser = self.acceptNewsTable.insert(self.bussinessID <- bussinessID , self.data <- (jsonData))
            
            try self.database.run(insertAppUser)
            print("Accepted news added")
            
        }
        catch
        {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    
    func getAcceptNews(bussinessID : Int64) -> AcceptNewsModel!
    {
        objc_sync_enter(lock)
        var acceptNewsModel = AcceptNewsModel()
        
        do {
            let acceptNews = try self.database.prepare(self.acceptNewsTable)
            
            for a in acceptNews {
                let data = a[self.data]
                let jsonDecoder = JSONDecoder()
                acceptNewsModel = try jsonDecoder.decode(AcceptNewsModel.self, from: data)
                objc_sync_exit(lock)
                return acceptNewsModel
            }
        } catch {
            print(error)
        }
        
        objc_sync_exit(lock)
        return AcceptNewsModel()
    }
    
    func updateAcceptNews (bussinessID: Int64, acceptNews : AcceptNewsModel)
    {
        objc_sync_enter(lock)
        do{
            let jsonEncoder = JSONEncoder()
            let jsonData = try jsonEncoder.encode(acceptNews)
            
            let user = self.acceptNewsTable.filter(self.bussinessID == bussinessID )
            let updateAcceptNews = user.update(self.data <- jsonData)
            
            try self.database.run(updateAcceptNews)
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    /// Insert partner to favourite partners array.
    ///
    /// - Parameter partner: The partner we want to add.
    func insertFavouritePartner(partner : PartnerModel)
    {
        objc_sync_enter(lock)
        let dbPartner = Partner()
        dbPartner.id = partner.id
        dbPartner.name = partner.name
        dbPartner.isRoot = partner.isRoot
        dbPartner.isFavourite = partner.IsFavourite
        dbPartner.information = partner.Information
        dbPartner.imageUri = partner.imageUri
        dbPartner.optInDate = partner.optInDate
        
        if(partner.storeInfo != nil)
        {
            
        }
        else
        {
            dbPartner.stores = nil
            dbPartner.addresses = nil
            dbPartner.phones = nil
        }
        
        dbPartner.imageLargeUri = partner.imageLargeUri
        dbPartner.website = partner.website
        
        do {
            let jsonEncoder = JSONEncoder()
            let jsonData = try jsonEncoder.encode(dbPartner)
            //let json = String(data: jsonData, encoding: String.Encoding.utf16)
            
            let insertFavouritePartner = self.partnerTable.insert(self.id <- dbPartner.id ,self.data <- (jsonData))
            
            try self.database.run(insertFavouritePartner)
            print("Favourite partner added")
            
        }
        catch
        {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    /// Deletes partner to favourite partners array using impout partner ID.
    ///
    /// - Parameter partnerID: The partner ID we want to delete.
    func deleteFavouritePartnerByID(partnerID : Int)
    {
        objc_sync_enter(lock)
        let partner = self.partnerTable.filter(self.id == partnerID )
        let deleteFavouritePartner = partner.delete()
        
        do{
            try self.database.run(deleteFavouritePartner)
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    /// Finds and returrns the favourite partner that has the inpur ID.
    ///
    /// - Parameter partnerID: The partner ID.
    /// - Returns: The favourite partner.
    func getFavouritePartner(partnerID : Int) -> Partner!
    {
        objc_sync_enter(lock)
        do {
            let favouritePartners = try self.database.prepare(self.partnerTable)
            
            for partner in favouritePartners {
                let id  = partner[self.id]
                if(id == partnerID)
                {
                    let data = partner[self.data]
                    let jsonDecoder = JSONDecoder()
                    let favouritePartner = try jsonDecoder.decode(Partner.self, from: data)
                    objc_sync_exit(lock)
                    return favouritePartner
                }
            }
        } catch {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    /// Insert offer to favourite offers table.
    ///
    /// - Parameter offer: The offer we want to add.
    func insertFavouriteOffer(offer : OfferModel)
    {
        objc_sync_enter(lock)
        do {
            let jsonEncoder = JSONEncoder()
            let jsonData = try jsonEncoder.encode(offer)
            //let json = String(data: jsonData, encoding: String.Encoding.utf16)
            
            let favouriteOffer = self.offerTable.insert(self.id <- offer.appOfferID ,self.data <- (jsonData))
            
            try self.database.run(favouriteOffer)
            print("Favourite offer added")
            
        }
        catch
        {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    func insertAcceptedAPK(bussinessID : Int64)
    {
        objc_sync_enter(lock)
        do {
            let formatter = DateFormatter()
            formatter.dateFormat = "dd/MM/yyyy HH:mm:ss"
            
            try self.database.run(self.acceptedAPKs.insert(self.bussinessID <- bussinessID,
                                                           self.acceptDate <- formatter.string(from: Date())))
            print("Accepted APK added")
        }
        catch
        {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    func insertPendingAPK(bussinessID : Int64)
    {
        objc_sync_enter(lock)
        do {
            let formatter = DateFormatter()
            formatter.dateFormat = "dd/MM/yyyy HH:mm:ss"
            
            try self.database.run(self.verifiedAPKs.insert(self.bussinessID <- bussinessID,
                                                           self.verifiedDate <- "",
                                                           self.confirmDate <- formatter.string(from: Date()),
                                                           self.isBlocked <- false))
            print("Pending APK added")
        }
        catch
        {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    func insertVerifiedAPK(bussinessID : Int64, isBlocked : Bool)
    {
        objc_sync_enter(lock)
        do {
            let formatter = DateFormatter()
            formatter.dateFormat = "dd/MM/yyyy HH:mm:ss"
            
            try self.database.run(self.verifiedAPKs.insert(or: .replace,
                                                           self.bussinessID <- bussinessID,
                                                           self.verifiedDate <- formatter.string(from: Date()),
                                                           self.confirmDate <- formatter.string(from: Date()),
                                                           self.isBlocked <- isBlocked))
            
            print("Verified APK added")
        }
        catch
        {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    func insertRegisteredAPK(bussinessID : Int64)
    {
        objc_sync_enter(lock)
        do {
            let formatter = DateFormatter()
            formatter.dateFormat = "dd/MM/yyyy HH:mm:ss"
            
            try self.database.run(self.registeredAPKs.insert(or: .replace,
                                                             self.bussinessID <- bussinessID,
                                                             self.registeredDate <- formatter.string(from: Date()),
                                                             self.lastUpdateDate <- "",
                                                             self.lastConfirmDate <- formatter.string(from: Date())))
            print("Registered APK added")
        }
        catch
        {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    func updateLastUpdateDate(bussinessID : Int64 ,lastUpdateDate : String)
    {
        objc_sync_enter(lock)
        do {
             try self.database.run(self.registeredAPKs.filter(self.bussinessID == bussinessID).update(self.lastUpdateDate <- lastUpdateDate))
        }
        catch
        {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    func updateLastConfirmDate(bussinessID : Int64 ,lastConfirmDate : String)
    {
        objc_sync_enter(lock)
        do {
            try self.database.run(self.registeredAPKs.filter(self.bussinessID == bussinessID).update(self.lastConfirmDate <- lastConfirmDate))
        }
        catch
        {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    /// Checks if input offer ID is included in favourites.
    ///
    /// - Parameter offerID: The offer ID.
    /// - Returns: True if offer is favourite, otherwise false.
    func isFavouriteOffer(offerID : Int) -> Bool
    {
        var result : Bool!
        
        objc_sync_enter(lock)
        let offer = getFavouriteOffer(offerID: offerID)
        if (offer != nil)
        {
            result = true
        }
        else
        {
            result = false
        }
        
        objc_sync_exit(lock)
        return result
    }
    
    /// Get as input offer ID and returns the specific offer if exists.
    ///
    /// - Parameter offerID: The offer ID
    /// - Returns: The offer
    func getFavouriteOffer(offerID : Int) -> Offer!
    {
        var offer : Offer!
        
        objc_sync_enter(lock)
        do {
            let favouriteOffers = try self.database.prepare(self.offerTable)
            
            for favouriteOffer in favouriteOffers {
                let id = favouriteOffer[self.id]
                if(id == offerID)
                {
                    let data = favouriteOffer[self.data]
                    let jsonDecoder = JSONDecoder()
                    offer = try jsonDecoder.decode(Offer.self, from: data)
                }
            }
        } catch {
            print(error)
        }
        
        objc_sync_exit(lock)
        return offer
    }
    
    /// Deletes offer from favourite.
    ///
    /// - Parameter offerID: The offer ID we want to delete.
    func deleteFavouriteOfferByID(offerID : Int)
    {
        objc_sync_enter(lock)
        let offer = self.offerTable.filter(self.id == offerID)
        let deleteFavouriteOffer = offer.delete()
        
        do{
            try self.database.run(deleteFavouriteOffer)
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    /// Returns all the favourite offers.
    ///
    /// - Returns: All favourite offers.
    func getAllFavouriteOffers() -> [Offer]
    {
        var allFavouriteOffers : [Offer] = []
        
        objc_sync_enter(lock)
        do {
            let favouriteOffers = try self.database.prepare(self.offerTable)
            
            for favouriteOffer in favouriteOffers {
                let data = favouriteOffer[self.data]
                let jsonDecoder = JSONDecoder()
                let offer = try jsonDecoder.decode(Offer.self, from: data)
                allFavouriteOffers.append(offer)
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return allFavouriteOffers
    }
}


