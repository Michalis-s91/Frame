//
//  SatusDB.swift
//  RichReach2
//
//  Created by Eumbrella on 27/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import SQLite

class StatusDB : NSObject
{
    let DATABASE_NAME = "StatusDB"
    
    var database : Connection!
    var lock = NSObject()
    var version = 0
    
    var statusTable = Table("StatusTable")
    
    //Status columns
    let apk = Expression<String>("apk")
    let areProductsSaved = Expression<Bool>("areProductsSaved")
    let productsPageNo = Expression<Int>("productsPageNo")
    let areBarcodesSaved = Expression<Bool>("areBarcodesSaved")
    let barcodesPageNo = Expression<Int>("productsPageNo")
    
    override init(){
        do{
            let documentDirectory = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let fileUrl = documentDirectory.appendingPathComponent(DATABASE_NAME).appendingPathExtension("sqlite3")
            self.database = try Connection(fileUrl.path)
        }
        catch
        {
            print(error)
        }
    }
    
    func checkForUpgrade()
    {
        createTables()
        
        if database.userVersion == 0 {
            
        }
        
        database.userVersion = version
    }
    
    /// Creates the products database tables.
    func createTables()
    {
        objc_sync_enter(lock)
        createsStatusTable()
        objc_sync_exit(lock)
    }
    
    /*********************************************************                  CREATES                  *********************************************************/
    func createsStatusTable()
    {
        let createsStatusTable = self.statusTable.create { (table) in
            table.column(self.apk, primaryKey : true)
            table.column(self.areProductsSaved)
            table.column(self.productsPageNo)
            table.column(self.areBarcodesSaved)
            table.column(self.barcodesPageNo)
            
        }
        
        do {
            try self.database.run(createsStatusTable)
        } catch {
            print(error)
        }
    }
    
    
    /*********************************************************                  GETS                  *********************************************************/
    func getProducts() -> StatusModel!
    {
        objc_sync_enter(lock)
        do {
            var statusModel : StatusModel = StatusModel()
            
            let status = try self.database.prepare(self.statusTable.filter(self.apk == APK ))
            
            for s in status {
                statusModel.areProductsSaved = s[self.areProductsSaved]
                statusModel.productsPageNo = s[self.productsPageNo]
                statusModel.areBarcodesSaved = s[self.areBarcodesSaved]
                statusModel.barcodesPageNo = s[self.barcodesPageNo]
                
                objc_sync_exit(lock)
                return statusModel
            }

        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
        
    }
    
    /*********************************************************                  UPDATES                  *********************************************************/
    func updateStatus (statusModel: StatusModel)
    {
        objc_sync_enter(lock)
        do{
            let status = self.statusTable.filter(self.apk == APK )
            let updateStatus = status.update(self.areProductsSaved <- statusModel.areProductsSaved,
                                              self.productsPageNo <- statusModel.productsPageNo,
                                              self.areBarcodesSaved <- statusModel.areBarcodesSaved,
                                              self.barcodesPageNo <- statusModel.barcodesPageNo)
            
            try self.database.run(updateStatus)
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    
}
