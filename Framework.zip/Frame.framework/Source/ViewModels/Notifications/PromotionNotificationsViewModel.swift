//
//  PromotionNotificationsViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 06/11/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

//
//  NotificationsViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 26/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// This ViewModel is associated with the NotificationsView which is responsible for displaying the push notifications
/// to the user. The ViewModel provides the functionality that is needed for loading and updating notifications from web api.
class PromotionNotificationsViewModel
{
    var pageToLoad = 1
    private var isNotificationsListEmpty : Bool!
    var IsNotificationsListEmpty : Bool!
    {
        get
        {
            return self.isNotificationsListEmpty
        }
        
        set(isNotificationsListEmpty)
        {
            self.isNotificationsListEmpty = isNotificationsListEmpty
            self.isNotificationsListNonEmpty = !isNotificationsListEmpty
        }
    }
    var isNotificationsListNonEmpty : Bool!
    var notificationsList : [PromotionModel]! = []
    var notificationClicked : NotificationClicked?  // This event is called when a notification is clicked.
    var dateFormatter =  DateFormatter()
    
    
    /// Constructor. Sets the date formatter.
    init()
    {
        dateFormatter.dateFormat = "dd/MM/yy"
    }
    
    
    /// Loads all push notifications from internet.
    func loadNotificationsList()
    {
        let appUser = localDatabase.getAppUser()
        var pushNotifications : [PromotionModel]!
        
        notificationsList.removeAll()
        do
        {
            if(appUser != nil)
            {
                let phoneNumber = appUser?.phoneNumber
                if(!isNullOrEmpty(string: phoneNumber))
                {
                    pushNotifications = try NotificationsWebApi.getPromotionNotificationOffers(userPhone: phoneNumber!)
                    
                    if (pushNotifications != nil && pushNotifications.count > 0)
                    {
                        isNotificationsListEmpty = false
                        
                        for pushNotification in pushNotifications
                        {
                            let notification = PromotionModel()
                            
                            notification.couponCode = pushNotification.couponCode
                            notification.imageUrl = pushNotification.imageUrl
                            notification.firstValidDate = pushNotification.firstValidDate
                            notification.lastValidDate = pushNotification.lastValidDate
                            notification.barcode = pushNotification.barcode
                            notification.shortDescription = pushNotification.shortDescription
                            notification.extendedDescription = pushNotification.extendedDescription
                            notification.termsAndConditions = pushNotification.termsAndConditions
                            notification.isSeen = pushNotification.isSeen
                            
                            notificationsList.append(notification)
                        }
                        
                        pageToLoad += 1
                        sortNotificationsList()
                    }
                    else
                    {
                        //notificationsList = []
                        IsNotificationsListEmpty = true
                    }
                }
            }
        }
        catch
        {
            
        }
    }
    
    
    /// Sorts the notification list descending by date and time the notifications have been received.
    func sortNotificationsList()
    {
        self.notificationsList = self.notificationsList.sorted(by: { dateFormatter.date(from: $0.firstValidDate)!  > dateFormatter.date(from: $1.firstValidDate)! })
    }
}
