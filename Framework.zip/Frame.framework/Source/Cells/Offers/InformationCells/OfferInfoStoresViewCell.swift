//
//  OfferInfoTableViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 09/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// OfferInfoStoresViewCell set the cell wich has store table for information table
class OfferInfoStoresViewCell: UITableViewCell,  UITableViewDelegate , UITableViewDataSource{

    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var splitter: UIView!
    @IBOutlet var notAvailableStoresLabel: UILabel!
    @IBOutlet var storesTableView: UITableView!
    
    
    var stores : [StoresInfo]!
    var navigationController : UINavigationController!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        titleLabel.font = UIFont.boldSystemFont(ofSize: 15.0)
        titleLabel.textColor = Colors.sectionTextColor
        splitter.backgroundColor = Colors.sectionTextUnderlineColor
        
        storesTableView.rowHeight = UITableViewAutomaticDimension
        storesTableView.tableFooterView = UIView()
        storesTableView.delegate = self
        storesTableView.dataSource = self
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return stores.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "stores_cell") as! StoresViewCell
        let store = stores[indexPath.row]
        
        cell.storeNameLabel.text = store.name
        cell.storePhoneLabel.text = store.phone
        cell.storeAddressLabel.text = store.address
        cell.storeLatitude = store.latitude
        cell.storeLongitude = store.longitude
        cell.address = store.address
        cell.navigationController = self.navigationController
        
        if(isNullOrEmpty(string: store.longitude) || isNullOrEmpty(string: store.latitude))
        {
            cell.mapImage.removeFromSuperview()
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        return cell
    }
    

}
