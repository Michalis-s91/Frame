//
//  UserGender.swift
//  BeautyLine
//
//  Created by Eumbrella on 18/12/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

enum UserGender : Int
{
    case Male = 0
    case Female = 1
}

