//
//  TabType.swift
//  RichReach2
//
//  Created by Eumbrella on 17/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

enum TabType : Int
{
    case Home = 1
    case Preferred = 2
    case Businesses = 3
    case WishList = 4
    case History = 5
    case Settings = 6
    case Loyalty = 7
    case HelpAndSupport = 8
    case Profile = 9
    case Barcode = 10
    case About = 11
    case Offers = 12
    case StoresLocator = 13
    case ProductFinder = 14
    case Notifications = 15
    case Transactions = 16
    case TermsAndConditions = 17
    case Feedback = 18
    case RedemptionPolicy = 19
}
