//
//  InformationVideoViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 16/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// InformationVideoViewCell is a cell that is been used for showing a video.
class InformationVideoViewCell: UITableViewCell {

    @IBOutlet var cellWebView: UIWebView!

    @IBOutlet var videoIndicator: UIActivityIndicatorView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
