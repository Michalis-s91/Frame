//
//  CustomTabBarController.swift
//  RichReach2
//
//  Created by Eumbrella on 07/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class CustomTabBarController: UITabBarController {

    var allPartnersViewController : UIViewController!
    var wishListViewController : UIViewController!
    var optInHistoryViewController : UIViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        /*let MainStoryBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        allPartnersViewController  = (MainStoryBoard.instantiateViewController(withIdentifier: "c")) as! UINavigationController
        wishListViewController =  (MainStoryBoard.instantiateViewController(withIdentifier: "d")) as! UINavigationController
        optInHistoryViewController = (MainStoryBoard.instantiateViewController(withIdentifier: "e")) as! UINavigationController
        
        allPartnersViewController.tabBarItem = UITabBarItem(tabBarSystemItem: .favorites, tag: 0)
        wishListViewController.tabBarItem = UITabBarItem(tabBarSystemItem: .favorites, tag: 1)
        optInHistoryViewController.tabBarItem = UITabBarItem(tabBarSystemItem: .favorites, tag: 2)
        
        viewControllers = [allPartnersViewController,wishListViewController,optInHistoryViewController  ]*/
        // Do any additional setup after loading the view.
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        selectedIndex = 0
        
        self.tabBar.tintColor = Colors.tabBarSelectedTextColor
        self.tabBar.unselectedItemTintColor = UIColor.lightGray
        //self.tabBar.shadowImage = ImageWithColor.imageWithColor(color: UIColor.red)
        /*self.tabBar.layer.borderWidth = 5
        self.tabBar.layer.borderColor = UIColor(red:0.0/255.0, green:0.0/255.0, blue:0.0/255.0, alpha:0.2).cgColor
        self.tabBar.clipsToBounds = true*/
        UITabBar.appearance().backgroundImage = ImageWithColor.imageWithColor(color: Colors.trasnparent)
        UITabBar.appearance().shadowImage = ImageWithColor.imageWithColor(color: Colors.tabs_color, size: CGSize(width: UIScreen.main.bounds.size.width , height: 1))
        //self.tabBarItem.setTitleTextAttributes({NSForegroundColorAttributeName: Colors.colorPrimary }, for:.Normal)
        //self.tabBar.setTitleTextAttributes([NSAttributedStringKey.foregroundColor: UIColor.red], for: .normal)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
