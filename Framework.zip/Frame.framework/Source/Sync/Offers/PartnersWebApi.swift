//
//  PartnersWebApi.swift
//  RichReach2
//
//  Created by Eumbrella on 05/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Web api for partners. Sends requests for getting all loyalty partners, all partners, partner opt in, partner info and partner offers.
class PartnersWebApi
{
    static var lock = NSObject()
    
    /// Post request for getting all loyalty partners and return a list with all loyalty partners.
    ///
    /// - Parameters:
    ///   - userPhone: The user phone number.
    ///   - isTesting: The isTesting flag.
    ///   - pageNumber: The page number to be loaded.
    /// - Returns: A list with all loyalty partners.
    static func getAllLoyaltyPartners(userPhone : String!, isTesting : Bool, pageNumber : Int) -> [PartnerModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://www.commtor.com/webapi/PartnersApi/LoadAvailableLoyaltyPartnersNew/",params: "ClientTelephone=\(userPhone ?? "")&IsTestAgent=\(isTesting)&PageNumber=\(pageNumber)")
        
            return try OffersFormatter.unPackAllPartners( packageString: httpRequest.requestResponse)
        }
        catch
        {
            
        }
        return nil
    }
    
    /// Post request for getting all partners and return a list with all partners.
    ///
    /// - Parameters:
    ///   - userPhone: The user phone number.
    ///   - isTesting: The isTesting flag.
    ///   - pageNumber: The page number to be loaded.
    ///   - currentAppVersion: The current app version.
    ///   - currentAppBuildVersion: The current app build version.
    /// - Returns: A list with all partners.
    static func getPartners( userPhone : String!, isTesting : Bool, pageNumber : Int, currentAppVersion : String!, currentAppBuildVersion : String!) -> [PartnerModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://www.commtor.com/webapi/PartnersApi/LoadAvailablePartnersNew/",params: "ClientTelephone=\(userPhone ?? "")&IsTestAgent=\(isTesting)&PageNumber=\(pageNumber)\(currentAppVersion == nil ? "" : "&CurrentAppVersion=" + currentAppVersion )\(currentAppBuildVersion == nil ? "" : "&CurrentAppBuildVersion=" + currentAppBuildVersion )")
        
            print(httpRequest.requestResponse)
            return try OffersFormatter.unPackAllPartners( packageString: httpRequest.requestResponse)
        }
        catch
        {
        }
        return nil
    }

    /// Post request for getting opt in for specific partner.
    ///
    /// - Parameters:
    ///   - userPhone: The user phone number.
    ///   - partnerID: The partner ID.
    ///   - isOptin: The flag is opt in.
    /// - Throws: error
    static func optInPartner(userPhone : String! , partnerID : Int, isOptin : Bool) throws
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.postAsync(url: "http://www.commtor.com/webapi/PartnersApi/PartnerOptIn/",params: "ClientTelephone=\(userPhone ?? "")&PartnerID=\(partnerID)&IsOptIn=\(isOptin)")
        }
        catch
        {
            throw Errors.error
        }
    }
    
    /// Post request for getting partner information and saves the results to input partner model.
    ///
    /// - Parameters:
    ///   - userPhone: The user phone number.
    ///   - partner: The partner model.
    ///   - language: The language(e.g. en for English).
    static func getPartnerInformation(userPhone : String!, partner : inout PartnerModel, language : String)
    {
        if (partner.storeInfo != nil)
        {
            partner.storeInfo.removeAll()
        }
        
        var apiResponse : String! = nil
        
        do
        {
            let httpRequest = HttpRequest()
            print("http://www.commtor.com/webapi/PartnersApi/PartnerInformation/?ClientTelephone=\(userPhone ?? "")PartnerID=\(String(partner.partnerID))&Language=en")
            try httpRequest.post(url: "http://www.commtor.com/webapi/PartnersApi/PartnerInformation/",params: "ClientTelephone=\(userPhone ?? "")&PartnerID=\(String(partner.partnerID))&Language=en")
            apiResponse = httpRequest.requestResponse
        }
        catch
        {
            
        }
        
        if (!isNullOrEmpty( string: apiResponse))
        {
            do
            {
                let partnersData = try OffersFormatter.unPackPartnerInformation(packageString: apiResponse!)
                if (partnersData != nil)
                {
                    var count = 0
                    for h in partnersData!
                    {
                        if (count == ((partnersData?.count)! - 1))
                        {
                            partner.website = h.item1
                            partner.Information = h.item2
                            partner.imageLargeUri = h.item3
                            partner.facebookPage = h.item4
                            partner.facebookPageID = h.item5
                            partner.shortName = h.item6
                        }
                        else
                        {
                            if (partner.storeInfo == nil)
                            {
                                partner.storeInfo = []
                                
                            }
                            partner.storeInfo.append(StoresInfo(name: h.item1, address: h.item2, phone: h.item3, latitude: h.item4, longitude: h.item5))
                        }
                        
                        count += 1
                    }
                }
            }
            catch
            {
                
            }
        }
    }
    
    /// Post request for partner offers and return the offers in a list.
    ///
    /// - Parameters:
    ///   - userPhone: The user phone number.
    ///   - partnerID: The partner ID.
    ///   - pageNumber: The page number to be loaded.
    ///   - localDB: The local database.
    /// - Returns: A list with partner offers.
    static func getPartnerOffers(userPhone : String!, partnerID : Int, pageNumber : Int, localDB : Database) -> [OfferModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://www.commtor.com/webapi/PartnersApi/GetPartnerOffers/",params: "ClientTelephone=\(userPhone ?? "")&PartnerID=\(partnerID)&PageNumber=\(pageNumber)")
            return try OffersFormatter.unPackPartnerOffers(packageString: httpRequest.requestResponse, localDB: localDB)
        }
        catch
        {
        }
        
        return nil
    }
}
