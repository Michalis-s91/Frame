//
//  SatusDB.swift
//  RichReach2
//
//  Created by Eumbrella on 27/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import SQLite
import QuartzCore

class StatusDB : NSObject
{
    let DATABASE_NAME = "StatusDB"
    
    var database : Connection!
    var lock = NSObject()
    var version = 6
    
    var statusTable = Table("StatusTable")
    
    //Status columns
    let apk = Expression<String>("apk")
    
    let isThemeSaved = Expression<Bool>("isThemeSaved")
    let areLeftDrawerTabsSaved = Expression<Bool>("areLeftDrawerTabsSaved")
    let areStylesSaved = Expression<Bool>("areStylesSaved")
    /*let areLeftDrawerStylesSaved = Expression<Bool>("areGeneralViewsSaved")
     let areLeftDrawerChildStylesSaved = Expression<Bool>("areLeftDrawerChildStylesSaved")
     let isToastStyleSaved = Expression<Bool>("isToastStyleSaved")
     let isTabBarStyleSaved = Expression<Bool>("isTabBarStyleSaved")
     let isDialogStyleSaved = Expression<Bool>("isDialogStyleSaved")*/
    let areRelationsSaved = Expression<Bool>("areRelationsSaved")
    let isLeftDrawerImageSaved = Expression<Bool>("isLeftDrawerImageSaved")
    let isNavImageSaved = Expression<Bool>("isNavImageSaved")
    
    let areGeneralViewsSaved = Expression<Bool>("areGeneralViewsSaved")
    let areExpandableListViewsSaved = Expression<Bool>("areExpandableListViewsSaved")
    let areEmbededViewsSaved = Expression<Bool>("areEmbededViewsSaved")
    let areEmbededViewsParametersSaved = Expression<Bool>("areEmbededViewsParametersSaved")
    let areCategoriesSaved = Expression<Bool>("areCategoriesSaved")
    let areBrandsSaved = Expression<Bool>("areBrandsSaved")
    let areProductsSaved = Expression<Bool>("areProductsSaved")
    let productsPageNo = Expression<Int>("productsPageNo")
    let areBarcodesSaved = Expression<Bool>("areBarcodesSaved")
    let barcodesPageNo = Expression<Int>("barcodesPageNo")
    
    let isBarcodeViewSaved = Expression<Bool?>("isBarcodeViewSaved")
    let areContactUsTabRelationsSaved = Expression<Bool?>("areContactUsTabRelationsSaved")
    let isContactUsViewSaved = Expression<Bool?>("isContactUsViewSaved")
    let isPointsStatementSaved = Expression<Bool?>("isPointsStatementSaved")
    let pointsStatementPageNo = Expression<Int?>("pointsStatementPageNo")
    let areTicketsSaved = Expression<Bool?>("areTicketsSaved")
    let isPointsStatementViewSaved = Expression<Bool?>("isPointsStatementViewSaved")
    let isTicketViewSaved = Expression<Bool?>("isTicketViewSaved")
    let areTicketStylesSaved = Expression<Bool?>("areTicketStylesSaved")
    let areGeneralSearchViewSaved = Expression<Bool?>("areGeneralSearchViewSaved")
    let isUserProfileViewSaved = Expression<Bool?>("isUserProfileViewSaved")
    let areUserProfileFieldsSaved = Expression<Bool?>("areUserProfileFieldsSaved")
    let areUserProfileFieldsStylesSaved = Expression<Bool?>("areUserProfileFieldsStylesSaved")
    let areStoreLocatorParametersSaved = Expression<Bool?>("areStoreLocatorParametersSaved")
    let areStoresSaved = Expression<Bool?>("areStoresSaved")
    let areSocialMediaSaved = Expression<Bool?>("areSocialMediaSaved")
    let areHolidaysSaved = Expression<Bool?>("areHolidaysSaved")
    
    let areSplashScrennParametersSaved = Expression<Bool?>("areSplashScrennParametersSaved")
    let isNotAvailableViewSaved = Expression<Bool?>("isNotAvailableViewSaved")
    let isBackgroundImageSaved = Expression<Bool?>("isBackgroundImageSaved")
    let isProductMenuSaved = Expression<Bool?>("isProductMenuSaved")
    let areProductMenuRelationsSaved = Expression<Bool?>("areProductMenuRelationsSaved")
    
    let isFirstViewSaved = Expression<Bool?>("isFirstViewSaved")
    
    let isOffersSaved = Expression<Bool?>("isOffersSaved")
    let isTermsSaved = Expression<Bool?>("isTermsSaved")
    let isRedemptionSaved = Expression<Bool?>("isRedemptionSaved")
    let isAboutSaved = Expression<Bool?>("isAboutSaved")
    let isHomeSaved = Expression<Bool?>("isHomeSaved")
    
    let areAuthorsSaved = Expression<Bool?>("areAuthorsSaved")
    let areArticlesSaved = Expression<Bool?>("areArticlesSaved")
    
    let areProximityOffersSaved = Expression<Bool?>("areProximityOffersSaved")
    
    let isAPKSaved = Expression<Bool?>("isAPKSaved")
    let lastUpdateDate = Expression<String?>("lastUpdateDate")
    let lastProductsSyncDate = Expression<String?>("lastProductsSyncDate")
    
    var updateTime : String!
    
    override init(){
        do{
            let documentDirectory = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let fileUrl = documentDirectory.appendingPathComponent(DATABASE_NAME).appendingPathExtension("sqlite3")
            self.database = try Connection(fileUrl.path)
        }
        catch
        {
            print(error)
        }
    }
    
    /// Checks if database need to be upgraded, and upgrade it if needed.
    func checkForUpgrade()
    {
        createTables()
        
        switch database.userVersion {
        case 0:
            upgradeToVersion1()
        case 1:
            upgradeToVersion2()
        case 2:
            upgradeToVersion3()
        case 3:
            upgradeToVersion4()
        case 4:
            upgradeToVersion5()
        case 5:
            upgradeToVersion6()
        default:
            break
        }
        
        database.userVersion = version
    }
    
    /// Upgrade database to version 1.
    func upgradeToVersion1()
    {
        do
        {
            try database.run(self.statusTable.addColumn(self.isBarcodeViewSaved))
            try database.run(self.statusTable.addColumn(self.areContactUsTabRelationsSaved))
            try database.run(self.statusTable.addColumn(self.isContactUsViewSaved))
            try database.run(self.statusTable.addColumn(self.isPointsStatementSaved))
            try database.run(self.statusTable.addColumn(self.pointsStatementPageNo))
            try database.run(self.statusTable.addColumn(self.areTicketsSaved))
            try database.run(self.statusTable.addColumn(self.isPointsStatementViewSaved))
            try database.run(self.statusTable.addColumn(self.isTicketViewSaved))
            try database.run(self.statusTable.addColumn(self.areTicketStylesSaved))
            try database.run(self.statusTable.addColumn(self.areGeneralSearchViewSaved))
            try database.run(self.statusTable.addColumn(self.isUserProfileViewSaved))
            try database.run(self.statusTable.addColumn(self.areUserProfileFieldsSaved))
            try database.run(self.statusTable.addColumn(self.areUserProfileFieldsStylesSaved))
            try database.run(self.statusTable.addColumn(self.areStoreLocatorParametersSaved))
            try database.run(self.statusTable.addColumn(self.areStoresSaved))
            try database.run(self.statusTable.addColumn(self.areSocialMediaSaved))
            try database.run(self.statusTable.addColumn(self.areHolidaysSaved))
            try database.run(self.statusTable.addColumn(self.isAPKSaved))
        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion2()
    }
    
    
    /// Upgrade database to version 2.
    func upgradeToVersion2()
    {
        do
        {
            try database.run(self.statusTable.addColumn(self.areSplashScrennParametersSaved))
            try database.run(self.statusTable.addColumn(self.isNotAvailableViewSaved))
            try database.run(self.statusTable.addColumn(self.isBackgroundImageSaved))
            try database.run(self.statusTable.addColumn(self.isProductMenuSaved))
            try database.run(self.statusTable.addColumn(self.areProductMenuRelationsSaved))
            
            try database.run(self.statusTable.addColumn(self.lastUpdateDate))
        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion3()
    }
    
    /// Upgrade database to version 3.
    func upgradeToVersion3()
    {
        do
        {
            try database.run(self.statusTable.addColumn(self.isFirstViewSaved))
        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion4()
    }
    
    /// Upgrade database to version 4.
    func upgradeToVersion4()
    {
        do
        {
            try database.run(self.statusTable.addColumn(self.isOffersSaved))
            try database.run(self.statusTable.addColumn(self.isTermsSaved))
            try database.run(self.statusTable.addColumn(self.isRedemptionSaved))
            try database.run(self.statusTable.addColumn(self.isAboutSaved))
            try database.run(self.statusTable.addColumn(self.isHomeSaved))
        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion5()
    }
    
    /// Upgrade database to version 5.
    func upgradeToVersion5()
    {
        do
        {
            try database.run(self.statusTable.addColumn(self.areAuthorsSaved))
            try database.run(self.statusTable.addColumn(self.areArticlesSaved))
            try database.run(self.statusTable.addColumn(self.lastProductsSyncDate))
        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion6()
    }
    
    /// Upgrade database to version 6.
    func upgradeToVersion6()
    {
        do
        {
            try database.run(self.statusTable.addColumn(self.areProximityOffersSaved))
        }
        catch
        {
            print(error)
        }
    }
    
    
    /// Creates the products database tables.
    func createTables()
    {
        objc_sync_enter(lock)
        createsStatusTable()
        objc_sync_exit(lock)
    }
    
    /*func needUpdate(apk : String) -> Bool
    {
        objc_sync_enter(lock)
        do {
            let status = try self.database.prepare(self.statusTable.filter(self.apk == apk ))
            
            for s in status {
                
                objc_sync_exit(lock)
                
                let updateStatus = try ParameterizationWebApi.needUpdate(apk: apk, lastUpdate: s[self.lastUpdateDate])
                
                if(updateStatus == nil)
                {
                    return false
                }
                
                if(updateStatus?.dateTime != nil)
                {
                    updateTime = updateStatus?.dateTime
                }
                else
                {
                    updateTime = s[self.lastUpdateDate]
                }
                
                return updateStatus!.needsUpdate
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return false
    }*/
    
    func needUpdate2(apk : String)
    {
        objc_sync_enter(lock)
        do {
            let status = try self.database.prepare(self.statusTable.filter(self.apk == apk ))
            
            for s in status {
                
                objc_sync_exit(lock)
                
                updateTime = s[self.lastUpdateDate]
                
                syncModel = try ParameterizationWebApi.needUpdate2(apk: apk, lastUpdate: s[self.lastUpdateDate])
                
                if(syncModel.currentDateTime != nil)
                {
                    updateTime = syncModel.currentDateTime
                }
            }
        }
        catch
        {
            print(error)
        }

        objc_sync_exit(lock)
    }
    
    /*********************************************************                  CREATES                  *********************************************************/
    func createsStatusTable()
    {
        let createsStatusTable = self.statusTable.create { (table) in
            table.column(self.apk, primaryKey : true)
            table.column(self.isThemeSaved)
            table.column(self.areLeftDrawerTabsSaved)
            table.column(self.areStylesSaved)
            /*table.column(self.areLeftDrawerChildStylesSaved)
             table.column(self.areLeftDrawerStylesSaved)
             table.column(self.isToastStyleSaved)
             table.column(self.isTabBarStyleSaved)
             table.column(self.isDialogStyleSaved)*/
            table.column(self.areRelationsSaved)
            table.column(self.isLeftDrawerImageSaved)
            table.column(self.isNavImageSaved)
            table.column(self.areGeneralViewsSaved)
            table.column(self.areExpandableListViewsSaved)
            table.column(self.areEmbededViewsSaved)
            table.column(self.areEmbededViewsParametersSaved)
            table.column(self.areCategoriesSaved)
            table.column(self.areBrandsSaved)
            table.column(self.areProductsSaved)
            table.column(self.productsPageNo)
            table.column(self.areBarcodesSaved)
            table.column(self.barcodesPageNo)
            
            table.column(self.isBarcodeViewSaved)
            table.column(self.areContactUsTabRelationsSaved)
            table.column(self.isContactUsViewSaved)
            table.column(self.isPointsStatementSaved)
            table.column(self.pointsStatementPageNo)
            table.column(self.areTicketsSaved)
            table.column(self.isPointsStatementViewSaved)
            table.column(self.isTicketViewSaved)
            table.column(self.areTicketStylesSaved)
            table.column(self.areGeneralSearchViewSaved)
            table.column(self.isUserProfileViewSaved)
            table.column(self.areUserProfileFieldsSaved)
            table.column(self.areUserProfileFieldsStylesSaved)
            table.column(self.areStoreLocatorParametersSaved)
            table.column(self.areStoresSaved)
            table.column(self.areSocialMediaSaved)
            table.column(self.areHolidaysSaved)
            
            table.column(self.areSplashScrennParametersSaved)
            table.column(self.isNotAvailableViewSaved)
            table.column(self.isBackgroundImageSaved)
            table.column(self.isProductMenuSaved)
            table.column(self.areProductMenuRelationsSaved)
            
            table.column(self.isFirstViewSaved)
            
            table.column(self.isOffersSaved)
            table.column(self.isTermsSaved)
            table.column(self.isRedemptionSaved)
            table.column(self.isAboutSaved)
            table.column(self.isHomeSaved)
            
            table.column(self.areAuthorsSaved)
            table.column(self.areArticlesSaved)
            
            table.column(self.areProximityOffersSaved)
            
            table.column(self.isAPKSaved)
            table.column(self.lastUpdateDate)
            table.column(self.lastProductsSyncDate)
        }
        
        do {
            try self.database.run(createsStatusTable)
        } catch {
            print(error)
        }
    }
    
    /*********************************************************                  INSERTS                  *********************************************************/
    func insertStatus(status : StatusModel, apk : String)
    {
        objc_sync_enter(lock)
        do
        {
            var lastUpdate : String!
            
            if(status.isAPKSaved)
            {
                lastUpdate = updateTime
            }
            else
            {
                lastUpdate = status.lastUpdateDate
            }
            
            let insertStatus = self.statusTable.insert(or: .replace,
                                                       self.apk <- apk,
                                                       self.isThemeSaved <- status.isThemeSaved,
                                                       self.areLeftDrawerTabsSaved <- status.areLeftDrawerTabsSaved,
                                                       self.areStylesSaved <- status.areStylesSaved,
                                                       /*self.areLeftDrawerChildStylesSaved <- status.areLeftDrawerChildStylesSaved,
                                                         self.areLeftDrawerStylesSaved <- status.areLeftDrawerStylesSaved,
                                                         self.isToastStyleSaved <- status.isToastStyleSaved,
                                                         self.isTabBarStyleSaved <- status.isTabBarStyleSaved,
                                                         self.isDialogStyleSaved <- status.isDialogStyleSaved,*/
                                                        self.areRelationsSaved <- status.areRelationsSaved,
                                                        self.isLeftDrawerImageSaved <- status.isLeftDrawerImageSaved,
                                                        self.isNavImageSaved <- status.isNavImageSaved,
                                                        self.areGeneralViewsSaved <- status.areGeneralViewsSaved,
                                                        self.areExpandableListViewsSaved <- status.areExpandableListViewsSaved,
                                                        self.areEmbededViewsSaved <- status.areEmbededViewsSaved,
                                                        self.areEmbededViewsParametersSaved <- status.areEmbededViewsParametersSaved,
                                                        self.areCategoriesSaved <- status.areCategoriesSaved,
                                                        self.areBrandsSaved <- status.areBarcodesSaved,
                                                        self.areProductsSaved <- status.areProductsSaved,
                                                        self.productsPageNo <- status.productsPageNo,
                                                        self.areBarcodesSaved <- status.areBarcodesSaved,
                                                        self.barcodesPageNo <- status.barcodesPageNo,
                                                        
                                                        self.isBarcodeViewSaved <- status.isBarcodeViewSaved,
                                                        self.areContactUsTabRelationsSaved <- status.areContactUsTabRelationsSaved,
                                                        self.isContactUsViewSaved <- status.isContactUsViewSaved,
                                                        self.isPointsStatementSaved <- status.isPointsStatementSaved,
                                                        self.pointsStatementPageNo <- status.pointsStatementPageNo,
                                                        self.areTicketsSaved <- status.areTicketsSaved,
                                                        self.isPointsStatementViewSaved <- status.isPointsStatementViewSaved,
                                                        self.isTicketViewSaved <- status.isTicketViewSaved,
                                                        self.areTicketStylesSaved <- status.areTicketStylesSaved,
                                                        self.areGeneralSearchViewSaved <- status.areGeneralSearchViewSaved,
                                                        self.isUserProfileViewSaved <- status.isUserProfileViewSaved,
                                                        self.areUserProfileFieldsSaved <- status.areUserProfileFieldsSaved,
                                                        self.areUserProfileFieldsStylesSaved <- status.areUserProfileFieldsStylesSaved,
                                                        self.areStoreLocatorParametersSaved <- status.areStoreLocatorParametersSaved,
                                                        self.areStoresSaved <- status.areStoresSaved,
                                                        self.areSocialMediaSaved <- status.areSocialMediaSaved,
                                                        self.areHolidaysSaved <- status.areHolidaysSaved,
                                                        
                                                        self.areSplashScrennParametersSaved <- status.areSplashScrennParametersSaved,
                                                        self.isNotAvailableViewSaved <- status.isNotAvailableViewSaved,
                                                        self.isBackgroundImageSaved <- status.isBackgroundImageSaved,
                                                        self.isProductMenuSaved <- status.isProductMenuSaved,
                                                        self.areProductMenuRelationsSaved <- status.areProductMenuRelationsSaved,
                                                        
                                                        self.isFirstViewSaved <- status.isFirstViewSaved,
                                                        
                                                        self.isOffersSaved <- status.isOffersSaved,
                                                        self.isTermsSaved <- status.isTermsSaved,
                                                        self.isRedemptionSaved <- status.isRedemptionSaved,
                                                        self.isAboutSaved <- status.isAboutSaved,
                                                        self.isHomeSaved <- status.isHomeSaved,
                                                        
                                                        self.areAuthorsSaved <- status.areAuthorsSaved,
                                                        self.areArticlesSaved <- status.areArticlesSaved,
                                                        
                                                         self.areProximityOffersSaved <- status.areProximityOffersSaved,
                                                        
                                                        self.isAPKSaved <- status.isAPKSaved,
                                                        self.lastUpdateDate <- lastUpdate,
                                                        self.lastProductsSyncDate <- statusModel.lastProductsSyncDate)
            
            
            try self.database.run(insertStatus)
            print("Status added")
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    
    
    /*********************************************************                  GETS                  *********************************************************/
    func getStatus(apk : String) -> StatusModel!
    {
        objc_sync_enter(lock)
        do {
            let statusModel : StatusModel = StatusModel()
            
            let status = try self.database.prepare(self.statusTable.filter(self.apk == apk ))
            
            for s in status {
                statusModel.isThemeSaved = s[self.isThemeSaved]
                statusModel.areLeftDrawerTabsSaved = s[self.areLeftDrawerTabsSaved]
                statusModel.areStylesSaved = s[self.areStylesSaved]
                /* statusModel.areLeftDrawerChildStylesSaved = s[self.areLeftDrawerChildStylesSaved]
                 statusModel.areLeftDrawerStylesSaved = s[self.areLeftDrawerStylesSaved]
                 statusModel.isToastStyleSaved = s[self.isToastStyleSaved]
                 statusModel.isTabBarStyleSaved = s[self.isTabBarStyleSaved]
                 statusModel.isDialogStyleSaved = s[self.isDialogStyleSaved]*/
                statusModel.areRelationsSaved = s[self.areRelationsSaved]
                statusModel.isLeftDrawerImageSaved = s[self.isLeftDrawerImageSaved]
                statusModel.isNavImageSaved = s[self.isNavImageSaved]
                statusModel.areGeneralViewsSaved = s[self.areGeneralViewsSaved]
                statusModel.areExpandableListViewsSaved = s[self.areExpandableListViewsSaved]
                statusModel.areEmbededViewsSaved = s[self.areEmbededViewsSaved]
                statusModel.areEmbededViewsParametersSaved = s[self.areEmbededViewsParametersSaved]
                statusModel.areCategoriesSaved = s[self.areCategoriesSaved]
                statusModel.areBrandsSaved = s[self.areBrandsSaved]
                statusModel.areProductsSaved = s[self.areProductsSaved]
                statusModel.productsPageNo = s[self.productsPageNo]
                statusModel.areBarcodesSaved = s[self.areBarcodesSaved]
                statusModel.barcodesPageNo = s[self.barcodesPageNo]
                
                statusModel.isBarcodeViewSaved = s[self.isBarcodeViewSaved] == nil ? false : s[self.isBarcodeViewSaved]!
                statusModel.areContactUsTabRelationsSaved = s[self.areContactUsTabRelationsSaved] == nil ? false : s[self.areContactUsTabRelationsSaved]!
                statusModel.isContactUsViewSaved = s[self.isContactUsViewSaved] == nil ? false : s[self.isContactUsViewSaved]!
                statusModel.isPointsStatementSaved = s[self.isPointsStatementSaved] == nil ? false : s[self.isPointsStatementSaved]!
                statusModel.pointsStatementPageNo = s[self.pointsStatementPageNo] == nil ? 1 : s[self.pointsStatementPageNo]!
                statusModel.areTicketsSaved = s[self.areTicketsSaved] == nil ? false : s[self.areTicketsSaved]!
                statusModel.isPointsStatementViewSaved = s[self.isPointsStatementViewSaved] == nil ? false : s[self.isPointsStatementViewSaved]!
                statusModel.isTicketViewSaved = s[self.isTicketViewSaved] == nil ? false : s[self.isTicketViewSaved]!
                statusModel.areTicketStylesSaved = s[self.areTicketStylesSaved] == nil ? false : s[self.areTicketStylesSaved]!
                statusModel.areGeneralSearchViewSaved = s[self.areGeneralSearchViewSaved] == nil ? false : s[self.areGeneralSearchViewSaved]!
                statusModel.isUserProfileViewSaved = s[self.isUserProfileViewSaved] == nil ? false : s[self.isUserProfileViewSaved]!
                statusModel.areUserProfileFieldsSaved = s[self.areUserProfileFieldsSaved] == nil ? false : s[self.areUserProfileFieldsSaved]!
                statusModel.areUserProfileFieldsStylesSaved = s[self.areUserProfileFieldsStylesSaved] == nil ? false : s[self.areUserProfileFieldsStylesSaved]!
                statusModel.areStoreLocatorParametersSaved = s[self.areStoreLocatorParametersSaved] == nil ? false : s[self.areStoreLocatorParametersSaved]!
                statusModel.areStoresSaved = s[self.areStoresSaved] == nil ? false : s[self.areStoresSaved]!
                statusModel.areSocialMediaSaved = s[self.areSocialMediaSaved] == nil ? false : s[self.areSocialMediaSaved]!
                statusModel.areHolidaysSaved = s[self.areHolidaysSaved] == nil ? false : s[self.areHolidaysSaved]!
                
                statusModel.areSplashScrennParametersSaved = s[self.areSplashScrennParametersSaved] == nil ? false : s[self.areSplashScrennParametersSaved]!
                statusModel.isNotAvailableViewSaved = s[self.isNotAvailableViewSaved] == nil ? false : s[self.isNotAvailableViewSaved]!
                statusModel.isBackgroundImageSaved = s[self.isBackgroundImageSaved] == nil ? false : s[self.isBackgroundImageSaved]!
                statusModel.isProductMenuSaved = s[self.isProductMenuSaved] == nil ? false : s[self.isProductMenuSaved]!
                statusModel.areProductMenuRelationsSaved = s[self.areProductMenuRelationsSaved] == nil ? false : s[self.areProductMenuRelationsSaved]!
                
                statusModel.isFirstViewSaved = s[self.isFirstViewSaved] == nil ? false : s[self.isFirstViewSaved]
                
                statusModel.isOffersSaved = s[self.isOffersSaved] == nil ? false : s[self.isOffersSaved]
                statusModel.isTermsSaved = s[self.isTermsSaved] == nil ? false : s[self.isTermsSaved]
                statusModel.isRedemptionSaved = s[self.isRedemptionSaved] == nil ? false : s[self.isRedemptionSaved]
                statusModel.isAboutSaved = s[self.isAboutSaved] == nil ? false : s[self.isAboutSaved]
                statusModel.isHomeSaved = s[self.isHomeSaved] == nil ? false : s[self.isHomeSaved]
                
                statusModel.areAuthorsSaved = s[self.areAuthorsSaved] == nil ? false : s[self.areAuthorsSaved]
                statusModel.areArticlesSaved = s[self.areArticlesSaved] == nil ? false : s[self.areArticlesSaved]
                
                statusModel.areProximityOffersSaved = s[self.areProximityOffersSaved] == nil ? false : s[self.areProximityOffersSaved]
                
                statusModel.isAPKSaved = s[self.isAPKSaved] == nil ? false : s[self.isAPKSaved]!
                statusModel.lastUpdateDate = s[self.lastUpdateDate]
                statusModel.lastProductsSyncDate = s[self.lastProductsSyncDate]
                
                objc_sync_exit(lock)
                return statusModel
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
        
    }
}
