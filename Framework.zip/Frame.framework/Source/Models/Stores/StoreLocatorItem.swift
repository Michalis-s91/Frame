//
//  StoreLocatorItem.swift
//  RichReach2
//
//  Created by Eumbrella on 24/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// Holds information for item of stores locator table view.
class StoreLocatorItem
{
    var cityName : String!
    var numOfStores : Int!
    var type : Int!
    var isExpaned : Bool!
    var storeInfo : StoreModel!
    
    init(cityName : String)
    {
        self.cityName = cityName
        self.type = StoresLocatorItemType.City.rawValue
        self.isExpaned = false
    }
    
    init()
    {
        self.type = 2
    }
    
    init(storeInfo : StoreModel)
    {
        self.storeInfo = storeInfo
        self.type  = StoresLocatorItemType.Store.rawValue
    }
}
