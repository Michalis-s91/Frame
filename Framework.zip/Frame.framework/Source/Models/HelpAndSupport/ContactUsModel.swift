//
//  ContactUsModel.swift
//  RichReach2
//
//  Created by Eumbrella on 23/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class ContactUsModel : Codable
{
    var id : Int!
    
    var types : [String]! = []
    var info : [ContactUsInfoModel]! = []
    
    var titleBackgroundColor : String!
    var titleFont : String!
    var titleTextSize : Int!
    var titleTextColor : String!
    
    var tintColor : String!
    
    var typeTitle : String!
    var typeFont : String!
    var typeTextSize : Int!
    var typeTextColor : String!
    
    var messageTitle : String!
    var messageFont : String!
    var messageTextSize : Int!
    var messageTextColor : String!
    
    var infoFont : String!
    var infoTextSize : Int!
    var infoTextColor : String!
    
    var buttonText : String!
    var buttonBackgroundColor : String!
    var buttonFont : String!
    var buttonTextSize : Int!
    var buttonTextColor : String!
    var buttonBorderWidth : Int!
    var buttonBorderColor : String!
    
    private enum CodingKeys : String, CodingKey {
        case id = "ID"
        case types = "SubjectTypeList"
        case info = "InfoList"
        case typeTitle = "SubjectTitle"
        case typeFont = "SubjectFont"
        case typeTextSize = "SubjectSize"
        case typeTextColor = "SubjectColor"
        case tintColor = "TintColor"
        case messageTitle = "MessageTitle"
        case messageFont = "MessageFont"
        case messageTextSize = "MessageTextSize"
        case messageTextColor = "MessageTextColor"
        case infoFont = "InfoFont"
        case infoTextSize = "InfoSize"
        case infoTextColor = "InfoColor"
        case buttonText = "ButtonText"
        case buttonBackgroundColor = "ButtonBackgroundColor"
        case buttonFont = "ButtonFont"
        case buttonTextSize = "ButtonSize"
        case buttonTextColor = "ButtonColor"
        case buttonBorderWidth = "ButtonBorderWidth"
        case buttonBorderColor = "ButtonBorderColor"
    }
}
