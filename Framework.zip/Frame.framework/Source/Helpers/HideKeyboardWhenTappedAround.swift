//
//  HideKeyboardWhenTappedAround.swift
//  RichReach2
//
//  Created by Eumbrella on 21/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

extension UIViewController {
    /**
     * Hides keyboard when click outside keyboard.
     */
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}
