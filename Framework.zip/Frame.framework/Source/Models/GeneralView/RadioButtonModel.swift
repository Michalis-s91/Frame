//
//  NewsletterModel.swift
//  RichReach2
//
//  Created by Eumbrella on 09/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class RadioButtonModel : Codable
{
    var id : Int!
    var imageUrl : String!
    var name : String!
    var selectedColor : String!
    var nonSelectedColor : String!
    
    var isSelected : Bool! = false
    var imageAspectRatio : Double!
    
    var nameTextColor : String!
    var nameTextSize : Int!
    var nameFont : String!
    
    var connectionID : Int!
    
    private enum CodingKeys : String, CodingKey {
        case id = "ID"
        case imageUrl = "ImageUrl"
        case name = "Name"
        case selectedColor = "SelectedColor"
        case nonSelectedColor = "NonSelectedColor"
        
        case nameTextColor = "NameTextColor"
        case nameTextSize = "NameTextSize"
        case nameFont = "NameFont"
        
        case connectionID = "ConnectionID"
    }
}
