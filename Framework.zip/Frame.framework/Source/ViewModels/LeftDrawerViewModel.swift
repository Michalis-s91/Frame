//
//  LeftDrawerViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 09/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit



class LeftDrawerViewModel : ViewController
{
    /*var leftDrawer : LeftDrawerViewController!
    var uiView : UIView!
    var viewController : ViewController!
    
    init(uiView : UIView, viewController : ViewController) {
        self.viewController = viewController
        leftDrawer = viewController.storyboard?.instantiateViewController(withIdentifier: "LeftDrawerViewController") as! LeftDrawerViewController
        self.uiView = uiView
    }
    
    func showLeftDrawer(){
        UIView.animate(withDuration: 0.6) {
            self.leftDrawer.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
            //self.leftDrawer.view.backgroundColor = UIColor.black.withAlphaComponent(0)
            self.addChildViewController(self.leftDrawer)
            self.view.addSubview(self.leftDrawer.view)
            AppDelegate.showLeftDrawer = false
        }
        
    }
    
    func hideLeftDrawer(){
        uiView.animate(withDuration: 0.6, animations: {
            self.leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
        }) { _ in
            self.leftDrawer.view.removeFromSuperview()
        }
        AppDelegate.showLeftDrawer = true
    }*/
    
}
