//
//  ProductsDB.swift
//  RichReach2
//
//  Created by Eumbrella on 16/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import SQLite
import QuartzCore

class ProductsDB : NSObject
{
    let DATABASE_NAME = "ProductsDB"
    
    var database : Connection!
    var lock = NSObject()
    var version = 0
    
    let productsTable = Table("ProductsTable")
    let barcodesTable = Table("BarcodesTable")
    //let categoriesTable = Table("CategoriesTable")
    let brandsTable = Table("BrandsTable")
    let productMenuTable = Table("ProductMenuTable")
    let productMenuRelationsTable = Table("ProductMenuRelationsTable")
    
    //Products columns
    //let clientID =  Expression<Int64>("clientID")
    let apk = Expression<String>("apk")
    let itemNo = Expression<Int64>("itemNo")
    let commonItemNo = Expression<String?>("commonItemNo")
    let productDescription = Expression<String?>("productDescription")
    let webDescription = Expression<String?>("webDescription")
    let overViewText = Expression<String?>("overViewText")
    let ingredientsText = Expression<String?>("ingredientsText")
    let howToUseText = Expression<String?>("howToUseText")
    let categoryCode = Expression<Int64?>("categoryCode")
    let familyCode = Expression<String?>("familyCode")
    let manufacturerCode = Expression<String?>("manufacturerCode")
    let manufacturerName = Expression<String?>("manufacturerName")
    let sapStatus = Expression<String?>("sapStatus")
    let imageA = Expression<String?>("imageA")
    let imageB = Expression<String?>("imageB")
    let availabilityForOnline = Expression<Bool?>("availabilityForOnline")
    let priceIncludingVAT = Expression<Double?>("priceIncludingVAT")
    
    //Barcode columns
    let barcode = Expression<String>("barcode")
    
    //Categories columns
    let id = Expression<Int64>("id")
    let code = Expression<String?>("code")
    let type = Expression<Int?>("type")
    let name = Expression<String?>("name")
    let image = Expression<String?>("image")
    let parentCategoryID = Expression<Int?>("parentCategoryID")
    let backgroundColor = Expression<String?>("backgroundColor")
    let textSize = Expression<Int?>("textSize")
    let textColor = Expression<String?>("textColor")
    let font = Expression<String?>("font")
    let tintColor = Expression<String?>("tintColor")
    
    //product menu columns
    let cID =  Expression<Int64>("clientID")
    let ID = Expression<Int>("ID")
    let parentID = Expression<Int>("parentID")
    let displayOrder = Expression<Int>("displayOrder")
    //let name = Expression<String>("name")
    
    //product menu relations columns
    let menuStructureID =  Expression<Int>("menuStructureID")
    let typeData = Expression<Int>("typeData")
    let typeDescription = Expression<String>("typeDescription")
    let relatedCode = Expression<String>("relatedCode")
    
    override init(){
        do{
            let documentDirectory = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let fileUrl = documentDirectory.appendingPathComponent(DATABASE_NAME).appendingPathExtension("sqlite3")
            self.database = try Connection(fileUrl.path)
        }
        catch
        {
            print(error)
        }
    }
    
    /// Checks if database need to be upgraded, and upgrade it if needed.
    func checkForUpgrade()
    {
        createTables()
        
        switch database.userVersion {
        case 0:
            break
        default:
            break
        }
        
        database.userVersion = version
    }
    
    /// Creates the products database tables.
    func createTables()
    {
        objc_sync_enter(lock)
        createProductsTable()
        createBarcodesTable()
        //createCategoriesTable()
        createBrandsTable()
        createProductMenuTable()
        createProductMenuRelationsTable()
        objc_sync_exit(lock)
    }
    
    func areProductsSaved(apk : String) -> Bool!
    {
        objc_sync_enter(lock)
        do {
            let products = try self.database.prepare(self.productsTable.filter(self.apk == APK))
            
            for _ in products
            {
                objc_sync_exit(lock)
                return true
            }
            
            objc_sync_exit(lock)
            return false
        }
        catch
        {
            print(error)
        }
        objc_sync_exit(lock)
        return false
    }
    
    
    /*********************************************************                  CREATES                  *********************************************************/
    func createProductsTable()
    {
        let createProductsTable = self.productsTable.create { (table) in
            table.column(self.apk)
            table.column(self.itemNo)
            //table.column(self.barcode)
            table.column(self.commonItemNo)
            table.column(self.productDescription)
            table.column(self.webDescription)
            table.column(self.overViewText)
            table.column(self.ingredientsText)
            table.column(self.howToUseText)
            table.column(self.categoryCode)
            table.column(self.familyCode)
            table.column(self.manufacturerCode)
            table.column(self.manufacturerName)
            table.column(self.sapStatus)
            table.column(self.imageA)
            table.column(self.imageB)
            table.column(self.availabilityForOnline)
            table.column(self.priceIncludingVAT)
            
            table.primaryKey(self.apk, self.itemNo)
            
        }
        
        do {
            try self.database.run(createProductsTable)
        } catch {
            print(error)
        }
    }
    
    func createBarcodesTable()
    {
        let createBarcodesTable = self.barcodesTable.create { (table) in
            table.column(self.apk)
            table.column(self.itemNo)
            table.column(self.barcode)
            
            table.primaryKey(self.apk, self.itemNo, self.barcode)
            
        }
        
        do {
            try self.database.run(createBarcodesTable)
        } catch {
            print(error)
        }
    }
    
    /*func createCategoriesTable()
    {
        let createCategoriesTable = self.categoriesTable.create { (table) in
            table.column(self.apk)
            table.column(self.id)
            table.column(self.type)
            table.column(self.parentCategoryID)
            table.column(self.name)
            table.column(self.image)
            table.column(self.backgroundColor)
            table.column(self.textSize)
            table.column(self.textColor)
            table.column(self.font)
            table.column(self.tintColor)
            
            table.primaryKey(self.apk, self.id)
        }
        
        do {
            try self.database.run(createCategoriesTable)
        } catch {
            print(error)
        }
    }*/
    
    func createBrandsTable()
    {
        let createBrandsTable = self.brandsTable.create { (table) in
            table.column(self.apk)
            table.column(self.id)
            table.column(self.code)
            table.column(self.type)
            table.column(self.name)
            table.column(self.image)
            
            table.primaryKey(self.apk, self.id)
        }
        
        do {
            try self.database.run(createBrandsTable)
        } catch {
            print(error)
        }
    }
    
    func createProductMenuTable()
    {
        /*let createProductMenuTable = self.productMenuTable.create { (table) in
            table.column(self.cID)
            table.column(self.ID)
            table.column(self.parentID)
            table.column(self.displayOrder)
            table.column(self.name)
            
            table.primaryKey(self.cID, self.ID,self.displayOrder)
        }
        
        do {
            try self.database.run(createProductMenuTable)
        } catch {
            print(error)
        }*/
        
        do
        {
            let createProductMenuTable = try self.database.prepare("CREATE TABLE ProductMenuTable(clientID INTEGER NOT NULL,ID INTEGER NOT NULL, parentID INTEGER NOT NULL, displayOrder INTEGER NOT NULL, name TEXT NOT NULL, PRIMARY KEY(clientID,parentID,displayOrder,ID))")
            try createProductMenuTable.run()
        }
        catch
        {
            print(error)
            print()
        }
    }
    
    func createProductMenuRelationsTable()
    {
        /*let createProductMenuTable = self.productMenuRelationsTable.create { (table) in
            table.column(self.cID)
            table.column(self.ID)
            table.column(self.menuStructureID)
            table.column(self.typeData)
            table.column(self.typeDescription)
            table.column(self.relatedCode)
            
            table.primaryKey(self.cID, self.ID,self.menuStructureID)
        }
        
        do {
            try self.database.run(createProductMenuTable)
        } catch {
            print(error)
        }*/
        
        do
        {
            let createProductMenuRelationsTable = try self.database.prepare("CREATE TABLE ProductMenuRelationsTable(clientID INTEGER NOT NULL,ID INTEGER NOT NULL, menuStructureID INTEGER NOT NULL, typeData INTEGER NOT NULL, typeDescription TEXT NOT NULL, relatedCode TEXT NOT NULL, PRIMARY KEY(ID,menuStructureID,typeData,typeDescription,relatedCode))")
            try createProductMenuRelationsTable.run()
        }
        catch
        {
            print(error)
            print()
        }
    }
    
    /*********************************************************                  INSERTS                  *********************************************************/
    func insertProducts(products : [ProductModel]!, apk : String)
    {
        objc_sync_enter(lock)
        
        var updatedProducts : [ProductModel]! = []
        
        if(products != nil)
        {
            do {
                let docsTrans = try self.database.prepare("INSERT INTO ProductsTable (apk, itemNo, commonItemNo, productDescription, webDescription, overViewText, ingredientsText, howToUseText, categoryCode, familyCode, manufacturerCode, manufacturerName, sapStatus, imageA, imageB, availabilityForOnline, priceIncludingVAT) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
                
                try database.transaction(.immediate) { () -> Void in
                    for p in products {
                        /*if(p.webDescription == nil || p.webDescription.count == 0 )
                        {
                            p.webDescription = p.productDescription
                        }*/
                        
                        do
                        {
                            /*var overViewText : String!
                            var ingredientsText : String!
                            var howToUseText : String!
                            
                            if(!isNullOrEmpty(string: p.overViewText))
                            {
                                overViewText = p.overViewText.replacingOccurrences(of: "¶", with: "\n").replacingOccurrences(of: "<p>", with: "").replacingOccurrences(of: "я", with: "ÿ").replacingOccurrences(of: "Д", with: "Ä").replacingOccurrences(of: "<br>", with: "\n").replacingOccurrences(of: "Ď", with: ":")
                            }
                            
                            if(!isNullOrEmpty(string: p.ingredientsText))
                            {
                                ingredientsText = p.ingredientsText.replacingOccurrences(of: "¶", with: "\n").replacingOccurrences(of: "<p>", with: "").replacingOccurrences(of: "я", with: "ÿ").replacingOccurrences(of: "Д", with: "Ä").replacingOccurrences(of: "<br>", with: "\n").replacingOccurrences(of: "Ď", with: ":")
                            }
                            
                            if(!isNullOrEmpty(string: p.howToUseText))
                            {
                                howToUseText = p.howToUseText.replacingOccurrences(of: "¶", with: "\n").replacingOccurrences(of: "<p>", with: "").replacingOccurrences(of: "я", with: "ÿ").replacingOccurrences(of: "Д", with: "Ä").replacingOccurrences(of: "<br>", with: "\n").replacingOccurrences(of: "Ď", with: ":")
                            }*/
                            
                            /*if(p.imageA != nil && p.imageA.count > 0)
                            {
                                cacheImage(url: p.imageA, downloadGroup: downloadGroup)
                            }
                            
                            if(p.imageB != nil && p.imageB.count > 0)
                            {
                                cacheImage(url: p.imageB, downloadGroup: downloadGroup)
                            }*/
                            
                            if(Int64(p.itemNoString) != nil)
                            {
                                try docsTrans.run( apk,
                                                   Int64(p.itemNoString)!,
                                                    /* p.barcode,*/
                                                p.commonItemNo,
                                                p.productDescription,
                                                p.webDescription,
                                                p.overViewText,
                                                p.ingredientsText,
                                                p.howToUseText,
                                                p.categoryCodeString != nil ? Int64(p.categoryCodeString) : nil,
                                                p.familyCode,
                                                p.manufacturerCode,
                                                p.manufacturerName,
                                                p.sapStatus,
                                                p.imageA,
                                                p.imageB,
                                                p.availabilityForOnlineInt != nil && p.availabilityForOnlineInt == 1 ? true : false,
                                                p.priceIncludingVAT)
                            }
                        }
                        catch
                        {
                            print(error)
                            updatedProducts.append(p)
                        }
                    }
                }
            } catch
            {
                print(error)
            }
        }
        
        /*if(products != nil)
         {
         do {
                for p in products
                {
                    if(p.imageA != nil && p.imageA.count > 0)
                    {
                        cacheImage(url: p.imageA, downloadGroup: downloadGroup)
                    }
                    
                    if(p.imageB != nil && p.imageB.count > 0)
                    {
                        cacheImage(url: p.imageB, downloadGroup: downloadGroup)
                    }
                    
                    let insertProduct = self.productsTable.insert(self.apk <- APK,
                                                                  self.itemNo <- Int64(p.itemNoString)!,
                                                                  /*self.barcode <- p.barcode,*/
                                                                  self.commonItemNo <- p.commonItemNo,
                                                                  self.productDescription <- p.productDescription,
                                                                  self.webDescription <- p.webDescription,
                                                                  self.overViewText <- p.overViewText,
                                                                  self.ingredientsText <- p.ingredientsText,
                                                                  self.howToUseText <- p.howToUseText,
                                                                  self.categoryCode <- p.categoryCodeString != nil ? Int64(p.categoryCodeString) : nil,
                                                                  self.familyCode <- p.familyCode,
                                                                  self.manufacturerCode <- p.manufacturerCode,
                                                                  self.manufacturerName <- p.manufacturerName,
                                                                  self.sapStatus <- p.sapStatus,
                                                                  self.imageA <- p.imageA,
                                                                  self.imageB <- p.imageB,
                                                                  self.availabilityForOnline <- p.availabilityForOnlineInt != nil && p.availabilityForOnlineInt == 1 ? true : false,
                                                                  self.priceIncludingVAT <- p.priceIncludingVAT)
                    
                    
                    try self.database.run(insertProduct)
                    //print("Product added")
                }
            }
            catch
            {
                print(error)
            }
        }*/
        objc_sync_exit(lock)
        
        updateProducts(products: updatedProducts, apk: apk)
    }
    
    
    func updateProducts(products : [ProductModel]!, apk : String)
    {
        objc_sync_enter(lock)
        
        if(products != nil)
        {
            do {
                let docsTrans = try self.database.prepare("UPDATE ProductsTable SET apk = ? , itemNo = ? , commonItemNo = ? , productDescription = ? , webDescription = ? , overViewText = ? , ingredientsText = ? , howToUseText = ? , categoryCode = ? , familyCode = ? , manufacturerCode = ? , manufacturerName = ? , sapStatus = ? , imageA = ? , imageB = ? , availabilityForOnline = ? , priceIncludingVAT = ? WHERE itemNo =  ?")
                
                try database.transaction(.immediate) { () -> Void in
                    for p in products {
                        /*if(p.webDescription == nil || p.webDescription.count == 0 )
                         {
                         p.webDescription = p.productDescription
                         }*/
                        
                        do
                        {
                            
                            try docsTrans.run( apk,
                                               Int64(p.itemNoString)!,
                                               /* p.barcode,*/
                                p.commonItemNo,
                                p.productDescription,
                                p.webDescription,
                                p.overViewText,
                                p.ingredientsText,
                                p.howToUseText,
                                p.categoryCodeString != nil ? Int64(p.categoryCodeString) : nil,
                                p.familyCode,
                                p.manufacturerCode,
                                p.manufacturerName,
                                p.sapStatus,
                                p.imageA,
                                p.imageB,
                                p.availabilityForOnlineInt != nil && p.availabilityForOnlineInt == 1 ? true : false,
                                p.priceIncludingVAT,
                                Int64(p.itemNoString)!)
                        }
                        catch
                        {
                            print(error)
                        }
                    }
                }
            } catch
            {
                print(error)
            }
        }
        
        objc_sync_exit(lock)
    }
    
    func insertBarcodes(barcodes : [BarcodeModel]!, apk : String)
    {
        objc_sync_enter(lock)
        
        if(barcodes != nil)
        {
            do {
                let docsTrans = try self.database.prepare("INSERT INTO BarcodesTable (apk, itemNo, barcode) VALUES (?,?,?)")
                try database.transaction(.immediate) { () -> Void in
                    for b in barcodes {
                        do
                        {
                            try docsTrans.run(apk,Int64(b.itemNoString)!, b.barcode)
                        }
                        catch
                        {
                            print(error)
                        }
                    }
                }
            } catch
            {
                print(error)
            }
        }
        
        /*if(barcodes != nil)
        {
            do {
                for b in barcodes
                {
            
                    
                    let insertBarcode = self.barcodesTable.insert(self.apk <- APK,
                                                                  self.itemNo <- Int64(b.itemNoString)!,
                                                                  self.barcode <- b.barcode)
                    
                    
                    try self.database.run(insertBarcode)
                    //print("Barcode added")
                }
            }
            catch
            {
                print(error)
            }
        }*/
        objc_sync_exit(lock)
    }
    
    /*func insertCategories(categories : [CategoryModel]!)
    {
        objc_sync_enter(lock)
        if(categories != nil)
        {
            for c in categories
            {
                do
                {
                    if(c.image != nil && c.image.count > 0)
                    {
                        cacheImage(url: c.image)
                    }
                    
                    let insertCategory = self.categoriesTable.insert(or: .replace,
                                                                     self.apk <- APK,
                                                                     self.id <- c.id,
                                                                     self.type <- c.type,
                                                                     self.parentCategoryID <- c.parentCategoryID,
                                                                     self.name <- c.name,
                                                                     self.image <- c.image,
                                                                     self.backgroundColor <- c.backgroundColor,
                                                                     self.textColor <- c.textColor,
                                                                     self.textSize <- c.textSize,
                                                                     self.font <- c.font,
                                                                     self.tintColor <- c.tintColor)
                    
                    try self.database.run(insertCategory)
                    print("Category added")
                    
                }
                catch
                {
                    print(error)
                }
            }
        }
        
        objc_sync_exit(lock)
    }*/
    
    func insertBrands(brands : [CategoryModel]!)
    {
        objc_sync_enter(lock)
        
        if(brands != nil)
        {
            for b in brands
            {
                do
                {
                    if(b.image != nil && b.image.count > 0)
                    {
                        cacheImage(url: b.image )
                    }
                    var texts = b.name.components(separatedBy: "_")
                    let insertBand = self.brandsTable.insert(or: .replace,
                                                             self.apk <- APK,
                                                             self.id <- b.id,
                                                             self.type <- b.type,
                                                             self.code <- texts[0],
                                                             self.name <- texts[1],
                                                             self.image <- b.image)
                    
                    try self.database.run(insertBand)
                }
                catch
                {
                    print(error)
                }
            }
        }
        
        objc_sync_exit(lock)
    }
    
    func insertProductMenu(productMenu : [ProductMenuModel]!)
    {
        objc_sync_enter(lock)
        
        if(productMenu != nil)
        {
            for p in productMenu
            {
                do
                {
                    let insertProductMenu = self.productMenuTable.insert(or: .replace,
                                                             self.cID <- p.clientID,
                                                             self.ID <- p.id,
                                                             self.parentID <- p.parentID,
                                                             self.displayOrder <- p.displayOrder,
                                                             self.name <- p.name)
                    
                    try self.database.run(insertProductMenu)
                    print("Product menu added")
                }
                catch
                {
                    print(error)
                }
            }
        }
        
        objc_sync_exit(lock)
    }
    
    func insertProductMenuRelations(productMenuRelations : [ProductMenuRelationModel]!)
    {
        objc_sync_enter(lock)
        
        if(productMenuRelations != nil)
        {
            /*for p in productMenuRelations
            {
             
                {
                    let insertProductMenu = self.productMenuRelationsTable.insert(or: .replace,
                                                                         self.cID <- p.clientID,
                                                                         self.ID <- p.id,
                                                                         self.menuStructureID <- p.menuStructureID,
                                                                         self.typeData <- p.typeData,
                                                                         self.typeDescription <- p.typeDescription,
                                                                         self.relatedCode <- p.relatedCode)
                    
                    try self.database.run(insertProductMenu)
                    print("Product menu relation added")
                }
                catch
                {
                    print(error)
                }
            }*/
                
                do {
                    let docsTrans = try self.database.prepare("INSERT INTO ProductMenuRelationsTable (clientID, ID, menuStructureID, typeData, typeDescription, relatedCode) VALUES (?,?,?,?,?,?)")
                    try database.transaction(.immediate) { () -> Void in
                        for p in productMenuRelations {
                            
                            do
                            {
                                try docsTrans.run( p.clientID,
                                                   p.id,
                                                   p.menuStructureID,
                                                   p.typeData,
                                                   p.typeDescription,
                                                   p.relatedCode)
                            }
                            catch
                            {
                                print(error)
                            }
                        }
                    }
                } catch
                {
                    print(error)
                }
        }
        
        objc_sync_exit(lock)
    }
    
    /*********************************************************                  GETS                  *********************************************************/
    func getProducts(sortProducts : Bool! = false) -> [ProductModel]!
    {
        objc_sync_enter(lock)
        print("insert lock 1")
        do {
            var productsModels : [ProductModel] = []
            
            var products : AnySequence<Row>! //try self.database.prepare(self.productsTable.filter(self.apk == APK )).order(self.manufacturerName)
            
            if(sortProducts)
            {
                products = try self.database.prepare(self.productsTable.filter(self.apk == APK ).order(self.manufacturerName) )
            }
            else
            {
                products = try self.database.prepare(self.productsTable.filter(self.apk == APK ))
            }
            
            for p in products {
                if(p[self.availabilityForOnline]! != nil && p[self.availabilityForOnline]! && p[self.sapStatus] == "5 - Live" && String(p[self.itemNo]).prefix(1) != "9")
                {
                    let product = ProductModel()
                    
                    product.itemNo = p[self.itemNo]
                    //product.barcode = p[self.barcode]
                    product.commonItemNo = p[self.commonItemNo]
                    product.productDescription = p[self.productDescription]
                    product.webDescription = p[self.webDescription]
                    product.overViewText = p[self.overViewText]
                    product.ingredientsText = p[self.ingredientsText]
                    product.howToUseText = p[self.howToUseText]
                    product.categoryCode = p[self.categoryCode]
                    product.familyCode = p[self.familyCode]
                    product.manufacturerCode = p[self.manufacturerCode]
                    product.manufacturerName = p[self.manufacturerName]
                    product.sapStatus = p[self.sapStatus]
                    product.imageA = p[self.imageA]
                    product.imageB = p[self.imageB]
                    product.availabilityForOnline = p[self.availabilityForOnline]
                    product.priceIncludingVAT = p[self.priceIncludingVAT]
                    
                    product.backgroundColor = "#ffffff"
                    product.font = "Helvetica"
                    product.textSize = 12
                    product.textColor = "#002559"
                    
                    productsModels.append(product)
                }
            }
            
            products = nil
            objc_sync_exit(lock)
            print("exit lock 1")
            return productsModels
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
        
    }
    
    func getBarcodes() -> [BarcodeModel]!
    {
        objc_sync_enter(lock)
        do {
            var barcodessModels : [BarcodeModel] = []
            
            let barcodes = try self.database.prepare(self.barcodesTable.filter(self.apk == APK ))
            
            for b in barcodes {
                let barcode = BarcodeModel()
                
                barcode.itemNo = b[self.itemNo]
                barcode.barcode = b[self.barcode]
                
                barcodessModels.append(barcode)
            }
            
            objc_sync_exit(lock)
            return barcodessModels
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getProductBarcode(itemNo : Int64) -> String
    {
        objc_sync_enter(lock)
        do {
            let barcodes = try self.database.prepare(self.barcodesTable.filter(self.apk == APK && self.itemNo == itemNo ))
            
            for b in barcodes {
                objc_sync_exit(lock)
                return b[self.barcode]
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return ""
    }
    
    
    func getProductItemNoViaBarcode(barcode : String) -> Int64
    {
        objc_sync_enter(lock)
        do {
            let barcodes = try self.database.prepare(self.barcodesTable.filter(self.apk == APK && self.barcode == barcode ))
            
            for b in barcodes {
                objc_sync_exit(lock)
                return b[self.itemNo]
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return -1
    }
    
    
    func getProductByItemNo(itemNo : String) -> ProductModel!
    {
        objc_sync_enter(lock)
        do {            
            if(Int64(itemNo.replacingOccurrences(of: " ", with: "")) != nil)
            {
                let products = try self.database.prepare(self.productsTable.filter(self.apk == APK && self.itemNo == Int64(itemNo.replacingOccurrences(of: " ", with: ""))!))
                
                for p in products {
                    let product = ProductModel()
                    
                    product.itemNo = p[self.itemNo]
                    //product.barcode = p[self.barcode]
                    product.commonItemNo = p[self.commonItemNo]
                    product.productDescription = p[self.productDescription]
                    product.webDescription = p[self.webDescription]
                    product.overViewText = p[self.overViewText]
                    product.ingredientsText = p[self.ingredientsText]
                    product.howToUseText = p[self.howToUseText]
                    product.categoryCode = p[self.categoryCode]
                    product.familyCode = p[self.familyCode]
                    product.manufacturerCode = p[self.manufacturerCode]
                    product.manufacturerName = p[self.manufacturerName]
                    product.sapStatus = p[self.sapStatus]
                    product.imageA = p[self.imageA]
                    product.imageB = p[self.imageB]
                    product.availabilityForOnline = p[self.availabilityForOnline]
                    product.priceIncludingVAT = p[self.priceIncludingVAT]
                    
                    product.backgroundColor = "#ffffff"
                    product.font = "Roboto"
                    product.textSize = 12
                    product.textColor = "#002559"
                    
                    product.informationList = viewsDB.getEmbededViewInformationList(id: 0, product : product, isForArticle : true)
                    
                    objc_sync_exit(lock)
                    return product
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
        
    }
    
    /*func getProductsByCategory(relatedCode : String, typeData : Int) -> [ProductModel]!
    {
        objc_sync_enter(lock)
        do {
            var productsModels : [ProductModel] = []
            
            var products : Statement!
            
            //var createProductMenuRelationsTable = try self.database.prepare("SELECT * FROM ProductsTable WHERE itemNo = \(relatedCode ?? "")")
            print("\(relatedCode)")
            switch typeData {
            case 0:
                products = try self.database.prepare("SELECT * FROM ProductsTable WHERE itemNo = \(relatedCode ?? "")")
            case 1:
                products = try self.database.prepare("SELECT * FROM ProductsTable WHERE commonItemNo = \(relatedCode ?? "")")
            case 2:
                products = try self.database.prepare("SELECT * FROM ProductsTable WHERE categoryCode = \(relatedCode ?? "")")
            default:
                break
            }
            //var a = try createProductMenuRelationsTable.run()
            
            /*print("SELECT * FROM ProductsTable WHERE itemNo = \(relatedCode ?? "")")
            let weatherReadings = createProductMenuRelationsTable.map{ row in
                let product = ProductModel()
                guard let city = row[0] as? String,
                    let zipCode = row[1] as? String,
                    let temperature = row[2] as? String else {
                        fatalError("There was a type error in the received result set: \(row)")
                }
            }*/

            
            if(products != nil)
            {
                for p in products {
                    let product = ProductModel()
                    
                    product.itemNo = p[1] as! Int64?
                    //product.barcode = p[self.barcode]
                    product.commonItemNo = p[2] as? String
                    product.productDescription = p[3] as? String
                    product.webDescription = p[4] as? String
                    product.overViewText = p[5] as? String
                    product.ingredientsText = p[6] as? String
                    product.howToUseText = p[7] as? String
                    product.categoryCode = p[8] as? Int64
                    product.familyCode = p[9] as? String
                    product.manufacturerCode = p[10] as? String
                    product.manufacturerName = p[11] as? String
                    product.sapStatus = p[12] as? String
                    product.imageA = p[13] as? String
                    product.imageB = p[14] as? String
                    //product.availabilityForOnline = p[15] as! Bool
                    product.priceIncludingVAT = p[16] as? Double
                    
                    product.backgroundColor = "#ffffff"
                    product.font = "Roboto"
                    product.textSize = 12
                    product.textColor = "#002559"
                    
                    productsModels.append(product)
                }
            }
            
            
            /*for row in createProductMenuRelationsTable
            {
                let product = ProductModel()
                product.itemNo = row[1] as! Int64
                print()
            }
            
            switch typeData {
            case 0:
                products = try self.database.prepare(self.productsTable.filter(self.apk == APK && self.itemNo == Int64(relatedCode)!))
            case 1:
                products = try self.database.prepare(self.productsTable.filter(self.apk == APK && self.commonItemNo == relatedCode))
            case 2:
                products = try self.database.prepare(self.productsTable.filter(self.apk == APK && self.categoryCode == Int64(relatedCode)))
            default:
                break
            }
            
            if(products != nil)
            {
                for p in products {
                    let product = ProductModel()
                    
                    product.itemNo = p[self.itemNo]
                    //product.barcode = p[self.barcode]
                    product.commonItemNo = p[self.commonItemNo]
                    product.productDescription = p[self.productDescription]
                    product.webDescription = p[self.webDescription]
                    product.overViewText = p[self.overViewText]
                    product.ingredientsText = p[self.ingredientsText]
                    product.howToUseText = p[self.howToUseText]
                    product.categoryCode = p[self.categoryCode]
                    product.familyCode = p[self.familyCode]
                    product.manufacturerCode = p[self.manufacturerCode]
                    product.manufacturerName = p[self.manufacturerName]
                    product.sapStatus = p[self.sapStatus]
                    product.imageA = p[self.imageA]
                    product.imageB = p[self.imageB]
                    product.availabilityForOnline = p[self.availabilityForOnline]
                    product.priceIncludingVAT = p[self.priceIncludingVAT]
                    
                    product.backgroundColor = "#ffffff"
                    product.font = "Roboto"
                    product.textSize = 12
                    product.textColor = "#002559"
                    
                    productsModels.append(product)
                }
            }*/
            
            objc_sync_exit(lock)
            return productsModels
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
        
    }*/
    
    /*func getProducts(manufacturerName : String) -> [ProductModel]!
    {
        objc_sync_enter(lock)
        do {
            var productsModels : [ProductModel] = []
            
            let products = try self.database.prepare(self.productsTable.filter(self.apk == APK && self.manufacturerCode == manufacturerName))
            
            for p in products {
                let product = ProductModel()
                
                product.itemNo = p[self.itemNo]
                //product.barcode = p[self.barcode]
                product.commonItemNo = p[self.commonItemNo]
                product.productDescription = p[self.productDescription]
                product.webDescription = p[self.webDescription]
                product.overViewText = p[self.overViewText]
                product.ingredientsText = p[self.ingredientsText]
                product.howToUseText = p[self.howToUseText]
                product.categoryCode = p[self.categoryCode]
                product.familyCode = p[self.familyCode]
                product.manufacturerCode = p[self.manufacturerCode]
                product.manufacturerName = p[self.manufacturerName]
                product.sapStatus = p[self.sapStatus]
                product.imageA = p[self.imageA]
                product.imageB = p[self.imageB]
                product.availabilityForOnline = p[self.availabilityForOnline]
                product.priceIncludingVAT = p[self.priceIncludingVAT]
                
                product.backgroundColor = "#ffffff"
                product.font = "Roboto"
                product.textSize = 12
                product.textColor = "#002559"
                
                productsModels.append(product)
            }
            
            objc_sync_exit(lock)
            return productsModels
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
        
    }*/
    
    func getProduct(barcode : String) -> ProductModel!
    {
        objc_sync_enter(lock)
        do {
            
            let barcodes = try self.database.prepare(self.barcodesTable.filter(self.apk == APK && self.barcode == barcode))
            
            for b in barcodes {
                
                print(b[self.itemNo])
                let products = try self.database.prepare(self.productsTable.filter(self.apk == APK && self.itemNo == b[self.itemNo]))
                
                for p in products
                {
                    let product = ProductModel()
                    
                    product.itemNo = p[self.itemNo]
                    //product.barcode = p[self.barcode]
                    product.commonItemNo = p[self.commonItemNo]
                    product.productDescription = p[self.productDescription]
                    product.webDescription = p[self.webDescription]
                    product.overViewText = p[self.overViewText]
                    product.ingredientsText = p[self.ingredientsText]
                    product.howToUseText = p[self.howToUseText]
                    product.categoryCode = p[self.categoryCode]
                    product.familyCode = p[self.familyCode]
                    product.manufacturerCode = p[self.manufacturerCode]
                    product.manufacturerName = p[self.manufacturerName]
                    product.sapStatus = p[self.sapStatus]
                    product.imageA = p[self.imageA]
                    product.imageB = p[self.imageB]
                    product.availabilityForOnline = p[self.availabilityForOnline]
                    product.priceIncludingVAT = p[self.priceIncludingVAT]
                    
                    product.backgroundColor = "#ffffff"
                    product.font = "Roboto"
                    product.textSize = 12
                    product.textColor = "#002559"
                    
                    objc_sync_exit(lock)
                    return product
                }
            }
            
           
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    /*func getCategories() -> [CategoryModel]!
    {
        objc_sync_enter(lock)
        do {
            var categoriesModels : [CategoryModel] = []
            
            let categories = try self.database.prepare(self.categoriesTable.filter(self.apk == APK ))
            
            for c in categories {
                let category = CategoryModel()
                
                category.id = c[self.id]
                category.name = c[self.name]
                category.image = c[self.image]
                category.type = c[self.type]
                category.parentCategoryID = c[self.parentCategoryID]
                category.backgroundColor = c[self.backgroundColor]
                category.textColor = c[self.textColor]
                category.textSize = c[self.textSize]
                category.font = c[self.font]
                category.tintColor = c[self.tintColor]
                
                categoriesModels.append(category)
            }
            
            objc_sync_exit(lock)
            return categoriesModels
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
        
    }*/
    
    func getBrands() -> [CategoryModel]!
    {
        objc_sync_enter(lock)
        print("insert lock 4")
        do {
            var brandsModels : [CategoryModel] = []
            
            var brands : AnySequence<Row>!  = try self.database.prepare(self.brandsTable.filter(self.apk == APK ).order(self.name))
            
            for b in brands {
                let brand = CategoryModel()
                
                brand.id = b[self.id]
                brand.code = b[self.code]
                brand.name = b[self.name]
                brand.image = b[self.image]
                brand.type = b[self.type]
                
                brandsModels.append(brand)
            }
            
            brands = nil
            objc_sync_exit(lock)
            print("exit lock 4")
            return brandsModels
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
        
    }
    
    func getProductMenu() -> [ProductMenuModel]!
    {
        objc_sync_enter(lock)
        print("insert lock 2")
        do {
            var productMenuModels : [ProductMenuModel] = []
            
            var productMenu : AnySequence<Row>! = try self.database.prepare(self.productMenuTable.filter(self.cID == clientID ))
            
            for p in productMenu {
                let productMenuModel = ProductMenuModel()
                
                productMenuModel.id = p[self.ID]
                productMenuModel.parentID = p[self.parentID]
                productMenuModel.displayOrder = p[self.displayOrder]
                productMenuModel.name = p[self.name]
                
                productMenuModels.append(productMenuModel)
            }
            
            productMenu = nil
            objc_sync_exit(lock)
            print("exit lock 2")
            return productMenuModels
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
        
    }
    
    func getProductMenuRelations(menuStructureID : Int) -> [ProductMenuRelationModel]!
    {
        objc_sync_enter(lock)
        do {
            var productMenuRelationModels : [ProductMenuRelationModel] = []
            
            let productMenu = try self.database.prepare(self.productMenuRelationsTable.filter(self.cID == clientID && self.menuStructureID == menuStructureID ))
            
            for p in productMenu {
                let productMenuRelationModel = ProductMenuRelationModel()
                
                productMenuRelationModel.id = p[self.ID]
                productMenuRelationModel.menuStructureID = p[self.menuStructureID]
                productMenuRelationModel.typeData = p[self.typeData]
                productMenuRelationModel.typeDescription = p[self.typeDescription]
                productMenuRelationModel.relatedCode = p[self.relatedCode]
                    
                productMenuRelationModels.append(productMenuRelationModel)
            }
            
            objc_sync_exit(lock)
            return productMenuRelationModels
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
        
    }
    
    func getProductMenuRelations() -> [ProductMenuRelationModel]!
    {
        objc_sync_enter(lock)
        print("insert lock 3")
        do {
            var productMenuRelationModels : [ProductMenuRelationModel] = []
            
            var productMenu : AnySequence<Row>! = try self.database.prepare(self.productMenuRelationsTable.filter(self.cID == clientID))
            
            for p in productMenu {
                let productMenuRelationModel = ProductMenuRelationModel()
                
                productMenuRelationModel.id = p[self.ID]
                productMenuRelationModel.menuStructureID = p[self.menuStructureID]
                productMenuRelationModel.typeData = p[self.typeData]
                productMenuRelationModel.typeDescription = p[self.typeDescription]
                productMenuRelationModel.relatedCode = p[self.relatedCode]
                
                productMenuRelationModels.append(productMenuRelationModel)
            }

            productMenu = nil
            objc_sync_exit(lock)
            print("exit lock 3")
            return productMenuRelationModels
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
        
    }
    
    func deleteEntries(apk : String)
    {
        objc_sync_enter(lock)
        
        if(!statusModel.areProductsSaved)
        {
            do{
                try self.database.run(self.productsTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
        
        if(!statusModel.areBarcodesSaved)
        {
            do{
                try self.database.run(self.barcodesTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
        
        
        if(!statusModel.areBrandsSaved)
        {
            do{
                try self.database.run(self.brandsTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
        
        if(!statusModel.isProductMenuSaved)
        {
            do{
                try self.database.run(self.productMenuTable.filter(self.cID == clientID).delete())
            } catch {
                print(error)
            }
        }
        
        if(!statusModel.areProductMenuRelationsSaved)
        {
            do{
                try self.database.run(self.productMenuRelationsTable.filter(self.cID == clientID).delete())
            } catch {
                print(error)
            }
        }
        
        objc_sync_exit(lock)
    }
}

