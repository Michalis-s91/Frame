//
//  ArticlesViewController.swift
//  RichReach
//
//  Created by Eumbrella on 25/01/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import UIKit
import Reachability

class BlogViewController: ViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var backgroundImage: UIImageView!
    @IBOutlet var articlesContainer: UIView!
    @IBOutlet var articlesTableView: UITableView!
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    
    @IBOutlet var viewBottom: NSLayoutConstraint!
    @IBOutlet var viewTrailing: NSLayoutConstraint!
    @IBOutlet var viewLeading: NSLayoutConstraint!
    @IBOutlet var viewTop: NSLayoutConstraint!
    
    var waitingView : WaitingViewController!
    var viewModel : BlogViewModel!
    var task : WebApiTask!
    //var articlesList : [ArticlesModel]! = []
    var images : [ImageCacheModel] = []
    var numberOfCachedImages = 10
    var previousArticlesListSize : Int! = 0
    var viewIsNotDisplayed = true
    var viewDidAppear = false
    var isViewSaved = false
    var synchronized : Synchronized = Synchronized()
    var lock = NSObject()
    var currentUIViewController: UIViewController!
    var reachability: Reachability!
    //var waitingView : WaitingViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        DispatchQueue.global(qos: .background).async {
            self.reachability = Reachability()
            NotificationCenter.default.addObserver(self, selector: #selector(self.reachabilityChanged(_:)), name: NSNotification.Name.reachabilityChanged, object: self.reachability)
            
            do {
                try self.reachability?.startNotifier()
            } catch {
                print("This is not working.")
                return
            }
        }
        
        if(borderWidth > 0)
        {
            self.view.backgroundColor = UIColor(borderColor)
            viewTrailing.constant = CGFloat(borderWidth)
            viewBottom.constant = CGFloat(borderWidth)
            viewTop.constant = CGFloat(borderWidth)
            viewLeading.constant = CGFloat(borderWidth)
        }
        
        if(selectedTab.hasBackgroundImage)
        {
            let data = parameterizationDatabase.getBackgroundImage(apk: APK)
            
            if(data != nil)
            {
                backgroundImage.image = UIImage(data: data!)
            }
        }
        
        currentUIViewController = self
        
        articlesTableView.contentInset = UIEdgeInsets(top: -30, left: 0, bottom: -20, right: 0)
        
        articlesTableView.rowHeight = UITableViewAutomaticDimension
        articlesTableView.tableFooterView = UIView()
        articlesTableView.delegate = self
        articlesTableView.dataSource = self
        
        //if(statusModel.areArticlesSaved)
        //{
            self.viewModel = BlogViewModel()
            viewModel.tabID = selectedTab.id
            viewModel.blogViewController = self
            self.viewModel.loadFromLocalDB()
            
            if(viewModel.articleViewList == nil || viewModel.articleViewList.count == 0)
            {
                indicator.stopAnimating()
                if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable() && statusModel.areArticlesSaved)
                {
                    self.notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.articlesContainer!, text:"No available information")
                }
                else
                {
                    self.waitingView =  showWaitingView(view: self, container: self.view, text: "No available information")
                }
            }
            
            previousArticlesListSize = viewModel.articlesList != nil ? viewModel.articlesList.count : 0
        
        /*}
        else
        {
            let waitingView =  showWaitingView(view: self, container: self.view, text: "No available information")
            DispatchQueue.global(qos: .background).async {
                while(!statusModel.areArticlesSaved)
                {
                    sleep(2)
                    if(!isActivityActive(viewController: self.currentUIViewController))
                    {
                        return
                    }
                    
                    if(!areParametersDownloading && errorOccured)
                    {
                        DispatchQueue.main.async(execute: {() -> Void in
                            waitingView.setText(text: "An error has occured. Please try again later...")
                            waitingView.showInternetIsRequired()
                        })
                        return
                    }
                }
                
                if(!areParametersDownloading && errorOccured)
                {
                    return
                }
                
                if(!isActivityActive(viewController: self.currentUIViewController))
                {
                    return
                }
                
                DispatchQueue.main.async(execute: {() -> Void in
                    waitingView.view.removeFromSuperview()
                    waitingView.removeFromParentViewController()
                    
                    self.viewModel = BlogViewModel()
                    self.viewModel.tabID = selectedTab.id
                    self.viewModel.loadFromLocalDB()
                    
                    if(self.viewModel.articleViewList == nil || self.viewModel.articleViewList.count == 0)
                    {
                        self.notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.articlesContainer!, text:"No available information")
                        self.previousArticlesListSize = self.viewModel.articlesList != nil ? self.viewModel.articlesList.count : 0
                    }
                    
                    self.articlesTableView.reloadData()
                })
            }
        }*/
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidLayoutSubviews() {
        if(!viewIsNotDisplayed)
        {
            super.viewDidAppear(true)
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        navigation = self.navigationController
        viewDidAppear = true
    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if(viewModel != nil && viewModel.articleViewList != nil)
        {
            return viewModel.articleViewList.count
        }
        else
        {
            return 0
        }
    }
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if(section == 0)
        {
            return 0
        }
        
        if(separatorHeight == 0)
        {
            return CGFloat.leastNormalMagnitude
        }
        
        return CGFloat(separatorHeight)
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return CGFloat.leastNormalMagnitude
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var information : GeneralInformation2!
        
        information = viewModel.articleViewList[indexPath.section]
        
        switch information.type {
        case SlotType.Title.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_title") as! InformationTitleViewCell
            var title : TitleModel! = information.title
            cell.titleLabel.text = title.title
            cell.titleLabel.font = UIFont (name: (title.titleFont)!, size: CGFloat((title.titleSize)!))
            cell.titleLabel.textColor = UIColor((title.titleColor)!)
            cell.titleLabel.backgroundColor = UIColor((title.titleBackgroundColor)!)
        
            
            if(title.isTitleCentered != nil && !title.isTitleCentered)
            {
                cell.titleLabel.textAlignment = .left
            }
            
            cell.selectionStyle = .none
            
            return cell
        case SlotType.Photo.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_image") as! InformationImageViewCell
            let photo : PhotoModel! = information.photo
            
            if(photo.title != nil)
            {
                let title : TitleModel! = photo.title
                
                cell.cellTitle.text = title.title
                cell.cellTitle.font = UIFont (name: (title.titleFont)!, size: CGFloat((title.titleSize)!))
                cell.cellTitle.textColor = UIColor((title.titleColor)!)
                cell.cellTitle.backgroundColor = UIColor((title.titleBackgroundColor)!)
                cell.titleHeightConstraint.constant = (title.title?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: UIFont (name: (title.titleFont)!, size: CGFloat((title.titleSize)!))!))!
            }
            else
            {
                cell.titleHeightConstraint.constant = 0
            }
            
            if(photo.link != nil)
            {
                cell.link = photo.link
                cell.awakeFromNib()
            }
            
            if(viewModel.blogView == nil)
            {
                let url = URL(string: percentEncode(s:photo.imageUrl))
                cell.cellImage.kf.setImage(with: url, completionHandler: {
                    (image, error, cacheType, imageUrl) in
                    // image: Image? `nil` means failed
                    // error: NSError? non-`nil` means failed
                    // cacheType: CacheType
                    //                  .none - Just downloaded
                    //                  .memory - Got from memory cache
                    //                  .disk - Got from disk cache
                    // imageUrl: URL of the image
                    
                    if(image != nil)
                    {
                        var aspectRatio = Double((image?.size.height)! / (image?.size.width)!)
                        
                        var height = 0.75 * UIScreen.main.bounds.size.width * CGFloat(aspectRatio)
                        photo.aspectRatio = aspectRatio
                        
                        /*if(cell.articleImageHeight.constant != height)
                         {
                         cell.articleImageHeight.constant = height
                         //self.articlesTableView.reloadData()
                         }
                         else */
                        if(!photo.isImageLoaded)
                        {
                            self.articlesTableView.reloadData()
                            photo.isImageLoaded = true
                        }
                        
                    }
                })
            }
            else
            {
                if(!photo.isImageLoaded)
                {
                    var image = UIImage(data: viewModel.blogView.imageData)
                    
                    images.append(ImageCacheModel(image:  image != nil ? image! : UIImage(), url: photo.imageUrl, photoModel : photo))
                    cell.cellImage.image = (images.last)?.image
                    photo.isImageLoaded = true
                    
                    if(images.count > numberOfCachedImages)
                    {
                        images[0].photoModel.isImageLoaded = false
                        images.remove(at: 0)
                    }
                }
                else
                {
                    for i in 0..<images.count
                    {
                        if(images[i].url ==  photo.imageUrl)
                        {
                            cell.cellImage.image = images[i].image
                            break
                        }
                    }
                }
            }
            
           
            if(photo.button != nil)
            {
                let button : ButtonModel! = photo.button
                
                cell.viewController = self
                cell.button = button
                
                cell.buttonWidth.constant = CGFloat(button.width)
                cell.buttonHeight.constant = CGFloat(button.height)
                cell.cellButton.setTitle(button.name, for: .normal)
                cell.cellButton.titleLabel?.font = UIFont (name: (button?.font)!, size: CGFloat(button.textSize))
                cell.cellButton.setTitleColor(UIColor(button.textColor), for: .normal)
                cell.cellButton.backgroundColor = UIColor(correctHexString(string: button.backgroundColor))
                
                cell.borderWidth.constant =  CGFloat(button.width + button.borderWidth * 2)
                cell.borderHeight.constant = CGFloat(button.height + button.borderWidth * 2)
                cell.buttonBorder.backgroundColor = button.borderWidth != 0 ? UIColor(correctHexString(string: button.borderColor)) : UIColor.clear
                
                
                var titleHeight : CGFloat! = 0.0
                
                if(information.photo.title != nil)
                {
                    titleHeight = photo.title.title?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: UIFont (name: (photo.title.titleFont)!, size: CGFloat((photo.title.titleSize)!))!)
                }
                
                var cellHeight : CGFloat!
                if(photo.aspectRatio != nil)
                {
                    cellHeight = UIScreen.main.bounds.size.width * CGFloat(photo.aspectRatio) + titleHeight
                }
                else
                {
                    cellHeight = UIScreen.main.bounds.size.width + titleHeight
                }
                
                switch button.buttonPosition
                {
                case 1:
                    break
                case 2:
                    cell.borderX.constant = UIScreen.main.bounds.size.width/2 - CGFloat(button.width + button.borderWidth * 2)/2
                    break
                case 3:
                    cell.borderX.constant = UIScreen.main.bounds.size.width - CGFloat(button.width) - CGFloat(button.borderWidth * 2)
                    break
                case 4:
                    cell.borderY.constant = cellHeight/2 - CGFloat(button.height + button.borderWidth * 2)/2
                    break
                case 5:
                    cell.borderY.constant = cellHeight/2 - CGFloat(button.height + button.borderWidth * 2)/2
                    cell.borderX.constant = UIScreen.main.bounds.size.width/2 - CGFloat(button.width + button.borderWidth * 2)/2
                    break
                case 6:
                    cell.borderY.constant = cellHeight/2 - CGFloat(button.height + button.borderWidth * 2)/2
                    cell.borderX.constant = UIScreen.main.bounds.size.width - CGFloat(button.width) - CGFloat(button.borderWidth * 2)
                    break
                case 7:
                    cell.borderY.constant = cellHeight - CGFloat(button.height) - CGFloat(button.borderWidth * 2)
                    break
                case 8:
                    cell.borderY.constant = cellHeight - CGFloat(button.height) - CGFloat(button.borderWidth * 2)
                    cell.borderX.constant = UIScreen.main.bounds.size.width/2 - CGFloat(button.width + button.borderWidth * 2)/2
                    break
                case 9:
                    cell.borderY.constant = cellHeight - CGFloat(button.height) - CGFloat(button.borderWidth * 2)
                    cell.borderX.constant = UIScreen.main.bounds.size.width - CGFloat(button.width) - CGFloat(button.borderWidth * 2)
                    break
                default :
                    break
                }
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case SlotType.Article.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_article") as! ArticleViewCell
            
            let article : ArticleModel! = information.article
            
            cell.title.text = article.title
            cell.title.font = UIFont (name: (article.titleFont)!, size: CGFloat((article.titleSize)!))
            cell.title.textColor = UIColor((article.titleColor)!)
            
            if(!isNullOrEmpty(string: article.category))
            {
                cell.categoryTextView.text = article.category
                cell.categoryTextView.font = UIFont (name: (article.categoryFont)!, size: CGFloat((article.categorySize)!))
                cell.categoryTextView.textColor = UIColor((article.categoryColor)!)
            }
            else
            {
                cell.categoryTextView.text = ""
                cell.categoryTextView.font = UIFont (name: (article.categoryFont)!, size: CGFloat(0))
                cell.categoryTextView.textColor = UIColor((article.categoryColor)!)
            }

            var date = article.publishDate.split(separator: " ")[0]
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let date2 = dateFormatter.date(from: String(date))!
            let dateFormatter2 = DateFormatter()
            dateFormatter2.dateFormat = "dd-MM-yyyy"
            
            cell.date.text = dateFormatter2.string(from: date2)
            
            cell.date.font = UIFont (name: (article.dateFont)!, size: CGFloat((article.dateTextSize)!))
            cell.date.textColor = UIColor((article.dateTextColor)!)
            
            if(article.areItemsSaved)
            {
                cell.articleImageHeight.constant = 0.75 * UIScreen.main.bounds.size.width * CGFloat(information.article.imageAspectRatio)
                
                if(!article.isImageLoaded)
                {
                    var image = UIImage(data: article!.imageData)
                    images.append(ImageCacheModel(image: image != nil ? image! : UIImage() , url: article.image, articleModel : article))
                    cell.articleImage.image = UIImage(data: article.imageData)
                    article.isImageLoaded = true
                    
                    if(images.count > numberOfCachedImages)
                    {
                        images[0].articleModel.isImageLoaded = false
                        images.remove(at: 0)
                    }
                }
                else
                {
                    for i in 0..<images.count
                    {
                        if(images[i].url ==  article.image)
                        {
                            cell.articleImage.image = images[i].image
                            break
                        }
                    }
                }
            }
            else
            {
                let url = URL(string: percentEncode(s:article.image))
                cell.articleImage.kf.setImage(with: url, completionHandler: {
                    (image, error, cacheType, imageUrl) in
                    // image: Image? `nil` means failed
                    // error: NSError? non-`nil` means failed
                    // cacheType: CacheType
                    //                  .none - Just downloaded
                    //                  .memory - Got from memory cache
                    //                  .disk - Got from disk cache
                    // imageUrl: URL of the image
                    
                    if(image != nil)
                    {
                        var aspectRatio = Double((image?.size.height)! / (image?.size.width)!)
                        
                        var height = 0.75 * UIScreen.main.bounds.size.width * CGFloat(aspectRatio)
                        cell.articleImageHeight.constant = height
                        
                        /*if(cell.articleImageHeight.constant != height)
                        {
                            cell.articleImageHeight.constant = height
                            //self.articlesTableView.reloadData()
                        }
                        else */
                        if(!article.isImageLoaded)
                        {
                            self.articlesTableView.reloadData()
                            article.isImageLoaded = true
                        }

                    }
                })
            }
            
            if(viewModel.articleViewList.count == indexPath.section + 1)
            {
                cell.splitter.backgroundColor = .white
            }
            else
            {
                cell.splitter.backgroundColor = .lightGray
            }
            
            cell.selectionStyle = .none
            
            return cell
        default:
            return tableView.dequeueReusableCell(withIdentifier: "general_info_text") as! InformationTextViewCell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var information : GeneralInformation2!
        
        information = viewModel.articleViewList[indexPath.section]
        
        switch information.type {
        case SlotType.Carousel.rawValue:
            let carousel = information.carousel
            var titleHeight : CGFloat! = 0.0
            
            if(carousel?.hasTitles)!
            {
                titleHeight = carousel?.urls[0].title.title?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: UIFont (name: (carousel?.urls[0].title.titleFont)!, size: CGFloat((carousel?.urls[0].title.titleSize)!))!)
            }
            
            var cellHeight : CGFloat!
            let aspcetRatio = carousel?.urls[0].aspectRatio
            if(aspcetRatio != nil)
            {
                cellHeight = UIScreen.main.bounds.size.width * CGFloat(aspcetRatio!) + titleHeight
            }
            else
            {
                cellHeight = UIScreen.main.bounds.size.width + titleHeight
            }
            
            return cellHeight
        case SlotType.Video.rawValue:
            return UIScreen.main.bounds.size.width/1.77 - 2
        case SlotType.Text.rawValue:
            return UITableViewAutomaticDimension
        case SlotType.Photo.rawValue:
            var titleHeight : CGFloat! = 0.0
            
            if(information.photo.title != nil)
            {
                titleHeight = information.photo.title.title?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: UIFont (name: (information.photo.title.titleFont)!, size: CGFloat((information.photo.title.titleSize)!))!)
            }
            
            var cellHeight : CGFloat!
            if(information.photo.aspectRatio != nil)
            {
                cellHeight = 0.9 * UIScreen.main.bounds.size.width * CGFloat(information.photo.aspectRatio) + titleHeight
            }
            else
            {
                cellHeight = 0.9 * UIScreen.main.bounds.size.width + titleHeight
            }
            
            return cellHeight
        case SlotType.Title.rawValue:
            let font = UIFont (name: (FontsAndSizes.titleFont), size: CGFloat((FontsAndSizes.titleTextSize)))
            return (information.title.title.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: font!) + 30)
        case SlotType.Product.rawValue:
            //return 0.75 * UIScreen.main.bounds.size.width * CGFloat(information.product.imageAspectRatio)
            return UITableViewAutomaticDimension
        case SlotType.Article.rawValue:
            //return 0.75 * UIScreen.main.bounds.size.width * CGFloat(information.product.imageAspectRatio)
            return UITableViewAutomaticDimension
        default:
            return 180
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if(viewModel.articleViewList[indexPath.section].type == SlotType.Article.rawValue)
        {
            let article = viewModel.articleViewList[indexPath.section].article
            
            if(article != nil)
            {
                showArticleView(article : article!, navigationController : self.navigationController!, articleViewList : viewModel.articleViewList, viewController : self)
            }
        }
    }
    
    var currentContentYoffset : CGFloat!
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let  height = scrollView.frame.size.height
        let contentYoffset = scrollView.contentOffset.y
        currentContentYoffset = contentYoffset
        let distanceFromBottom = scrollView.contentSize.height - contentYoffset - 15
        if distanceFromBottom < height {
            synchronized.synchronize(obj: lock)
            {
                if (viewModel != nil && viewModel.articleViewList != nil)
                {
                    if (!viewModel.ignoreLoadingMoreData)
                    {
                        viewModel.ignoreLoadingMoreData = true
                        task = WebApiTask(viewController: self, action: loadMoreArticles, displayToast: false, isSynchronizationTimerEnabled: false)
                        task.isFailureActionToast = false
                        task.failureAction = viewModel.setIgnoreLoadingMoreDataFlag
                        task.start()
                    }
                }
            }
        }
    }
    
    func loadMoreArticles()
    {
        viewModel.loadMoreArticles()
        
        /*if(previousArticlesListSize == viewModel.articlesList.count)
        {
            return
        }*/
        
        if (!isActivityActive(viewController: self) && CustomTabbarViewController.navigationControllers.count == 0)
        {
            return
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.indicator.stopAnimating()
            
            let contentOffset = self.articlesTableView.contentOffset
            
            if(self.viewModel.articleViewList.count > 0 && self.notAvailableView != nil)
            {
                self.notAvailableView.view.removeFromSuperview()
                self.notAvailableView.removeFromParentViewController()
            }
            
            if(self.waitingView != nil)
            {
                self.waitingView.view.removeFromSuperview()
                self.waitingView.removeFromParentViewController()
            }
            
            if(self.viewModel.articleViewList == nil || self.viewModel.articleViewList.count == 0)
            {
                self.notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.articlesContainer!, text:"No available information")
            }
            
            self.articlesTableView.reloadData()
            
            
            
            /*if(self.viewModel.articleViewList[0].type != SlotType.Article.rawValue)
            {
                self.articlesTableView.scrollToRow( at: IndexPath(row: 0, section: self.previousArticlesListSize + 1), at: .bottom , animated: false)
            }
            else
            {
                self.articlesTableView.scrollToRow( at: IndexPath(row: 0, section: self.previousArticlesListSize), at: .bottom , animated: false)
            }*/
            
            if(self.previousArticlesListSize == self.viewModel.articlesList.count)
            {
                return
            }
            
            self.previousArticlesListSize = self.viewModel.articlesList.count
            self.viewModel.ignoreLoadingMoreData = false
            
            /*DispatchQueue.main.async(execute: {() -> Void in
                
                self.articlesTableView.layoutIfNeeded()
                self.articlesTableView.setContentOffset(contentOffset, animated: true)
            })*/
            
            //self.articlesTableView.reloadData()
            
            //let range = NSMakeRange(0, self.articlesTableView.numberOfSections)
            //let sections = NSIndexSet(indexesIn: range)
            //self.articlesTableView.reloadSections(sections as IndexSet, with: .automatic)
            
            //UIView.transition(with: self.articlesTableView, duration: 1.0, options: .transitionCrossDissolve, animations: {self.articlesTableView.reloadData()}, completion: nil)

        })
        
        
    }
    
    @objc func reachabilityChanged(_ note: NSNotification) {
        let reachability = note.object as! Reachability
        
        if reachability.connection != .none {
            if (waitingView != nil && !viewModel.ignoreLoadingMoreData)
            {
                viewModel.pageToLoad = 1
                viewModel.ignoreLoadingMoreData = true
                task = WebApiTask(viewController: self, action: loadMoreArticles, displayToast: false, isSynchronizationTimerEnabled: false)
                task.failureAction = viewModel.setIgnoreLoadingMoreDataFlag
                task.start()
            }
        }
    }

    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }

}
