//
//  DescriptionTextFieldDialog.swift
//  RichReach2
//
//  Created by Eumbrella on 10/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class DescriptionTextFieldDialog: UIViewController {

    @IBOutlet var descriptionView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dialogView: UIView!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet var splitter: UIView!
    @IBOutlet var closeButton: UIButton!
    @IBOutlet var textField: UITextField!
    @IBOutlet var button: UIButton!
    
    @IBOutlet var textFieldSplitter1: UIView!
    @IBOutlet var textFieldSplitter2: UIView!
    @IBOutlet var textFieldSplitter3: UIView!
    
    
    var titleText : String!
    var descriptionText : String!
    
    static var dialogDisappeared = true
    var dismissWhenClickOutside = true
    var buttonRunnable : Runnable!
    var inputText : String!
    
    var viewIsAppeared = false
    var keyboardSize = CGSize()
    var userProfile : UserProfileViewController2!
    var isStatusTextDialogDisplayed : Bool!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        DescriptionTextFieldDialog.dialogDisappeared = false
        
        titleLabel.textColor = Colors.sectionTextColor
        
        dialogView.sizeToFit()
        descriptionLabel.sizeToFit()
        descriptionLabel.numberOfLines = 0
        
        if(splitter != nil)
        {
            splitter.backgroundColor = Colors.dialogLineColor
        }
        
        if(closeButton != nil)
        {
            let closeImage = UIImage(named: "ic_dialog_close")?.withRenderingMode(.alwaysTemplate)
            closeButton.setImage(closeImage, for: .normal)
            closeButton.tintColor = Colors.dialogTintColor
        }
        
        let onBackgroundClick = UITapGestureRecognizer(target: self, action: #selector(DescriptionDialog.onBackgroundClick(sender:)))
        backgroundView.isUserInteractionEnabled = true
        backgroundView.addGestureRecognizer(onBackgroundClick)
        
        titleLabel.textColor = Colors.dialogTextColor
        titleLabel.font = UIFont (name: FontsAndSizes.dialogFont, size: CGFloat(FontsAndSizes.dialogTextSize))
        
        if(APK == APKsEnum.BeautyLine.rawValue)
        {
            descriptionLabel.font = UIFont (name: "CharpentierSansPro-Leger", size: CGFloat(FontsAndSizes.dialogTextSize))
            descriptionLabel.textColor = Colors.dialogTextColor
            
            textField.font = UIFont (name: "CharpentierSansPro-Leger", size: CGFloat(FontsAndSizes.dialogTextSize))
            textField.textColor = Colors.dialogTextColor
        }

        if(APK == APKsEnum.RichReach.rawValue)
        {
            button.layer.cornerRadius = 10
            button.backgroundColor = Colors.buttonGray
            //button.setBackgroundImage(imageWithColor(color: Colors.buttonGraySelected), for: .highlighted)
        }
        else
        {
            button.layer.borderColor = UIColor("#1D2D51").cgColor //UIColor(field.fieldStyle.borderColor).cgColor
            button.layer.borderWidth = 1.0
            button.titleLabel?.font = UIFont(name: "CharpentierSansPro-Demi", size: CGFloat(18)) //UIFont(name: field.fieldStyle.textFont, size: CGFloat(field.fieldStyle.textTextSize))
            button.setTitleColor(Colors.dialogTextColor, for: .normal)//UIColor("#1D2D51"), for: .normal)//setTitleColor(UIColor(field.fieldStyle.borderColor), for: .normal)
            button.backgroundColor = UIColor.clear
            
            textFieldSplitter1.backgroundColor = UIColor("#1D2D51")
            textFieldSplitter2.backgroundColor = UIColor("#1D2D51")
            textFieldSplitter3.backgroundColor = UIColor("#1D2D51")
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: NSNotification.Name.UIKeyboardDidShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        keyboardSize.height = 0
        titleLabel.text = titleText
        descriptionLabel.text = descriptionText
    
        self.descriptionLabel.layoutIfNeeded()
        self.descriptionView.layoutIfNeeded()
        self.dialogView.layoutIfNeeded()
    }
    
    override func viewDidLayoutSubviews() {
        if(viewIsAppeared)
        {
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height - keyboardSize.height
        }
        else
        {
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        viewIsAppeared = true
        DescriptionTextFieldDialog.dialogDisappeared = false
        
        roundCorners([.topLeft,.topRight], radius: 10, view: dialogView)
        
        UIView.animate(withDuration: 0.3, animations: {
            self.descriptionView.backgroundColor = Colors.dialogsBackgroundColor
            
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height - self.keyboardSize.height
        }, completion: nil)
        self.dialogView.isHidden = false
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        DescriptionTextFieldDialog.dialogDisappeared = true
    }
    
    @objc func onBackgroundClick(sender:UITapGestureRecognizer) {
        if(dismissWhenClickOutside)
        {
            dismissDialog()
        }
    }
    
    @IBAction func dismissDialog(_ sender: UIButton) {
        dismissDialog()
    }
    
    /// Sets the dialog view.
    ///
    /// - Parameters:
    ///   - title: The dialog title.
    ///   - description: The dialog description.
    func setDialogView(title: String, description: String)
    {
        titleText = title
        descriptionText = description
    }
    
    /// Update descritpion.
    ///
    /// - Parameter newDescription: The new description.
    func updateDescription(newDescription : String)
    {
        descriptionLabel.text = newDescription
    
        self.titleLabel.layoutIfNeeded()
        self.descriptionLabel.layoutIfNeeded()
        self.button.layoutIfNeeded()
        self.textField.layoutIfNeeded()
        self.descriptionView.layoutIfNeeded()
        self.dialogView.layoutIfNeeded()
        
        viewDidLoad()
        viewDidAppear(true)
        viewDidLayoutSubviews()
        //self.view.layoutIfNeeded()
    }
    
    
    /// Dismiss dialog with animation.
    func dismissDialog(){
        UIView.animate(withDuration: 0.3, animations: {
            if(self.descriptionView != nil && self.dialogView != nil)
            {
                self.descriptionView.backgroundColor = UIColor.init(red: 1,
                                                                    green: 1,
                                                                    blue: 1,
                                                                    alpha: 0)
                
                self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
            }
        }, completion: {(finished: Bool) in
            self.dismiss(animated: true,completion: nil)
        })
        
        DescriptionTextFieldDialog.dialogDisappeared = true
        
        if(userProfile != nil)
        {
            userProfile.isStatusTextDialogDisplayed = false
        }
    }
    
    /// Dismiss dialog with animation.
    func dismissDialog(runnable : @escaping Runnable){
        UIView.animate(withDuration: 0.3, animations: {
            if(self.descriptionView != nil && self.dialogView != nil)
            {
                self.descriptionView.backgroundColor = UIColor.init(red: 1,
                                                                    green: 1,
                                                                    blue: 1,
                                                                    alpha: 0)
                
                self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
            }
        }, completion: {(finished: Bool) in
            self.dismiss(animated: true,completion: { () in
                if(runnable != nil)
                {
                    runnable()
                }
            })
        })
    }

    @IBAction func buttonClicked(_ sender: UIButton) {
        textField.endEditing(true)
        inputText = textField.text
        buttonRunnable()
    }
    
    @objc func keyboardWasShown(notification: NSNotification){
        var keyboardHeight : CGFloat!
        
        if let keyboardFrame: NSValue = notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue {
            let keyboardRectangle = keyboardFrame.cgRectValue
            keyboardHeight = keyboardRectangle.height
        }
        
        var info = notification.userInfo!
        keyboardSize = ((info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size)!
        keyboardSize.height = keyboardHeight
        
        self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height - keyboardSize.height
    }
    
    @objc func keyboardWillBeHidden(notification: NSNotification){
        keyboardSize.height = 0
    }

}
