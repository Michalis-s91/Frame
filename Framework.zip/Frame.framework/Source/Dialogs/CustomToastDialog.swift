//
//  CustomToast.swift
//  RichReach2
//
//  Created by Eumbrella on 15/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// Provides customised Toast class. Instead of the iOS default toast, our implementation uses a Popup Window that
/// is displayed on the top of the screen. Our toast implementation (popup window) comes with a button that allows the
/// user to close the message that is displayed.
class CustomToastDialog: UIViewController {

    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet var dialogView: UIView!
    @IBOutlet weak var dialogTextView: UILabel!
    @IBOutlet var statusBar: UIView?
    @IBOutlet var closeView: UIView!
    
    @IBOutlet var toastDialogView: UIView!
    @IBOutlet var toastView: UIView!
    
    @IBOutlet var statusBarHeight: NSLayoutConstraint!
    
    var message : String!
    var barHeight : CGFloat!
    
    static var parentView : UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dialogTextView.sizeToFit()
        dialogTextView.numberOfLines = 0
    
        if let b = dialogView?.frame.size.height
        {
            if (b < CGFloat(60.0))
            {
                dialogView?.translatesAutoresizingMaskIntoConstraints = true
                
                if UIDevice().userInterfaceIdiom == .phone {
                    switch UIScreen.main.nativeBounds.height {
                    case 2436:
                        dialogView?.frame = CGRect(x: 0, y: (dialogView?.frame.origin.y)!, width: UIScreen.main.bounds.size.width, height: 100 )
                    default:
                        dialogView?.frame = CGRect(x: 0, y: (dialogView?.frame.origin.y)!, width: UIScreen.main.bounds.size.width, height: 60 )
                    }
                }
                //dialogView?.frame = CGRect(x: 0, y: (dialogView?.frame.origin.y)!, width: UIScreen.main.bounds.size.width, height: 60 )
            }
        }
    
        toastDialogView.isUserInteractionEnabled = true
        dialogView.isUserInteractionEnabled = true
        closeButton.isUserInteractionEnabled = true
        
        dialogTextView.text = message
        
        barHeight = UIApplication.shared.statusBarFrame.height

        dialogView?.backgroundColor = Colors.toastColor
        statusBar?.backgroundColor = Colors.toastColor
        dialogTextView.textColor = Colors.toastTextColor
        
        dialogTextView.font = UIFont (name: FontsAndSizes.toastFont, size: CGFloat(FontsAndSizes.toastTextSize))
        
        let closeImage = UIImage(named: "ic_dialog_close")?.withRenderingMode(.alwaysTemplate)
        closeButton.setImage(closeImage, for: .normal)
        closeButton.tintColor = Colors.toastTintColor
        
        statusBarHeight.constant = UIApplication.shared.statusBarFrame.height
    }
    
    override func viewDidAppear(_ animated: Bool) {
        roundCorners([.bottomLeft,.bottomRight], radius: 10, view: dialogView!)
    }

    @objc func onBackgroundClick(sender:UITapGestureRecognizer) {
        dismissDialog()
    }

    @IBAction func closeDialog(_ sender: UIButton) {
        dismissDialog()
    }
    
    /// Dismiss dialog with animation.
    func dismissDialog(){
        UIView.animate(withDuration: 0.8, animations: {
            if(AppDelegate.isPotraitOrientation)
            {
                self.view.frame = CGRect(x: 0, y: -1000, width: UIScreen.main.bounds.size.width, height: (self.toastDialogView?.frame.height)! )
            }
            else
            {
                self.view.frame = CGRect(x: 0, y: -1000, width: UIScreen.main.bounds.size.height, height: (self.toastDialogView?.frame.height)! )
            }
            
        }, completion: {(finished: Bool) in
            self.dismiss(animated: true,completion: nil)
        })
    }
}
