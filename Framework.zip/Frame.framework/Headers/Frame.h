//
//  Frame.h
//  Frame
//
//  Created by George Rousou on 18/09/2019.
//  Copyright © 2019 George Rousou. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Frame.
FOUNDATION_EXPORT double FrameVersionNumber;

//! Project version string for Frame.
FOUNDATION_EXPORT const unsigned char FrameVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Frame/PublicHeader.h>


