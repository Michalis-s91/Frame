//
//  StoresWepApi.swift
//  RichReach2
//
//  Created by Eumbrella on 27/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Web api for getting store locator view parameters, stores informations (address, phone etc.), stores hours and stores holidays.
class StoresWepApi
{
    /// Post requset for getting store locator view parameters.
    ///
    /// - Parameter clientID: The cliend ID.
    /// - Returns: The store locator view parameters.
    static func getStoreLocatorInfoParameters(clientID : Int64!) throws -> StoreLocatorInfoParametersModel!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http:/www.eumbrellacorp.com/webapi/eorderingAPI/GetStoreLocatorInfoParameters?Clientid=" + String(clientID),params:  "")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let storeLocatorInfoParameters = try decoder.decode(StoreLocatorInfoParametersModel.self, from : (response.data(using: .utf8))!)
                
                return storeLocatorInfoParameters
            }
        }
        catch
        {
            throw Errors.error
        }
        
        return nil
    }
    
    static func getProximityOffers(clientID : Int64!, pageNumber : Int!, userPhone : String!) throws -> [ProximityOfferModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://www.eumbrellacorp.com/webapi/eOrderingAPI/GetProximityOffers?ClientID=\(clientID!)&PageNo=\(pageNumber!)&Mobile=\(userPhone ?? "")", params: "")
        
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let proximityOffers = try decoder.decode(ProximityOffers.self, from : (response.data(using: .utf8))!)
                
                return proximityOffers.proximityOffersList
            }
        }
        catch
        {
            print((error))
        }
        
        return nil
    }
    
    
    /// Post requset for getting stores informations.
    ///
    /// - Parameter clientID: The cliend ID.
    /// - Returns: The stores informations.
    static func getStores(clientID : Int64!) throws -> [StoreModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http:/www.eumbrellacorp.com/webapi/eorderingAPI/GetStoreInfoDataList?Clientid=" + String(clientID),params:  "")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let stores = try decoder.decode(Stores.self, from : (response.data(using: .utf8))!)
                
                return stores.storesList
            }
        }
        catch
        {
            print((error))
            throw Errors.error
        }
        
        return nil
    }
    
    /// Post requset for getting stores hours.
    ///
    /// - Parameter clientID: The cliend ID.
    /// - Returns: The stores hours.
    static func getStoresHours(clientID : Int64!) throws -> [HoursModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http:/www.eumbrellacorp.com/webapi/eorderingAPI/GetShopsTimeTableForLocal?Clientid=" + String(clientID),params:  "")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let storesHours = try decoder.decode(Hours.self, from : (response.data(using: .utf8))!)
                
                return storesHours.hoursList
            }
        }
        catch
        {
            print((error))
            throw Errors.error
        }
        
        return nil
    }
    
    static func getYearlyHolidays(clientID : Int64!) throws -> [YearlyHolidaysModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http:/www.eumbrellacorp.com/webapi/eorderingAPI/GetYearlyHolidaysForLocal?Clientid=" + String(clientID),params:  "")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let holidays = try decoder.decode(Holidays.self, from : (response.data(using: .utf8))!)
                
                return holidays.holidaysList
            }
        }
        catch
        {
            print((error))
            throw Errors.error
        }
        
        return nil
    }
    
    static func getShopYearlyHolidays(clientID : Int64!) throws -> [YearlyShopHolidaysModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http:/www.eumbrellacorp.com/webapi/eorderingAPI/GetShopYearlyHolidaysForLocal?Clientid=" + String(clientID),params:  "")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let shopHolidays = try decoder.decode(ShopHolidays.self, from : (response.data(using: .utf8))!)
                
                return shopHolidays.shopHolidaysList
            }
        }
        catch
        {
            print((error))
            throw Errors.error
        }
        
        return nil
    }
}

/// Helper classes for deserialisation.
class Stores : Codable
{
    var storesList : [StoreModel]!

    private enum CodingKeys : String, CodingKey {
        case storesList = "StoresList"
    }
}

class ProximityOffers : Codable
{
    var proximityOffersList : [ProximityOfferModel]!
    
    private enum CodingKeys : String, CodingKey {
        case proximityOffersList = "OffersList"
    }
}

class Hours : Codable
{
    var hoursList : [HoursModel]!
    
    private enum CodingKeys : String, CodingKey {
        case hoursList = "timeTableList"
    }
}

class Holidays : Codable
{
    var holidaysList : [YearlyHolidaysModel]!
    
    private enum CodingKeys : String, CodingKey {
        case holidaysList = "holidaysList"
    }
}

class ShopHolidays : Codable
{
    var shopHolidaysList : [YearlyShopHolidaysModel]!
    
    private enum CodingKeys : String, CodingKey {
        case shopHolidaysList = "holidaysList"
    }
}
