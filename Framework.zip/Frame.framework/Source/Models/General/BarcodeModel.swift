//
//  BarcodeModel.swift
//  RichReach2
//
//  Created by Eumbrella on 25/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class BarcodeModel : Codable
{
    var itemNoString : String!
    var itemNo : Int64!
    var barcode : String!
    
    private enum CodingKeys : String, CodingKey {
        case itemNoString = "ItemNo"
        case barcode = "Barcode"
        
    }
}
