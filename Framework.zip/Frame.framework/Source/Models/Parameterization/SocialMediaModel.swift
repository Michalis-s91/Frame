//
//  SocialMediaModel.swift
//  RichReach2
//
//  Created by Eumbrella on 02/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class SocialMediaModel : Codable
{
    var index : Int!
    var type : Int!
    var link : String!
    
    private enum CodingKeys : String, CodingKey {
        case index = "SocialMediaIndex"
        case type = "SocialMediaType"
        case link = "Link"
    }
}
