//
//  TicketItemViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 13/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// TicketItemViewCell is a cell that is been used at loyalty ticket table
class TicketItemViewCell: UITableViewCell {

    @IBOutlet var descriptionLabel: UILabel!
    @IBOutlet var erpReferenceLabel: UILabel!
    @IBOutlet var barcodeLabel: UILabel!
    @IBOutlet var quantityLabel: UILabel!
    @IBOutlet var priceLabel: UILabel!
    @IBOutlet var vatLabel: UILabel!
    @IBOutlet var amountLabel: UILabel!
    @IBOutlet var discountLabel: UILabel!
    @IBOutlet var discountPercLabel: UILabel!
    @IBOutlet var grossLabel: UILabel!
    
    @IBOutlet var lineHeight: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
