//
//  OptionsListViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 25/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class OptionsListViewController: UIViewController{

    @IBOutlet var optionsListView: UIView!
    @IBOutlet var optionsTable: UITableView!
    
    var store : StoreModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        /*optionsTable.tableFooterView = UIView()
        optionsTable.delegate = self
        optionsTable.dataSource = self*/
    }

    /*func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return store.options.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "option_cell") as! OptionViewCell
        cell.optionLabel.text = store.options[indexPath.row]
        
        if(indexPath.row == store.options.count - 1)
        {
            cell.splitter.removeFromSuperview()
        }
        return cell
    }*/
    

}
