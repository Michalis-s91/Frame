//
//  NotificationModel.swift
//  RichReach2
//
//  Created by Eumbrella on 26/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Holds notification related information such as the campaign ID and the partner name
class NotificationModel
{
    var campaignID : Int64!
    var partnerName : String!
    var partnerImageUri : String!
    var message : String!
    var apkName : String!
    private var isSeen : Bool!
    var IsSeen : Bool!
    {
        get
        {
            return isSeen
        }
        
        set(seen)
        {
            self.isSeen = seen
            self.isNotSeen = !seen
        }
    }
    var isNotSeen : Bool!
    var timeStamp : Date!
    private var timeStampString : String!
    var TimeStampString : String!
    {
        get
        {
            return self.timeStampString
        }
        
        set(timeStampString)
        {
            self.timeStampString = timeStampString
        }
    }
    
    /// Returns the time stamp in string format.
    ///
    /// - Returns: The time stamp in string format.
    func getTimeStampString() -> String
    {
        return timeStampString
    }
    
}
