//
//  VerificationType.swift
//  RichReach2
//
//  Created by Eumbrella on 07/10/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

enum VerificationType : Int
{
    case PhoneNumber = 1
    //case Email = 2
    case PhoneNumberAndEmail = 3
}


