//
//  UnderConstructionViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 03/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Beauty line view for showing under construction message.
class UnderConstructionViewController: ViewController {
    @IBOutlet var image: UIImageView!
    @IBOutlet var label: UILabel!
    
    var viewIsNotDisplayed = true
    var notAvailableViewModel : NotAvailableModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        navigationBarItem = self.navigationItem
       
        notAvailableViewModel = viewsDB.getNotAvailableView()
        
        if(notAvailableViewModel != nil)
        {
            self.view.backgroundColor = UIColor.white //UIColor(notAvailableView.backgroundColor)
            
            label.textColor = UIColor(notAvailableViewModel.messageTextColor)
            label.font = UIFont (name: (notAvailableViewModel.messageFont)!, size: CGFloat((notAvailableViewModel.messageTextSize)!))
            
            let url = URL(string: percentEncode(s: notAvailableViewModel.image))
            image.kf.setImage(with: url)
        }
        
        if(selectedTab.tabType != TabType.Transactions.rawValue)
        {
            let label = LabelWithPadding()
            
            label.text = selectedTab.name
            
            let font = UIFont (name: (FontsAndSizes.titleFont), size: CGFloat((FontsAndSizes.titleTextSize)))
            label.font = font
            label.textColor = Colors.titleTextColor
            label.backgroundColor = Colors.titleBackround
            label.numberOfLines = 0
            let line = UIView()
            line.backgroundColor = Colors.titleSplitterColor
            
            if(!FontsAndSizes.isTitleCentered)
            {
                label.leftPadding = borderWidth + 10
                label.textAlignment = .left
            }
            else
            {
                label.textAlignment = .center
            }
            
            var titleHeightSize : CGFloat = 40
            if(font != nil)
            {
                titleHeightSize = (label.text?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: font!))! + 20
            }
            
            label.frame = CGRect(x: 0, y: titleTopPadding, width: UIScreen.main.bounds.size.width, height: titleHeightSize)
            line.frame = CGRect(x: 0, y: titleTopPadding + titleHeightSize, width: UIScreen.main.bounds.size.width * 0.8, height: 1)
            line.center.x = UIScreen.main.bounds.size.width / 2
            
            self.view.addSubview(label)
            self.view.addSubview(line)
            
            self.label.text = "View under construction..."
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        viewIsNotDisplayed = false
        super.viewDidAppear(true)
    }
    
    override func viewDidLayoutSubviews() {
        if(!viewIsNotDisplayed)
        {
            super.viewDidAppear(true)
        }
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }

}
