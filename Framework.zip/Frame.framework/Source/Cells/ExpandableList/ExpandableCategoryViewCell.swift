//
//  ExpandableCategoryViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 08/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class ExpandableCategoryViewCell: UITableViewCell {

    @IBOutlet var categoryLabel: UILabel!
    @IBOutlet var expandImage: UIImageView!
    @IBOutlet var categoryImage: UIImageView!
    
    @IBOutlet var categoryImageWidth: NSLayoutConstraint!
    @IBOutlet var leftPadding: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
