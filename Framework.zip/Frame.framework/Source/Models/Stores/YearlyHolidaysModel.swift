//
//  YearlyHolidaysModel.swift
//  RichReach2
//
//  Created by Eumbrella on 05/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class YearlyHolidaysModel : Codable
{
    var holidayDate : String!
    var description : String!
    
    private enum CodingKeys : String, CodingKey {
        case holidayDate = "HolidayDate"
        case description = "Description"
    }
}
