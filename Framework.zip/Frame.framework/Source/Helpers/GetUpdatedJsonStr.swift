//
//  GetUpdatedJsonStr.swift
//  RichReach2
//
//  Created by Eumbrella on 09/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/**
 * Helper for removing special characters from string.
 */
class GetUpdatedJsonStr
{
    /**
     * Removes special characters from the input string and returns the updated string.
     * @param inputString The input string.
     * @return The updated string.
     */
    static func getUpdatedJsonStr(inputString : String) -> String
    {
        if (isNullOrEmpty(string: inputString) || inputString.lowercased() == "null")
        {
            return ""
        }
        
        var outputString = inputString.replacingOccurrences(of: "|", with: "\"")
        outputString = outputString.replacingOccurrences(of: "\\\\",with: "\\")
        //outputString = outputString.replacingOccurrences(of: "{",with: "[")
        //outputString = outputString.replacingOccurrences(of: "}",with: "]")
        if(outputString[0] == "\"")
        {
            outputString = String(outputString.dropFirst(1))
        }
        
        if(outputString[outputString.count - 1] == "\"")
        {
            outputString = String(outputString.dropLast())
        }
        
        return  outputString//System.Text.RegularExpressions.Regex.Unescape(outputString)
    }
}
