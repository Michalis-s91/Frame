//
//  FieldStyleModel.swift
//  RichReach2
//
//  Created by Eumbrella on 04/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class FieldStyleModel : Codable
{
    var id : Int!
    var labelTextColor : String!
    var labelFont : String!
    var labelTextSize : Int!
    var textTextColor : String!
    var textFont : String!
    var textTextSize : Int!
    var borderColor : String!
    var asteriskColor : String!
    var tintColor : String!
    var borderStyle : Int!
    
    private enum CodingKeys : String, CodingKey {
        case id = "ID"
        case labelTextColor = "LabelTextColor"
        case labelFont = "LabelFont"
        case labelTextSize = "LabelTextSize"
        case textTextColor = "TextColor"
        case textFont = "TextFont"
        case textTextSize = "TextSize"
        case borderColor = "BorderColor"
        case asteriskColor = "AsteriskColor"
        case tintColor = "TintColor"
        case borderStyle = "BorderStyle"
    }
}
