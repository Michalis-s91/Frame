//
//  LoyaltyStatementViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 13/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Creates a view with container and is been used for showing the loyalty statement view.
class LoyaltyStatementViewController: ViewController {

    @IBOutlet var loyaltyStatementContainer: UIView!
    @IBOutlet var headerView: UIView!
    var partnerTemp : PartnerModel!
    var loyaltyStatementView : LoyaltyStatementView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if(AppDelegate.isPotraitOrientation)
        {
            // headerView.frame = CGRect(x: 0, y: 0, width: loyaltyStatementContainer.frame.height, height: headerView.frame.height)
            //self.tabBarController?.tabBar.isHidden = true
            let titleFont = UIFont(name: "UIFontWeightRegular", size: 15) ?? UIFont.systemFont(ofSize: 15)
            self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.font: titleFont, NSAttributedStringKey.foregroundColor:UIColor.white]
            self.title = partnerTemp != nil && !isNullOrEmpty(string: partnerTemp.name) ? partnerTemp.name + " - " + NSLocalizedString("loyaltyStatementTitle", comment: "") : NSLocalizedString("loyaltyStatementTitle", comment: "")
            
            headerView.backgroundColor = Colors.bckg_drawer_item
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if(UIApplication.shared.statusBarOrientation != .landscapeRight)
        {
            headerView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.height, height: headerView.frame.height)
            roundCorners([.bottomLeft,.bottomRight], radius: 10, view: headerView)
            
            loyaltyStatementView = self.storyboard?.instantiateViewController(withIdentifier: "LoyaltyStatementView") as? LoyaltyStatementView
            loyaltyStatementView.partner = partnerTemp
            
            //loyaltyStatementView.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.height, height: UIScreen.main.bounds.size.width - 64 - 35)
            //loyaltyStatementView.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: (loyaltyStatementContainer?.frame.height)!)
            loyaltyStatementView.view.frame = CGRect(x: 0, y: 0, width: (loyaltyStatementContainer?.frame.width)!, height: (loyaltyStatementContainer?.frame.height)!)
            
            loyaltyStatementView.willMove(toParentViewController: self)
            self.loyaltyStatementContainer?.addSubview((loyaltyStatementView.view)!)
            //self.addChildViewController(wishListView)
            loyaltyStatementView.didMove(toParentViewController: self)
            loyaltyStatementView.loyaltyStatementContainer = loyaltyStatementContainer
            loyaltyStatementView.parentNavigationController = self.navigationController
        }
    }
    
    override func willMove(toParentViewController parent: UIViewController?)
    {
        super.willMove(toParentViewController: parent)
        if parent == nil
        {
            switch UIDevice.current.orientation{
            case .portrait:
                AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.portrait, andRotateTo: UIInterfaceOrientation.landscapeLeft)
            case .portraitUpsideDown:
                AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.portrait, andRotateTo: UIInterfaceOrientation.landscapeLeft)
            case .landscapeLeft:
                AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.portrait, andRotateTo: UIInterfaceOrientation.portrait)
            case .landscapeRight:
                AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.portrait, andRotateTo: UIInterfaceOrientation.portrait)
            default:
                AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.portrait, andRotateTo: UIInterfaceOrientation.landscapeLeft)
            }
            AppDelegate.isPotraitOrientation = true
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let backItem = UIBarButtonItem()
        backItem.title = partnerTemp != nil && !isNullOrEmpty(string: partnerTemp.name) ? partnerTemp.name + " - " + NSLocalizedString("loyaltyTicketTitle", comment: "") : NSLocalizedString("loyaltyTicketTitle", comment: "")
        
        let font = UIFont(name: "UIFontWeightRegular", size: 15) ?? UIFont.systemFont(ofSize: 15)
        backItem.setTitleTextAttributes([NSAttributedStringKey.font: font, NSAttributedStringKey.foregroundColor:UIColor.white], for: .normal)
        navigationItem.backBarButtonItem = backItem
    }
    
    @IBAction func syncClicked(_ sender: UIBarButtonItem) {
        loyaltyStatementView.onOptionsItemSelected()
    }
}
