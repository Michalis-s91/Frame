//
//  UrlModel.swift
//  RichReach2
//
//  Created by Eumbrella on 07/06/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Holds information about a carousel image (e.g title specifications and image url).
class UrlModel : Codable
{
    var url : String!
    var title : TitleModel!
    //var titleID : Int!
    var id : Int!
    var aspectRatio : Double!
    
    private enum CodingKeys : String, CodingKey {
        case url = "Url"
        case title = "Title"
        case id = "UrlId"
    }
}
