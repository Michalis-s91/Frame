//
//  StoresLocatorViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 23/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// StoresLocatorViewModel is the view model associated to the stores locator view.
class StoresLocatorViewModel
{
    var cities : [CityModel]! = []
    var cityTextColor : String!
    var cityTextSize : Int!
    var cityTextFont : String!
    
    var addressTextColor : String!
    var addressTextSize : Int!
    var addressTextFont : String!
    
    
    /// Constructor. Initialises the properties of class.
    init()
    {
      
    }
}
