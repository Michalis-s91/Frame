//
//  CheckBoxConnectionID.swift
//  RichReach
//
//  Created by Eumbrella on 21/03/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

enum CheckBoxConnectionID : Int
{
    case IsAdult = 6
    case ReceiveCardSMS = 7
    //case Right = 8
    case ReceiveEmail = 9
    case ReceiveSms = 10
}
