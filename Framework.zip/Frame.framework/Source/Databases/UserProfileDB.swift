//
//  UserProfileDB.swift
//  RichReach2
//
//  Created by Eumbrella on 31/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import SQLite
import QuartzCore

class UserProfileDB : NSObject
{
    
    let DATABASE_NAME = "UserProfileDB"
    
    var database : Connection!
    var lock = NSObject()
    var version = 1
    
    var userProfileViewTable = Table("UserProfileViewTable")
    var fieldsTable = Table("FieldsTable")
    var dropDownItemsTable = Table("DropDownItemsTable")
    var fieldsStylesTable = Table("FieldsStylesTable")
    var verificationViewTable = Table("VerificationViewTable")
    
    //user profile view table columns
    let apk = Expression<String>("apk")
    let index = Expression<Int>("index")
    let type = Expression<Int>("type")
    let isFullWidth = Expression<Bool>("isFullWidth")
    let id1 = Expression<Int>("id1")
    let id2 = Expression<Int?>("id2")
    let backgroundColor = Expression<String?>("backgroundColor")
    let shouldHideOnUpdateProfileView = Expression<Bool?>("shouldHideOnUpdateProfileView")
    
    //fields table columns
    let isDropDown = Expression<Bool>("isDropDown")
    let inputType = Expression<Int?>("inputType")
    let placeHolder = Expression<String?>("placeHolder")
    let isRequirement = Expression<Bool>("isRequirement")
    let labelName = Expression<String>("labelName")
    let styleID = Expression<Int>("styleID")
    let dropDownItems = Expression<[String]?>("dropDownItems")
    
    //dropdown items columns
    let id = Expression<Int>("id")
    let text = Expression<String>("text")
    
    //field style table
    let labelTextColor = Expression<String>("labelTextColor")
    let labelFont = Expression<String>("labelFont")
    let labelTextSize = Expression<Int>("labelTextSize")
    let textTextColor = Expression<String>("textTextColor")
    let textFont = Expression<String>("textFont")
    let textTextSize = Expression<Int>("textTextSize")
    let borderColor = Expression<String>("borderColor")
    let asteriskColor = Expression<String>("asteriskColor")
    let tintColor = Expression<String>("tintColor")
    let borderStyle = Expression<Int?>("borderStyle")
    

    override init(){
        do{
            let documentDirectory = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let fileUrl = documentDirectory.appendingPathComponent(DATABASE_NAME).appendingPathExtension("sqlite3")
            self.database = try Connection(fileUrl.path)
        }
        catch
        {
            print(error)
        }
    }
    
    /// Checks if database need to be upgraded, and upgrade it if needed.
    func checkForUpgrade()
    {
        createTables()
        
        switch database.userVersion {
        case 0:
            upgradeToVersion1()
        default:
            break
        }
        
        
        database.userVersion = version
    }
    
    /// Upgrade database to version 1.
    func upgradeToVersion1()
    {
        do
        {
            try database.run(self.fieldsStylesTable.addColumn(self.borderStyle))
            try database.run(self.userProfileViewTable.addColumn(self.backgroundColor))
            try database.run(self.userProfileViewTable.addColumn(self.shouldHideOnUpdateProfileView))
        }
        catch
        {
            print(error)
        }
    }
    
    /// Creates the products database tables.
    func createTables()
    {
        objc_sync_enter(lock)
        createUserProfileViewTable()
        createFieldsTable()
        createFieldsStylesTable()
        createDropDownItemsTable()
        createVerificationViewTable()
        objc_sync_exit(lock)
    }
    
    /*********************************************************                  CREATES                  *********************************************************/
    func createVerificationViewTable()
    {
        let createVerificationViewTable = self.verificationViewTable.create { (table) in
            table.column(self.apk)
            table.column(self.index)
            table.column(self.type)
            table.column(self.id1)
            
            table.primaryKey(self.apk, self.index)
        }
        
        do {
            try self.database.run(createVerificationViewTable)
        } catch {
            print(error)
        }
    }
    
    func createUserProfileViewTable()
    {
        let createsUserProfileViewTable = self.userProfileViewTable.create { (table) in
            table.column(self.apk)
            table.column(self.index)
            table.column(self.type)
            table.column(self.isFullWidth)
            table.column(self.id1)
            table.column(self.id2)
            table.column(self.backgroundColor)
            table.column(self.shouldHideOnUpdateProfileView)
            table.primaryKey(self.apk, self.index)
        }
        
        do {
            try self.database.run(createsUserProfileViewTable)
        } catch {
            print(error)
        }
    }
    
    func createFieldsTable()
    {
        let createFieldsTable = self.fieldsTable.create { (table) in
            table.column(self.apk)
            table.column(self.index)
            table.column(self.type)
            table.column(self.isDropDown)
            table.column(self.inputType)
            table.column(self.placeHolder)
            table.column(self.isRequirement)
            table.column(self.labelName)
            table.column(self.styleID)
            
            table.primaryKey(self.apk ,self.index)
        }
        do {
            try self.database.run(createFieldsTable)
        } catch {
            print(error)
        }
    }
    
    func createFieldsStylesTable()
    {
        let createFieldsStylesTable = self.fieldsStylesTable.create { (table) in
            table.column(self.id, primaryKey: true)
            table.column(self.apk)
            table.column(self.labelTextColor)
            table.column(self.labelFont)
            table.column(self.labelTextSize)
            table.column(self.textTextColor)
            table.column(self.textFont)
            table.column(self.textTextSize)
            table.column(self.borderColor)
            table.column(self.asteriskColor)
            table.column(self.tintColor)
            table.column(self.borderStyle)
        }
        
        do {
            try self.database.run(createFieldsStylesTable)
        } catch {
            print(error)
        }
    }
    
    func createDropDownItemsTable()
    {
        let createDropDownItemsTable = self.dropDownItemsTable.create { (table) in
            table.column(self.apk)
            table.column(self.index)
            table.column(self.id)
            table.column(self.text)
            
            table.primaryKey(self.apk ,self.index, self.id)
        }
        
        do {
            try self.database.run(createDropDownItemsTable)
        } catch {
            print(error)
        }
    }
    
    /*********************************************************                  INSERTS                  *********************************************************/
    func insertVerificationView(verificationView : [VerificationModel]!)
    {
        objc_sync_enter(lock)
        do
        {
            if(verificationView != nil)
            {
                for v in verificationView
                {
                    let insertUserProfileView = self.verificationViewTable.insert(or: .replace,
                                                                                 self.apk <- APK,
                                                                                 self.index <- v.index,
                                                                                 self.type <- v.type,
                                                                                 self.id1 <- v.id)
                    
                    do
                    {
                        switch v.type
                        {
                        case UserProfileCellType.Title.rawValue:
                            viewsDB.insertTitle(id: v.id, title: v.title)
                        case UserProfileCellType.Button.rawValue:
                            v.button.tabID = -1
                            viewsDB.insertButton(id: v.id, button: v.button)
                        case UserProfileCellType.CheckBox.rawValue:
                            viewsDB.insertCheckBox(id: v.id, checkBox: v.checkBox)
                        default:
                            break
                        }
                        
                        try self.database.run(insertUserProfileView)
                        print("User profile cell added")
                    }
                    catch
                    {
                        print(error)
                    }
                    
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertUserProfileView(userProfileView : [UserProfileCellModel]!)
    {
        objc_sync_enter(lock)
        do
        {
            if(userProfileView != nil)
            {
                for u in userProfileView
                {
                    let insertUserProfileView = self.userProfileViewTable.insert(or: .replace,
                                                                                 self.apk <- APK,
                                                                                 self.index <- u.index,
                                                                                 self.type <- u.type,
                                                                                 self.isFullWidth <- u.isFullWidth,
                                                                                 self.id1 <- u.id1,
                                                                                 self.id2 <- u.id2,
                                                                                 self.backgroundColor <- u.backgroundColor,
                                                                                 self.shouldHideOnUpdateProfileView <- u.shouldHideOnUpdateProfileView)
                    
                    do
                    {
                        switch u.type
                        {
                        case UserProfileCellType.Title.rawValue:
                            viewsDB.insertTitle(id: u.id1, title: u.title)
                        case UserProfileCellType.Button.rawValue:
                            u.button.tabID = -1
                            viewsDB.insertButton(id: u.id1, button: u.button)
                        case UserProfileCellType.Switch.rawValue:
                            viewsDB.insertSwitch(id: u.id1, switchModel: u.switchModel)
                        /*case UserProfileCellType.RadioButton.rawValue:
                            if(u.radioButton.name == nil && u.radioButton.imageUrl != nil)
                            {
                                u.radioButton.imageAspectRatio = calculateImageAspectRatio(imageUrl: percentEncode(s: u.radioButton.imageUrl))
                                downloadImage(url: u.radioButton.imageUrl)
                            }
                            viewsDB.insertRadioButton(radioButton: u.radioButton)*/
                        default:
                            break
                        }
                        
                        try self.database.run(insertUserProfileView)
                        print("User profile cell added")
                    }
                    catch
                    {
                        print(error)
                    }

                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }

    func insertFields(fields : [FieldModel]!)
    {
        objc_sync_enter(lock)
        do
        {
            if(fields != nil)
            {
                for f in fields
                {
                    let insertFields = self.fieldsTable.insert(or: .replace,
                                                               self.apk <- APK,
                                                               self.index <- f.index,
                                                               self.type <- f.type,
                                                               self.isDropDown <- f.isDropDown,
                                                               self.inputType <- f.inputType,
                                                               self.placeHolder <- f.placeHolder,
                                                               self.isRequirement <- f.isRequirement,
                                                               self.labelName <- f.labelName,
                                                               self.styleID <- f.styleID)
                    
                    if(f.isDropDown)
                    {
                        insertDropDownItems(index : f.index, dropDownItems : f.dropDownItems)
                    }
                    
                    do
                    {
                        try self.database.run(insertFields)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    print("Field added")
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertFieldsStyles(fieldsStyles : [FieldStyleModel]!)
    {
        objc_sync_enter(lock)
        do
        {
            if(fieldsStyles != nil)
            {
                for f in fieldsStyles
                {
                    let insertFieldsStyles = self.fieldsStylesTable.insert(or: .replace,
                                                                     self.id <- f.id,
                                                                     self.apk <- APK,
                                                                     self.labelTextColor <- f.labelTextColor ,
                                                                     self.labelFont <- correctFontString(s: f.labelFont),
                                                                     self.labelTextSize <- f.labelTextSize ,
                                                                     self.textTextColor <- f.textTextColor,
                                                                     self.textFont <- correctFontString(s: f.textFont),
                                                                     self.textTextSize <- f.textTextSize,
                                                                     self.borderColor <- f.borderColor,
                                                                     self.asteriskColor <- f.asteriskColor,
                                                                     self.tintColor <- f.tintColor,
                                                                     self.borderStyle <- f.borderStyle)
                    do
                    {
                        try self.database.run(insertFieldsStyles)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    print("Field style added")
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertDropDownItems(index : Int!, dropDownItems : [String]!)
    {
        objc_sync_enter(lock)
        do
        {
            if(dropDownItems != nil)
            {
                var i = 0
                for d in dropDownItems
                {
                    let insertDropDownItems = self.dropDownItemsTable.insert(or: .replace,
                                                                           self.apk <- APK,
                                                                           self.index <- index,
                                                                           self.id <- i, //Int(d.id),
                                                                           self.text <- d)
                    
                    do
                    {
                        try self.database.run(insertDropDownItems)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    i += 1
                    print("Drop down item added")
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    

    /*********************************************************                  GETS                  *********************************************************/
    func getVerificationView() -> [UserProfileCellModel]!
    {
        objc_sync_enter(lock)
        do {
            var userProfileViewModels : [UserProfileCellModel] = []
            
            let userProfileView = try self.database.prepare(self.verificationViewTable.filter(self.apk == APK))
            
            for u in userProfileView
            {
                let userProfileViewModel = UserProfileCellModel()
                
                userProfileViewModel.index = u[self.index]
                userProfileViewModel.type = u[self.type]
                userProfileViewModel.isFullWidth = true
                userProfileViewModel.id1 = u[self.id1]
                
                switch userProfileViewModel.type
                {
                case UserProfileCellType.Title.rawValue:
                    userProfileViewModel.title = viewsDB.getTitle(id: userProfileViewModel.id1)
                case UserProfileCellType.Field.rawValue:
                    var firstField = FieldModel()
                    var firstFieldStyle = FieldStyleModel()
                    
                    firstField = getField(index: userProfileViewModel.index)
                    firstFieldStyle = getFieldStyle(id: firstField.styleID)
                    firstField.fieldStyle = firstFieldStyle
                    
                    userProfileViewModel.fields = []
                    userProfileViewModel.fields.append(firstField)
                case UserProfileCellType.Button.rawValue:
                    userProfileViewModel.button = viewsDB.getButton(id: userProfileViewModel.id1)
                case UserProfileCellType.CheckBox.rawValue:
                    userProfileViewModel.checkBox = viewsDB.getCheckBox(id: userProfileViewModel.id1)
                default:
                    break
                }
                
                userProfileViewModels.append(userProfileViewModel)
            }
            
            objc_sync_exit(lock)
            return userProfileViewModels
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getUserProfileView() -> [UserProfileCellModel]!
    {
        objc_sync_enter(lock)
        do {
            var userProfileViewModels : [UserProfileCellModel] = []

            let userProfileView = try self.database.prepare(self.userProfileViewTable.filter(self.apk == APK))
            
            for u in userProfileView
            {
                let userProfileViewModel = UserProfileCellModel()
                
                userProfileViewModel.index = u[self.index]
                userProfileViewModel.type = u[self.type]
                userProfileViewModel.isFullWidth = u[self.isFullWidth]
                userProfileViewModel.id1 = u[self.id1]
                userProfileViewModel.id2 = u[self.id2]
                userProfileViewModel.backgroundColor = u[self.backgroundColor]
                userProfileViewModel.shouldHideOnUpdateProfileView = u[self.shouldHideOnUpdateProfileView] == nil ? false : u[self.shouldHideOnUpdateProfileView]
                
                switch userProfileViewModel.type
                {
                case UserProfileCellType.Title.rawValue:
                    userProfileViewModel.title = viewsDB.getTitle(id: userProfileViewModel.id1)
                case UserProfileCellType.Field.rawValue:
                    var firstField = FieldModel()
                    var firstFieldStyle = FieldStyleModel()
                    
                    
                    firstField = getField(index: (userProfileViewModel.index * 10000) + 1)
                    firstFieldStyle = getFieldStyle(id: firstField.styleID)
                    firstField.fieldStyle = firstFieldStyle
                    
                    userProfileViewModel.fields = []
                    userProfileViewModel.fields.append(firstField)
                    
                    if(userProfileViewModel.id2 != nil)
                    {
                        var secondField = FieldModel()
                        var secondFieldStyle = FieldStyleModel()
                        
                        secondField = getField(index: (userProfileViewModel.index * 10000) + 2)
                        secondFieldStyle = getFieldStyle(id: secondField.styleID)
                        secondField.fieldStyle = secondFieldStyle
                        
                        userProfileViewModel.fields.append(secondField)
                    }
                    
                    
                case UserProfileCellType.Button.rawValue:
                    userProfileViewModel.button = viewsDB.getButton(id: userProfileViewModel.id1)
                case UserProfileCellType.RadioButton.rawValue:
                    userProfileViewModel.radioButton = viewsDB.getRadioButton(id: userProfileViewModel.id1)
                case UserProfileCellType.CheckBox.rawValue:
                    userProfileViewModel.checkBox = viewsDB.getCheckBox(id: userProfileViewModel.id1)
                case UserProfileCellType.Switch.rawValue:
                    userProfileViewModel.switchModel = viewsDB.getSwitch(id: userProfileViewModel.id1)
                default:
                    break
                }
                
                userProfileViewModels.append(userProfileViewModel)
            }
            
            objc_sync_exit(lock)
            return userProfileViewModels
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    
    func getField(index : Int) -> FieldModel!
    {
        objc_sync_enter(lock)
        do {
            let fieldModel = FieldModel()
            
            let field = try self.database.prepare(self.fieldsTable.filter(self.apk == APK && self.index == index))
            
            for f in field
            {
                fieldModel.index = f[self.index]
                fieldModel.type = f[self.type]
                fieldModel.isDropDown = f[self.isDropDown]
                fieldModel.inputType = f[self.inputType]
                fieldModel.placeHolder = f[self.placeHolder]
                fieldModel.isRequirement = f[self.isRequirement]
                fieldModel.labelName = f[self.labelName]
                fieldModel.styleID = f[self.styleID]
                fieldModel.selectedDropDownItem = 0
                
                if(fieldModel.isDropDown)
                {
                    fieldModel.dropDownItemsModel = getDropwDownItems(index: fieldModel.index)
                }
                
                objc_sync_exit(lock)
                return fieldModel
            }
            
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    
    func getFieldStyle(id : Int!) -> FieldStyleModel!
    {
        objc_sync_enter(lock)
        do {
            let fieldStyleModel = FieldStyleModel()
            
            let fieldStyle = try self.database.prepare(self.fieldsStylesTable.filter(self.id == id))
            
            for f in fieldStyle
            {
                fieldStyleModel.labelTextColor = f[self.labelTextColor]
                fieldStyleModel.labelFont = f[self.labelFont]
                fieldStyleModel.labelTextSize = f[self.labelTextSize]
                fieldStyleModel.textTextColor = f[self.textTextColor]
                fieldStyleModel.textFont = f[self.textFont]
                fieldStyleModel.textTextSize = f[self.textTextSize]
                fieldStyleModel.borderColor = f[self.borderColor]
                fieldStyleModel.asteriskColor = f[self.asteriskColor]
                fieldStyleModel.tintColor = f[self.tintColor]
                fieldStyleModel.borderStyle = f[self.borderStyle]
                
                objc_sync_exit(lock)
                return fieldStyleModel
            }
            
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getDropwDownItems(index : Int!) -> [SingleTextModel]!
    {
        objc_sync_enter(lock)
        do {
            var dropDownItemsModel : [SingleTextModel] = []
            
            let dropDownItems = try self.database.prepare(self.dropDownItemsTable.filter(self.apk == APK && self.index == index))
            
            for d in dropDownItems
            {
                let singleTextModel = SingleTextModel(id: Int64( d[self.id]), textStr: d[self.text])
                dropDownItemsModel.append(singleTextModel)
            }
            
            objc_sync_exit(lock)
            return dropDownItemsModel
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func deleteEntries(apk : String)
    {
        objc_sync_enter(lock)
        
        if(!statusModel.areUserProfileFieldsSaved)
        {
            do{
                try self.database.run(self.fieldsTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
            
            do{
                try self.database.run(self.dropDownItemsTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
            
            do{
                let fields = try self.database.prepare(self.userProfileViewTable.filter(self.apk == apk))
                
                for f in fields {
                    if(f[self.type] == UserProfileCellType.Title.rawValue)
                    {
                        viewsDB.deleteTitle(apk: apk, id: f[self.id1])
                    }
                    else if(f[self.type] == UserProfileCellType.Button.rawValue)
                    {
                        viewsDB.deleteButton(id: f[self.id1])
                    }
                    else if(f[self.type] == UserProfileCellType.RadioButton.rawValue)
                    {
                        viewsDB.deleteRadioButton(id: f[self.id1])
                    }
                    else if(f[self.type] == UserProfileCellType.CheckBox.rawValue)
                    {
                        viewsDB.deleteCheckBox(id: f[self.id1])
                    }
                    else if(f[self.type] == UserProfileCellType.Switch.rawValue)
                    {
                        viewsDB.deleteSwitch(id: f[self.id1])
                    }
                }
            }catch
            {}
            
            viewsDB.deleteCheckBoxConnections(apk: apk)
        }
        
        if(!statusModel.isUserProfileViewSaved)
        {
            do{
                try self.database.run(self.verificationViewTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
            
            do{
                try self.database.run(self.userProfileViewTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
            
        }
        
        if(!statusModel.areUserProfileFieldsStylesSaved)
        {
            do{
                try self.database.run(self.fieldsStylesTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
    
        objc_sync_exit(lock)
    }
    
}
