//
//  LoyaltyStatementViewController2.swift
//  RichReach2
//
//  Created by Eumbrella on 01/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class LoyaltyStatementViewController2: ViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var headerView: UIView!
    @IBOutlet var loyaltyStatementTable: UITableView!
    @IBOutlet var containerView: UIView!
    
    @IBOutlet var dateHeader: UILabel!
    @IBOutlet var documentHeader: UILabel!
    @IBOutlet var amountHeader: UILabel!
    @IBOutlet var rewardHeader: UILabel!
    @IBOutlet var redemptionHeader: UILabel!
    @IBOutlet var balanceHeader: UILabel!
    
    
    var partner : PartnerModel!
    var viewModel : LoyaltyStatementViewModel!
    //var notAvailableView : NotAvailableViewController!
    var task : WebApiTask!
    var loyaltyStatementListCount = 0
    var loadMoreDataLock = NSObject()
    var ignoreLoadingMoreData = false
    var previousOffersListSize = 0
    var synchronized : Synchronized = Synchronized()
    var ticketSelected = false
    
    var pointsStatementView : PointsStatementView!
    //var b = loyaltyDB.getTicketView()
    
    var firstStyle : TicketStyle!
    var secondStyle : TicketStyle!
    
    override func viewDidLoad() {
        AppDelegate.isPotraitOrientation = false
        
        pointsStatementView = loyaltyDB.getPointsStatementView()
        firstStyle = pointsStatementView.style1Model
        
        if(pointsStatementView.style2Model != nil)
        {
            secondStyle = pointsStatementView.style2Model
        }
        else
        {
            secondStyle = pointsStatementView.style1Model
        }
        
        switch UIDevice.current.orientation{
        case .portrait:
            AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.landscapeRight, andRotateTo: UIInterfaceOrientation.landscapeRight)
        case .portraitUpsideDown:
            AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.landscapeRight, andRotateTo: UIInterfaceOrientation.landscapeRight)
        case .landscapeLeft:
            AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.landscapeLeft, andRotateTo: UIInterfaceOrientation.landscapeLeft)
        case .landscapeRight:
            AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.landscapeRight, andRotateTo: UIInterfaceOrientation.landscapeRight)
        default:
            AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.landscapeRight, andRotateTo: UIInterfaceOrientation.landscapeRight)
        }
        
        super.viewDidLoad()
        
        self.prepare(for:  UIStoryboardSegue(identifier: "a",source: UIViewController() ,destination: UIViewController()), sender: nil)
        
        loyaltyStatementTable.tableFooterView = UIView()
        loyaltyStatementTable.delegate = self
        loyaltyStatementTable.dataSource = self
        
        partner = PartnerModel()
        partner.partnerID = 56
        partner.name = "Pirilos"
        viewModel = LoyaltyStatementViewModel(partner: partner, tableView: loyaltyStatementTable)
        
        
        headerView.backgroundColor = UIColor(pointsStatementView.headerBackgroundColor)
        
        dateHeader.textColor = UIColor(pointsStatementView.headerTextColor)
        documentHeader.textColor = UIColor(pointsStatementView.headerTextColor)
        amountHeader.textColor = UIColor(pointsStatementView.headerTextColor)
        rewardHeader.textColor = UIColor(pointsStatementView.headerTextColor)
        redemptionHeader.textColor = UIColor(pointsStatementView.headerTextColor)
        balanceHeader.textColor = UIColor(pointsStatementView.headerTextColor)
        
        dateHeader.font = UIFont(name: pointsStatementView.headerFont, size: CGFloat(pointsStatementView.headerTextSize))
        documentHeader.font = UIFont(name: pointsStatementView.headerFont, size: CGFloat(pointsStatementView.headerTextSize))
        amountHeader.font = UIFont(name: pointsStatementView.headerFont, size: CGFloat(pointsStatementView.headerTextSize))
        rewardHeader.font = UIFont(name: pointsStatementView.headerFont, size: CGFloat(pointsStatementView.headerTextSize))
        redemptionHeader.font = UIFont(name: pointsStatementView.headerFont, size: CGFloat(pointsStatementView.headerTextSize))
        balanceHeader.font = UIFont(name: pointsStatementView.headerFont, size: CGFloat(pointsStatementView.headerTextSize))
        
        loyaltyStatementTable.separatorColor = UIColor(pointsStatementView.headerBackgroundColor)
        
        /*firstStyle = StyleModel()
         secondStyle = StyleModel()
         
         firstStyle.backgroundColor = "#ffffff"
         firstStyle.textColor = "#002559"
         firstStyle.font = "Roboto-Light"
         firstStyle.textSize = 14
         
         secondStyle.backgroundColor = "#d3f1ff"
         secondStyle.textColor = "#002559"
         secondStyle.font = "Roboto-Light"
         secondStyle.textSize = 14*/
        
        
        self.container = containerView
        
        loadLoyaltyStatement()
        
        task = WebApiTask( viewController: self, action: loadLoyaltyStatementAsync, displayToast: false)
        task.start()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        UIApplication.shared.isStatusBarHidden = false
        super.viewWillAppear(animated)
    }
    
    var viewIsDisplayed = false
    
    override func viewDidLayoutSubviews() {
        if(viewIsDisplayed)
        {
            super.viewDidAppear(true)
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        //headerView.frame.size.width = CGRect(x: 0, y: 0, width: headerView.frame.width, height: headerView.frame.height)
        headerView.frame.size.width = headerView.frame.width
        headerView.frame.size.height =  headerView.frame.height
        headerView.layoutSubviews()
        headerView.layoutIfNeeded()
        
        //headerView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: headerView.frame.height)
        roundCorners([.bottomLeft,.bottomRight], radius: 10, view: headerView)
        viewIsDisplayed = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        //AppDelegate.isPotraitOrientation = true
        
        
        if(!ticketSelected)
        {
            //AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.portrait, andRotateTo: UIInterfaceOrientation.portrait)
            print()
        }
        else
        {
            ticketSelected = false
        }
        
        super.viewWillDisappear(true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //        let backItem = UIBarButtonItem()
        //        backItem.title = partner != nil && !isNullOrEmpty(string: partner.name) ? partner.name + " - " + NSLocalizedString("loyaltyTicketTitle", comment: "") : NSLocalizedString("loyaltyTicketTitle", comment: "")
        //
        //        let font = UIFont(name: "UIFontWeightRegular", size: 15) ?? UIFont.systemFont(ofSize: 15)
        //        backItem.setTitleTextAttributes([NSAttributedStringKey.font: font, NSAttributedStringKey.foregroundColor:UIColor.white], for: .normal)
        //        navigationItem.backBarButtonItem = backItem
        
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(viewModel == nil)
        {
            return 0
        }
        else
        {
            return viewModel.LoyaltyStatementList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "loyalty_statement_cell") as! LoyaltyStatementViewCell
        
        let ticket = viewModel.LoyaltyStatementList[indexPath.row]
        
        if(indexPath.row % 2 == 0)
        {
            cell.backgroundColor = UIColor(firstStyle.backgroundColor)
            
            cell.transactionDateLabel.textColor = UIColor(firstStyle.textColor)
            cell.ticketNoLabel.textColor =  UIColor(firstStyle.textColor)
            cell.amountLabel.textColor = UIColor(firstStyle.textColor)
            cell.rewardPointsLabel.textColor = UIColor(firstStyle.textColor)
            cell.redemptionPointsLabel.textColor = UIColor(firstStyle.textColor)
            cell.balanceLabel.textColor = UIColor(firstStyle.textColor)
            
            cell.transactionDateLabel.font = UIFont (name: (firstStyle.font)!, size: CGFloat((firstStyle.textSize)!))
            cell.ticketNoLabel.font = UIFont (name: (firstStyle.font)!, size: CGFloat((firstStyle.textSize)!))
            cell.amountLabel.font = UIFont (name: (firstStyle.font)!, size: CGFloat((firstStyle.textSize)!))
            cell.rewardPointsLabel.font = UIFont (name: (firstStyle.font)!, size: CGFloat((firstStyle.textSize)!))
            cell.redemptionPointsLabel.font = UIFont (name: (firstStyle.font)!, size: CGFloat((firstStyle.textSize)!))
            cell.balanceLabel.font = UIFont (name: (firstStyle.font)!, size: CGFloat((firstStyle.textSize)!))
        }
        else
        {
            cell.backgroundColor = UIColor(secondStyle.backgroundColor)
            
            cell.transactionDateLabel.textColor = UIColor(secondStyle.textColor)
            cell.ticketNoLabel.textColor =  UIColor(secondStyle.textColor)
            cell.amountLabel.textColor = UIColor(secondStyle.textColor)
            cell.rewardPointsLabel.textColor = UIColor(secondStyle.textColor)
            cell.redemptionPointsLabel.textColor = UIColor(secondStyle.textColor)
            cell.balanceLabel.textColor = UIColor(secondStyle.textColor)
            
            cell.transactionDateLabel.font = UIFont (name: (firstStyle.font)!, size: CGFloat((secondStyle.textSize)!))
            cell.ticketNoLabel.font = UIFont (name: (firstStyle.font)!, size: CGFloat((secondStyle.textSize)!))
            cell.amountLabel.font = UIFont (name: (firstStyle.font)!, size: CGFloat((secondStyle.textSize)!))
            cell.rewardPointsLabel.font = UIFont (name: (firstStyle.font)!, size: CGFloat((secondStyle.textSize)!))
            cell.redemptionPointsLabel.font = UIFont (name: (firstStyle.font)!, size: CGFloat((secondStyle.textSize)!))
            cell.balanceLabel.font = UIFont (name: (firstStyle.font)!, size: CGFloat((secondStyle.textSize)!))
            
        }
        
        cell.transactionDateLabel.text = ticket.transDate
        cell.ticketNoLabel.attributedText =  NSAttributedString(string: ticket.ticketNo, attributes:[.underlineStyle: NSUnderlineStyle.styleSingle.rawValue])
        cell.amountLabel.text = ticket.amount
        cell.rewardPointsLabel.text = ticket.rewardPoints
        cell.redemptionPointsLabel.text = ticket.redemptionPoints
        //cell.balanceLabel.text = ticket.balance
        
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        ticketSelected = true
        isViewPushed = true
        let LoyaltyTicketStoryBoard : UIStoryboard = UIStoryboard(name: "LoyaltyTicketView2", bundle: nil)
        let loyaltyTicketView =  LoyaltyTicketStoryBoard.instantiateViewController(withIdentifier: "LoyaltyTicketViewController") as! LoyaltyTicketViewController2
        loyaltyTicketView.ticket = viewModel.LoyaltyStatementList[indexPath.row]
        partner.name = "Beauty Line"
        loyaltyTicketView.partner = partner
        navigationController?.pushViewController(loyaltyTicketView, animated: true)
    }
    
    /// Loads statement data from internet
    func loadLoyaltyStatement()
    {
        viewModel.LoyaltyStatementList = loyaltyDB.getPointsStatement()
        
        self.loyaltyStatementTable.reloadData()
        
        if (self.viewModel.LoyaltyStatementList == nil || self.viewModel.LoyaltyStatementList.count == 0)
        {
            self.notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.container!, text: NSLocalizedString("noAvailableStatement", comment: ""))
            self.notAvailableView.image.removeFromSuperview()
        }
        else
        {
            if(self.notAvailableView != nil)
            {
                self.notAvailableView.view.removeFromSuperview()
            }
        }
        
    }
    
    func loadLoyaltyStatementAsync()
    {
        do
        {
            APKChanger.getPointsStatementAndBalance()
            viewModel.LoyaltyStatementList = loyaltyDB.getPointsStatement()
            
            DispatchQueue.main.async(execute: {() -> Void in
                self.loyaltyStatementTable.reloadData()
                
                if (self.viewModel.LoyaltyStatementList == nil || self.viewModel.LoyaltyStatementList.count == 0)
                {
                    //self.notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.container!, text: NSLocalizedString("noAvailableStatement", comment: ""))
                    //self.notAvailableView.image.removeFromSuperview()
                }
                else
                {
                    if(self.notAvailableView != nil)
                    {
                        self.notAvailableView.view.removeFromSuperview()
                    }
                }
            })
            
        }
        catch
        {
            
        }
    }
    
    
    /// This function is been called when failure occured.
    func failureAction()
    {
        ignoreLoadingMoreData = false
    }
    
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        //AppDelegate.isPotraitOrientation = !AppDelegate.isPotraitOrientation
        self.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    @IBAction func syncClicked(_ sender: UIBarButtonItem) {
        task = WebApiTask( viewController: self, action: loadLoyaltyStatementAsync, displayToast: true)
        task.successMessage = NSLocalizedString("synchronizationCompleted", comment: "")
        task.displayToast = true
        task.start()
    }
}
