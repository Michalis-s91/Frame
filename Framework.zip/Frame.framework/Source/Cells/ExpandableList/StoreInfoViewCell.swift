//
//  StoreInfoViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 23/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


class StoreInfoViewCell: UITableViewCell {

    @IBOutlet var statusLabel: UILabel!
    @IBOutlet var addressLabel: UILabel!
    
    @IBOutlet var phoneImage: UIImageView!
    @IBOutlet var mapImage: UIImageView!
    @IBOutlet var informationImage: UIImageView!
    
    var navigationController: UINavigationController!
    
    var storeName : String!
    var storePhone : String!
    var storeLongitude : String!
    var storeLatitude : String!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        let onTelephoneClick = UITapGestureRecognizer(target: self, action: #selector(StoreInfoViewCell.onTelephoneClick))
        phoneImage.isUserInteractionEnabled = true
        phoneImage.addGestureRecognizer(onTelephoneClick)
        
        let onMapClick = UITapGestureRecognizer(target: self, action: #selector(StoreInfoViewCell.onMapClick))
        mapImage.isUserInteractionEnabled = true
        mapImage.addGestureRecognizer(onMapClick)
        
        let onInfoClick = UITapGestureRecognizer(target: self, action: #selector(StoreInfoViewCell.onInfoClick))
        informationImage.isUserInteractionEnabled = true
        informationImage.addGestureRecognizer(onInfoClick)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @objc func onTelephoneClick (sender:UITapGestureRecognizer) {
        UIApplication.shared.openURL(URL(string: "tel://" + storePhone)!) //open(URL(string: "tel://" + storePhoneLabel.text!)! , options: [:], completionHandler: nil)
    }
    
    @objc func onMapClick (sender:UITapGestureRecognizer) {
        isViewPushed = true
        let MapStoryBoard : UIStoryboard = UIStoryboard(name: "MapView", bundle: nil)
        let mapView =  MapStoryBoard.instantiateViewController(withIdentifier: "MapViewController") as! MapViewController
        mapView.longitude = self.storeLongitude
        mapView.latitude = storeLatitude
        mapView.name = storeName
        mapView.address = addressLabel.text
        self.navigationController?.pushViewController(mapView, animated: true)
        
        //openMapForPlace(latitude: storeLatitude, longitude: storeLongitude, name : storeNameLabel.text! )
    }
    
    @objc func onInfoClick (sender:UITapGestureRecognizer) {
    }

}
