//
//  FTImageSize.h
//  FTImageSize
//
//  Created by liufengting on 02/12/2016.
//  Copyright © 2016 LiuFengting. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FTImageSize.
FOUNDATION_EXPORT double FTImageSizeVersionNumber;

//! Project version string for FTImageSize.
FOUNDATION_EXPORT const unsigned char FTImageSizeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FTImageSize/PublicHeader.h>
