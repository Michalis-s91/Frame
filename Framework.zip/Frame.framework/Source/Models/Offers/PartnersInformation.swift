//
//  File.swift
//  RichReach2
//
//  Created by Eumbrella on 06/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Holds partner information like partner name.
class PartnersInformation
{
    var item1 : String!
    var item2 : String!
    var item3 : String!
    var item4 : String!
    var item5 : String!
    var item6 : String!
    
    
    /// Constructor. Initialises the properties of class.
    ///
    /// - Parameters:
    ///   - item1: The first item.
    ///   - item2: The second item.
    ///   - item3: The third item.
    ///   - item4: The fourth item.
    ///   - item5: The fifth item.
    ///   - item6: The sixth item.
    init(item1 : String, item2 : String, item3 : String, item4 : String, item5 : String, item6 : String)
    {
        self.item1 = item1
        self.item2 = item2
        self.item3 = item3
        self.item4 = item4
        self.item5 = item5
        self.item6 = item6
    }
    
    /// Constructor. Initialises the properties of class.
    ///
    /// - Parameters:
    ///   - item1: The first item.
    ///   - item2: The second item.
    ///   - item3: The third item.
    ///   - item4: The fourth item.
    ///   - item5: The fifth item.
    init(item1 : String, item2 : String, item3 : String, item4 : String, item5 : String)
    {
        self.item1 = item1
        self.item2 = item2
        self.item3 = item3
        self.item4 = item4
        self.item5 = item5
    }
    
    /// Constructor. Initialises the properties of class.
    ///
    /// - Parameters:
    ///   - item1: The first item.
    ///   - item2: The second item.
    ///   - item3: The third item.
    init(item1 : String, item2 : String, item3 : String)
    {
        self.item1 = item1
        self.item2 = item2
        self.item3 = item3
    }
    
    /// Constructor. Initialises the properties of class.
    ///
    /// - Parameters:
    ///   - item1: The first item.
    ///   - item2: The second item.
    init(item1 : String, item2 : String)
    {
        self.item1 = item1
        self.item2 = item2
    }
}
