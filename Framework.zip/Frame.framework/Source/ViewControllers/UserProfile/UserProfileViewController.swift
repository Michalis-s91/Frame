//
//  UserProfileViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 22/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Creates user profile view. UserProfileView is the view being used for displaying information related to the user's profile (e.g. name, surname
/// etc.). User can register or update his/her profile information using this view.
class UserProfileViewController: ViewController , UITextFieldDelegate , ModalViewControllerDelegate {
    @IBOutlet  var telephoneView: UIView!
    @IBOutlet  var telephoneTitle: UILabel!
    @IBOutlet  var telephoneText: UILabel!
    
    @IBOutlet  var nameView: UIView!
    @IBOutlet  var nameTitle: UILabel!
    @IBOutlet  var nameText: UITextField!
    
    @IBOutlet  var surnameView: UIView!
    @IBOutlet  var surnameTitle: UILabel!
    @IBOutlet  var surnameText: UITextField!
    
    @IBOutlet  var genderView: UIView!
    @IBOutlet  var genderTitle: UILabel!
    @IBOutlet  var genderText: UILabel!
    
    @IBOutlet  var dateOfBirthView: UIView!
    @IBOutlet  var dateOfBirthTitle: UILabel!
    @IBOutlet  var dateOfBirthText: UILabel!
    
    @IBOutlet  var emailView: UIView!
    @IBOutlet  var emailTitle: UILabel!
    @IBOutlet  var emailText: UITextField!
    @IBOutlet  var emailVerifyLabel: UILabel!
    @IBOutlet  var emailVerifyImage: UIImageView!
    
    @IBOutlet var notVerifyEmailView: UIView!
    @IBOutlet var verifyEmailView: UIView!
    @IBOutlet var notVerifyLabel: UILabel!
    @IBOutlet var verifyLabel: UILabel!
    
    
    @IBOutlet  var provincesView: UIView!
    @IBOutlet  var provincesTitle: UILabel!
    @IBOutlet  var provincesText: UILabel!
    
    @IBOutlet  var cityView: UIView!
    @IBOutlet  var cityTitle: UILabel!
    @IBOutlet  var cityText: UITextField!
    
    @IBOutlet  var addressView: UIView!
    @IBOutlet  var addressTitle: UILabel!
    @IBOutlet  var addressText: UITextField!
    
    @IBOutlet  var postCodeView: UIView!
    @IBOutlet  var postCodeTitle: UILabel!
    @IBOutlet  var postCodeText: UITextField!
    
    @IBOutlet  var submitButton: UIButton!
    
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var innerView: UIView!
    
    
    var appUser: AppUser!
    var tableDialog : TableDialog!
    var birthDatePickerDialog : DatePickerDialog!
    var viewModel : UserProfileViewModel!
    var dialogType = 0
    var activeView : UIView!
    var showSucceedDialog = false

    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.prepare(for:  UIStoryboardSegue(identifier: "a",source: UIViewController() ,destination: UIViewController()), sender: nil)
        self.automaticallyAdjustsScrollViewInsets = false
        
        if(viewModel == nil)
        {
            viewModel = UserProfileViewModel(viewController : self)
            viewModel.initializeProperties()
        }
        
        appUser = localDatabase.getAppUser()
        
        
        setView()
        setOnTapListeners()
        
        registerForKeyboardNotifications()
    }
  
    
    override func viewWillAppear(_ animated: Bool) {
        registerForKeyboardNotifications()
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let appUser = localDatabase.getAppUser()
        if (appUser != nil && !(appUser?.isUserRegisteredToAPNS)!)
        {
            self.previousViewController = self
            AppDelegate.registerForPushNotifications(application: appApplication)
            appDelegate.locationManager.requestAlwaysAuthorization()
            
            apkUserPreferences?.acceptNotifications = true
            apkUserPreferences?.acceptLocation = true
            parameterizationDatabase.insertAPKUserPreferences(apkUserPreferences: apkUserPreferences!)
            setLocationService()
        }
        
        if(showSucceedDialog)
        {
            let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
            let dialog = sb.instantiateInitialViewController()! as! MessageDialog
            self.present(dialog,animated:true)
            dialog.setDialogView(title: "Success", description: "Registration is successful.", buttonName: NSLocalizedString("ok", comment: "") , dismissWhenClickOutside: true)

        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    @IBAction func submitBarIconClicked(_ sender: UIBarButtonItem) {
        let task = WebApiTask(viewController: self, action: updateUserProfile, displayToast: true)
        task.start()
    }
    
    @IBAction func submitButtonClicked(_ sender: UIButton) {
        let task = WebApiTask(viewController: self, action: updateUserProfile, displayToast: true)
        task.start()
    }
    
    @objc func onClickTelephone(sender : UITapGestureRecognizer) {
        displayToastMessage(message: NSLocalizedString("phoneNumberUpdateNotAllowed", comment: ""))
    }
    
    @objc func onClickName(sender : UITapGestureRecognizer) {
        activeView = nameView
        nameText.becomeFirstResponder()
    }
    
    @IBAction func nameTextClick(_ sender: UITextField) {
        activeView = nameView
    }
    
    @objc func onClickSurname(sender : UITapGestureRecognizer) {
        activeView = surnameView
        surnameText.becomeFirstResponder()
    }
    
    @IBAction func surnameTextClick(_ sender: UITextField) {
        activeView = surnameView
    }
    
    @objc func onClickEmail(sender : UITapGestureRecognizer) {
        if(appUser.hasVerifiedEmailAddress)
        {
            displayToastMessage(message: NSLocalizedString("emailUpdateNotAllowed", comment: ""))
        }
        else
        {
            activeView = emailView
            emailText.becomeFirstResponder()
        }
    }
    
    @IBAction func emailTextClick(_ sender: UITextField) {
        if(appUser.hasVerifiedEmailAddress)
        {
            displayToastMessage(message: NSLocalizedString("emailUpdateNotAllowed", comment: ""))
        }
        else
        {
            activeView = emailView
        }
    }
    
    @objc func onClickCity(sender : UITapGestureRecognizer) {
        activeView = cityView
        cityText.becomeFirstResponder()
    }
    
    @IBAction func cityTextClick(_ sender: UITextField) {
        activeView = cityView
    }
    
    @objc func onClickAddress(sender : UITapGestureRecognizer) {
        activeView = addressView
        addressText.becomeFirstResponder()
    }
    
    @IBAction func addressTextClick(_ sender: UITextField) {
        activeView = addressView
    }
    
    @objc func onClickPostCode(sender : UITapGestureRecognizer) {
        activeView = postCodeView
        postCodeText.becomeFirstResponder()
    }
    
    @IBAction func postCodeTextClick(_ sender: UITextField) {
        activeView = postCodeView
    }
    
    @objc func onClickVerifyEmail(sender : UITapGestureRecognizer) {
        //verifyEmailAddress()
    }
    
    @objc func onClickGenders(sender : UITapGestureRecognizer) {
        let sb = UIStoryboard(name:"TableDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController()!
        tableDialog = dialog as? TableDialog
        self.present(dialog,animated:true)
        tableDialog.delegate = self
        tableDialog.setDialogView(title: "Gender", types: StaticDataRepository.getUserGenders(), selectedType: "" )
        dialogType = 1
    }
    
    @objc func onClickDateOfBirth(sender : UITapGestureRecognizer) {
        let sb = UIStoryboard(name:"DatePickerDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController()!
        birthDatePickerDialog = dialog  as? DatePickerDialog
        self.present(dialog,animated:true)
        birthDatePickerDialog.delegate = self
        birthDatePickerDialog.setDialogView(title : "Date" ,userProfileViewModel: viewModel)
        dialogType = 2
    }
    
    @objc func onClickProvinces(sender : UITapGestureRecognizer) {
        let sb = UIStoryboard(name:"TableDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController()!
        tableDialog = dialog as? TableDialog
        self.present(dialog,animated:true)
        tableDialog.delegate = self
        tableDialog.setDialogView(title: "District", types: StaticDataRepository.getProvinces(), selectedType: "" )
        dialogType = 3
    }
    
    @IBAction func nameTextChanged(_ sender: UITextField) {
        viewModel.name = sender.text!
    }
    
    @IBAction func surnameTextChanged(_ sender: UITextField) {
        viewModel.surname = sender.text!
    }
    
    @IBAction func emailTextChanged(_ sender: UITextField) {
        viewModel.EmailAddress = sender.text
    }
    
    @IBAction func cityTextChanged(_ sender: UITextField) {
        viewModel.city = sender.text!
    }
    
    @IBAction func addressTextChanged(_ sender: UITextField) {
        viewModel.homeAddress = sender.text!
    }
    
    @IBAction func postCodeTextChanged(_ sender: UITextField) {
        viewModel.postCode = sender.text!
    }
    
    
    /// Displays a toast message to the user using our custom toast view.
    ///
    /// - Parameter message: The message to be displayed.
    private func displayToastMessage(message : String)
    {
        if(!isNullOrEmpty(string: message))
        {
            let toast = CustomToast()
            toast.setToast(viewController : self, message : message, duration : CustomToast.TOAST_LENGTH_LONG)
            toast.show()
        }
    }
    
    
    /// Sets the view.
    func setView(){
        appUser = localDatabase.getAppUser()
        
        telephoneTitle.font = UIFont.boldSystemFont(ofSize: 15.0)
        telephoneTitle.text = NSLocalizedString("profilePhoneNumber", comment: "")
        
        nameTitle.font = UIFont.boldSystemFont(ofSize: 15.0)
        nameTitle.text = NSLocalizedString("profileName", comment: "")
        nameText.attributedPlaceholder = NSAttributedString(string: NSLocalizedString("profileNameHint", comment: ""),
                                                            attributes: [NSAttributedStringKey.foregroundColor: UIColor.black])
        self.nameText.delegate = self
        self.nameText.autocorrectionType = .no
        
        surnameTitle.font = UIFont.boldSystemFont(ofSize: 15.0)
        surnameTitle.text = NSLocalizedString("profileSurname", comment: "")
        surnameText.attributedPlaceholder = NSAttributedString(string: NSLocalizedString("profileSurnameHint", comment: ""),
                                                               attributes: [NSAttributedStringKey.foregroundColor: UIColor.black])
        self.surnameText.delegate = self
        self.surnameText.autocorrectionType = .no
        
        genderTitle.font = UIFont.boldSystemFont(ofSize: 15.0)
        genderTitle.text = NSLocalizedString("profileGender", comment: "")
        
        dateOfBirthTitle.font = UIFont.boldSystemFont(ofSize: 15.0)
        dateOfBirthTitle.text = NSLocalizedString("profileDateOfBirth", comment: "")
        
        emailTitle.font = UIFont.boldSystemFont(ofSize: 15.0)
        emailTitle.text = NSLocalizedString("profileEmailAddress", comment: "")
        emailText.attributedPlaceholder = NSAttributedString(string: NSLocalizedString("profileEmailAddressHint", comment: ""),
                                                             attributes: [NSAttributedStringKey.foregroundColor: UIColor.black])
        self.emailText.delegate = self
        self.emailText.autocorrectionType = .no
        notVerifyLabel.text = NSLocalizedString("clickHereToVerify", comment: "")
        verifyLabel.text = NSLocalizedString("verified", comment: "")
        
        provincesTitle.font = UIFont.boldSystemFont(ofSize: 15.0)
        provincesTitle.text = NSLocalizedString("profileProvince", comment: "")
        
        cityTitle.font = UIFont.boldSystemFont(ofSize: 15.0)
        cityTitle.text = NSLocalizedString("profileCity", comment: "")
        cityText.attributedPlaceholder = NSAttributedString(string: NSLocalizedString("profileCityHint", comment: ""),
                                                            attributes: [NSAttributedStringKey.foregroundColor: UIColor.black])
        self.cityText.delegate = self
        self.cityText.autocorrectionType = .no
        
        addressTitle.font = UIFont.boldSystemFont(ofSize: 15.0)
        addressTitle.text = NSLocalizedString("profileHomeAddress", comment: "")
        addressText.attributedPlaceholder = NSAttributedString(string: NSLocalizedString("profileHomeAddressHint", comment: ""),
                                                               attributes: [NSAttributedStringKey.foregroundColor: UIColor.black])
        self.addressText.delegate = self
        self.addressText.autocorrectionType = .no
        
        postCodeTitle.font = UIFont.boldSystemFont(ofSize: 15.0)
        postCodeTitle.text = NSLocalizedString("profilePostCode", comment: "")
        postCodeText.attributedPlaceholder = NSAttributedString(string: NSLocalizedString("profilePostCodeHint", comment: ""),
                                                                attributes: [NSAttributedStringKey.foregroundColor: UIColor.black])
        self.postCodeText.delegate = self
        self.postCodeText.autocorrectionType = .no
        
        submitButton.backgroundColor = Colors.buttonGray
        submitButton.setBackgroundImage(imageWithColor(color: Colors.buttonGraySelected), for: .highlighted)
    }
    
    /// Updates the user's profile information on the local database and our server.
    func updateUserProfile() {
        viewModel.updateUserProfile()
        
        if(!isActivityActive(viewController : self))
        {
            return
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.displayToastMessage(message: self.viewModel.updateStatusText)
        })
    }
    
    /// Set tap listeners on sub views.
    func setOnTapListeners() {
        let onClickTelephone = UITapGestureRecognizer(target: self, action: #selector(UserProfileViewController.onClickTelephone))
        telephoneView.addGestureRecognizer(onClickTelephone)
        
        let onClickName = UITapGestureRecognizer(target: self, action: #selector(UserProfileViewController.onClickName))
        nameView.addGestureRecognizer(onClickName)
        
        let onClickSurname = UITapGestureRecognizer(target: self, action: #selector(UserProfileViewController.onClickSurname))
        surnameView.addGestureRecognizer(onClickSurname)
        
        let onClickGenders = UITapGestureRecognizer(target: self, action: #selector(UserProfileViewController.onClickGenders))
        genderView.addGestureRecognizer(onClickGenders)
        
        let onClickDateOfBirth = UITapGestureRecognizer(target: self, action: #selector(UserProfileViewController.onClickDateOfBirth))
        dateOfBirthView.addGestureRecognizer(onClickDateOfBirth)
        
        let onClickEmail = UITapGestureRecognizer(target: self, action: #selector(UserProfileViewController.onClickEmail))
        emailView.addGestureRecognizer(onClickEmail)
        
        if(appUser.hasVerifiedEmailAddress)
        {
            emailText.isUserInteractionEnabled = false
        }
        
        let onClickProvinces = UITapGestureRecognizer(target: self, action: #selector(UserProfileViewController.onClickProvinces))
        provincesView.addGestureRecognizer(onClickProvinces)
        
        let onClickCity = UITapGestureRecognizer(target: self, action: #selector(UserProfileViewController.onClickCity))
        cityView.addGestureRecognizer(onClickCity)
        
        let onClickAddress = UITapGestureRecognizer(target: self, action: #selector(UserProfileViewController.onClickAddress))
        addressView.addGestureRecognizer(onClickAddress)
        
        let onClickPostCode = UITapGestureRecognizer(target: self, action: #selector(UserProfileViewController.onClickPostCode))
        postCodeView.addGestureRecognizer(onClickPostCode)
        
        let onClickVerifyEmail = UITapGestureRecognizer(target: self, action: #selector(UserProfileViewController.onClickVerifyEmail))
        notVerifyEmailView.addGestureRecognizer(onClickVerifyEmail)
    }
    
    
    /// This function is been called when dialog is dismissed.
    func dismissed() {
        switch dialogType {
        case 1:
            if (tableDialog.selectedType != "")
            {
                viewModel.SelectedGender = tableDialog.selectedTypeInt
                
                if(viewModel.titleID == nil)
                {
                    if(tableDialog.selectedTypeInt == UserGender.Male.rawValue)
                    {
                        viewModel.titleID = UserTitle.Mr.rawValue
                    }
                    else
                    {
                        viewModel.titleID = UserTitle.Ms.rawValue
                    }
                }
                else
                {
                    if(tableDialog.selectedTypeInt == UserGender.Male.rawValue)
                    {
                        viewModel.titleID = UserTitle.Mr.rawValue
                    }
                    else
                    {
                        if(!isTitleFemale(titleID: viewModel.titleID))
                        {
                            viewModel.titleID = UserTitle.Ms.rawValue
                        }
                    }
                }
                                
                //userProfile.titleID = userProfile.titleID == nil ? ((selectedGender + 1) == UserGender.Male.rawValue ? UserTitle.Mr.rawValue : UserTitle.Ms.rawValue ) : userProfile.titleID
                //genderText.text = tableDialog.selectedType
            }
        case 2:
                dateOfBirthText.text = viewModel.birthDate
        case 3:
            if (tableDialog.selectedType != "")
            {
                viewModel.SelectedProvince = tableDialog.selectedTypeInt
                //provincesText.text = tableDialog.selectedType
            }
        default:
            break
        }
    }

    
    /// Register view for keyboard notifications.
    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: NSNotification.Name.UIKeyboardDidShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    /*
     func deregisterFromKeyboardNotifications(){
     //Removing notifies on keyboard appearing
     NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillShow, object: nil)
     NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
     }*/
    
    @IBOutlet var contentViewHeight: NSLayoutConstraint!
    var lastOffset : CGPoint!
    var isFirstTime = true
    var keyBoardHeight : CGFloat = 216.0
    var yOffset : CGFloat!
    
    @objc func keyboardWasShown(notification: NSNotification){
        var info = notification.userInfo!
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        
        if (activeView == nil || !isFirstTime)
        {
            isFirstTime = true
            return
        }
        
        isFirstTime = false
        
        lastOffset = scrollView.contentOffset
        
        self.scrollView.isScrollEnabled = true
        
        
        
        let viewHeight = UIScreen.main.bounds.size.height - UIApplication.shared.statusBarFrame.height - (self.navigationController?.navigationBar.frame.size.height)!
        
        print(activeView.frame.origin.y)
        print(activeView.frame.size.height)
        print(scrollView.contentOffset.y)
        print(yOffset)
        
        yOffset = (keyboardSize?.height)! - (viewHeight - (activeView.frame.origin.y + activeView.frame.size.height -  scrollView.contentOffset.y)) + 5
        
        if(yOffset > 0)
        {
            UIView.animate(withDuration: 0.3) {
                self.scrollView.contentOffset = CGPoint(x: 0, y: self.scrollView.contentOffset.y + self.yOffset)
            }
        }
        
    }
    
    @objc func keyboardWillBeHidden(notification: NSNotification){
        if (activeView == nil)
        {
            return
        }
        
        if(yOffset != nil && yOffset > 0)
        {
            UIView.animate(withDuration: 0.3) {
                self.scrollView.contentOffset = CGPoint(x: 0, y: self.scrollView.contentOffset.y - self.yOffset)
            }
        }
    
        activeView = nil
    }
    
    /*private func verifyEmailAddressAsync()
     {
     //viewModel.verifyEmailAddress()
     
     DispatchQueue.main.async(execute: {() -> Void in
     let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
     let dialog = sb.instantiateInitialViewController()! as! MessageDialog
     self.present(dialog,animated:true)
     dialog.setDialogView(title: NSLocalizedString("emailAddressValidation", comment: ""), description: NSLocalizedString("emailVerificationOnProcess", comment: ""), buttonName: NSLocalizedString("ok", comment: ""), dismissWhenClickOutside: true)
     })
     }
     
     private func verificationFailure()
     {
     let customToast = CustomToast(viewController : self, message : NSLocalizedString("synchronizationFailedPleaseTryAgain", comment: ""))
     customToast.show()
     }
     
     func verifyEmailAddress()
     {
     if (!isNullOrEmpty(string: viewModel.emailAddress))
     {
     if (!isEmailAddressValid(address: viewModel.emailAddress))
     {
     let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
     let dialog = sb.instantiateInitialViewController()!
     let dialogViewController = dialog as! MessageDialog
     self.present(dialog,animated:true)
     dialogViewController.setDialogView(title: NSLocalizedString("invalidEmailAddress", comment: ""), description: NSLocalizedString("pleaseEnterValidEmailAddress", comment: ""), buttonName: NSLocalizedString("ok", comment: ""), dismissWhenClickOutside: true)
     }
     else
     {
     let task = WebApiTask(viewController: self, action: verifyEmailAddressAsync, displayToast: true)
     task.setFailureAction(action: verificationFailure, isFailureActionToast: true)
     task.start()
     }
     }
     else
     {
     let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
     let dialog = sb.instantiateInitialViewController()!
     let dialogViewController = dialog as! MessageDialog
     self.present(dialog,animated:true)
     dialogViewController.setDialogView(title: NSLocalizedString("invalidEmailAddress", comment: ""), description: NSLocalizedString("pleaseEnterValidEmailAddress", comment: ""), buttonName: NSLocalizedString("ok", comment: ""), dismissWhenClickOutside: true)
     }
     }*/
}
