//
//  ViewsWebApi.swift
//  RichReach2
//
//  Created by Eumbrella on 27/06/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Web api for getting views parameters.
class ViewsWebApi
{
    static func getFirstView() throws -> [GeneralInformation2]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetDefaultTabGeneralView",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let informations = try decoder.decode(Informations.self, from : (response.data(using: .utf8))!)
                
                return informations.informationsList
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    /// Post request for getting general views.
    ///
    /// - Returns: The general views.
    static func getGeneralViews() throws -> [GeneralInformation2]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetNonDefaultTabGeneralView",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let informations = try decoder.decode(Informations.self, from : (response.data(using: .utf8))!)
                
                return informations.informationsList
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    /// Post request for getting splash view banners.
    ///
    /// - Returns: The splash view banners.
    static func getSplashViewBanners() throws -> [GeneralInformation2]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetOverlaySplashScreenView",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let informations = try decoder.decode(Informations.self, from : (response.data(using: .utf8))!)
                
                return informations.informationsList
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    /*static func getPdfs() -> [PDFModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetPdfs",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let pdfs = try decoder.decode(PDF.self, from : (response.data(using: .utf8))!)
                
                return pdfs.pdfsList
            }
        }
        catch
        {
            print(error)
        }
        
        return nil
    }*/
    
    /// Post request for getting expandable list views parameters.
    ///
    /// - Returns: The expandable list views parameters.
    static func getExpandableListViews() throws -> [ExpandableListModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetExpandableListView",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let expandableListViews = try decoder.decode(ExpandableListView.self, from : (response.data(using: .utf8))!)
                
                return expandableListViews.expandableListViewList
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    /// Post request for getting expandable lists.
    ///
    /// - Returns: The expandable lists.
    static func getExpandableLists() -> [ExpandableListParentModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetExpandableList",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let expandableLists = try decoder.decode(ExpandableList.self, from : (response.data(using: .utf8))!)
                
                return expandableLists.expandableListList
            }
        }
        catch
        {
            print(error)
        }
        
        return nil
    }
    
    /// Post request for getting embeded views(e.g product view).
    ///
    /// - Returns: The embeded views.
    static func getEmbededViews() throws -> [EmbededGeneralViewModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetEmbededGeneralView",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let embededViews = try decoder.decode(EmbededView.self, from : (response.data(using: .utf8))!)
                
                return embededViews.embededViewsList
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    /// Post request for getting embeded views parameters.
    ///
    /// - Returns: The embeded views parameters.
    static func getEmbededViewsParameters() throws -> [EmbededViewParametersModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetEmbededViewParameters",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let embededViewsParameters = try decoder.decode(EmbededViewParameters.self, from : (response.data(using: .utf8))!)
                
                return embededViewsParameters.embededViewsParametersList
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    /// Post request for getting contact us views tab relations.
    ///
    /// - Returns: The contact us views tab relations.
    static func getContactUsTabRelations() throws -> [ContactUsTabRelation]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetContuctUsTabsRelation",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let contactUsTabRelations = try decoder.decode(ContactUsTabRelations.self, from : (response.data(using: .utf8))!)
                
                return contactUsTabRelations.contactUsTabRelationsList
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    /// Post request for getting contact us views parameters.
    ///
    /// - Returns: The contact us views parameters.
    static func getContactUsView() throws -> [ContactUsModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetContuctUsViewNew",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let contactUsView = try decoder.decode(ContactUs.self, from : (response.data(using: .utf8))!)
                
                return contactUsView.contactUsList
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    /// Post request for getting barcode view parameters.
    ///
    /// - Returns: The barcode view parameters.
    static func getBarcodeView() throws -> BarcodeModel2!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/RichReachWebApplication/api/ParametersApi/GetApkBarcodeView",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let barcodeView = try decoder.decode(BarcodeModel2.self, from : (response.data(using: .utf8))!)
                
                return barcodeView
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    /// Post request for getting general search view parameters.
    ///
    /// - Returns: The general search view parameters.
    static func getGeneralSearchView() throws -> [GeneralSearchView]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetGeneralSearchView",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let generalSearchView = try decoder.decode(GeneralSearchViewList.self, from : (response.data(using: .utf8))!)
                
                return generalSearchView.generalSearchViewList
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    /// Post request for getting splash view parameters.
    ///
    /// - Returns: The splash view parameters.
    static func getSplashViewParameters() throws -> SplashViewParametersModel!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetOverLaySplashScreenParameters",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let splashViewParameters = try decoder.decode(SplashViewParametersModel.self, from : (response.data(using: .utf8))!)
                
                return splashViewParameters
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    /// Post request for getting not available view.
    ///
    /// - Returns: The not available view.
    static func getNotAvailableView() throws -> NotAvailableModel!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetNotAvailableView",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let notAvailableView = try decoder.decode(NotAvailableModel.self, from : (response.data(using: .utf8))!)
                
                return notAvailableView
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    static func getBlogView(tabID : Int!, pageToLoad : Int!) throws -> BlogView!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/RichReachWebApplication/api/BlogApi/GetBlogViewArticles/",params:  "ApkName=\(APK ?? "")&ViewTabID=\(tabID!)&PageNumber=\(pageToLoad!)")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let blogView = try decoder.decode(BlogView.self, from : (response.data(using: .utf8))!)
                
                return blogView
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    static func getBogAuthors() throws -> BlogAuthors!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/RichReachWebApplication/api/BlogApi/GetBlogAuthors/",params:  "ApkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let blogAuthors = try decoder.decode(BlogAuthors.self, from : (response.data(using: .utf8))!)
                
        
                return blogAuthors
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
}


/// Helper classes for deserialisation.

class BlogView : Codable
{
    var image : String!
    var title : String!
    var titleFont : String!
    var titleTextSize : Int!
    var titleTextColor : String!
    
    var blogViewsArticles: [ArticleModel]!
    var categories : [ArticleCategoryModel]!
    var authors : [AuthorModel]!
    
    private enum CodingKeys : String, CodingKey {
        case image = "ImageUrl"
        case title = "Title"
        case titleFont = "TitleFont"
        case titleTextSize = "TitleTextSize"
        case titleTextColor = "TitleTextColor"
        
        case blogViewsArticles = "ArticlesList"
        case categories = "ArticleCategories"
        case authors = "Authors"
    }
}


class ExpandableListView : Codable
{
    var expandableListViewList : [ExpandableListModel]!
    
    private enum CodingKeys : String, CodingKey {
        case expandableListViewList = "expandableViewList"
    }
}

class ExpandableList : Codable
{
    var expandableListList : [ExpandableListParentModel]!
    
    private enum CodingKeys : String, CodingKey {
        case expandableListList = "expandableList_List"
    }
}

class EmbededView : Codable
{
    var embededViewsList : [EmbededGeneralViewModel]!
    
    private enum CodingKeys : String, CodingKey {
        case embededViewsList = "EmbededGeneralInformationList"
    }
}

class EmbededViewParameters : Codable
{
    var embededViewsParametersList : [EmbededViewParametersModel]!
    
    private enum CodingKeys : String, CodingKey {
        case embededViewsParametersList = "EmbededParaList"
    }
}

class ContactUs : Codable
{
    var contactUsList : [ContactUsModel]!
    
    private enum CodingKeys : String, CodingKey {
        case contactUsList = "ContuctUsList"
    }
}

class ContactUsTabRelations : Codable
{
    var contactUsTabRelationsList : [ContactUsTabRelation]!
    
    private enum CodingKeys : String, CodingKey {
        case contactUsTabRelationsList = "ContactUsTabsRelationList"
    }
}

class GeneralSearchViewList : Codable
{
    var generalSearchViewList : [GeneralSearchView]!
    
    private enum CodingKeys : String, CodingKey {
        case generalSearchViewList = "GeneralSearchList"
    }
}



