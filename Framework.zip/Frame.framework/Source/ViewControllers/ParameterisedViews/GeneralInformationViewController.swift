//
//  GeneralInformationViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 16/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import Kingfisher
import AVFoundation
import RSBarcodes

/// Creates a view with container and is been used for showing the general information view.
class GeneralInformationViewController: ViewController , UITableViewDelegate, UITableViewDataSource, UIWebViewDelegate{
    
    @IBOutlet var generalInformationContainer: UIView!
    @IBOutlet var backgroundImage: UIImageView!
    @IBOutlet var informationTableView: UITableView!
    
    
    @IBOutlet var viewBottom: NSLayoutConstraint!
    @IBOutlet var viewTrailing: NSLayoutConstraint!
    @IBOutlet var viewLeading: NSLayoutConstraint!
    @IBOutlet var viewTop: NSLayoutConstraint!
    
    var viewModel : GeneralViewViewModel!
    //var notAvailableView : NotAvailableViewController!
    var currentUIViewController: UIViewController!
    
    var informationsList : [GeneralInformation2]! = []
    static var sectionLoaded : [Bool] = []
    var videosPostions : [Int] = []
    var videoLoaded : [Bool] = []
    var videoIsBeenPlaying = false
    var headersView : [UIView] = []
    var viewController : ViewController!
    var titleLabel : UILabel!
    var titleBackground : UIView!
    var webView : UIWebView!
    var indicator : UIActivityIndicatorView!
    var isEmbeded = false
    var isArticle = false
    
    var viewIsNotDisplayed = true
    var viewDidAppear = false
    var isViewSaved = false
    var pdfTries = 0
    var images : [ImageCacheModel] = []
    var numberOfCachedImages = 10
    var PDFWebViews : [UIWebView] = []
    var isPDFLoaded : [Bool] = []
    
    var areItemsSaved = true
    var articleModel : ArticleModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(borderWidth > 0)
        {
            self.view.backgroundColor = UIColor(borderColor)
            viewTrailing.constant = CGFloat(borderWidth)
            viewBottom.constant = CGFloat(borderWidth)
            viewTop.constant = CGFloat(borderWidth)
            viewLeading.constant = CGFloat(borderWidth)
        }
        
        if(selectedTab.hasBackgroundImage)
        {
            let data = parameterizationDatabase.getBackgroundImage(apk: APK)
            
            if(data != nil)
            {
                backgroundImage.image = UIImage(data: data!)
            }
        }
        
        currentUIViewController = self
        
        informationTableView.rowHeight = UITableViewAutomaticDimension
        informationTableView.tableFooterView = UIView()
        informationTableView.delegate = self
        informationTableView.dataSource = self
        
        if(isArticle)
        {
            informationTableView.contentInset = UIEdgeInsets(top: -15, left: 0, bottom: -10, right: 0)
            
            GeneralInformationViewController.sectionLoaded.removeAll()
            for _ in 0..<informationsList.count
            {
                GeneralInformationViewController.sectionLoaded.append(false)
                headersView.append(UIView())
            }
        }
        else
        {
            if(isEmbeded){
                GeneralInformationViewController.sectionLoaded.removeAll()
                for _ in 0..<informationsList.count
                {
                    GeneralInformationViewController.sectionLoaded.append(false)
                }
            }
            informationTableView.contentInset = UIEdgeInsets(top: -35, left: 0, bottom: -20, right: 0)
        }
        
        if(selectedTab.id == defaultTabID && statusModel.isFirstViewSaved)
        {
            isViewSaved = true
        }
        else
        {
            if(selectedTab.tabType == TabType.Offers.rawValue && statusModel.isOffersSaved)
            {
                isViewSaved = true
            }
            else if(selectedTab.tabType == TabType.Home.rawValue && statusModel.isHomeSaved)
            {
                isViewSaved = true
            }
            else if(selectedTab.tabType == TabType.About.rawValue && statusModel.isAboutSaved)
            {
                isViewSaved = true
            }
            else if(selectedTab.tabType == TabType.RedemptionPolicy.rawValue && statusModel.isRedemptionSaved)
            {
                isViewSaved = true
            }
            else if(selectedTab.tabType == TabType.TermsAndConditions.rawValue && statusModel.isTermsSaved)
            {
                isViewSaved = true
            }
        }
        
        if(isViewSaved && areItemsSaved)
        {
            self.viewModel = GeneralViewViewModel()
            
            informationsList = self.viewModel.loadFromLocalDB()
            /*var g = GeneralInformation2()
             var p = ProductModel()
             
             p.itemNo = 7055685
             
             g.product = p
             g.type = SlotType.Product.rawValue
             g.index = 4
             
             informationsList.append(g)*/
            
            for _ in 0..<informationsList.count
            {
                PDFWebViews.append(UIWebView())
                isPDFLoaded.append(false)
            }
            
            if(informationsList == nil || informationsList?.count == 0)
            {
                self.notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.generalInformationContainer!, text:"No available information")
            }
            else
            {
                GeneralInformationViewController.sectionLoaded.removeAll()
                for _ in 0..<informationsList.count
                {
                    GeneralInformationViewController.sectionLoaded.append(false)
                    headersView.append(UIView())
                }
            }
        }
        
        if(self.viewModel == nil && !areParametersDownloading)
        {
            loadGeneralView()
        }
        
        if(isEmbeded)
        {
            for _ in 0..<informationsList.count
            {
                PDFWebViews.append(UIWebView())
                isPDFLoaded.append(false)
            }
            
            self.navigationItem.leftBarButtonItem?.image = UIImage(named: "ic_back")
            
            if(informationsList == nil || informationsList?.count == 0)
            {
                self.notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.generalInformationContainer!, text:"No available information")
            }
        }
        
        KingfisherManager.shared.downloader.downloadTimeout = 45
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidLayoutSubviews() {
        if(!viewIsNotDisplayed)
        {
            super.viewDidAppear(true)
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        navigation = self.navigationController
        isFirstTabSeen = true
        if(self.viewModel == nil)
        {
            loadGeneralView()
        }
        
        informationTableView.reloadData()
        viewDidAppear = true
        
        if(isEmbeded)
        {
            self.view.window?.backgroundColor = UIColor.white
            
            let topPadding : Int!  = parameterizationDatabase.getTheme(apk: APK).topPadding == nil ? 0 : parameterizationDatabase.getTheme(apk: APK).topPadding
            
            self.view.frame.origin.y =  offset + CGFloat(topPadding)
            self.view.frame.size.height = self.view.frame.size.height - CGFloat(topPadding)
        }
           
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        let url = NSURL(string : "")
        let request  = URLRequest(url : url as! URL)
        if(webView != nil)
        {
            webView.loadRequest(request)
        }
    }
    
    func loadGeneralView()
    {
        self.viewModel = GeneralViewViewModel()
        
        if(!isEmbeded)
        {
            statusModel = statusDB.getStatus(apk: APK)
            
            if(isViewSaved)
            {
                informationsList = self.viewModel.loadFromLocalDB()
                
                if(informationsList == nil || informationsList?.count == 0)
                {
                    self.notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.generalInformationContainer!, text:"No available information")
                }
                else
                {
                    GeneralInformationViewController.sectionLoaded.removeAll()
                    for _ in 0..<informationsList.count
                    {
                        GeneralInformationViewController.sectionLoaded.append(false)
                        headersView.append(UIView())
                    }
                }
            }
            else
            {
                let waitingView =  showWaitingView(view: self, container: self.view, text: "No available information")
                DispatchQueue.global(qos: .background).async {
                    while(!statusModel.areGeneralViewsSaved)
                    {
                        sleep(2)
                        if(!isActivityActive(viewController: self.currentUIViewController))
                        {
                            return
                        }
                        
                        if(!areParametersDownloading && errorOccured)
                        {
                            DispatchQueue.main.async(execute: {() -> Void in
                                waitingView.setText(text: "An error has occured. Please try again later...")
                                waitingView.showInternetIsRequired()
                            })
                            return
                        }
                    }
                    
                    if(!areParametersDownloading && errorOccured)
                    {
                        return
                    }
                    
                    if(!isActivityActive(viewController: self.currentUIViewController))
                    {
                        return
                    }
                    
                    DispatchQueue.main.async(execute: {() -> Void in
                        waitingView.view.removeFromSuperview()
                        waitingView.removeFromParentViewController()
                        
                        self.informationsList = self.viewModel.loadFromLocalDB()
                        
                        if(self.informationsList == nil || self.informationsList?.count == 0)
                        {
                            self.notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.generalInformationContainer!, text:"No available information")
                        }
                        else
                        {
                            GeneralInformationViewController.sectionLoaded.removeAll()
                            for _ in 0..<self.informationsList.count
                            {
                                GeneralInformationViewController.sectionLoaded.append(false)
                                self.headersView.append(UIView())
                            }
                            
                            for _ in 0..<self.informationsList.count
                            {
                                self.PDFWebViews.append(UIWebView())
                                self.isPDFLoaded.append(false)
                            }
                        }
                        
                        self.informationTableView.reloadData()
                    })
                }
            }
        }
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if(informationsList != nil)
        {
            return informationsList.count
        }
        else
        {
            return 0
        }
    }
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if(section == 0)
        {
            return 0
        }
        
        if(separatorHeight == 0)
        {
            return CGFloat.leastNormalMagnitude
        }
        
        if(separatorHeight == nil)
        {
            return 0
        }
        else
        {
            return CGFloat(separatorHeight)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return CGFloat.leastNormalMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        if(separatorHeight != nil && separatorHeight > 0 && separatorColor != nil)
        {
            headerView.backgroundColor = UIColor((separatorColor)!)
        }
        return headerView
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var information : GeneralInformation2!
        
        information = informationsList[indexPath.section]
        
        switch information.type {
        case SlotType.Title.rawValue:
            if(isArticle)
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_title") as! InformationTitleViewCell
                var title : TitleModel! = information.title
                cell.titleLabel.text = title.title
                cell.titleLabel.font = UIFont (name: (title.titleFont)!, size: CGFloat((title.titleSize)!))
                cell.titleLabel.textColor = UIColor((title.titleColor)!)
                cell.titleLabel.backgroundColor = UIColor((title.titleBackgroundColor)!)
                
                
                cell.titleWidth = cell.titleWidth.setMultiplier(multiplier: CGFloat(0.9))
                
                //cell.titleLabel.bringSubview(toFront: self.view)
                self.view.bringSubview(toFront: cell.titleLabel)
                self.view.bringSubview(toFront: cell)
                cell.frame = CGRect(x: 0, y: 0, width: 10000, height: 50)
                if(title.isTitleCentered != nil && !title.isTitleCentered)
                {
                    cell.titleLabel.textAlignment = .left
                }
                
                cell.selectionStyle = .none
                
                return cell
            }else
            {
                if(titleLabel == nil)
                {
                    let title : TitleModel! = information.title
                    let label = LabelWithPadding()
                    
                    //informationTableView.frame = CGRect(x: informationTableView.frame.origin.x, y: informationTableView.frame.origin.y + 15.0, width: informationTableView.frame.size.width, height: informationTableView.frame.size.height - 15.0)
                    
                    let font = UIFont (name: (FontsAndSizes.titleFont), size: CGFloat((FontsAndSizes.titleTextSize)))
                    
                    if(isEmbeded)
                    {
                        label.text = title.title
                    }
                    else
                    {
                        label.text = selectedTab.name
                    }
                    
                    label.font = font
                    label.textColor = Colors.titleTextColor
                    label.backgroundColor = Colors.titleBackround
                    label.numberOfLines = 0
                    
                    let line = UIView()
                    line.backgroundColor = Colors.titleSplitterColor
                    
                    if(!FontsAndSizes.isTitleCentered)
                    {
                        label.leftPadding = borderWidth + 10
                        label.textAlignment = .left
                    }
                    else
                    {
                        label.textAlignment = .center
                    }
                    
                    var titleHeightSize : CGFloat = 40
                    
                    if(font != nil)
                    {
                        titleHeightSize = title.title.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: font!) + 20
                    }
                    
                    let blankView = UIView()
                    blankView.backgroundColor = UIColor.white
                    
                    label.frame = CGRect(x: 0, y: titleTopPadding, width: UIScreen.main.bounds.size.width, height: titleHeightSize)
                    line.frame = CGRect(x: 0, y: titleTopPadding + titleHeightSize, width: UIScreen.main.bounds.size.width * 0.8, height: 1)
                    line.center.x = UIScreen.main.bounds.size.width / 2
                    
                    blankView.frame = CGRect(x: tableView.frame.origin.x, y: tableView.frame.origin.y, width: tableView.frame.size.width, height: (titleTopPadding + titleHeightSize) - tableView.frame.origin.y)
                    self.view.addSubview(blankView)
                    //titleBackground = blankView
                    
                    titleLabel = label
                    self.view.addSubview(label)
                    self.view.addSubview(line)
                }
                
                
                
                let cell = UITableViewCell()
                cell.selectionStyle = .none
                
                return cell
            }
        case SlotType.Photo.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_image") as! InformationImageViewCell
            let photo : PhotoModel! = information.photo
            
            cell.viewController = self
            
            if(photo.title != nil)
            {
                let title : TitleModel! = photo.title
                
                cell.cellTitle.text = title.title
                cell.cellTitle.font = UIFont (name: (title.titleFont)!, size: CGFloat((title.titleSize)!))
                cell.cellTitle.textColor = UIColor((title.titleColor)!)
                cell.cellTitle.backgroundColor = UIColor((title.titleBackgroundColor)!)
                
                print(title.titleFont)
                
                cell.titleHeightConstraint.constant = (title.title?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: UIFont (name: (title.titleFont)!, size: CGFloat((title.titleSize)!))!))!
                
                if(title.isTitleCentered)
                {
                    cell.cellTitle.textAlignment = .center
                }
                else
                {
                    cell.cellTitle.textAlignment = .left
                }
            }
            else
            {
                cell.titleHeightConstraint.constant = 0
            }
            
            if(photo.link != nil)
            {
                cell.link = photo.link
                cell.awakeFromNib()
            }
            
            
            //cell.cellImage.kf.setImage(with: url)
            if(isArticle)
            {
                if(articleModel != nil && articleModel.areItemsSaved || photo.isSignature)
                {
                    var image = viewsDB.getImage(url: photo.imageUrl)
                    
                    if(!photo.isImageLoaded)
                    {
                        if(photo.isSignature)
                        {
                            if let image = UIImage(data: photo.photoData)
                            {
                                images.append(ImageCacheModel(image: image, url: photo.imageUrl ,photoModel : photo))
                            }
                        }
                        else
                        {
                            if let image = viewsDB.getImage(url: photo.imageUrl)
                            {
                                images.append(ImageCacheModel(image: image, url: photo.imageUrl ,photoModel : photo))
                            }
                        }
                        
                        cell.cellImage.image = (images.last)?.image
                        photo.isImageLoaded = true
                        
                        if(images.count > numberOfCachedImages)
                        {
                            images[0].photoModel.isImageLoaded = false
                            images.remove(at: 0)
                        }
                    }
                    else
                    {
                        for i in 0..<images.count
                        {
                            if(images[i].url ==  photo.imageUrl)
                            {
                                cell.cellImage.image = images[i].image
                                break
                            }
                        }
                    }
                }
                else
                {
                    let url = URL(string: percentEncode(s: photo.imageUrl))
                    cell.cellImage.kf.setImage(with: url, completionHandler: {
                        (image, error, cacheType, imageUrl) in
                        // image: Image? `nil` means failed
                        // error: NSError? non-`nil` means failed
                        // cacheType: CacheType
                        //                  .none - Just downloaded
                        //                  .memory - Got from memory cache
                        //                  .disk - Got from disk cache
                        // imageUrl: URL of the image
                        
                        if(image != nil)
                        {
                            var aspectRatio = Double((image?.size.height)! / (image?.size.width)!)
                            
                            if(photo?.aspectRatio != aspectRatio)
                            {
                                photo?.aspectRatio = aspectRatio
                                self.informationTableView.reloadData()
                            }
                            else if(cacheType == .none)
                            {
                                self.informationTableView.reloadData()
                            }
                        }
                    })
                }
            }
            else if(isEmbeded)
            {
                let url = URL(string: percentEncode(s: photo.imageUrl))
                cell.cellImage.kf.setImage(with: url, completionHandler: {
                    (image, error, cacheType, imageUrl) in
                    // image: Image? `nil` means failed
                    // error: NSError? non-`nil` means failed
                    // cacheType: CacheType
                    //                  .none - Just downloaded
                    //                  .memory - Got from memory cache
                    //                  .disk - Got from disk cache
                    // imageUrl: URL of the image
                    
                    if(image != nil)
                    {
                        photo?.aspectRatio = Double((image?.size.height)! / (image?.size.width)!)
                        
                        if(cacheType == .none)
                        {
                            self.informationTableView.reloadData()
                        }
                    }
                })
            }
            else
            {
                print("loading image")
                
                //cell.cellImage.image =  viewsDB.getImage(url: photo.imageUrl)
                
                

                if(!photo.isImageLoaded)
                {
                    var image = viewsDB.getImage(url: photo.imageUrl)
                    
                    if(image != nil)
                    {
                        images.append(ImageCacheModel(image: image!, url: photo.imageUrl ,photoModel : photo))
                        cell.cellImage.image = (images.last)?.image
                        photo.isImageLoaded = true
                        
                        if(images.count > numberOfCachedImages)
                        {
                            images[0].photoModel.isImageLoaded = false
                            images.remove(at: 0)
                        }
                    }
                    else
                    {
                        let url = URL(string: percentEncode(s:photo.imageUrl))
                        cell.cellImage.kf.setImage(with: url, completionHandler: {
                            (image, error, cacheType, imageUrl) in
                            // image: Image? `nil` means failed
                            // error: NSError? non-`nil` means failed
                            // cacheType: CacheType
                            //                  .none - Just downloaded
                            //                  .memory - Got from memory cache
                            //                  .disk - Got from disk cache
                            // imageUrl: URL of the image
                            
                            if(image != nil)
                            {
                                var aspectRatio = Double((image?.size.height)! / (image?.size.width)!)
                                
                                var height = UIScreen.main.bounds.size.width * CGFloat(aspectRatio)
                                photo.aspectRatio = aspectRatio
                                
                                /*if(cell.articleImageHeight.constant != height)
                                 {
                                 cell.articleImageHeight.constant = height
                                 //self.articlesTableView.reloadData()
                                 }
                                 else */
                                
                                self.images.append(ImageCacheModel(image: image!, url: photo.imageUrl ,photoModel : photo))
                                photo.isImageLoaded = true
                                
                                if(self.images.count > self.numberOfCachedImages)
                                {
                                    self.images[0].photoModel.isImageLoaded = false
                                    self.images.remove(at: 0)
                                }
                                
                                if(!photo.isImageLoaded)
                                {
                                    self.informationTableView.reloadData()
                                    //photo.isImageLoaded = true
                                    //viewsDB.insertImage(url: photo.imageUrl, str: UIImagePNGRepresentation(image!)!)
                                }
                                
                            }
                        })
                    }
                }
                else
                {
                    for i in 0..<images.count
                    {
                        if(images[i].url ==  photo.imageUrl)
                        {
                            cell.cellImage.image = images[i].image
                            break
                        }
                    }
                }
                
            }
            
            
            
            if(!photo.takeFullWidth)
            {
                cell.imageWidth = cell.imageWidth.setMultiplier(multiplier: 0.5)
            }
            else if(isArticle)
            {
                cell.imageWidth = cell.imageWidth.setMultiplier(multiplier: 0.9)
            }
            
            if(photo.button != nil)
            {
                let button : ButtonModel! = photo.button
                
                cell.button = button
                
                cell.buttonWidth.constant = CGFloat(button.width)
                cell.buttonHeight.constant = CGFloat(button.height)
                cell.cellButton.setTitle(button.name, for: .normal)
                cell.cellButton.titleLabel?.font = UIFont (name: (button?.font)!, size: CGFloat(button.textSize))
                cell.cellButton.setTitleColor(UIColor(button.textColor), for: .normal)
                cell.cellButton.backgroundColor = UIColor(correctHexString(string: button.backgroundColor))
                
                cell.borderWidth.constant =  CGFloat(button.width + button.borderWidth * 2)
                cell.borderHeight.constant = CGFloat(button.height + button.borderWidth * 2)
                cell.buttonBorder.backgroundColor = button.borderWidth != 0 ? UIColor(correctHexString(string: button.borderColor)) : UIColor.clear
                
                if(button.cornerRadius != nil)
                {
                    if(button.borderWidth == 0 || button.borderColor == "#00000000")
                    {
                        cell.cellButton.layer.cornerRadius = CGFloat(button.cornerRadius)
                    }
                    else
                    {
                        cell.buttonBorder.layer.cornerRadius = CGFloat(button.cornerRadius)
                    }
                }
                
                var titleHeight : CGFloat! = 0.0
                
                if(information.photo.title != nil)
                {
                    titleHeight = photo.title.title?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: UIFont (name: (photo.title.titleFont)!, size: CGFloat((photo.title.titleSize)!))!)
                }
                
                var cellHeight : CGFloat!
                if(photo.aspectRatio != nil)
                {
                    cellHeight = UIScreen.main.bounds.size.width * CGFloat(photo.aspectRatio) + titleHeight
                }
                else
                {
                    cellHeight = UIScreen.main.bounds.size.width + titleHeight
                }
                
                switch button.buttonPosition
                {
                case 1:
                    break
                case 2:
                    cell.borderX.constant = UIScreen.main.bounds.size.width/2 - CGFloat(button.width + button.borderWidth * 2)/2
                    break
                case 3:
                    cell.borderX.constant = UIScreen.main.bounds.size.width - CGFloat(button.width) - CGFloat(button.borderWidth * 2)
                    break
                case 4:
                    cell.borderY.constant = cellHeight/2 - CGFloat(button.height + button.borderWidth * 2)/2
                    break
                case 5:
                    cell.borderY.constant = cellHeight/2 - CGFloat(button.height + button.borderWidth * 2)/2
                    cell.borderX.constant = UIScreen.main.bounds.size.width/2 - CGFloat(button.width + button.borderWidth * 2)/2
                    break
                case 6:
                    cell.borderY.constant = cellHeight/2 - CGFloat(button.height + button.borderWidth * 2)/2
                    cell.borderX.constant = UIScreen.main.bounds.size.width - CGFloat(button.width) - CGFloat(button.borderWidth * 2)
                    break
                case 7:
                    cell.borderY.constant = cellHeight - CGFloat(button.height) - CGFloat(button.borderWidth * 2)
                    break
                case 8:
                    cell.borderY.constant = cellHeight - CGFloat(button.height) - CGFloat(button.borderWidth * 2)
                    cell.borderX.constant = UIScreen.main.bounds.size.width/2 - CGFloat(button.width + button.borderWidth * 2)/2
                    break
                case 9:
                    cell.borderY.constant = cellHeight - CGFloat(button.height) - CGFloat(button.borderWidth * 2)
                    cell.borderX.constant = UIScreen.main.bounds.size.width - CGFloat(button.width) - CGFloat(button.borderWidth * 2)
                    break
                default :
                    break
                }
            }
            else
            {
                cell.buttonWidth.constant = CGFloat(0)
                cell.buttonHeight.constant = CGFloat(0)
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case SlotType.Text.rawValue:
            let text : TextModel! = information.text
            
            if(text.showBarcode)
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_barcode") as! InformationTextViewCell2
                
                if(isArticle)
                {
                    cell.titleWidth = cell.titleWidth.setMultiplier(multiplier: 0.9)
                }
                
                cell.titleLabel.text = text?.title
                cell.descriptionText.text = text?.description
                cell.titleLabel.font = UIFont (name: (text?.titleFont)!, size: CGFloat((text?.titleSize)!))
                cell.titleLabel.textColor = UIColor((text?.titleColor)!)
                cell.descriptionText.font = UIFont (name: "Helvetica", size: CGFloat(15))
                cell.descriptionText.textColor = UIColor.black
                cell.splitter.backgroundColor = UIColor((text?.splitterColor)!)
                cell.backgroundColor = UIColor((text?.backgroundColor)!)
                cell.descriptionText.textAlignment = .center
                //cell.descriptionText.backgroundColor = UIColor((text?.backgroundColor)!)
                
                if(text?.isTitleCentered)!
                {
                    cell.titleLabel.textAlignment = .center
                }
                
                cell.selectionStyle = UITableViewCellSelectionStyle.none
                
                let barcodeHelper = BarcodeHelper()
                cell.imageText.image =   barcodeHelper.getImageFromString(barcodeID: text.description, type : AVMetadataObject.ObjectType.code128.rawValue)
                
                return cell
            }
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_text") as! InformationTextViewCell
            
            cell.titleLabel.text = text?.title
            cell.descriptionText.text = text?.description
            cell.titleLabel.font = UIFont (name: (text?.titleFont)!, size: CGFloat((text?.titleSize)!))
            cell.titleLabel.textColor = UIColor((text?.titleColor)!)
            cell.descriptionText.font = UIFont (name: (text?.descriptionFont)!, size: CGFloat((text?.descriptionSize)!))
            cell.descriptionText.textColor = UIColor((text?.descriptionColor)!)
            cell.splitter.backgroundColor = UIColor((text?.splitterColor)!)
            cell.backgroundColor = UIColor((text?.backgroundColor)!)
            cell.descriptionText.backgroundColor = UIColor((text?.backgroundColor)!)
            
            if(text?.isTitleCentered)!
            {
                cell.titleLabel.textAlignment = .center
            }
            else
            {
                cell.titleLabel.textAlignment = .left
            }
            
            if(isArticle)
            {
                cell.titleWidth = cell.titleWidth.setMultiplier(multiplier: 0.9)
            }
            
            switch text?.descriptionAlignmentType.rawValue
            {
            case AlignmentType.Left.rawValue? :
                cell.descriptionText.textAlignment = .left
            case AlignmentType.Center.rawValue? :
                cell.descriptionText.textAlignment = .center
            case AlignmentType.Justified.rawValue? :
                cell.descriptionText.textAlignment = .justified
            default :
                break
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
            
        case SlotType.Video.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_video") as! InformationVideoViewCell
          
            if(GeneralInformationViewController.sectionLoaded.count >= (indexPath.section + 1) && !GeneralInformationViewController.sectionLoaded[indexPath.section])
            {
                videosPostions.append(indexPath.section)
                
                cell.cellWebView.mediaPlaybackRequiresUserAction = false
                cell.cellWebView.allowsInlineMediaPlayback = true
                cell.cellWebView.delegate = self
                cell.cellWebView.mediaPlaybackAllowsAirPlay = false
                cell.cellWebView.scrollView.isScrollEnabled = false
                cell.cellWebView.scrollView.showsVerticalScrollIndicator = false
                cell.cellWebView.scrollView.showsHorizontalScrollIndicator = false
                
                
                webView = cell.cellWebView
                indicator = cell.videoIndicator
                
                GeneralInformationViewController.sectionLoaded[indexPath.section] = true
                
                videoLoaded.append(false)
                var cellRect = informationTableView.rectForRow(at: indexPath)
                cellRect.size.height =  cellRect.size.height
                let completelyVisible = informationTableView.bounds.contains(cellRect)
                
                if (completelyVisible) {
                    playVideo(item: information)
                    
                }
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            
            return cell
        case SlotType.Carousel.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_carousel") as! InformationCarouselViewCell
            
            let carousel : CarouselModel! = information.carousel
            
            cell.urls = carousel?.urls
            cell.hasTitles = carousel.hasTitles
            cell.titleSize = carousel.titleSize
            cell.isAutomatic = carousel?.isAutomatic
            cell.isManual = carousel?.isManual
            cell.isScrollingEnabled = carousel?.isScrollingEnabled
            cell.interval = (carousel?.interval)!
            // cell.imageGaleryWidth = cell.imageGaleryWidth.setMultiplier(multiplier: CGFloat(carousel.widthPercentage/100))
            
            if(isArticle)
            {
                cell.imageGaleryWidth = cell.imageGaleryWidth.setMultiplier(multiplier: CGFloat(0.9))
            }
            
            cell.setCarusel(width : informationTableView.frame.size.width)
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case SlotType.PDF.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_pdf") as! InformationPDFViewCell
            
            cell.cellWebView.isUserInteractionEnabled = true
            //cell.cellWebView.scrollView.isScrollEnabled = false
            //cell.cellWebView.scrollView.bounces = false
            
            
            let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
            let url = NSURL(fileURLWithPath: path)
            if let pathComponent = url.appendingPathComponent("\(APK.replacingOccurrences(of: ".", with: ""))\(information.index!)\(selectedTab.id!).pdf") {
                let filePath = pathComponent.path
                let fileManager = FileManager.default
                if fileManager.fileExists(atPath: filePath) {
                    let url = URL(fileURLWithPath: path).appendingPathComponent("\(APK.replacingOccurrences(of: ".", with: ""))\(information.index!)\(selectedTab.id!).pdf")
                    let request  = URLRequest(url : url)
                    cell.cellWebView.loadRequest(request)
                } else {
                    print("FILE NOT AVAILABLE")
                    
                    if(pdfTries < 10)
                    {
                        informationTableView.reloadData()
                    }
                    
                    pdfTries += 1
                }
            } else {
                print("FILE PATH NOT AVAILABLE")
                
                if(pdfTries < 10)
                {
                    informationTableView.reloadData()
                }
                
                pdfTries += 1
            }
            
            /*var pdfDocumentRef = CGPDFDocument(createWithURl : 1 ) //CGPDFDocumentCreateWithURL((CFURLRef)url);
             CGPDFPageRef pdfPageRef = CGPDFDocumentGetPage(pdfDocumentRef, 1);
             
             CGRect pdfPageRect = CGPDFPageGetBoxRect(pdfPageRef, kCGPDFMediaBox);
             
             var height = pdfPageRect.size.height;*/
            
            //cell.cellWebView.backgroundColor = UIColor.clear
            //cell.cellWebView.scrollView.backgroundColor = UIColor.clear
            //cell.cellWebView.frame.size.height = (UIScreen.main.bounds.size.width - CGFloat(borderWidth * 2)) * 1.417 * CGFloat(information.pdf.numOfPages)
            //cell.cellWebView.sc
            
            PDFWebViews[indexPath.row] = cell.cellWebView
            
            cell.cellWebView.delegate = self
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case SlotType.Product.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_product") as! InformationProductViewCell
            
            var product : ProductModel! = information.product //productsDB.getProductByItemNo(itemNo : information.productItemCode)
            
            cell.productInformationsList = product.informationList
            
            cell.productDescription.font = UIFont(name: "CharpentierSansPro-Normal", size: CGFloat(18))
            cell.productDescription.textColor = UIColor(product.informationList[0].text.descriptionColor)
            
            if(product.areInformationsDisplayed)
            {
                cell.plusIcon.image = UIImage(named: "ic_minus")?.withRenderingMode(.alwaysTemplate)
                cell.plusIcon.tintColor = UIColor(cell.productInformationsList[0].text.titleColor)
            }
            else
            {
                cell.plusIcon.image = UIImage(named: "ic_plus")?.withRenderingMode(.alwaysTemplate)
                cell.plusIcon.tintColor = UIColor(cell.productInformationsList[0].text.titleColor)
            }
            
            if(product != nil)
            {
                cell.product = product
                //cell.generalInformationList = informationsList
                cell.tableView = informationTableView
                //cell.itemPosition = indexPath.section
                cell.parentView = self
                
                cell.productDescription.text = product.webDescription
                
                var photoImage = ""
                if(product.imageA != nil && product.imageA.count > 0)
                {
                    photoImage = product.imageA
                }
                else if(product.imageB != nil && product.imageB.count > 0)
                {
                    photoImage = product.imageB
                }
                
                let url = URL(string: percentEncode(s: photoImage))
                cell.productImage.kf.setImage(with: url, completionHandler: {
                    (image, error, cacheType, imageUrl) in
                    
                    if(image != nil)
                    {
                        //product?.imageAspectRatio = Double((image?.size.height)! / (image?.size.width)!)
                        
                        if(cacheType == .none)
                        {
                            self.informationTableView.reloadData()
                        }
                        
                        if(cell.imageHeight.constant == 0)
                        {
                            cell.imageHeight.constant = 0.75 * UIScreen.main.bounds.size.width * CGFloat(Double((image?.size.height)! / (image?.size.width)!))
                        }
                        
                    }
                })
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case SlotType.RelatedArticle.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_related_article") as! RelatedArticleViewCell
            
            var article : ArticleModel! = information.article
            
            if((indexPath.section == 0) || informationsList[indexPath.section - 1].type != SlotType.RelatedArticle.rawValue)
            {
                cell.splitter.backgroundColor = UIColor(article.titleColor)
                cell.titleLabel.text = "LATEST STORIES"
                cell.titleLabel.font = UIFont (name: (article.titleFont)!, size: CGFloat((article.titleSize )! - 4))
                cell.titleLabel.textColor = UIColor((article.titleColor)!)
                
                cell.titleLabelTop.constant = 15
                cell.splitterTop.constant = 10
            }
            else
            {
                cell.splitter.backgroundColor = UIColor.clear
                cell.titleLabel.text = ""
                cell.titleLabelTop.constant = 0
                cell.splitterTop.constant = 10
                
            }
            
            if(article != nil && article.areItemsSaved)
            {
                if(cell.articleImageHeight.constant == 0)
                {
                    cell.articleImageHeight.constant = 0.25 * UIScreen.main.bounds.size.width * CGFloat(information.article.imageAspectRatio)
                }
                
                var image = UIImage(data : article.imageData)
                
                if(!article.isImageLoaded)
                {
                    if let image = UIImage(data : article.imageData)
                    {
                        images.append(ImageCacheModel(image: image, url: article.image ,articleModel : article))
                    }
                    
                    cell.articleImage.image = (images.last)?.image
                    article.isImageLoaded = true
                    
                    if(images.count > numberOfCachedImages)
                    {
                        images[0].articleModel.isImageLoaded = false
                        images.remove(at: 0)
                    }
                }
                else
                {
                    for i in 0..<images.count
                    {
                        if(images[i].url ==  article.image)
                        {
                            cell.articleImageHeight.constant = 0.25 * UIScreen.main.bounds.size.width * CGFloat(information.article.imageAspectRatio)
                            cell.articleImage.image = images[i].image
                            break
                        }
                    }
                }
            }
            else
            {
                let url = URL(string: percentEncode(s:article.image))
                cell.articleImage.kf.setImage(with: url, completionHandler: {
                    (image, error, cacheType, imageUrl) in
                    // image: Image? `nil` means failed
                    // error: NSError? non-`nil` means failed
                    // cacheType: CacheType
                    //                  .none - Just downloaded
                    //                  .memory - Got from memory cache
                    //                  .disk - Got from disk cache
                    // imageUrl: URL of the image
                    
                    if(image != nil)
                    {
                        var aspectRatio = Double((image?.size.height)! / (image?.size.width)!)
                        
                        if(cell.articleImageHeight.constant == 0)
                        {
                            cell.articleImageHeight.constant = 0.25 * UIScreen.main.bounds.size.width * CGFloat(aspectRatio)
                        }
                        
                        if(cacheType == .none)
                        {
                            self.informationTableView.reloadData()
                        }
                    }
                })
            }
            
            /*if(article.areItemsSaved)
             {
             cell.articleImage.image = UIImage(data: article.imageData)
             
             if(cell.articleImageHeight.constant == 0)
             {
             cell.articleImageHeight.constant = 0.25 * UIScreen.main.bounds.size.width * CGFloat(information.article.imageAspectRatio)
             }
             }
             else
             {
             let url = URL(string: percentEncode(s:article.image))
             cell.articleImage.kf.setImage(with: url, completionHandler: {
             (image, error, cacheType, imageUrl) in
             // image: Image? `nil` means failed
             // error: NSError? non-`nil` means failed
             // cacheType: CacheType
             //                  .none - Just downloaded
             //                  .memory - Got from memory cache
             //                  .disk - Got from disk cache
             // imageUrl: URL of the image
             
             if(image != nil)
             {
             var aspectRatio = Double((image?.size.height)! / (image?.size.width)!)
             
             if(cell.articleImageHeight.constant == 0)
             {
             cell.articleImageHeight.constant = 0.25 * UIScreen.main.bounds.size.width * CGFloat(aspectRatio)
             }
             
             if(cacheType == .none)
             {
             self.informationTableView.reloadData()
             }
             }
             })
             }*/
            
            cell.articleTitleLabel.text = article.title
            cell.articleTitleLabel.font = UIFont (name: (article.titleFont)!, size: CGFloat((article.titleSize)! - 8))
            cell.articleTitleLabel.textColor = UIColor((article.titleColor)!)
            
            
            if((article.title as NSString).size(withAttributes: [NSAttributedStringKey.font: cell.articleTitleLabel.font]).width < cell.articleTitleLabel.frame.size.width)
            {
                cell.articleTitleHeight.constant = UIFont (name: (article.titleFont)!, size: CGFloat((article.titleSize)! - 8))!.lineHeight + 3
            }
            else
            {
                cell.articleTitleHeight.constant = cell.articleTitleLabel.font.lineHeight * 2 + 5
            }
            
            //cell.articleCategoryLabel.text = article.category
            //cell.articleCategoryLabel.font = UIFont (name: (article.categoryFont)!, size: CGFloat((article.categorySize)!))
            //cell.articleCategoryLabel.textColor = UIColor((article.categoryColor)!)
            
            var date = article.publishDate.split(separator: " ")[0]
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let date2 = dateFormatter.date(from: String(date))!
            let dateFormatter2 = DateFormatter()
            dateFormatter2.dateFormat = "MMMM dd"
            
            cell.articleDateLabel.text = dateFormatter2.string(from: date2)
            
            //cell.articleDateLabel.text = article.publishDate
            cell.articleDateLabel.font = UIFont (name: (article.dateFont)!, size: CGFloat((article.dateTextSize)!))
            cell.articleDateLabel.textColor = UIColor((article.dateTextColor)!)
            
            cell.selectionStyle = .none
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case SlotType.Share.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_share") as! ShareViewCell
            
            let share : ShareModel! = information.share
            
            cell.shareDescription.text = share.description
            cell.shareDescription.font = UIFont (name: (share.descriptionFont)!, size: CGFloat((share.descriptionTextSize)!))
            cell.shareDescription.textColor = UIColor((share.descriptionTextColor)!)
            
            cell.shareIcon.image = UIImage(named: "ic_actionbar_share")?.withRenderingMode(.alwaysTemplate)
            cell.shareIcon.tintColor = UIColor(share.tintColor)
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        default:
            return tableView.dequeueReusableCell(withIdentifier: "general_info_text") as! InformationTextViewCell
            
           
        }
        
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var information : GeneralInformation2!
        
        information = informationsList[indexPath.section]
        switch information.type {
        case SlotType.Carousel.rawValue:
            
            var width = UIScreen.main.bounds.size.width
            if(isArticle)
            {
                width = width * 0.9
            }
            
            let carousel = information.carousel
            var titleHeight : CGFloat! = 0.0
            
            if(carousel?.hasTitles)!
            {
                titleHeight = carousel?.urls[0].title.title?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: UIFont (name: (carousel?.urls[0].title.titleFont)!, size: CGFloat((carousel?.urls[0].title.titleSize)!))!)
            }
            
            var cellHeight : CGFloat!
            let aspcetRatio = carousel?.urls[0].aspectRatio
            if(aspcetRatio != nil)
            {
                cellHeight = width * CGFloat(aspcetRatio!) + titleHeight
            }
            else
            {
                cellHeight = width + titleHeight
            }
            
            return cellHeight
        case SlotType.Video.rawValue:
            return UIScreen.main.bounds.size.width/1.77 - 2
        case SlotType.Text.rawValue:
            return UITableViewAutomaticDimension
        case SlotType.Photo.rawValue:
            var titleHeight : CGFloat! = 0.0
            
            if(information.photo.title != nil)
            {
                titleHeight = information.photo.title.title?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: UIFont (name: (information.photo.title.titleFont)!, size: CGFloat((information.photo.title.titleSize)!))!)
            }
            
            var cellHeight : CGFloat!
            if(information.photo.aspectRatio != nil)
            {
                if (isArticle)
                {
                    cellHeight = 0.9 * UIScreen.main.bounds.size.width * CGFloat(information.photo.aspectRatio) + titleHeight
                }
                else if(information.photo.takeFullWidth)
                {
                    cellHeight = UIScreen.main.bounds.size.width * CGFloat(information.photo.aspectRatio) + titleHeight
                }
                else
                {
                    cellHeight = 0.5 * UIScreen.main.bounds.size.width * CGFloat(information.photo.aspectRatio) + titleHeight
                }
            }
            else
            {
                cellHeight = UIScreen.main.bounds.size.width + titleHeight
            }
            
            return cellHeight
        case SlotType.Title.rawValue:
            let font = UIFont (name: (FontsAndSizes.titleFont), size: CGFloat((FontsAndSizes.titleTextSize)))
            
            if(isArticle)
            {
                return  UITableViewAutomaticDimension//(information.title.title.height(withConstrainedWidth: 0.9 * UIScreen.main.bounds.size.width, font: font!) + 30)
            }
            else
            {
                return (information.title.title.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: font!) + 30)
            }
        case SlotType.PDF.rawValue:
            //var screenAspectRatio = (UIScreen.main.bounds.size.height / (UIScreen.main.bounds.size.width - CGFloat(borderWidth * 2)))
            //return (UIScreen.main.bounds.size.width - CGFloat(borderWidth * 2)) * 1.417 * CGFloat(information.pdf.numOfPages)
            
            return indexPath.row < PDFWebViews.count ? PDFWebViews[indexPath.row].frame.size.height : 0
            
        case SlotType.Product.rawValue, SlotType.RelatedArticle.rawValue, SlotType.Share.rawValue:
            //return 0.75 * UIScreen.main.bounds.size.width * CGFloat(information.product.imageAspectRatio)
            return UITableViewAutomaticDimension
        default:
            return 180
        }
        
    }
    
    private var cellHeights: [IndexPath: CGFloat?] = [:]
    var expandedIndexPaths: [IndexPath] = []
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cellHeights[indexPath] = cell.frame.height
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        if let height = cellHeights[indexPath] {
            return height ?? UITableViewAutomaticDimension
        }
        return UITableViewAutomaticDimension
    }
    
    
    func expandCell(cell: UITableViewCell) {
        if let indexPath = informationTableView.indexPath(for: cell) {
            if !expandedIndexPaths.contains(indexPath) {
                expandedIndexPaths.append(indexPath)
                cellHeights[indexPath] = nil
                informationTableView.reloadRows(at: [indexPath], with: UITableViewRowAnimation.automatic)
                //tableView.scrollToRow(at: indexPath, at: .top, animated: true)
            }
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        for v in videosPostions
        {
            let indexPathTemp = IndexPath(row:  0, section: v)
            
            
            var cellRect = informationTableView.rectForRow(at: indexPathTemp)
            cellRect.size.height =  cellRect.size.height
            let completelyVisible = informationTableView.bounds.contains(cellRect)
            var information : GeneralInformation2!
            information = informationsList[v]
            
            if (completelyVisible) {
                if(!videoIsBeenPlaying && information.video.autoPlay){
                    playVideo(item: information)
                }
            }
            
            if(!completelyVisible)
            {
                // playVideo(item: information)
                
                if (!isYoutubeUrl(checkUrl: information.video.videoUrl)){
                    
                    webView.stringByEvaluatingJavaScript(from: "var vid = document.getElementById(\"video1\"); vid.pause();")
                }
                else{
                    playVideo(item: information)
                    webView.stringByEvaluatingJavaScript(from: "var vid = document.getElementById(\"video2\"); vid.src=vid.src;")
                }
                videoIsBeenPlaying=false
            }
        }
        
    }
    
    
    
    func playVideo(item: GeneralInformation2){
        var i = 0
        let width = UIScreen.main.bounds.size.width - CGFloat(2 * borderWidth)
        let height = width/1.77
        webView.allowsInlineMediaPlayback = true
        webView.mediaPlaybackRequiresUserAction = false
        indicator.startAnimating()
        if(!videoLoaded[i])
        {
            //item.video.videoUrl = "https://www.youtube.com/embed/_LUv8EhF9d4"
            
            if (isYoutubeUrl(checkUrl: item.video.videoUrl)) {
                webView.loadHTMLString("<iframe id=\"video2\" width=\"\(width)\" height=\"\(height)\" src=\"\(item.video.videoUrl ?? "")?playsinline=1\" frameborder=\"0\" allowfullscreen></iframe>", baseURL: nil)
                webView.stringByEvaluatingJavaScript(from: "var vid = document.getElementById(\"video2\"); vid.play();")
                videoIsBeenPlaying = true
            }else{
                if (item.video.autoPlay){
                    webView.loadHTMLString("<video controls muted  loop autoplay playsinline webkit-playsinline id=\"video1\" width=\"\(width)\" height=\"\(height)\"> <source src=\"\(item.video.videoUrl ?? "")\" type=\"video/mp4\"></video>", baseURL: nil)
                    self.webView.stringByEvaluatingJavaScript(from: "var vid = document.getElementById(\"video1\"); vid.play(); vid.addEventListener('ended', captureFrame); function captureFrame(e) { var lastFrame = this.duration; this.currentTime = lastFrame; this.pause();}")
                    videoIsBeenPlaying = true
                    
                }else{
                    webView.loadHTMLString("<video controls muted  loop autoplay playsinline webkit-playsinline id=\"video1\" width=\"\(width)\" height=\"\(height)\"> <source src=\"\(item.video.videoUrl ?? "")\" type=\"video/mp4\"></video>", baseURL: nil)
                    DispatchQueue.global(qos: .background).async {
                        sleep(2)
                        DispatchQueue.main.async {
                            self.webView.stringByEvaluatingJavaScript(from: "var vid = document.getElementById(\"video1\"); vid.pause();")
                            self.videoIsBeenPlaying = false
                        }
                    }
                }
            }
            
            videoLoaded[i] = true
            i += 1
        }
        else
        {
            videoIsBeenPlaying = true
            if (!isYoutubeUrl(checkUrl: item.video.videoUrl)) {
                webView.stringByEvaluatingJavaScript(from: "var vid = document.getElementById(\"video1\"); vid.play();")
            }
            else{
                webView.stringByEvaluatingJavaScript(from: "var vid = document.getElementById(\"video2\"); vid.play();")
            }
        }
        //indicator.stopAnimating()
    }
    
    
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var information : GeneralInformation2!
        
        information = informationsList[indexPath.section]
        
        switch information.type {
        case SlotType.Share.rawValue:
            var shareModel = information.share
            let items: [Any] = [information.share.title, URL(string: information.share.url )!, UIImage(data: information.share.image)]
            let ac = UIActivityViewController(activityItems: items, applicationActivities: nil)
            self.present(ac, animated: true)
        case SlotType.RelatedArticle.rawValue:
            let article = information.article
            
            if(article != nil)
            {
                showArticleView(article : article!, navigationController : self.navigationController!, viewController : self)
            }
            
            break
        default:
            break
        }
    }
    
    var PDFLoaded = false
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        for subview:UIView in webView.scrollView.subviews {
            if (subview is UIScrollView) {
                for shadowView: UIView in subview.subviews {
                    if (shadowView is UIImageView) {
                        shadowView.isHidden = true
                    }
                }
            }
            
            subview.layer.shadowOpacity = 0
            for subsubview in subview.subviews {
                subsubview.layer.shadowOpacity = 0
            }
        }
        
        var frame = webView.frame
        frame.size.height = 1
        webView.frame = frame
        let fittingSize = webView.sizeThatFits(CGSize.init(width: 0, height: 0))
        frame.size = fittingSize
        webView.frame = frame
        
        if(!PDFLoaded)
        {
            PDFLoaded = true
            informationTableView.reloadData()
        }
    }
    
    func webView(_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebViewNavigationType) -> Bool
    {
        switch navigationType {
        case .linkClicked:
            // Open links in Safari
            guard let url = request.url else { return true }
            //restartApp = false
            
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            } else {
                // openURL(_:) is deprecated in iOS 10+.
                UIApplication.shared.openURL(url)
            }
            return false
        default:
            // Handle other navigation types...
            return true
        }
    }
    
    
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        if(isEmbeded)
        {
            isViewPushed = false
            self.navigationController?.popViewController(animated: true)
        }
        else
        {
            self.showHideLeftDrawer()
        }
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
}
