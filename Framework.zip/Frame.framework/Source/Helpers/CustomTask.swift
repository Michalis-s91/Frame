//
//  CustomAsyncTask.swift
//  RichReach2
//
//  Created by Eumbrella on 27/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import AVFoundation


class  CustomTask
{
    var viewController : ViewController!
    var container : UIView!
    var action : Runnable!
    var failureAction : Runnable!
    var timer : SynchronizationTimer!
    //var task : Task
    
    var successMessage = ""
    var errorMessage = ""
    var notAvailableMessage = NSLocalizedString("noDataLoadedActivateInternetConnection", comment: "")
    var displayToast = false
    var isSynchronizationTimerEnabled : Bool!
    var shouldDisplayNotAvailableView = false
    var isFailureActionToast : Bool!
    var isInternetAvailableFlag : Bool!
    var task : DispatchWorkItem!
    var notAvailableView : NotAvailableViewController!
    
    var backgroundTask : BackgroundTask!
    
    init (viewController : ViewController!, action : @escaping Runnable, displayToast : Bool = false, isSynchronizationTimerEnabled : Bool = true, elapsedSecondsToDisplayMessage : Int = 3, toastMessage : String = NSLocalizedString("congestedNetworkMessage", comment: "") ){
        self.viewController = viewController
        self.action = action
        self.isSynchronizationTimerEnabled = isSynchronizationTimerEnabled
        self.displayToast = displayToast
        
        if (isSynchronizationTimerEnabled)
        {
            timer = SynchronizationTimer(viewController : self.viewController, elapsedSecondsToDisplayMessage : elapsedSecondsToDisplayMessage, toastMessage: toastMessage)
        }
        
        backgroundTask = BackgroundTask(application: UIApplication.shared)
    }
    
    /// Sets the action to be performed in case the task fails (e.g. because of an exception).
    ///
    /// - Parameters:
    ///   - action: The action to be performed in case the task doesn't perform any work due to internet connection or an exception.
    ///   - isFailureActionToast: True if is failure toast, otherwise false.
    func setFailureAction(action : @escaping Runnable, isFailureActionToast : Bool = false)
    {
        self.failureAction = action
        self.isFailureActionToast = isFailureActionToast
    }
    
    /// Stops the synchronization timer.
    func stop(){
        stopSynchronizationTimer()
        stopTask()
    }
    
    /// Starts the synchronization timer.
    func startSynchronizationTimer()
    {
        if (isSynchronizationTimerEnabled)
        {
            timer.shouldDisplayCustomToast(shouldDisplayToast: displayToast)
            timer.start()
        }
    }
    
    /// Stops the synchronization timer execution.
    func stopSynchronizationTimer(){
        if (isSynchronizationTimerEnabled)
        {
            do
            {
                if (isSynchronizationTimerEnabled) {
                    timer.stop()
                }
            } catch
            {
                
            }
        }
    }
    
    /// Stops the task execution.
    func stopTask(){
        /*queue.isSuspended = true // halts execution of the queue
         queue.cancelAllOperations() // notify all pending operations to terminate
         //queue.isSuspended = false // let it go.
         queue = nil*/
        
        
        //backgroundTask.end()
        
        
        /*do {
         UIApplication.shared.endBackgroundTask(1)
         //self.dwi2 = nil
         //self.action = nil
         
         DispatchQueue.main.async(execute: {() -> Void in
         //self.task.cancel()
         })
         }
         catch
         {
         
         }*/
        
        /*if (identifier != UIBackgroundTaskInvalid) {
         application.endBackgroundTask(identifier)
         }
         
         identifier = UIBackgroundTaskInvalid*/
    }
    

    
    /// Displays a toast message.
    ///
    /// - Parameter message: The message to be displayed.
    func displayToastMessage(message: String){
        if(!isActivityActive(viewController: viewController))
        {
            return
        }
        
        if(!isNullOrEmpty(string: message))
        {
            DispatchQueue.main.async(execute: {() -> Void in
                
                
                let toast = CustomToast()
                toast.setToast(viewController : self.viewController,message : message, duration: CustomToast.TOAST_LENGTH_LONG )
                toast.show()
            })
        }
    }
    
    /// Sets whether the task should display the "Not Available" view in case no data are loaded.
    ///
    /// - Parameters:
    ///   - shouldDisplayNotAvailableView: A flag that indicates whether the "Not Available" view should be displayed in case no data are loaded.
    ///   - container: The contianer for displaying the not available view.
    func shouldDisplayNotAvailableView (shouldDisplayNotAvailableView : Bool, container : UIView){
        self.shouldDisplayNotAvailableView = shouldDisplayNotAvailableView
        self.container = container
    }
    
    /// Displays a view that tells user that no data were loaded due to connectivity issues.
    func displayNotAvailableView(){
        DispatchQueue.main.async(execute: {() -> Void in
            self.notAvailableView = ShowNotAvailableView.showNotAvailableView(view : self.viewController, container : self.container, text: self.notAvailableMessage)
        })
        
    }
    
    /// Sets whether the task should display the activity indicator or not. Note that the activity indicator is activated from the
    /// synchronization timer.
    ///
    /// - Parameter shouldDisplayActivityIndicator: A flag that indicates whether the activity indicator should be displayed or not.
    func shouldDisplayActivityIndicator (shouldDisplayActivityIndicator : Bool){
        
        if (isSynchronizationTimerEnabled)
        {
            timer.setShouldDisplayActivityIndicator(shouldDisplayActivityIndicator : shouldDisplayActivityIndicator)
        }
    }
}
