//
//  WebApiTask.swift
//  RichReach2
//
//  Created by Eumbrella on 15/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import AVFoundation

/// WebApiTask implements task-related functionality. It accepts an action as an input parameter and if there is active
/// internet connection it performs the action. The WebApiTask can also display the appropriate messages in case it
/// succeeds, fails or there is no active internet connection.
///
/// WebApiTask also has a synchronization timer that allows it to display a toast and/or a progress bar in case the
/// operation takes too long to complete.
class WebApiTask : Canceller
{
    var _shouldCancel: Bool = false
    
    func setShouldCancel(shouldCancel: Bool) {
        _shouldCancel = shouldCancel
    }
    
    func shouldCancel() -> Bool {
        return _shouldCancel
    }
    
    typealias Runnable = () -> ()
    
    var viewController : ViewController!
    var container : UIView!
    var action : Runnable!
    var failureAction : Runnable!
    var timer : SynchronizationTimer!
    //var task : Task
    
    var successMessage = ""
    var errorMessage = ""
    var notAvailableMessage = NSLocalizedString("noDataLoadedActivateInternetConnection", comment: "")
    var displayToast = false
    var isSynchronizationTimerEnabled : Bool!
    var shouldDisplayNotAvailableView = false
    var isFailureActionToast : Bool!
    var isInternetAvailableFlag : Bool!
    var task : DispatchWorkItem!
    var notAvailableView : NotAvailableViewController!
    
    var backgroundTask : BackgroundTask!
    
    init (viewController : ViewController!, action : @escaping Runnable, displayToast : Bool = false, isSynchronizationTimerEnabled : Bool = true, elapsedSecondsToDisplayMessage : Int = 3 ){
        self.viewController = viewController
        self.action = action
        self.isSynchronizationTimerEnabled = isSynchronizationTimerEnabled
        self.displayToast = displayToast
        
        if (isSynchronizationTimerEnabled)
        {
            timer = SynchronizationTimer(viewController : self.viewController, elapsedSecondsToDisplayMessage : elapsedSecondsToDisplayMessage, toastMessage: NSLocalizedString("congestedNetworkMessage", comment: ""))
        }
        
        backgroundTask = BackgroundTask(application: UIApplication.shared)
    }
    
    /// Sets the action to be performed in case the task fails (e.g. because of an exception).
    ///
    /// - Parameters:
    ///   - action: The action to be performed in case the task doesn't perform any work due to internet connection or an exception.
    ///   - isFailureActionToast: True if is failure toast, otherwise false.
    func setFailureAction(action : @escaping Runnable, isFailureActionToast : Bool = false)
    {
        self.failureAction = action
        self.isFailureActionToast = isFailureActionToast
    }
    
    /// Checks whether there is an active internet connection and if so it runs the task action.
    func start() {
        if(notAvailableView != nil)
        {
            notAvailableView.view.removeFromSuperview()
            notAvailableView.removeFromParentViewController()
        }
        
        runAsync()
    }
    
    /// Stops the synchronization timer.
    func stop(){
        stopSynchronizationTimer()
        stopTask()
    }
    
    /// Starts the synchronization timer.
    func startSynchronizationTimer()
    {
        if (isSynchronizationTimerEnabled)
        {
            timer.shouldDisplayCustomToast(shouldDisplayToast: displayToast)
            timer.start()
        }
    }
    
    /// Stops the synchronization timer execution.
    func stopSynchronizationTimer(){
        if (isSynchronizationTimerEnabled)
        {
            do
            {
                if (isSynchronizationTimerEnabled) {
                    timer.stop()
                }
            } catch
            {
            
            }
        }
    }
    
    /// Stops the task execution.
    func stopTask(){
        /*queue.isSuspended = true // halts execution of the queue
        queue.cancelAllOperations() // notify all pending operations to terminate
        //queue.isSuspended = false // let it go.
        queue = nil*/
        
        
        //backgroundTask.end()
        
        
        /*do {
            UIApplication.shared.endBackgroundTask(1)
            //self.dwi2 = nil
            //self.action = nil
            
            DispatchQueue.main.async(execute: {() -> Void in
                //self.task.cancel()
            })
        }
        catch
        {
            
        }*/
        
        /*if (identifier != UIBackgroundTaskInvalid) {
            application.endBackgroundTask(identifier)
        }
        
        identifier = UIBackgroundTaskInvalid*/
    }
    
    var dwi2:DispatchWorkItem!
    var queue : OperationQueue! =  OperationQueue()
   
    
    
    func runAsync(){
        
        /*queue.maxConcurrentOperationCount = 1
        queue.addOperation {
            self.runAsync2()
        }*/
        //backgroundTask.begin(action : runAsync2)
        /*let application = UIApplication.shared
        
        //DispatchQueue.global(qos: .background).async {
        self.backgroundTask.run(application: application) {_ in 
                self.runAsync2()
            }
        //}*/
        
        //dwi2 = DispatchWorkItem {
            self.runAsync2()
        //}
        
        //DispatchQueue.global().async(execute: dwi2)

        //var a = UIApplication.shared.beginBackgroundTask(expirationHandler: nil)
        //DispatchQueue.main.asyncAfter(deadline: .now(), execute: task)
        //DispatchQueue.global(qos: .background).async( execute: task)
    }

    /// Runs the task action
    func runAsync2() -> Void
    {
        do {
            DispatchQueue.global(qos: .background).async {
                self.startSynchronizationTimer()
                
                self.isInternetAvailableFlag = false
                if (self.isInternetAvailable())
                {
                    DispatchQueue.main.async(execute: {() -> Void in
                        if(self.container != nil && self.container.subviews.count > 2)
                        {
                            self.container.subviews[self.container.subviews.count - 1].removeFromSuperview()
                        }
                    })
                    
                    self.isInternetAvailableFlag = true
                    self.action()
                }
                else
                {
                    if (self.failureAction != nil && self.viewController != nil && self.isFailureActionToast == false)
                    {
                        DispatchQueue.main.async {
                            self.failureAction()
                        }
                    }
                    
                    if (self.displayToast && self.viewController != nil)
                    {
                        DispatchQueue.main.async {
                            let toast = CustomToast()
                            toast.setToast(viewController: self.viewController, message: NSLocalizedString("internetRequired", comment: ""), duration: CustomToast.TOAST_LENGTH_LONG)
                            toast.show()
                        }
                    }
                    else
                    {
                        if (self.shouldDisplayNotAvailableView)
                        {
                            DispatchQueue.main.async {
                                self.displayNotAvailableView()
                            }
                        }
                    }
                }
                
                self.stopSynchronizationTimer()
                usleep(300000)
                
                if (self.displayToast && self.isInternetAvailableFlag)
                {
                    self.displayToastMessage(message: self.successMessage)
                }
            }
        }
        catch
        {
            self.stopSynchronizationTimer()
            
            if (self.failureAction != nil && self.viewController != nil)
            {
                DispatchQueue.main.async {
                    self.failureAction()
                }
            }
            
            if (self.displayToast)
            {
                self.displayToastMessage(message: self.errorMessage)
            }
            else
            {
                if (self.shouldDisplayNotAvailableView)
                {
                    self.displayNotAvailableView()
                }
            }
        }
    }
    
    /// Checks and returns whether there is an active internet connection or not.
    ///
    /// - Returns: True if there is an active internet connection, otherwise false.
    func isInternetAvailable() -> Bool {
        return NetworkHelper.isReachable()
    }
    
    /// Displays a toast message.
    ///
    /// - Parameter message: The message to be displayed.
    func displayToastMessage(message: String){
        if(!isActivityActive(viewController: viewController))
        {
            return
        }
        
        if(!isNullOrEmpty(string: message))
        {
            DispatchQueue.main.async(execute: {() -> Void in
                let toast = CustomToast()
                toast.setToast(viewController : self.viewController,message : message, duration: CustomToast.TOAST_LENGTH_LONG )
                toast.show()
            })
        }
    }
    
    /// Sets whether the task should display the "Not Available" view in case no data are loaded.
    ///
    /// - Parameters:
    ///   - shouldDisplayNotAvailableView: A flag that indicates whether the "Not Available" view should be displayed in case no data are loaded.
    ///   - container: The contianer for displaying the not available view.
    func shouldDisplayNotAvailableView (shouldDisplayNotAvailableView : Bool, container : UIView){
        self.shouldDisplayNotAvailableView = shouldDisplayNotAvailableView
        self.container = container
    }
    
    /// Displays a view that tells user that no data were loaded due to connectivity issues.
    func displayNotAvailableView(){
        DispatchQueue.main.async(execute: {() -> Void in
            self.viewController.notAvailableView = ShowNotAvailableView.showNotAvailableView(view : self.viewController, container : self.container, text: self.notAvailableMessage)
        })

    }
    
    /// Sets whether the task should display the activity indicator or not. Note that the activity indicator is activated from the
    /// synchronization timer.
    ///
    /// - Parameter shouldDisplayActivityIndicator: A flag that indicates whether the activity indicator should be displayed or not.
    func shouldDisplayActivityIndicator (shouldDisplayActivityIndicator : Bool){
        
        if (isSynchronizationTimerEnabled)
        {
            timer.setShouldDisplayActivityIndicator(shouldDisplayActivityIndicator : shouldDisplayActivityIndicator)
        }
    }
    
}
