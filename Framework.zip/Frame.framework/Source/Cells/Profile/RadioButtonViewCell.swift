//
//  NewslettersViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 09/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class RadioButtonViewCell: UITableViewCell {

    @IBOutlet var ratioButton: DLRadioButton!
    @IBOutlet var radioImage: UIImageView!
    @IBOutlet var radioView: UIView!
    @IBOutlet var radioLabel: UILabel!
    
    var radioModel : RadioButtonModel!
    var viewModel : UserProfileViewModel2!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        let onRadioClick = UITapGestureRecognizer(target: self, action: #selector(RadioButtonViewCell.onRadioClick))
        radioView.isUserInteractionEnabled = true
        radioView.addGestureRecognizer(onRadioClick)
    }
    
    override func didMoveToSuperview() {
        if(radioModel != nil && viewModel != nil && viewModel.acceptNews != nil)
        {
            if(radioModel.connectionID == 1)
            {
                radioModel.isSelected = viewModel.acceptNews.acceptNews1 == 1 ? true : false
            }
            else if(radioModel.connectionID == 2)
            {
                radioModel.isSelected = viewModel.acceptNews.acceptNews2 == 1 ? true : false
            }
            else if(radioModel.connectionID == 3)
            {
                radioModel.isSelected = viewModel.acceptNews.acceptNews3 == 1 ? true : false
            }
            else if(radioModel.connectionID == 4)
            {
                radioModel.isSelected = viewModel.acceptNews.acceptNews4 == 1 ? true : false
            }
            else if(radioModel.connectionID == 5)
            {
                radioModel.isSelected = viewModel.acceptNews.acceptNews5 == 1 ? true : false
            }
            else if(radioModel.connectionID == 6)
            {
                radioModel.isSelected = viewModel.acceptNews.acceptNews6 == 1 ? true : false
            }
            else if(radioModel.connectionID == 7)
            {
                radioModel.isSelected = viewModel.acceptNews.acceptNews7 == 1 ? true : false
            }
            else if(radioModel.connectionID == 8)
            {
                radioModel.isSelected = viewModel.acceptNews.acceptNews8 == 1 ? true : false
            }
        }
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        if(radioModel != nil)
        {
            if(radioModel.isSelected)
            {
                ratioButton.isSelected = true
                ratioButton.iconColor = UIColor(radioModel.selectedColor)
                ratioButton.iconStrokeWidth = 5
            }
            else
            {
                ratioButton.isSelected = false
                ratioButton.iconColor = UIColor(radioModel.nonSelectedColor)
                ratioButton.iconStrokeWidth = 3
            }
        }
    }
    
    @objc func onRadioClick (sender: UITapGestureRecognizer) {
        viewModel.areAcceptNewsChanged = true
    
        if(!ratioButton.isSelected)
        {
            ratioButton.iconColor = UIColor(radioModel.selectedColor)
            ratioButton.iconStrokeWidth = 5
        }
        else
        {
            ratioButton.iconColor = UIColor(radioModel.nonSelectedColor)
            ratioButton.iconStrokeWidth = 3
        }
        
        ratioButton.isSelected = !ratioButton.isSelected
        radioModel.isSelected = ratioButton.isSelected
        
        switch radioModel.connectionID {
        case 1:
            viewModel.acceptNews.acceptNews1 = radioModel.isSelected ? 1 : 0
        case 2:
            viewModel.acceptNews.acceptNews2 = radioModel.isSelected ? 1 : 0
        case 3:
            viewModel.acceptNews.acceptNews3 = radioModel.isSelected ? 1 : 0
        case 4:
            viewModel.acceptNews.acceptNews4 = radioModel.isSelected ? 1 : 0
        case 5:
            viewModel.acceptNews.acceptNews5 = radioModel.isSelected ? 1 : 0
        case 6:
            viewModel.acceptNews.acceptNews6 = radioModel.isSelected ? 1 : 0
        case 7:
            viewModel.acceptNews.acceptNews7 = radioModel.isSelected ? 1 : 0
        case 8:
            viewModel.acceptNews.acceptNews8 = radioModel.isSelected ? 1 : 0
        default:
            break
        }
    }

}
