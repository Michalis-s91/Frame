//
//  ContactUsTypes.swift
//  RichReach2
//
//  Created by Eumbrella on 29/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class StringTable : Codable
{
    var strings : [String]! = []
    var types : [Int]! = []
}
