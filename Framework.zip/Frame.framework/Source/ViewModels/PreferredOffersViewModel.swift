//
//  PreferredOffersViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 22/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class PreferredOffersViewModel
{
    static var offersPageToLoad = 0
    var offersList : [OfferModel]!
    //static List<ImageView> isFavouriteList = new ArrayList<>()
    var isOffersNotAvailable = false
    var iteration = 0
    
    init()
    {
        //offersPageToLoad = 2
    }
}
