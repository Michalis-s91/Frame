//
//  APKInitializer.swift
//  RichReach2
//
//  Created by Eumbrella on 24/04/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Initialises parameters of app.
class APKInitializer
{
    var navDownloadGroup = DispatchGroup()
    var leftDrawerDownloadGroup = DispatchGroup()
    var backgroundDownloadGroup = DispatchGroup()
    var waitForNavImageToDownloaded = false
    var waitForLeftDrawerImageToDownloaded = false
    var waitForBackgroundImageToDownload = false
    var leftDrawerImageName : String!
    var navImageName : String!
    var backgroundImageName : String!
    
    var errorOccurred = false
    /// Calls apis and saves parameters in local database for given APK.
    ///
    /// - Parameter apk: The APK.
    func getProperties() -> Bool
    {
        do
        {
            navDownloadGroup = DispatchGroup()
            leftDrawerDownloadGroup = DispatchGroup()
            
            waitForNavImageToDownloaded = false
            waitForLeftDrawerImageToDownloaded = false
            waitForBackgroundImageToDownload = false
            
            //let statusModel : StatusModel! = statusDB.getStatus(apk: APK)
            
            if(!(statusModel?.isThemeSaved)!)
            {
                let theme  = try ParameterizationWebApi.getTheme(apk: APK)
                parameterizationDatabase.insertTheme(theme: theme)
                statusModel?.isThemeSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
                leftDrawerImageName = theme?.leftDrawerImage
                navImageName = theme?.navigationBarImage
                backgroundImageName = theme?.backgroundImageUrl
            }
            else
            {
                let theme = parameterizationDatabase.getTheme(apk: APK)
                leftDrawerImageName = theme?.leftDrawerImage
                navImageName = theme?.navigationBarImage
                backgroundImageName = theme?.backgroundImageUrl
            }
            
            if(!(statusModel?.isNavImageSaved)!)
            {
                if let url = URL(string: navImageName)
                {
                    waitForNavImageToDownloaded = true
                    navDownloadGroup.enter()
                    downloadNavImage(url: url )
                    /*navDownloadGroup.notify(queue: .main) {
                        waitForNavImageToDownloaded = false
                    }*/
                }
            }
            
            if(!(statusModel?.isLeftDrawerImageSaved)!)
            {
                if let url = URL(string: leftDrawerImageName)
                {
                    waitForLeftDrawerImageToDownloaded = true
                    leftDrawerDownloadGroup.enter()
                    downloadLeftDrawerImage(url: url)
                    /*leftDrawerDownloadGroup.notify(queue: .main) {
                        waitForLeftDrawerImageToDownloaded = false
                    }*/
                }
            }
            
            if(!(statusModel?.isBackgroundImageSaved)!)
            {
                if let url = URL(string: backgroundImageName)
                {
                    waitForBackgroundImageToDownload = true
                    backgroundDownloadGroup.enter()
                    downloadBackgroundImage(url: url)
                }
            }
            
            navDownloadGroup.notify(queue: .main) {
                self.errorOccurred = true
             }
            
            leftDrawerDownloadGroup.notify(queue: .main) {
                self.errorOccurred = true
             }
            
            backgroundDownloadGroup.notify(queue: .main)
            {
                self.errorOccurred = true
            }
            
            while(waitForNavImageToDownloaded || waitForLeftDrawerImageToDownloaded || waitForBackgroundImageToDownload)
            {
                if(errorOccurred)
                {
                    return false
                }
            }
            
            
            //let defaultTabs = ParameterizationWebApi.getDefaultTabs()
            //parameterizationDatabase.insertDefaultTabs(tabs: defaultTabs)

            
            //parameterizationDatabase.insertLeftDrawerTabs(tabs: leftDrawerTabs)
            
            if(!(statusModel?.areSocialMediaSaved)!)
            {
                let socialMedia = try ParameterizationWebApi.getSocialMedia(apk : APK)
                parameterizationDatabase.insertSocialMedia(socialMedia: socialMedia)
                statusModel.areSocialMediaSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            if(!(statusModel?.areStylesSaved)!)
            {
                let styles = try ParameterizationWebApi.getStyles(apk: APK)
                parameterizationDatabase.insertStyles(styles: styles)
                statusModel?.areStylesSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
            }
            
            if(!(statusModel?.areLeftDrawerTabsSaved)!)
            {
                let leftDrawerTabsLinks =  try ParameterizationWebApi.getLeftDrawerTabsLinks(apk: APK)
                var leftDrawerTabs = try ParameterizationWebApi.getLeftDrawerTabs(apk: APK)
                
                if(leftDrawerTabsLinks != nil && leftDrawerTabs != nil)
                {
                    var count = 0
                    for tab in leftDrawerTabs!
                    {
                        if(tab.type == LeftDrawerTabsType.DirectLink.rawValue)
                        {
                            tab.link = leftDrawerTabsLinks![count].link
                            count += 1
                        }
                    }
                }
                
                var relations : [PCRelation]!
                if(!(statusModel?.areRelationsSaved)!)
                {
                    relations = try ParameterizationWebApi.getRelations(apk: APK)
                    statusModel?.areRelationsSaved = true
                    statusDB.insertStatus(status : statusModel, apk : APK)
                    parameterizationDatabase.insertPCRelations(relations: relations)
                }
                else
                {
                    relations = parameterizationDatabase.getPCRelations(apk: APK)
                }
                
                if(leftDrawerTabs != nil && relations != nil)
                {
                    var tabIndex = 0
                    
                    for var tab in leftDrawerTabs!
                    {
                        
                        //LeftDrawerViewController.leftDrawerGroupTabs.append(tab.name)
                        //LeftDrawerViewController.leftDrawerGroupTabsID.append(tab.id)
                        
                        if(relations != nil)
                        {
                            for r in relations!
                            {
                                if(r.childID == tab.id)
                                {
                                    r.child = tab
                                    tab.isChild = true
                                    tab.parentID = r.parentID
                                    //LeftDrawerViewController.leftDrawerGroupTabs.remove(at: LeftDrawerViewController.leftDrawerGroupTabs.count - 1)
                                    //LeftDrawerViewController.leftDrawerGroupTabsID.remove(at: LeftDrawerViewController.leftDrawerGroupTabs.count)
                                    break
                                }
                                else if (r.parentID == tab.id)
                                {
                                    r.parent = tab
                                    tab.isParent = true
                                    expandedTable.append(0)
                                    break
                                }
                            }
                        }
                        
                        //Set the storyboard name and view id for given tab for first vissible tab.
                        setStoryboardNameAndID(tab : &tab)
                        
                        /*if(tab.id == 1)
                        {
                            if(!tab.isParent)
                            {
                                setStoryboardNameAndID(tab : &tab)
                            }
                            else
                            {
                                for r in relations!
                                {
                                    if (r.parentID == tab.id)
                                    {
                                        for var t in leftDrawerTabs!
                                        {
                                            if(t.id == r.childID)
                                            {
                                                setStoryboardNameAndID(tab : &t)
                                            }
                                        }
                                        //break
                                    }
                                }
                            }
                            
                        }*/
                        
                        if(tab.type == LeftDrawerTabsType.Preferred.rawValue)
                        {
                            let appUser = localDatabase.getAppUser()
                            
                            if(appUser != nil)
                            {
                                if(appUser?.partnerID != 0)
                                {
                                    tab.isVissible = true
                                }
                            }
                        }
                        
                        tabIndex += 1
                    }
                    
                    //parameterizationDatabase.deleteLeftDrawerTabs()
                    parameterizationDatabase.insertLeftDrawerTabs(tabs: leftDrawerTabs)
                    statusModel?.areLeftDrawerTabsSaved = true
                    statusDB.insertStatus(status : statusModel, apk : APK)
                    return true
                }
                else if (leftDrawerTabs != nil)
                {
                    parameterizationDatabase.insertLeftDrawerTabs(tabs: leftDrawerTabs)
                    statusModel?.areLeftDrawerTabsSaved = true
                    statusDB.insertStatus(status : statusModel, apk : APK)
                    return true
                }
                else
                {
                    return false
                }
            }
            
            return true
        }
        catch
        {
            return false
        }
    }
    
    
    /// Get paremeters from local database and set them to app.
    static func setProperties()
    {
        let theme  = parameterizationDatabase.getTheme(apk: APK)
        
        if(theme != nil)
        {
            defaultTabID = theme?.defaultTabID

            Colors.colorPrimary = UIColor((theme?.navigationBarColor)!)
            Colors.navigationBarTintColor = UIColor((theme?.navigationBarTintColor)!)
            Colors.leftDrawerShadowColor = UIColor((theme?.leftDrawerShadowColor)!)
            
            LeftDrawerViewController.showImages = (theme?.showLeftDrawerImages)!
            LeftDrawerViewController.showLine = (theme?.showLeftDrawerLines)!
            if(LeftDrawerViewController.showLine)
            {
                Colors.leftDrawerLineColor = UIColor((theme?.leftDrawerLineColor)!)
            }
            
            //Left drawer
            var s : Style! = parameterizationDatabase.getLeftDrawerStyle(apk: APK, id : (theme?.leftDrawerStyle)!)
            
            if(s != nil)
            {
                leftDrawerTopPadding = s.topPadding
                Colors.leftDrawerBackground = UIColor(s.backgroundColor)
                Colors.leftDrawerSelectedItemBackground = UIColor(s.selectedColor)
                Colors.leftDrawerItemTextColor = UIColor(s.textColor)
                Colors.leftDrawerTintColor = UIColor(s.tintColor)
                
                if(s.bold != nil && s.bold)
                {
                    LeftDrawerViewController.bold = true
                }
                
                if(s.italic != nil && s.italic)
                {
                    LeftDrawerViewController.italic = true
                }
                
                FontsAndSizes.leftDrawerFont = s.font.components(separatedBy: ".")[0]
                FontsAndSizes.leftDrawerSize = Double(s.textSize)
            }
            
            //Left drawer child
            s = parameterizationDatabase.getLeftDrawerChildStyle(apk: APK, id : (theme?.leftDrawerChildStyle)!)
            
            Colors.leftDrawerChildBackground = UIColor(s.backgroundColor)
            Colors.leftDrawerChildItemTextColor = UIColor(s.textColor)
            Colors.leftDrawerChildTintColor = UIColor(s.tintColor)
            FontsAndSizes.leftDrawerChildFont = s.font.components(separatedBy: ".")[0]
            FontsAndSizes.leftDrawerChildSize = Double(s.textSize)
            
            
            //Tab bar
            s = parameterizationDatabase.getTabBarStyle(apk: APK, id : (theme?.tabBarStyle)!)
            Colors.tabBarBackground = UIColor(s.backgroundColor)
            Colors.tabBarSelectedTextColor = UIColor(s.selectedColor)
            Colors.tabBarTextColor = UIColor(s.textColor)
            Colors.tabBarTintColor = UIColor(s.tintColor)
            CustomTabbarViewController.font = s.font.components(separatedBy: ".")[0]
            //CustomTabbarViewController.textSize = s.textSize
            
            //Toast
            s = parameterizationDatabase.getToastStyle(apk: APK, id : (theme?.toastStyle)!)
            Colors.toastColor = UIColor(s.backgroundColor)
            Colors.toastTextColor = UIColor(s.textColor)
            Colors.toastTintColor = UIColor(s.tintColor)
            FontsAndSizes.toastFont = s.font.components(separatedBy: ".")[0]
            FontsAndSizes.toastTextSize = Double(s.textSize)
            
            
            //Dialog
            s = parameterizationDatabase.getDialogStyle(apk: APK, id : (theme?.dialogsStyle)!)
            Colors.dialogBackround = UIColor(s.backgroundColor)
            Colors.dialogTextColor = UIColor(s.textColor)
            Colors.dialogSelectionColor = UIColor(s.selectedColor)
            Colors.dialogTintColor = UIColor(s.tintColor)
            Colors.dialogLineColor = UIColor(s.lineColor)
            FontsAndSizes.dialogFont = s.font.components(separatedBy: ".")[0]
            FontsAndSizes.dialogTextSize = Double(s.textSize)
            
            //Title
            let titleStyle = parameterizationDatabase.getTitleStyle(apk: APK, id : (theme?.titleStyle)!)
            
            if(titleStyle != nil)
            {
                Colors.titleBackround = UIColor((titleStyle?.titleBackgroundColor)!)
                Colors.titleTextColor = UIColor((titleStyle?.titleColor)!)
                Colors.titleSplitterColor = UIColor((titleStyle?.splitterColor)!)
                FontsAndSizes.titleFont = (titleStyle?.titleFont)!
                FontsAndSizes.titleTextSize = Double((titleStyle?.titleSize)!)
                FontsAndSizes.isTitleCentered = (titleStyle?.isTitleCentered)!
                titleTopPadding = titleStyle?.topPadding == nil ? 0 : CGFloat((titleStyle?.topPadding)!)
            }
            
            
            let leftDrawerTabsList = parameterizationDatabase.getLeftDrawerTabs(apk: APK)
            
            if(leftDrawerTabsList != nil)
            {
                for tab in leftDrawerTabsList!
                {
                    if(!tab.isChild && tab.isVissible)
                    {
                        LeftDrawerViewController.leftDrawerGroupTabs.append(tab.name)
                        LeftDrawerViewController.leftDrawerGroupTabsID.append(tab.id)
                    }
                    
                }
                

                //let appUser = localDatabase.getAppUser()
                //appUser?.paremeterizationInitialized = true
                //localDatabase.updateAppUser(appUser: appUser!)

            }
        }
        

    }
    
    func downloadNavImage(url: URL) {
        getDataFromUrl(url: url) { data, response, error in
            guard let data = data, error == nil else
            {
                DispatchQueue.global(qos: .background).async {
                    self.errorOccurred = true
                    self.navDownloadGroup.leave()
                }
                return
            }
            
            //DispatchQueue.main.async() {
            print(data.count)
            parameterizationDatabase.insertNavImage(str: data)
            statusModel.isNavImageSaved = true
            statusDB.insertStatus(status : statusModel, apk : APK)
            self.waitForNavImageToDownloaded = false
                //self.navDownloadGroup.leave()
            //}
        }
    }
    
    func downloadLeftDrawerImage(url: URL) {
        getDataFromUrl(url: url) { data, response, error in
            guard let data = data, error == nil else
            {
                DispatchQueue.global(qos: .background).async {
                    self.errorOccurred = true
                    self.leftDrawerDownloadGroup.leave()
                }
                return

            }
            
            //DispatchQueue.main.async() {
            //DispatchQueue.global(qos: .background).async {
            parameterizationDatabase.insertLeftDrawerImage(str: data)
            statusModel.isLeftDrawerImageSaved = true
            statusDB.insertStatus(status : statusModel, apk : APK)
            self.waitForLeftDrawerImageToDownloaded = false
                //self.leftDrawerDownloadGroup.leave()
            //}
            //}
        }
    }
    
    func downloadBackgroundImage(url: URL) {
        getDataFromUrl(url: url) { data, response, error in
            guard let data = data, error == nil else
            {
                DispatchQueue.global(qos: .background).async {
                    self.backgroundDownloadGroup.leave()
                    self.errorOccurred = true
                }
                return
            }
            
            parameterizationDatabase.insertBackgroundImage(str: data)
            statusModel.isBackgroundImageSaved = true
            statusDB.insertStatus(status : statusModel, apk : APK)
            self.waitForBackgroundImageToDownload = false
        }
    }
}
