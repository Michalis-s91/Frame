//
//  ParameterizationDB.swift
//  RichReach2
//
//  Created by Eumbrella on 18/04/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//
import UIKit
import SQLite
import QuartzCore

/// Parameterization database is used for saving app parameters like left drawer tabs, toast style etc.
class Parameterization : NSObject
{
    static private let DATABASE_NAME = "OrdersDB"
    
    var database : Connection!
    
    let themeTable = Table("Theme")
    let apkUserPreferences = Table("APKUserPreferences")
    let leftDrawerTabsTable = Table("LeftDrawerTabs")
    let leftDrawerStyleTable = Table("LeftDrawerStyle")
    let leftDrawerChildStyleTable = Table("LeftDrawerChildStyle")
    let tabBarStyleTable = Table("TabBarStyle")
    let toastStyleTable = Table("ToastStyle")
    let dialogStyleTable = Table("DialogStyle")
    let pcRelationsTable = Table("PCRelations")
    let leftDrawerImageTable = Table("LeftDrawerImage")
    let navImageTable = Table("NavImage")
    let backgroundImageTable = Table("BackgroundImage")
    let socialMediaTable = Table("SocialMediaTable")
    let signupBonusTablle = Table("SignupBonusTablle")
    let splashViewParametersTable = Table("SplashViewParametersTable")
    
    //Theme columns
    let apk = Expression<String>("apk")
    let leftDrawerStyle = Expression<Int>("leftDrawerStyle")
    let leftDrawerChildStyle = Expression<Int>("leftDrawerChildStyle")
    let tabBarStyle = Expression<Int>("tabBarStyle")
    let toastStyle = Expression<Int>("toastStyle")
    let dialogStyle = Expression<Int>("dialogStyle")
    let navigationBarColor = Expression<String>("navigationBarColor")
    let statusBarColor = Expression<String>("statusBarColor")
    let navigationBarTintColor = Expression<String>("navigationBarTintColor")
    let showLeftDrawerImages = Expression<Bool>("showLeftDrawerImages")
    let navigationBarImage = Expression<String>("navigationBarImage")
    let showLineAtLeftDrawer = Expression<Bool>("showLineAtLeftDrawer")
    let leftDrawerLineColor = Expression<String?>("leftDrawerLineColor")
    let leftDrawerImageUrl = Expression<String>("leftDrawerImageUrl")
    let topPadding = Expression<Int?>("topPadding")
    let leftDrawerShadowColor = Expression<String?>("leftDrawerShadowColor")
    let titleStyle = Expression<Int?>("titleStyle")
    let backgroundImageUrl = Expression<String?>("backgroundImageUrl")
    var defaultTabID = Expression<Int?>("defaultTabID")
    
    //LeftDrawerTabs columns
    let id = Expression<Int>("id")
    let name = Expression<String?>("name")
    let image = Expression<String?>("image")
    let type = Expression<Int?>("type")
    let isChild = Expression<Bool?>("isChild")
    let isParent = Expression<Bool?>("isParent")
    let storyboardName = Expression<String?>("storyboardName")
    let viewID = Expression<String?>("viewID")
    let showAtTabBar = Expression<Bool>("showAtTabBar")
    let separatorHeight = Expression<Int?>("separatorHeight")
    let separatorColor = Expression<String?>("separatorColor")
    let leftDrawerTabLink = Expression<String?>("leftDrawerTabLink")
    let isVissible = Expression<Bool>("isVissible")
    let borderColor = Expression<String?>("borderColor")
    let borderSize = Expression<Int?>("borderSize")
    let needsUserRegistration = Expression<Bool?>("needsUserRegistration")
    let tabType = Expression<Int?>("tabType")
    let hasBackgroundImage = Expression<Bool?>("hasBackgroundImage")
    
    //Styles columns
    let backgroundColor = Expression<String>("backgroundColor")
    let textColor = Expression<String>("textColor")
    let font = Expression<String>("font")
    let selectedColor = Expression<String?>("selectedColor")
    let tintColor = Expression<String>("tintColor")
    let bold = Expression<Bool>("bold")
    let italic = Expression<Bool>("italic")
    let textSize = Expression<Double>("textSize")
    let lineColor = Expression<String>("lineColor")
    
    //pcRelations columns
    let parentID = Expression<Int>("parentID")
    let childID = Expression<Int>("childID")
    
    //left drawer bar image
    let leftDrawerImage = Expression<Data>("leftDrawerImage")
    
    //navigation bar image
    let navImage = Expression<Data>("navImage")
    
    //background image
    let backgroundImage = Expression<Data>("backgroundImage")
    
    //social media
    let index = Expression<Int>("index")
    let link = Expression<String>("link")
    let socialMediaType = Expression<Int>("socialMediaType")
    
    //splash view parameters
    let logo = Expression<String>("logo")
    let time = Expression<Int>("time")
    
    var startDate = Expression<Date>("startDate")
    var endDate = Expression<Date>("endDate")
    var imageData = Expression<Data>("imageData")
    
    var acceptNotifications = Expression<Bool>("acceptNotifications")
    var acceptLocation = Expression<Bool>("acceptLocation")
    
    
    var lock = NSObject()
    var version = 5
    
    override init(){
        do{
            let documentDirectory = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let fileUrl = documentDirectory.appendingPathComponent(Parameterization.DATABASE_NAME).appendingPathExtension("sqlite3")
            self.database = try Connection(fileUrl.path)
            //self.createTables()
        } catch {
            print(error)
        }
    }
    
    
    
    /*********************************************************                  UPGRADE                  *********************************************************/
    
    
    /// Checks if database need to be upgraded, and upgrade it if needed.
    func checkForUpgrade()
    {
        objc_sync_enter(lock)
        createTables()
        
        switch database.userVersion {
        case 0:
            upgradeToVersion1()
            
            do
            {
                print(try database.exists(column: "borderColor", in:"LeftDrawerTabs"))
                print(try database.exists(column: "borderSize", in: "LeftDrawerTabs"))
                
                if (try !database.exists(column: "apk", in: "LeftDrawerTabs"))
                {
                    dropTables()
                    createTables()
                }
            }
            catch
            {}
            
        case 1:
            upgradeToVersion2()
        case 2:
            upgradeToVersion3()
        case 3:
            upgradeToVersion4()
        case 4:
            upgradeToVersion5()
        default:
            break
        }
        
        
        objc_sync_exit(lock)
        database.userVersion = version
    }
    
    /// Upgrade database to version 1.
    func upgradeToVersion1()
    {
        do
        {
            try database.run(self.leftDrawerTabsTable.addColumn(self.borderColor))
            try database.run(self.leftDrawerTabsTable.addColumn(self.borderSize))
        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion2()
    }
    
    
    /// Upgrade database to version 2.
    func upgradeToVersion2()
    {
        do
        {
            try database.run(self.themeTable.addColumn(self.titleStyle))
            try database.run(self.themeTable.addColumn(self.topPadding))
            try database.run(self.themeTable.addColumn(self.leftDrawerShadowColor))
            try database.run(self.leftDrawerTabsTable.addColumn(self.needsUserRegistration))
        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion3()
    }
    
    /// Upgrade database to version 3.
    func upgradeToVersion3()
    {
        do
        {
            try database.run(self.leftDrawerTabsTable.addColumn(self.hasBackgroundImage))
            try database.run(self.leftDrawerTabsTable.addColumn(self.tabType))
            
            try database.run(self.leftDrawerStyleTable.addColumn(self.topPadding))
            
            try database.run(self.themeTable.addColumn(self.backgroundImageUrl))
        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion4()
    }
    

    /// Upgrade database to version 4.
    func upgradeToVersion4()
    {
        do
        {
            
            do {
                try self.database.prepare("CREATE TABLE t1_backup(apk, parentID, childID);").run()
                try self.database.prepare("INSERT INTO t1_backup(apk, parentID, childID) SELECT apk, parentID, childID FROM PCRelations;").run()
                try self.database.prepare("DROP TABLE PCRelations;").run()
                try self.database.prepare("CREATE TABLE PCRelations(apk, parentID, childID, PRIMARY KEY(apk, parentID, childID )); ").run()
                try self.database.prepare("INSERT INTO PCRelations(apk, parentID, childID) SELECT apk, parentID, childID FROM t1_backup;").run()
                try self.database.prepare("DROP TABLE t1_backup;").run()
            } catch
            {
                print(error)
            }
            
            try database.run(self.themeTable.addColumn(self.defaultTabID))
        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion5()
    }
    
    func upgradeToVersion5()
    {
        do
        {
            try database.run(self.signupBonusTablle.addColumn(self.image))
        }
        catch
        {
            print(error)
        }
    }
    
    
    /// Checks if border color column is added.
    ///
    /// - Parameter apk: The APK.
    /// - Returns: True if border color column is added, otherwise false.
    func isBorderAdded(apk : String) -> Bool!
    {
        var result = true
        do
        {
            let leftDrawerTabs = try self.database.prepare(self.leftDrawerTabsTable.filter(self.apk == apk ))
            
            for l in leftDrawerTabs
            {
                if(l[self.borderColor] != nil )
                {
                    objc_sync_exit(lock)
                    return true
                }
                result = false
            }
        }
        catch{}
        
        objc_sync_exit(lock)
        return result
    }
    
    
    /*********************************************************                  CREATES                  *********************************************************/
    
    /// Creates the paremeterization database tables.
    func createTables()
    {
        objc_sync_enter(lock)
        createThemeTable()
        createAPKUserPreferences()
        createLeftDrawerTabsTable()
        createLeftDrawerStyleTable()
        createLeftDrawerChildStyleTable()
        createTabBarStyleTable()
        createToastStyleTable()
        createDialogStyleTable()
        createPCRelationsTable()
        createImagesTables()
        createSocialMediaTable()
        createSplashViewParametersTable()
        createSignupBonusTablle()
        objc_sync_exit(lock)
    }
    
    
    /// Create theme table.
    func createThemeTable()
    {
        let createThemeTable = self.themeTable.create { (table) in
            table.column(self.apk, primaryKey : true)
            table.column(self.leftDrawerStyle)
            table.column(self.leftDrawerChildStyle)
            table.column(self.tabBarStyle)
            table.column(self.toastStyle)
            table.column(self.dialogStyle)
            table.column(self.navigationBarColor)
            table.column(self.statusBarColor)
            table.column(self.navigationBarTintColor)
            table.column(self.showLeftDrawerImages)
            table.column(self.navigationBarImage)
            table.column(self.showLineAtLeftDrawer)
            table.column(self.leftDrawerLineColor)
            table.column(self.leftDrawerImageUrl)
            table.column(self.topPadding)
            table.column(self.leftDrawerShadowColor)
            table.column(self.titleStyle)
            table.column(self.backgroundImageUrl)
            table.column(self.defaultTabID)
        }
        
        do {
            try self.database.run(createThemeTable)
        } catch {
            print(error)
        }
    }
    
    func createAPKUserPreferences()
    {
        let createAPKUserPreferences = self.apkUserPreferences.create { (table) in
            table.column(self.apk, primaryKey : true)
            table.column(self.acceptNotifications)
            table.column(self.acceptLocation)
        }
        
        do {
            try self.database.run(createAPKUserPreferences)
        } catch {
            print(error)
        }
    }
    
    /// Create left drawer tabs table.
    func createLeftDrawerTabsTable()
    {
        let createLeftDrawerTabsTable = self.leftDrawerTabsTable.create { (table) in
            table.column(self.apk)
            table.column(self.id)
            table.column(self.name)
            table.column(self.image)
            table.column(self.type)
            table.column(self.parentID)
            table.column(self.isChild)
            table.column(self.isParent)
            table.column(self.storyboardName)
            table.column(self.viewID)
            table.column(self.showAtTabBar)
            table.column(self.separatorHeight)
            table.column(self.separatorColor)
            table.column(self.leftDrawerTabLink)
            table.column(self.isVissible)
            table.column(self.borderColor)
            table.column(self.borderSize)
            table.column(self.needsUserRegistration)
            table.column(self.tabType)
            table.column(self.hasBackgroundImage)
            
            table.primaryKey(self.apk,self.id)
        }
        
        do {
            try self.database.run(createLeftDrawerTabsTable)
        } catch {
            print(error)
        }
    }
    
    
    /// Create left drawer style table.
    func createLeftDrawerStyleTable()
    {
        let createLeftDrawerStyleTable = self.leftDrawerStyleTable.create { (table) in
            table.column(self.apk)
            table.column(self.id)
            table.column(self.backgroundColor)
            table.column(self.textColor)
            table.column(self.font)
            table.column(self.selectedColor)
            table.column(self.tintColor)
            table.column(self.bold)
            table.column(self.italic)
            table.column(self.textSize)
            table.column(self.topPadding)
            
            table.primaryKey(self.apk,self.id)
        }
        
        do {
            try self.database.run(createLeftDrawerStyleTable)
        } catch {
            print(error)
        }
    }
    
    
    /// Create left drawer child style table.
    func createLeftDrawerChildStyleTable()
    {
        let createLeftDrawerChildStyleTable = self.leftDrawerChildStyleTable.create { (table) in
            table.column(self.apk)
            table.column(self.id)
            table.column(self.backgroundColor)
            table.column(self.textColor)
            table.column(self.font)
            table.column(self.selectedColor)
            table.column(self.tintColor)
            table.column(self.bold)
            table.column(self.italic)
            table.column(self.textSize)
            
            table.primaryKey(self.apk,self.id)
        }
        
        do {
            try self.database.run(createLeftDrawerChildStyleTable)
        } catch {
            print(error)
        }
    }
    
    
    /// Create tab bar style table.
    func createTabBarStyleTable()
    {
        let createTabBarStyleTable = self.tabBarStyleTable.create { (table) in
            table.column(self.apk)
            table.column(self.id)
            table.column(self.backgroundColor)
            table.column(self.textColor)
            table.column(self.font)
            table.column(self.selectedColor)
            table.column(self.tintColor)
            table.column(self.textSize)
            
            table.primaryKey(self.apk,self.id)
        }
        
        do {
            try self.database.run(createTabBarStyleTable)
        } catch {
            print(error)
        }
    }
    
    
    /// Create toast style table.
    func createToastStyleTable()
    {
        let createToastStyleTable = self.toastStyleTable.create { (table) in
            table.column(self.apk)
            table.column(self.id)
            table.column(self.backgroundColor)
            table.column(self.textColor)
            table.column(self.font)
            table.column(self.tintColor)
            table.column(self.textSize)
            
            table.primaryKey(self.apk,self.id)
        }
        
        do {
            try self.database.run(createToastStyleTable)
        } catch {
            print(error)
        }
    }
    
    
    /// Create dialog style table.
    func createDialogStyleTable()
    {
        let createDialogStyleTable = self.dialogStyleTable.create { (table) in
            table.column(self.apk)
            table.column(self.id)
            table.column(self.backgroundColor)
            table.column(self.textColor)
            table.column(self.font)
            table.column(self.selectedColor)
            table.column(self.tintColor)
            table.column(self.lineColor)
            table.column(self.textSize)
            
            table.primaryKey(self.apk,self.id)
        }
        
        do {
            try self.database.run(createDialogStyleTable)
        } catch {
            print(error)
        }
    }
    
    
    /// Create relations table.
    func createPCRelationsTable()
    {
        let createPCRelationsTable = self.pcRelationsTable.create { (table) in
            table.column(self.apk)
            table.column(self.parentID)
            table.column(self.childID)
            
            table.primaryKey(self.apk, self.parentID, self.childID)
        }
        
        do {
            try self.database.run(createPCRelationsTable)
        } catch {
            print(error)
        }
    }
    
    
    /// Create images table.
    func createImagesTables()
    {
        let createLeftDrawerImageTable = self.leftDrawerImageTable.create { (table) in
            table.column(self.apk)
            table.column(self.leftDrawerImage)
        }
        
        do {
            try self.database.run(createLeftDrawerImageTable)
        } catch {
            print(error)
        }
        
        let createNavImageTable = self.navImageTable.create { (table) in
            table.column(self.apk)
            table.column(self.navImage)
        }
        
        do {
            try self.database.run(createNavImageTable)
        } catch {
            print(error)
        }
        
        let createBackgroundImageTable = self.backgroundImageTable.create { (table) in
            table.column(self.apk)
            table.column(self.backgroundImage)
        }
        
        do {
            try self.database.run(createBackgroundImageTable)
        } catch {
            print(error)
        }
    }
    
    /// Create social media table.
    func createSocialMediaTable()
    {
        let createSocialMediaTable = self.socialMediaTable.create { (table) in
            table.column(self.apk)
            table.column(self.index)
            table.column(self.socialMediaType)
            table.column(self.link)
            
            table.primaryKey(self.apk,self.index)
        }
        
        do {
            try self.database.run(createSocialMediaTable)
        } catch {
            print(error)
        }
    }
    
    func createSplashViewParametersTable()
    {
        let createSplashViewParametersTable = self.splashViewParametersTable.create { (table) in
            table.column(self.apk, primaryKey : true)
            table.column(self.backgroundColor)
            table.column(self.logo)
            table.column(self.time)
            table.column(self.textColor)
            table.column(self.font)
        }
        
        do {
            try self.database.run(createSplashViewParametersTable)
        } catch {
            print(error)
        }
    }
    
    func createSignupBonusTablle()
    {
        let createSignupBonusTablle = self.signupBonusTablle.create { (table) in
            table.column(self.apk, primaryKey : true)
            table.column(self.image)
            table.column(self.imageData)
            table.column(self.startDate)
            table.column(self.endDate)
        }
        
        do {
            try self.database.run(createSignupBonusTablle)
        } catch {
            print(error)
        }
    }
    
    /// Checks if apk paramaters are saved.
    ///
    /// - Parameter apk: The apk we want to check.
    /// - Returns: True if apk paramaters are saved, otherwise false.
    func isAPKSaved(apk : String) -> Bool
    {
        objc_sync_enter(lock)
        do {
            let leftDrawerTabs = try self.database.prepare(self.leftDrawerTabsTable)
            for l in leftDrawerTabs {
                if(apk == l[self.apk])
                {
                    objc_sync_exit(lock)
                    return true
                }
            }
        } catch {
            print(error)
        }
        
        objc_sync_exit(lock)
        return false
    }
    
    /// Checks if apk paramaters are saved.
    ///
    /// - Parameter apk: The apk we want to check.
    /// - Returns: True if apk paramaters are saved, otherwise false.
    func isAPKSaved2(apk : String) -> Bool
    {
        objc_sync_enter(lock)
        do {
            let themes = try self.database.prepare(self.themeTable)
            
            for t in themes {
                if(apk == t[self.apk])
                {
                    objc_sync_exit(lock)
                    return true
                }
            }
        } catch {
            print(error)
        }
        
        objc_sync_exit(lock)
        return false
    }
    
    /// Drop all tables.
    func dropTables()
    {
        objc_sync_enter(lock)
        do
        {
            let dropTheme = self.themeTable.drop()
            try self.database.run(dropTheme)
        }
        catch
        {
        }
        

        
        do
        {
            let dropLeftDrawerTabs = self.leftDrawerTabsTable.drop()
            try self.database.run(dropLeftDrawerTabs)
        }
        catch
        {
        }
        
        do
        {
            let dropLeftDrawerStyle = self.leftDrawerStyleTable.drop()
            try self.database.run(dropLeftDrawerStyle)
        }
        catch
        {
        }
        
        do
        {
            let dropLeftDrawerChildStyle = self.leftDrawerChildStyleTable.drop()
            try self.database.run(dropLeftDrawerChildStyle)
        }
        catch
        {
        }
        
        do
        {
            let dropTabBarStyle = self.tabBarStyleTable.drop()
            try self.database.run(dropTabBarStyle)
        }
        catch
        {
        }
        
        do
        {
            let dropToastStyle = self.toastStyleTable.drop()
            try self.database.run(dropToastStyle)
        }
        catch
        {
        }
        
        do
        {
            let dropDialogStyle = self.dialogStyleTable.drop()
            try self.database.run(dropDialogStyle)
        }
        catch
        {
        }
        
        
        do
        {
            let dropRelations = self.pcRelationsTable.drop()
            try self.database.run(dropRelations)
        }
        catch
        {
        }
        
        do
        {
            let dropNavImage = self.navImageTable.drop()
            try self.database.run(dropNavImage)
        }
        catch
        {
        }
        
        do
        {
            let dropLeftDrawerImage = self.leftDrawerImageTable.drop()
            try self.database.run(dropLeftDrawerImage)
        }
        catch
        {
        }
        objc_sync_exit(lock)
    }
    
    
    /// Deletes all entries from all tables.
    func deleteEntries2()
    {
        objc_sync_enter(lock)
        
        let deleteTheme = self.themeTable.delete()
        
        let deleteStyles1 = self.leftDrawerStyleTable.delete()
        
        let deleteStyles2 = self.leftDrawerChildStyleTable.delete()
        
        let deleteStyles3 = self.tabBarStyleTable.delete()
        
        let deleteStyles4 = self.toastStyleTable.delete()
        
        let deleteStyles5 = self.dialogStyleTable.delete()
        
        let deleteLeftDrawerImage = self.leftDrawerImageTable.delete()
        
        let deleteNavigationBarImage = self.navImageTable.delete()
        
        do{
            try self.database.run(deleteTheme)
        } catch {
            print(error)
        }
        
        do{
            try self.database.run(deleteStyles1)
        } catch {
            print(error)
        }
        
        do{
            try self.database.run(deleteStyles2)
        } catch {
            print(error)
        }
        
        do{
            try self.database.run(deleteStyles3)
        } catch {
            print(error)
        }
        
        do{
            try self.database.run(deleteStyles4)
        } catch {
            print(error)
        }
        
        do{
            try self.database.run(deleteStyles5)
        } catch {
            print(error)
        }
        
        let leftDrawerTabs = self.leftDrawerTabsTable
        let deleteLeftDrawerTabs = leftDrawerTabs.delete()
        
        do{
            try self.database.run(deleteLeftDrawerTabs)
        } catch {
            print(error)
        }
        
        let relations = self.pcRelationsTable
        let deleteRelations = relations.delete()
        
        do{
            try self.database.run(deleteRelations)
        } catch {
            print(error)
        }
        
        do{
            try self.database.run(deleteLeftDrawerImage)
        } catch {
            print(error)
        }
        
        do{
            try self.database.run(deleteNavigationBarImage)
        } catch {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    /*********************************************************                  INSERTS                  *********************************************************/
    
    /// Insert new theme to theme table.
    ///
    /// - Parameter theme: The theme.
    func insertTheme(theme : Theme!)
    {
        objc_sync_enter(lock)
        if(theme != nil)
        {
            do {
                let insertTheme = self.themeTable.insert(or: .replace,
                                                         self.apk <- APK,
                                                         self.leftDrawerStyle <- theme.leftDrawerStyle,
                                                         self.leftDrawerChildStyle <- theme.leftDrawerChildStyle ,
                                                         self.tabBarStyle <- theme.tabBarStyle,
                                                         self.toastStyle <- theme.toastStyle,
                                                         self.dialogStyle <- theme.dialogsStyle,
                                                         self.navigationBarColor <- theme.navigationBarColor,
                                                         self.statusBarColor <- theme.statusBarColor,
                                                         self.navigationBarTintColor <- theme.navigationBarTintColor,
                                                         self.showLeftDrawerImages <- theme.showLeftDrawerImages,
                                                         self.navigationBarImage <- theme.navigationBarImage,
                                                         self.showLineAtLeftDrawer <- theme.showLeftDrawerLines,
                                                         self.leftDrawerLineColor <- theme.leftDrawerLineColor,
                                                         self.leftDrawerImageUrl <- theme.leftDrawerImage,
                                                         self.topPadding <- theme.topPadding,
                                                         self.leftDrawerShadowColor <- theme.leftDrawerShadowColor,
                                                         self.titleStyle <- theme.titleStyle,
                                                         self.backgroundImageUrl <- theme.backgroundImageUrl,
                                                         self.defaultTabID <- theme.defaultTabID)
                
                if( theme.titleStyle != nil && theme.titleStyleModel != nil)
                {
                    viewsDB.insertTitle(id: theme.titleStyle, title: theme.titleStyleModel)
                }
                
                try self.database.run(insertTheme)
                print("Theme added")
            }
            catch
            {
                print(error)
            }
        }
        
        objc_sync_exit(lock)
    }

    func insertAPKUserPreferences(apkUserPreferences : APKUserPreferences)
    {
        objc_sync_enter(lock)
        if(apkUserPreferences != nil)
        {
            do {
                let insertAPKUserPreferences = self.apkUserPreferences.insert(or: .replace,
                                                         self.apk <- APK,
                                                         self.acceptNotifications <- apkUserPreferences.acceptNotifications,
                                                         self.acceptLocation <- apkUserPreferences.acceptLocation)
                
                try self.database.run(insertAPKUserPreferences)
                print("APK User Preferences added")
            }
            catch
            {
                print(error)
            }
        }
        
        objc_sync_exit(lock)
    }
    
    /// Insert left drawer tabs to left drawer tabs table.
    ///
    /// - Parameter tabs: Left drawer tabs.
    func insertLeftDrawerTabs(tabs : [Tab]!)
    {
        objc_sync_enter(lock)
        if(tabs != nil)
        {
            for t in tabs
            {
                do {
                    let insertLeftDrawerTabs = self.leftDrawerTabsTable.insert(or: .replace,
                                                                               self.apk <- APK,
                                                                               self.id <- t.id,
                                                                               self.name <- t.name,
                                                                               self.image <- t.image,
                                                                               self.type <- t.type,
                                                                               self.parentID <- t.parentID,
                                                                               self.isChild <- t.isChild,
                                                                               self.isParent <- t.isParent,
                                                                               self.storyboardName <- t.storyboardName,
                                                                               self.viewID <- t.viewID,
                                                                               self.showAtTabBar <- t.showAtTabbar,
                                                                               self.separatorHeight <- t.separatorHeight,
                                                                               self.separatorColor <- t.separatorColor,
                                                                               self.leftDrawerTabLink <- t.link,
                                                                               self.isVissible <- t.isVissible,
                                                                               self.borderColor <- t.borderColor,
                                                                               self.borderSize <- t.borderSize,
                                                                               self.needsUserRegistration <- t.needsUserRegistration,
                                                                               self.tabType <- t.tabType,
                                                                               self.hasBackgroundImage <- t.hasBackgroundImage)
                    
                    try self.database.run(insertLeftDrawerTabs)
                    print("Left drawer tab added")
                }
                catch
                {
                    print(error)
                }
            }
            
            objc_sync_exit(lock)
            return
        }
        
        objc_sync_exit(lock)
    }
    
    
    /// Update left drawer tab visibility.
    ///
    /// - Parameter tab: The tab we want to change visibility.
    func updateLeftDrawerTab(tab : Tab)
    {
        objc_sync_enter(lock)
        do{
            let tabRow = self.leftDrawerTabsTable.filter(self.apk == APK && self.id == tab.id )
            let updateTab = tabRow.update(self.isVissible <- tab.isVissible)
            
            try self.database.run(updateTab)
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    
    /// Insert styles to styles table.
    ///
    /// - Parameter styles: The styles.
    func insertStyles(styles : Styles!)
    {
        objc_sync_enter(lock)
        if(styles != nil)
        {
            var s = styles.leftDrawerStyle[0]
            
            do {
                let insertStyle = self.leftDrawerStyleTable.insert(or: .replace,
                                                                   self.apk <- APK,
                                                                   self.id <- s.id,
                                                                   self.backgroundColor <- s.backgroundColor,
                                                                   self.textColor <- s.textColor,
                                                                   self.font <- correctFontString(s: s.font),
                                                                   self.selectedColor <- s.selectedColor,
                                                                   self.tintColor <- s.tintColor,
                                                                   self.bold <- s.bold,
                                                                   self.italic <- s.italic,
                                                                   self.textSize <- Double(s.textSize),
                                                                   self.topPadding <- s.topPadding)
                
                try self.database.run(insertStyle)
                print("Style added")
            }
            catch
            {
                print(error)
            }
            
            s = styles.leftDrawerChildStyle[0]
            
            do {
                let insertStyle = self.leftDrawerChildStyleTable.insert(or: .replace,
                                                                        self.apk <- APK,
                                                                        self.id <- s.id,
                                                                        self.backgroundColor <- s.backgroundColor,
                                                                        self.textColor <- s.textColor,
                                                                        self.font <- correctFontString(s: s.font),
                                                                        self.selectedColor <- s.selectedColor,
                                                                        self.tintColor <- s.tintColor,
                                                                        self.bold <- s.bold,
                                                                        self.italic <- s.italic,
                                                                        self.textSize <- Double(s.textSize))
                
                try self.database.run(insertStyle)
                print("Style added")
            }
            catch
            {
                print(error)
            }
            
            s = styles.tabBarStyle[0]
            
            do {
                let insertStyle = self.tabBarStyleTable.insert(or: .replace,
                                                               self.apk <- APK,
                                                               self.id <- s.id,
                                                               self.backgroundColor <- s.backgroundColor,
                                                               self.textColor <- s.textColor,
                                                               self.font <- correctFontString(s: s.font),
                                                               self.selectedColor <- s.selectedColor,
                                                               self.tintColor <- s.tintColor,
                                                               self.textSize <- Double(s.textSize))
                
                try self.database.run(insertStyle)
                print("Style added")
            }
            catch
            {
                print(error)
            }
            
            s = styles.toastStyle[0]
            
            do {
                let insertStyle = self.toastStyleTable.insert(or: .replace,
                                                              self.apk <- APK,
                                                              self.id <- s.id,
                                                              self.backgroundColor <- s.backgroundColor,
                                                              self.textColor <- s.textColor,
                                                              self.font <- correctFontString(s: s.font),
                                                              self.tintColor <- s.tintColor,
                                                              self.textSize <- Double(s.textSize))
                
                try self.database.run(insertStyle)
                print("Style added")
            }
            catch
            {
                print(error)
            }
            
            s = styles.dialogStyle[0]
            
            do {
                let insertStyle = self.dialogStyleTable.insert(or: .replace,
                                                               self.apk <- APK,
                                                               self.id <- s.id,
                                                               self.backgroundColor <- s.backgroundColor,
                                                               self.textColor <- s.textColor,
                                                               self.font <- correctFontString(s: s.font),
                                                               self.selectedColor <- s.selectedColor,
                                                               self.tintColor <- s.tintColor,
                                                               self.textSize <- Double(s.textSize),
                                                               self.lineColor <- s.lineColor)
                
                try self.database.run(insertStyle)
                print("Style added")
            }
            catch
            {
                print(error)
            }
            
            objc_sync_exit(lock)
        }
        else
        {
            objc_sync_exit(lock)
        }
    }
    
    /// Insert relations to relations table.
    ///
    /// - Parameter relations: The relations.
    func insertPCRelations(relations : [PCRelation]!)
    {
        objc_sync_enter(lock)
        if(relations != nil)
        {
            for r in relations
            {
                do {
                    let insertPCRelations = self.pcRelationsTable.insert(or: .replace,
                                                                         self.apk <- APK,
                                                                         self.parentID <- r.parentID,
                                                                         self.childID <- r.childID)
                    
                    try self.database.run(insertPCRelations)
                    print("Relation added")
                }
                catch
                {
                    print(error)
                }
            }
        }
        
        objc_sync_exit(lock)
    }
    
    /// Inserts navigation image.
    ///
    /// - Parameter str: The data of navigations image.
    func insertNavImage(str : Data )
    {
        objc_sync_enter(lock)
        if(str != nil)
        {
            do {
                let insertNavImage = self.navImageTable.insert(or: .replace,
                                                               self.apk <- APK,
                                                               self.navImage <- str)
                
                try self.database.run(insertNavImage)
                print("Navigation image added")
            }
            catch
            {
                print(error)
            }
            
        }
        objc_sync_exit(lock)
    }
    
    /// Inserts left drawer image.
    ///
    /// - Parameter str: The data of left drawer image.
    func insertLeftDrawerImage(str : Data )
    {
        objc_sync_enter(lock)
        if(str != nil)
        {
            do {
                let insertLeftDrawerImage = self.leftDrawerImageTable.insert(or: .replace,
                                                                             self.apk <- APK,
                                                                             self.leftDrawerImage <- str)
                
                try self.database.run(insertLeftDrawerImage)
                print("Left drawer image added")
            }
            catch
            {
                print(error)
            }
            
        }
        objc_sync_exit(lock)
    }
    
    /// Inserts left drawer image.
    ///
    /// - Parameter str: The data of left drawer image.
    func insertBackgroundImage(str : Data )
    {
        objc_sync_enter(lock)
        if(str != nil)
        {
            do {
                let insertBackgroundImage = self.backgroundImageTable.insert(or: .replace,
                                                                             self.apk <- APK,
                                                                             self.backgroundImage <- str)
                
                try self.database.run(insertBackgroundImage)
                print("Background image added")
            }
            catch
            {
                print(error)
            }
            
        }
        objc_sync_exit(lock)
    }
    
    
    
    /// Insert social media tab.
    ///
    /// - Parameter socialMedia: Social media tab model.
    func insertSocialMedia(socialMedia : [SocialMediaModel]!)
    {
        objc_sync_enter(lock)
        if(socialMedia != nil)
        {
            do {
                for s in socialMedia
                {
                    let insertSocialMedia = self.socialMediaTable.insert(or: .replace,
                                                                         self.apk <- APK,
                                                                         self.index <- s.index,
                                                                         self.socialMediaType <- s.type,
                                                                         self.link <- s.link)
                    
                    do {
                        try self.database.run(insertSocialMedia)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    print("Social media added")
                }
            }
            catch
            {
                print(error)
            }
            
        }
        objc_sync_exit(lock)
    }
    
    func insertSplashViewParameters(splashViewParameters : SplashViewParametersModel!)
    {
        objc_sync_enter(lock)
        do
        {
            if(splashViewParameters != nil)
            {
                
                let inserSplashViewParameters = self.splashViewParametersTable.insert(or: .replace,
                                                                                      self.apk <- APK,
                                                                                      self.backgroundColor <- splashViewParameters.backgroundColor,
                                                                                      self.logo <- splashViewParameters.logo,
                                                                                      self.time <- splashViewParameters.time,
                                                                                      self.textColor <- splashViewParameters.textColor,
                                                                                      self.font <- splashViewParameters.font)
                
                try self.database.run(inserSplashViewParameters)
                
                print("Splash view parameters added")
                
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertSignupBonus(signupBonus : SignupBonusModel!) throws
    {
        objc_sync_enter(lock)
        do
        {
            if(signupBonus != nil)
            {
                let dateFormatter = DateFormatter()
                dateFormatter.locale = Locale.current
                dateFormatter.dateFormat = "yyyy-MM-dd"
                
                
                var startDate = dateFormatter.date(from: signupBonus.startDateString)
                startDate!.addTimeInterval(60 * 60 * 2)
                var endDate = dateFormatter.date(from: signupBonus.endDateString)
                endDate!.addTimeInterval(60 * 60 * 2)
                
                let imageData : Data! = ImageDownloader.downloadImage(url: signupBonus.image)
                
                let insertSignupBonus = self.signupBonusTablle.insert(or: .replace,
                                                                            self.apk <- APK,
                                                                            self.startDate <- startDate!,
                                                                            self.endDate <- endDate!,
                                                                            self.image <- signupBonus.image,
                                                                            self.imageData <- imageData != nil ? imageData! : Data())
                
                try self.database.run(insertSignupBonus)
                
                print("Sign up bonus added")
                
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        
        if(signupBonus != nil && ImageDownloader.errorOccured && !isNullOrEmpty(string: signupBonus.image))
        {
            ImageDownloader.errorOccured = false
            throw Errors.error
        }
    }
    
    
    /*********************************************************                  GETS                  *********************************************************/
    
    /// Returns the saved theme.
    ///
    /// - Returns: The theme.
    func getTheme(apk : String) -> Theme!
    {
        objc_sync_enter(lock)
        do {
            let themes = try self.database.prepare(self.themeTable.filter(self.apk == apk))
            
            for t in themes {
                let theme = Theme()
                
                theme.leftDrawerStyle = t[self.leftDrawerStyle]
                theme.leftDrawerChildStyle = t[self.leftDrawerChildStyle]
                theme.tabBarStyle = t[self.tabBarStyle]
                theme.toastStyle = t[self.toastStyle]
                theme.dialogsStyle = t[self.dialogStyle]
                theme.navigationBarColor = t[self.navigationBarColor]
                theme.statusBarColor = t[self.statusBarColor]
                theme.navigationBarTintColor = t[self.navigationBarTintColor]
                theme.showLeftDrawerImages = t[self.showLeftDrawerImages]
                theme.navigationBarImage = t[self.navigationBarImage]
                theme.showLeftDrawerLines = t[self.showLineAtLeftDrawer]
                theme.leftDrawerLineColor = t[self.leftDrawerLineColor]
                theme.leftDrawerImage = t[self.leftDrawerImageUrl]
                theme.topPadding = t[self.topPadding]
                theme.leftDrawerShadowColor = t[self.leftDrawerShadowColor]
                theme.titleStyle = t[self.titleStyle]
                theme.backgroundImageUrl = t[self.backgroundImageUrl]
                theme.defaultTabID = t[self.defaultTabID]
                
                objc_sync_exit(lock)
                return theme
            }
        } catch {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    
    func getAPKUserPreferences(apk : String) -> APKUserPreferences!
    {
        objc_sync_enter(lock)
        do {
            let apkUserPreferences = try self.database.prepare(self.apkUserPreferences.filter(self.apk == apk))
            
            for a in apkUserPreferences {
                let apkUserPreferencesModel = APKUserPreferences()
                
                apkUserPreferencesModel.acceptNotifications = a[self.acceptNotifications] == nil ? false : a[self.acceptNotifications]
                apkUserPreferencesModel.acceptLocation = a[self.acceptLocation] == nil ? false : a[self.acceptLocation]

                objc_sync_exit(lock)
                return apkUserPreferencesModel
            }
        } catch {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    
    /// Returns the saved left drawer tabs.
    ///
    /// - Returns: The left drawer tabs.
    func getLeftDrawerTabs(apk : String) -> [Tab]!
    {
        var leftDrawerTabs : [Tab] = []
        
        objc_sync_enter(lock)
        do {
            let dbLeftDrawerTabs = try self.database.prepare(self.leftDrawerTabsTable.filter(self.apk == APK))
            
            for d in dbLeftDrawerTabs {
                let tab = Tab()
                
                tab.id = d[self.id]
                tab.name = d[self.name]
                tab.image = d[self.image]
                tab.type = d[self.type]
                tab.parentID = d[self.parentID]
                tab.isChild = d[self.isChild]!
                tab.isParent = d[self.isParent]!
                tab.storyboardName = d[self.storyboardName]
                tab.viewID = d[self.viewID]
                tab.showAtTabbar = d[self.showAtTabBar]
                tab.separatorHeight = d[self.separatorHeight]
                tab.separatorColor = d[self.separatorColor]
                tab.link = d[self.leftDrawerTabLink]
                tab.isVissible = d[self.isVissible]
                tab.borderColor = d[self.borderColor]
                tab.borderSize = d[self.borderSize]
                tab.needsUserRegistration = d[self.needsUserRegistration]
                tab.tabType = d[self.tabType]
                tab.hasBackgroundImage = d[self.hasBackgroundImage]
                
                leftDrawerTabs.append(tab)
            }
            
            objc_sync_exit(lock)
            return leftDrawerTabs
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    
    
    
    /// Returns the saved left drawer style.
    ///
    /// - Returns: The left drawer style.
    func getLeftDrawerStyle(apk : String, id : Int) -> Style!
    {
        
        objc_sync_enter(lock)
        do {
            let dbStyle = try self.database.prepare(self.leftDrawerStyleTable.filter(self.apk == APK && self.id == id ))
            
            for d in dbStyle {
                let style = Style()
                
                style.id = d[self.id]
                style.backgroundColor = d[self.backgroundColor]
                style.textColor = d[self.textColor]
                style.font = d[self.font]
                style.selectedColor = d[self.selectedColor]
                style.tintColor = d[self.tintColor]
                style.bold = d[self.bold]
                style.italic = d[self.italic]
                style.textSize = Float(d[self.textSize])
                style.topPadding = d[self.topPadding]
                
                objc_sync_exit(lock)
                return style
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    
    /// Returns the saved left drawer child style.
    ///
    /// - Returns: The left drawer child style.
    func getLeftDrawerChildStyle(apk : String, id : Int) -> Style!
    {
        
        objc_sync_enter(lock)
        do {
            let dbStyle = try self.database.prepare(self.leftDrawerChildStyleTable.filter(self.apk == APK && self.id == id ))
            
            for d in dbStyle {
                let style = Style()
                
                style.id = d[self.id]
                style.backgroundColor = d[self.backgroundColor]
                style.textColor = d[self.textColor]
                style.font = d[self.font]
                style.selectedColor = d[self.selectedColor]
                style.tintColor = d[self.tintColor]
                style.bold = d[self.bold]
                style.italic = d[self.italic]
                style.textSize = Float(d[self.textSize])
                
                objc_sync_exit(lock)
                return style
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    /// Returns the saved tab bar style.
    ///
    /// - Returns: The tab bar style.
    func getTabBarStyle(apk : String, id : Int) -> Style!
    {
        
        objc_sync_enter(lock)
        do {
            let dbStyle = try self.database.prepare(self.tabBarStyleTable.filter(self.apk == APK && self.id == id ))
            
            for d in dbStyle {
                let style = Style()
                
                style.id = d[self.id]
                style.backgroundColor = d[self.backgroundColor]
                style.textColor = d[self.textColor]
                style.font = d[self.font]
                style.selectedColor = d[self.selectedColor]
                style.tintColor = d[self.tintColor]
                style.textSize = Float(d[self.textSize])
                
                objc_sync_exit(lock)
                return style
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    /// Returns the saved toast style.
    ///
    /// - Returns: The toast style.
    func getToastStyle(apk : String, id : Int) -> Style!
    {
        
        objc_sync_enter(lock)
        do {
            let dbStyle = try self.database.prepare(self.toastStyleTable.filter(self.apk == APK && self.id == id ))
            
            for d in dbStyle {
                let style = Style()
                
                style.id = d[self.id]
                style.backgroundColor = d[self.backgroundColor]
                style.textColor = d[self.textColor]
                style.font = d[self.font]
                style.tintColor = d[self.tintColor]
                style.textSize = Float(d[self.textSize])
                
                objc_sync_exit(lock)
                return style
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    /// Returns the saved dialog style.
    ///
    /// - Returns: The dialog style.
    func getDialogStyle(apk : String, id : Int) -> Style!
    {
        
        objc_sync_enter(lock)
        do {
            let dbStyle = try self.database.prepare(self.dialogStyleTable.filter(self.apk == APK && self.id == id ))
            
            for d in dbStyle {
                let style = Style()
                
                style.id = d[self.id]
                style.backgroundColor = d[self.backgroundColor]
                style.textColor = d[self.textColor]
                style.font = d[self.font]
                style.selectedColor = d[self.selectedColor]
                style.tintColor = d[self.tintColor]
                style.lineColor = d[self.lineColor]
                style.textSize = Float(d[self.textSize])
                
                objc_sync_exit(lock)
                return style
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    /// Returns the saved title style.
    ///
    /// - Returns: The dialog style.
    func getTitleStyle(apk : String, id : Int) -> TitleModel!
    {
        objc_sync_enter(lock)
        do {
            let titleStyle = viewsDB.getTitle(id: id)
            
            objc_sync_exit(lock)
            return titleStyle
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    
    
    /// Returns the saved relations.
    ///
    /// - Returns: The relations.
    func getPCRelations(apk : String) -> [PCRelation]!
    {
        var relations : [PCRelation] = []
        
        objc_sync_enter(lock)
        do {
            let dbRelations = try self.database.prepare(self.pcRelationsTable)
            
            for d in dbRelations {
                if(apk == d[self.apk])
                {
                    let relation = PCRelation()
                    
                    relation.parentID = d[self.parentID]
                    relation.childID = d[self.childID]
                    relations.append(relation)
                }
            }
            
            objc_sync_exit(lock)
            return relations
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    
    /// Returns the navigation image in data format.
    ///
    /// - Returns: The navigation image.
    func getNavImage(apk : String) -> Data!
    {
        var str : Data
        
        objc_sync_enter(lock)
        do {
            let dbNavImage = try self.database.prepare(self.navImageTable)
            
            for n in dbNavImage {
                if(apk == n[self.apk])
                {
                    str = n[self.navImage]
                    objc_sync_exit(lock)
                    return str
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    /// Returns the left drawer image in data format.
    ///
    /// - Returns: The left drawer image.
    func getLeftDrawerImage(apk : String) -> Data!
    {
        var str : Data
        
        objc_sync_enter(lock)
        do {
            let dbLeftDrawerImage = try self.database.prepare(self.leftDrawerImageTable)
            
            for n in dbLeftDrawerImage {
                if(apk == n[self.apk])
                {
                    str = n[self.leftDrawerImage]
                    objc_sync_exit(lock)
                    return str
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    /// Returns the left drawer image in data format.
    ///
    /// - Returns: The left drawer image.
    func getBackgroundImage(apk : String) -> Data!
    {
        var str : Data
        
        objc_sync_enter(lock)
        do {
            let backgroundImage = try self.database.prepare(self.backgroundImageTable)
            
            for b in backgroundImage {
                if(apk == b[self.apk])
                {
                    str = b[self.backgroundImage]
                    objc_sync_exit(lock)
                    return str
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    
    /// Returns the social media view.
    ///
    /// - Returns: The social media tab model.
    func getSocialMedia() -> [SocialMediaModel]!
    {
        objc_sync_enter(lock)
        do {
            
            var socialMediaModels : [SocialMediaModel] = []
            
            let socialMedias = try self.database.prepare(self.socialMediaTable.filter(self.apk == APK))
            
            for s in socialMedias {
                let socialMediaModel = SocialMediaModel()
                
                socialMediaModel.type = s[self.socialMediaType]
                socialMediaModel.link = s[self.link]
                
                socialMediaModels.append(socialMediaModel)
            }
            objc_sync_exit(lock)
            return socialMediaModels
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getSplashViewParameters() -> SplashViewParametersModel!
    {
        objc_sync_enter(lock)
        do {
            let splashViewParametersModel = SplashViewParametersModel()
            
            let splashViewParameters = try self.database.prepare(self.splashViewParametersTable.filter(self.apk == APK))
            
            for s in splashViewParameters
            {
                splashViewParametersModel.backgroundColor = s[self.backgroundColor]
                splashViewParametersModel.logo = s[self.logo]
                splashViewParametersModel.time = s[self.time]
                splashViewParametersModel.textColor = s[self.textColor]
                splashViewParametersModel.font = s[self.font]
                
                objc_sync_exit(lock)
                return splashViewParametersModel
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getSignupBonus() -> SignupBonusModel!
    {
        objc_sync_enter(lock)
        do {
            let signupBonusModel = SignupBonusModel()
            
            let signupBonus = try self.database.prepare(self.signupBonusTablle.filter(self.apk == APK))
            
            for s in signupBonus
            {
                signupBonusModel.image = s[self.image] == nil ? "" :  s[self.image]
                signupBonusModel.imageData = s[self.imageData]
                signupBonusModel.startDate = s[self.startDate]
                signupBonusModel.endDate = s[self.endDate]
                
                objc_sync_exit(lock)
                return signupBonusModel
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    /*********************************************************                  UPDATES                  *********************************************************/
    
    /// Deletes entries for speicfic APK from left drawer tabs table.
    func deleteEntries(apk : String)
    {
        objc_sync_enter(lock)
        
        if(!statusModel.areLeftDrawerTabsSaved)
        {
            do{
                try self.database.run(self.leftDrawerTabsTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
        
        if(!statusModel.areRelationsSaved)
        {
            do{
                try self.database.run(self.pcRelationsTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
        
        if(!statusModel.areSocialMediaSaved)
        {
            do{
                try self.database.run(self.socialMediaTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
        
        if(!statusModel.isNavImageSaved)
        {
            do{
                try self.database.run(self.navImageTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
        
        if(!statusModel.areSocialMediaSaved)
        {
            do{
                try self.database.run(self.leftDrawerImageTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
        
        objc_sync_exit(lock)
    }
    
    func deleteTheme(apk : String)
    {
        objc_sync_enter(lock)
        let themeToBeDeleted = self.themeTable.filter(self.apk == apk)
        
        do{
            try self.database.run(themeToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    /// Deletes entries for speicfic APK from left drawer tabs table.
    func deleteLeftDrawerTabs(apk : String)
    {
        objc_sync_enter(lock)
        let leftDrawerTabsToBeDeleted = self.leftDrawerTabsTable.filter(self.apk == apk)
        
        do{
            try self.database.run(leftDrawerTabsToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    /// Deletes entries for speicfic APK from relations table.
    func deleteRelations(apk : String)
    {
        objc_sync_enter(lock)
        let relationsToBeDeleted = self.pcRelationsTable.filter(self.apk == apk)
        
        do{
            try self.database.run(relationsToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    /// Deletes entries for speicfic APK from left drawer style table.
    func deleteLeftDrawerStyle(apk : String)
    {
        objc_sync_enter(lock)
        let leftDrawerStyleToBeDeleted = self.leftDrawerStyleTable.filter(self.apk == apk)
        
        do{
            try self.database.run(leftDrawerStyleToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    /// Deletes entries for speicfic APK from left drawer style table.
    func deleteLeftDrawerChildStyle(apk : String)
    {
        objc_sync_enter(lock)
        let leftDrawerChildStyleToBeDeleted = self.leftDrawerChildStyleTable.filter(self.apk == apk)
        
        do{
            try self.database.run(leftDrawerChildStyleToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    /// Deletes entries for speicfic APK from left drawer style table.
    func deleteTabBarStyle(apk : String)
    {
        objc_sync_enter(lock)
        let tabBarStyleToBeDeleted = self.tabBarStyleTable.filter(self.apk == apk)
        
        do{
            try self.database.run(tabBarStyleToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    /// Deletes entries for speicfic APK from left drawer style table.
    func deleteToastStyle(apk : String)
    {
        objc_sync_enter(lock)
        let toastStyleToBeDeleted = self.toastStyleTable.filter(self.apk == apk)
        
        do{
            try self.database.run(toastStyleToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    /// Deletes entries for speicfic APK from left drawer style table.
    func deleteDialogStyle(apk : String)
    {
        objc_sync_enter(lock)
        let dialogStyleToBeDeleted = self.dialogStyleTable.filter(self.apk == apk)
        
        do{
            try self.database.run(dialogStyleToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    /// Deletes entries for speicfic APK from left drawer style table.
    func deleteLeftDrawerImage(apk : String)
    {
        objc_sync_enter(lock)
        let leftDrawerImageToBeDeleted = self.leftDrawerImageTable.filter(self.apk == apk)
        
        do{
            try self.database.run(leftDrawerImageToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    /// Deletes entries for speicfic APK from left drawer style table.
    func deleteNavigationImage(apk : String)
    {
        objc_sync_enter(lock)
        let navigationImageToBeDeleted = self.navImageTable.filter(self.apk == apk)
        
        do{
            try self.database.run(navigationImageToBeDeleted.delete())
        } catch {
            print(error)
        }
        objc_sync_exit(lock)
    }
    
    
    func updateAllParameters(apk : String)
    {
        updateThemeTable(apk : apk)
        updateLeftDrawerTabsTable(apk: apk)
        updateRelationsTable(apk : apk)
        updateLeftDrawerStyleTable(apk : apk)
        updateLeftDrawerChildsStyleTable(apk : apk)
        updateTabBarStyleTable(apk : apk)
        updateToastStyleTable(apk : apk)
        updateDialogStyleTable(apk : apk)
        updateLeftDrawerImageTable(apk : apk)
        updateNavigationImageTable(apk : apk)
    }
    
    func updateThemeTable(apk : String)
    {
        deleteTheme(apk: apk)
        do
        {
            let theme  = try ParameterizationWebApi.getTheme(apk: apk)
            parameterizationDatabase.insertTheme(theme: theme)
        }catch{}
    }
    
    func updateLeftDrawerTabsTable(apk : String)
    {
        deleteLeftDrawerTabs(apk: apk)
        do
        {
            let leftDrawerTabs  = try ParameterizationWebApi.getLeftDrawerTabs(apk: apk)
            parameterizationDatabase.insertLeftDrawerTabs(tabs: leftDrawerTabs)
        } catch {
            print(error)
        }
    }
    
    func updateRelationsTable(apk : String)
    {
        deleteRelations(apk: apk)
        
        do
        {
            let relations = try ParameterizationWebApi.getRelations(apk: apk)
            parameterizationDatabase.insertPCRelations(relations: relations)
        } catch {
            print(error)
        }
    }
    
    func updateLeftDrawerStyleTable(apk : String)
    {
        deleteLeftDrawerStyle(apk: apk)
        
        do
        {
            let styles  = try ParameterizationWebApi.getStyles(apk: apk)
            parameterizationDatabase.insertStyles(styles: styles)
        } catch {
            print(error)
        }
    }
    
    func updateLeftDrawerChildsStyleTable(apk : String)
    {
        deleteLeftDrawerChildStyle(apk: apk)
        
        do
        {
            let styles  = try ParameterizationWebApi.getStyles(apk: apk)
            parameterizationDatabase.insertStyles(styles: styles)
        } catch {
            print(error)
        }
    }
    
    func updateTabBarStyleTable(apk : String)
    {
        deleteTabBarStyle(apk: apk)
        
        do
        {
            let styles  = try ParameterizationWebApi.getStyles(apk: apk)
            parameterizationDatabase.insertStyles(styles: styles)
        } catch {
            print(error)
        }
    }
    
    func updateToastStyleTable(apk : String)
    {
        deleteToastStyle(apk: apk)
        
        do
        {
            let styles  = try ParameterizationWebApi.getStyles(apk: apk)
            parameterizationDatabase.insertStyles(styles: styles)
        } catch {
            print(error)
        }
    }
    
    func updateDialogStyleTable(apk : String)
    {
        deleteDialogStyle(apk: apk)
        
        do
        {
            let styles  = try ParameterizationWebApi.getStyles(apk: apk)
            parameterizationDatabase.insertStyles(styles: styles)
        } catch {
            print(error)
        }
    }
    
    func updateLeftDrawerImageTable(apk : String)
    {
        deleteLeftDrawerImage(apk: apk)
        let theme  = parameterizationDatabase.getTheme(apk: APK)
        
        if(theme != nil)
        {
            if let url = URL(string: (theme?.leftDrawerImage)!) {
                downloadLeftDrawerImage(url: url)
            }
        }
    }
    
    func updateNavigationImageTable(apk : String)
    {
        deleteNavigationImage(apk: apk)
        let theme  = parameterizationDatabase.getTheme(apk: APK)
        
        if(theme != nil)
        {
            if let url = URL(string: (theme?.navigationBarImage)!) {
                downloadLeftDrawerImage(url: url)
            }
        }
    }
}
