//
//  ViewStoryboardID.swift
//  RichReach2
//
//  Created by Eumbrella on 11/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Saves the views ID's of corresponds views.
enum ViewStoryboardID : String
{
    //case Loyalty = "AllPartnersNavigationController"
    case Notifications = "NotificationsNavigationController"
    case HelpAndSupport = "HelpAndSupportNavigationController"
    case Profile = "ProfileNavigationController"
    case Barcode = "BarcodeNavigationController"
    case About = "AboutNavigationController"
    case Preferred = "PreferredOffersNavigationController"
    case Businesses = "AllPartnersNavigationController"
    case WishList = "WishListNavigationController"
    case History = "OptInHistoryNavigationController"
    case Settings = "OffersSettingsNavigationController"
    case General = "GeneralInformationNavigationController"
    case BenefitsCard = "BarcodeViewNavigationController"
    case ExpandableList  = "ExpandableListNavigationController"
    //case BarcodeScan  = "ExpandableListView"
    case ContactUs  = "ContactUsNavigationController"
    case LoyaltyStatement  = "LoyaltyStatementNavigationController"
    case Profile2 = "UserProfileNavigationController"
    //case Feedback  = "ContactUsView"
}
