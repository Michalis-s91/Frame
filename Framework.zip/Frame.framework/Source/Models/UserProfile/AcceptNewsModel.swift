//
//  AcceptNewsModel.swift
//  RichReach2
//
//  Created by Eumbrella on 01/11/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class AcceptNewsModel : Codable
{
    var acceptNews1 : Int! = 0
    var acceptNews2 : Int! = 0
    var acceptNews3 : Int! = 0
    var acceptNews4 : Int! = 0
    var acceptNews5 : Int! = 0
    var acceptNews6 : Int! = 0
    var acceptNews7 : Int! = 0
    var acceptNews8 : Int! = 0
}
