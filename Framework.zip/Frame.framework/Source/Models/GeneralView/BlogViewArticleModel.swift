//
//  ArticleViewArticleModel.swift
//  RichReach
//
//  Created by Eumbrella on 05/02/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

class BlogViewArticleModel : Codable
{
    var tabID : Int!
    var articleID : Int64!
    
    private enum CodingKeys : String, CodingKey {
        case tabID = "TabID"
        case articleID = "ArticleID"
    }
}
