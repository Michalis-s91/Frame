//
//  LoyaltyStatementViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 13/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// LoyaltyStatementViewModel is the view model associated to the loyalty statement view. It is used for setting loyalty statement list.
class LoyaltyStatementViewModel
{
    var partner : PartnerModel!
    var loyaltyStatementPageToLoad = 0
    private var loyaltyStatementList : [LoyaltyStatementModel] = []
    var LoyaltyStatementList : [LoyaltyStatementModel]!
    {
        get
        {
            return self.loyaltyStatementList
        }
        
        set (loyaltyStatementList)
        {
            self.loyaltyStatementList = loyaltyStatementList
            if (loyaltyStatementList == nil || loyaltyStatementList.count == 0)
            {
                isLoyaltyStatementNotAvailable = true
            }
            else
            {
                isLoyaltyStatementNotAvailable = false
            }
        }
    }
    var isLoyaltyStatementNotAvailable = false
    var title : String!
    var tableView : UITableView!
    
    
    /// Constructor. Sets the partner and the table view.
    ///
    /// - Parameters:
    ///   - partner: The partner.
    ///   - tableView: The table view.
    init(partner : PartnerModel!, tableView : UITableView)
    {
        self.partner = partner
        self.tableView = tableView
        
        self.title = partner != nil && !isNullOrEmpty(string: partner.name) ? partner.name + " - " + NSLocalizedString("loyaltyStatementTitle", comment: "") : NSLocalizedString("loyaltyStatementTitle", comment: "")
        loyaltyStatementPageToLoad = 2
    }
    
    /// Loads loyalty points statement from internet.
    ///
    /// - Returns: The loyalty poitns statement table.
    func loadFromInternet(userPhone: String! = (localDatabase.getAppUser()?.phoneNumber)!, partnerID: Int!) -> [LoyaltyStatementModel]
    {
        do
        {
            var statement = try LoyaltyWebApi.getPointsStatement(userPhone: userPhone, partnerID: Int64(partnerID), pageToLoad: 1)

            if(statement != nil && (statement?.count)! > 0)
            {
                loyaltyStatementPageToLoad = 2
            }
            else
            {
                statement = []
            }
            
            return statement!
        }
        catch
        {
            
        }
        
        return []
    }
    
    
    /// Loads more information about loyalty statement.
    func loadMoreFromInternet(userPhone: String! = (localDatabase.getAppUser()?.phoneNumber)!, partnerID: Int!)
    {
        do
        {
            let moreItems = try LoyaltyWebApi.getPointsStatement(userPhone: userPhone, partnerID: Int64(partnerID), pageToLoad: loyaltyStatementPageToLoad)
            
            if(moreItems != nil && (moreItems?.count)! > 0)
            {
                for i in moreItems!
                {
                    let o = LoyaltyStatementModel(rowSerial: String(i.rowSerial),ticketNo: i.ticketNo,transDate: i.transDate,amount: i.amount,rewardPoints: i.rewardPoints,redemptionPoints: i.redemptionPoints,balance: i.balance)
                    
                    loyaltyStatementList.append(o)
                }
                
                DispatchQueue.main.async(execute: {() -> Void in
                    self.tableView.reloadData()
                })
                
                loyaltyStatementPageToLoad += 1
            }
        }
        catch
        {
            
        }
    }
    
    
    /// Loads available loyalty statement.
    ///
    /// - Parameter list: The loyalty statement list.
    func loadAvailableLoyaltyStatement( list : [LoyaltyStatementModel]!)
    {
        if (list != nil && list.count > 0)
        {
            for i in list
            {
                let o = LoyaltyStatementModel(rowSerial: String(i.rowSerial),ticketNo: i.ticketNo,transDate: i.transDate,amount: i.amount,rewardPoints: i.rewardPoints,redemptionPoints: i.redemptionPoints,balance: i.balance)
                if(!loyaltyStatementList.contains(o))
                {
                    loyaltyStatementList.append(o)
                }
            }
        }
    }
}
