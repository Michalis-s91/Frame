//
//  UserProfileModel.swift
//  RichReach2
//
//  Created by Eumbrella on 23/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// UserProfileModel holds information regarding the user's profile such as the user's name, surname and phone number.
class UserProfileModel : NSObject {
    var phoneNumber : String!
    var name : String!
    var surname : String!
    var gender : Int!
    var emailAddress : String!
    var province : String!
    var city : String!
    var homeAddress : String!
    var postCode : String!
    var birthDate : String!
    var hasVerifiedEmailAddress : Bool!
    var titleID : Int!
}
