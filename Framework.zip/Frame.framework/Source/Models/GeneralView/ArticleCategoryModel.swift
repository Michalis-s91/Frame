//
//  ArticleCategoryModel.swift
//  RichReach
//
//  Created by Eumbrella on 05/02/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

class ArticleCategoryModel : Codable
{
    var id : Int!
    var name : String!
    
    private enum CodingKeys : String, CodingKey {
        case id = "ID"
        case name = "Name"
    }
}
