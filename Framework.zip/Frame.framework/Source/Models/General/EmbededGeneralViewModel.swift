//
//  EmbededGeneralViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 17/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class EmbededGeneralViewModel : Codable
{
    var type : Int!
    var index : Int!
    var id : Int!
    var slotID : Int!
    var infoType : Int!
    
    var photo : PhotoModel!
    var video : VideoModel!
    var carousel : CarouselModel!
    var text : TextModel!
    var pdf : PDFModel!
    var hour : [HourModel]!
    var title : TitleModel!
    var storeInfoHeader : StoreInfoHeaderModel!
    
    private enum CodingKeys : String, CodingKey {
        case type = "SlotType"
        case photo = "Photo"
        case video = "Video"
        case carousel = "Carousel"
        case text = "Text"
        case pdf = "Pdf"
        case hour = "Hour"
        case title = "Title"
        case storeInfoHeader = "StoreInfoHeader"
        case index = "SlotIndex"
        case id = "ID"
        case slotID = "SlotID"
        case infoType = "InfoType"
    }
}
