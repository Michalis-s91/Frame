//
//  VideoModel.swift
//  RichReach2
//
//  Created by Eumbrella on 18/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Holds information about video.
class VideoModel : Codable
{
    var title : String!
    var videoUrl : String!
    var autoPlay : Bool!
    var alternativePhoto : String!
    var alternativePhotoAspectRatio : Double! = 0.0
    
    init()
    {
        
    }
    
    init(title : String, url : String)
    {
        self.title = title
        self.videoUrl = url
    }
    
    private enum CodingKeys : String, CodingKey {
        case title = "Title"
        case videoUrl = "Url"
        case autoPlay = "AutoPlay"
        case alternativePhoto = "AlternativePhoto"
        //case alternativePhotoAspectRatio = "AlternativePhotoAspectRatio"
    }
}
