//
//  StoreInfo.swift
//  RichReach2
//
//  Created by Eumbrella on 23/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// Holds information about a store.
class StoreModel : Codable
{
    var addressID : Int!
    var description : String!
    var address1 : String!
    var address2 : String!
    var city : String!
    var region : String!
    var postCode : String!
    var contactPhone : String!
    var contactFax : String!
    var contactEmail : String!
    var latitude : String!
    var longitude : String!
    var contactPhone2 : String!
    var contactMobile : String!
    var ERPCode : String!
    var radius : Int!
    var radiusString : String!
    var infoType : String!
    var infoID : Int!
    var photo : PhotoModel!
    var video : VideoModel!
    var carousel : CarouselModel!
    var closedHolidays : [YearlyHolidaysModel]! = []
    var opendHolidays : [YearlyShopHolidaysModel]! = []
    
    var hours : ListHoursModel!
    
    var dayGroups : [DayGroupModel]!
    
    var isOptionsDisplayed = false
    
    private enum CodingKeys : String, CodingKey {
        case addressID = "AddressID"
        case description = "Description"
        case address1 = "Address1"
        case address2 = "Address2"
        case city = "City"
        case region = "Region"
        case postCode = "PostCode"
        case contactPhone = "ContactPhone"
        case contactFax = "ContactFax"
        case contactEmail = "ContactEmail"
        case radiusString = "MaxDistanceForProximityOffers"
        case latitude = "Latitude"
        case longitude = "Longitude"
        case contactPhone2 = "ContactPhone2"
        case contactMobile = "ContactMobile"
        case ERPCode = "ERPCode"
        case infoType = "ShowOnAppPVCType"
        case infoID = "PVCID"
        case photo = "photo"
        case video = "video"
        case carousel = "carousel"
    }
}
