//
//  StoreInformationViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 25/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Creates a view that shoes information about a specific store (e.g address, phone number).
class StoreInformationViewController: ViewController, UITableViewDelegate, UITableViewDataSource, UIWebViewDelegate  {
    
    @IBOutlet var storeInformationTable: UITableView!
    @IBOutlet var backgroundImage: UIImageView!
    
    @IBOutlet var tableViewTrailing: NSLayoutConstraint!
    @IBOutlet var tableViewBottom: NSLayoutConstraint!
    @IBOutlet var tableViewTop: NSLayoutConstraint!
    @IBOutlet var tableViewLeading: NSLayoutConstraint!
    
    
    var viewModel : StoreInformationViewModel!
    var store : StoreModel!
    var storeInfoParameters : StoreLocatorInfoParametersModel!
    var holidays : [YearlyHolidaysModel]! = []
    var isVideoLoaded = false
    var videoIsBeenPlaying = false
    var viewDidAppear = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.prepare(for:  UIStoryboardSegue(identifier: "a",source: UIViewController() ,destination: UIViewController()), sender: nil)
        
        viewModel = StoreInformationViewModel()
        
        storeInformationTable.rowHeight = UITableViewAutomaticDimension
        storeInformationTable.tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, width: 1, height: 20))
        storeInformationTable.delegate = self
        storeInformationTable.dataSource = self
        // Do any additional setup after loading the view.
        
        if(storeInfoParameters.borderSize > 0)
        {
            tableViewTrailing.constant = CGFloat(storeInfoParameters.borderSize)
            tableViewBottom.constant = CGFloat(storeInfoParameters.borderSize)
            tableViewTop.constant = CGFloat(storeInfoParameters.borderSize)
            tableViewLeading.constant = CGFloat(storeInfoParameters.borderSize)
            
            view.backgroundColor = UIColor(storeInfoParameters.borderColor)
        }
        
        if(selectedTab.hasBackgroundImage)
        {
            let data = parameterizationDatabase.getBackgroundImage(apk: APK)
            
            if(data != nil)
            {
                backgroundImage.image = UIImage(data: data!)
            }
        }
        
        self.navigationItem.leftBarButtonItem?.image = UIImage(named: "ic_back")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.storeInformationTable.reloadData()
        viewDidAppear = true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(holidays.count > 0)
        {
            return 3 + store.dayGroups.count + holidays.count + 1
        }
        else
        {
            return 3 + store.dayGroups.count
        }
    }
    
    func convertHoursToString(openHour : Double , closeHour : Double) -> String
    {
        var result : String!
        
        result = convertTimeToString(time : openHour) + " - "
        result.append(convertTimeToString(time : closeHour))
        return result
    }
    
    func convertTimeToString(time : Double) -> String
    {
        var result : String!
        
        let hour = Int(time)
        
        if(hour < 10)
        {
            result = "0" + String(hour) + ":"
        }
        else
        {
            result = String(hour) + ":"
        }
        
        var minutes = String(time).split(separator: ".")[1]
        if(minutes.count == 1)
        {
            minutes.append(contentsOf: "0")
        }
        
        result.append(String(minutes))
        
        return result
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //let information : GeneralInformation2!
        
        if(indexPath.row == 3 + store.dayGroups.count)
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "store_info_holiday_section") as! StoreHolidayTitleViewCell
            
            cell.titleLabel.text = "HOLIDAYS"
            cell.titleLabel.textColor = UIColor((storeInfoParameters.textColor)!)
            cell.titleLabel.font = UIFont (name: storeInfoParameters.textFont, size: CGFloat((storeInfoParameters.sizeOfText + 2)))
            
            cell.selectionStyle = .none
            return cell
        }
        else if(indexPath.row > 3 + store.dayGroups.count)
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "store_info_holiday") as! StoreHolidayViewCell

            let holiday = holidays[indexPath.row - 3 - store.dayGroups.count - 1]
            
            cell.dateLabel.font = UIFont (name: (storeInfoParameters.textFont)!, size: CGFloat(storeInfoParameters.sizeOfText))
            cell.dateLabel.textColor = UIColor((storeInfoParameters.textColor)!)
            cell.descriptionLabel.font = UIFont (name: (storeInfoParameters.textFont)!, size: CGFloat((storeInfoParameters.sizeOfText)!))
            cell.descriptionLabel.textColor = UIColor((storeInfoParameters.textColor)!)
            cell.hoursLabel.font = UIFont (name: (storeInfoParameters.textFont)!, size: CGFloat((storeInfoParameters.sizeOfText)!))
            cell.hoursLabel.textColor = UIColor((storeInfoParameters.textColor)!)
            
            cell.selectionStyle = .none
            
            cell.dateLabel.text = "* " + holiday.holidayDate
            
            for h in store.opendHolidays
            {
                if(holiday.holidayDate == h.holidayDate)
                {
                    cell.descriptionLabel.text = "Store will be open."
                    

                    if(!isNullOrEmpty(string:  h.startTime2))
                    {
                        let firstTime = h.startTime1 + " - " + h.endTime1
                        let secondTime = h.startTime2 + " - " + h.endTime2
                        cell.hoursLabel.text = firstTime + " , " + secondTime
                    }
                    else
                    {
                        cell.hoursLabel.text = h.startTime1 + " - " + h.endTime1
                    }
                    return cell
                }
            }
            
            cell.descriptionLabel.text = holiday.description
            cell.hoursLabel.text = "Closed"
            cell.hoursLabel.textColor = UIColor.red
            
            
            return cell
        }
        else if(indexPath.row > 2)
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "store_info_hour2") as! InformationHourViewCell
            let group = store.dayGroups[indexPath.row - 3]
            var days : String!
            var hours : String!
            
            for d in group.days
            {
                if(days == nil)
                {
                    days = d
                }
                else
                {
                    days  = days + ", " + d
                }
            }
            
            cell.dayLabel.text = days
            
            if(group.startTime1 == nil)
            {
                cell.hoursLabel.text = "Closed"
                cell.hoursLabel.textColor = UIColor.red
            }
            else
            {
                hours = group.startTime1 + " - " + group.endTime1
                
                if(group.startTime2 != nil)
                {
                    hours = hours + " , " + group.startTime2 + " - " + group.endTime2
                }
                
                cell.hoursLabel.text = hours
                cell.hoursLabel.textColor = UIColor((storeInfoParameters.textColor)!)
            }
            
            cell.dayLabel.font = UIFont (name: (storeInfoParameters.textFont)!, size: CGFloat(storeInfoParameters.sizeOfText))
            cell.dayLabel.textColor = UIColor((storeInfoParameters.textColor)!)
            cell.hoursLabel.font = UIFont (name: (storeInfoParameters.textFont)!, size: CGFloat((storeInfoParameters.sizeOfText)!))
            
            
            //cell.hoursLabel.sizeToFit()
            cell.selectionStyle = .none
            return cell
        }
        
        if(indexPath.row == 0)
        {
            /*let cell = tableView.dequeueReusableCell(withIdentifier: "store_info_title") as! InformationTitleViewCell
             
             cell.titleLabel.text = store.description
             cell.titleLabel.font = UIFont (name: (storeInfoParameters.titleFont)!, size: CGFloat((storeInfoParameters.titleTextSize)!))
             cell.titleLabel.textColor = UIColor((storeInfoParameters.titleTextColor)!)
             cell.titleLabel.backgroundColor =  UIColor((storeInfoParameters.titleBackgroundColor)!)
             
             cell.selectionStyle = .none
             return cell*/
            let label = UILabel()
            
            //informationTableView.frame = CGRect(x: informationTableView.frame.origin.x, y: informationTableView.frame.origin.y + 15.0, width: informationTableView.frame.size.width, height: informationTableView.frame.size.height - 15.0)
            let font = UIFont (name: (storeInfoParameters.titleFont)!, size: CGFloat((storeInfoParameters.titleTextSize)!))
            let titleHeight = store.description.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: font!) + 20
            
            let blankView = UIView()
            blankView.backgroundColor = UIColor.white
            blankView.frame = CGRect(x: storeInformationTable.frame.origin.x, y: storeInformationTable.frame.origin.y, width: storeInformationTable.frame.size.width, height: (label.frame.origin.y + titleHeight) - storeInformationTable.frame.origin.y )
            self.view.addSubview(blankView)
            
            label.text = store.description
            label.font = font
            label.textColor = UIColor((storeInfoParameters.titleTextColor)!)
            label.backgroundColor = UIColor((storeInfoParameters.titleBackgroundColor)!)
            label.numberOfLines = 0
            label.textAlignment = .center
            
            
            label.frame = CGRect(x: 0, y: titleTopPadding, width: UIScreen.main.bounds.size.width, height: titleHeight)
            
            self.view.addSubview(label)
            
            return UITableViewCell()
        }
        
        
        if(indexPath.row == 2)
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "store_info_header") as! InformationHeaderViewCell
            
            cell.store = store
            cell.navigationController = self.navigationController
            cell.addressLabel.text = store.address1
            cell.phoneLabel.text = store.contactPhone
            
            cell.addressLabel.font = UIFont (name: (storeInfoParameters.textFont)!, size: CGFloat((storeInfoParameters.sizeOfText)!))
            cell.findUsLabel.font = UIFont (name: (storeInfoParameters.textFont)!, size: CGFloat((storeInfoParameters.sizeOfText)!))
            cell.phoneLabel.font = UIFont (name: storeInfoParameters.textFont, size: CGFloat(storeInfoParameters.sizeOfText))
            cell.statusLabel.font =  UIFont (name: storeInfoParameters.textFont, size: CGFloat(storeInfoParameters.sizeOfText))
            cell.addressLabel.textColor = UIColor(storeInfoParameters.textColor)
            cell.findUsLabel.textColor = UIColor(storeInfoParameters.textColor)
            cell.phoneLabel.textColor = UIColor(storeInfoParameters.textColor)
            
            cell.findUsLabel.attributedText = NSAttributedString(string: cell.findUsLabel.text!, attributes: [.underlineStyle: NSUnderlineStyle.styleSingle.rawValue])
            
            cell.hoursHeader.textColor = UIColor((storeInfoParameters.textColor)!)
            cell.hoursHeader.font = UIFont (name: storeInfoParameters.textFont, size: CGFloat((storeInfoParameters.sizeOfText + 2)))
            
            cell.phoneImage.image = UIImage(named: "ic_phone")?.withRenderingMode(.alwaysTemplate)
            cell.phoneImage.tintColor = UIColor(storeInfoParameters.tintColor)
            
            cell.mapImage.image = UIImage(named: "ic_location_marker")?.withRenderingMode(.alwaysTemplate)
            
            if(store.latitude != nil && store.longitude != nil)
            {
                cell.mapImage.tintColor = UIColor(storeInfoParameters.tintColor)
                cell.mapImageWidth.constant = 20
                cell.mapLabelLeading.constant = 5
            }
            else
            {
                cell.mapImage.tintColor = UIColor.clear
                cell.findUsLabel.text = ""
                cell.mapImageWidth.constant = 0
                cell.mapLabelLeading.constant = 0
                cell.mapView.removeFromSuperview()
            }
            
            if(isShopOpen(store : store, holidays : holidays))
            {
                cell.statusLabel.textColor = UIColor("#249DD9") //UIColor.green
                cell.statusLabel.text = "OPEN"
            }
            else
            {
                cell.statusLabel.textColor = UIColor.red
                cell.statusLabel.text = "CLOSED"
            }
            
            cell.selectionStyle = .none
            return cell
        }
            
        switch Int(store.infoType)
        {
        case SlotType.Photo.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "store_info_image") as! InformationImageViewCell
            let photo : PhotoModel! = store.photo
            
            if(photo.title != nil)
            {
                let title : TitleModel! = photo.title
                cell.cellTitle.text = title?.title
                cell.cellTitle.font = UIFont (name: (title.titleFont)!, size: CGFloat((title.titleSize)!))
                cell.cellTitle.textColor = UIColor((title.titleColor)!)
                cell.cellTitle.backgroundColor = UIColor((title.titleBackgroundColor)!)
            }
            else
            {
                cell.cellTitle.text = ""
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            cell.link = photo.link
            
            
            var image = storesDB.getImage(url:  photo.imageUrl)
            if(image != nil)
            {
                cell.cellImage.image = image
            }
            else
            {
                let url = URL(string: percentEncode(s: photo.imageUrl))
                cell.cellImage.kf.setImage(with: url)
            }
            
            cell.cellImage.autoresizingMask = [.flexibleWidth , .flexibleHeight]
            cell.cellImage.autoresizesSubviews = true
            cell.selectionStyle = .none
            return cell
        case SlotType.Carousel.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "store_info_carousel") as! InformationCarouselViewCell
            
            let carousel : CarouselModel! = store.carousel
            cell.urls = carousel?.urls
            cell.hasTitles = carousel.hasTitles
            cell.titleSize = carousel.titleSize
            cell.isAutomatic = carousel?.isAutomatic
            cell.isManual = carousel?.isManual
            cell.isScrollingEnabled = carousel?.isScrollingEnabled
            cell.interval = (carousel?.interval)!
            
            //if(viewDidAppear)
            //{
                cell.setCarusel(isStore : true, width : storeInformationTable.frame.size.width)
            //}
            
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case SlotType.Video.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_video") as! InformationVideoViewCell
            
                cell.cellWebView.mediaPlaybackRequiresUserAction = false
                cell.cellWebView.allowsInlineMediaPlayback = true
                cell.cellWebView.delegate = self
                cell.cellWebView.mediaPlaybackAllowsAirPlay = false
                cell.cellWebView.scrollView.isScrollEnabled = false
                cell.cellWebView.scrollView.showsVerticalScrollIndicator = false
                cell.cellWebView.scrollView.showsHorizontalScrollIndicator = false
            
            
                var cellRect = storeInformationTable.rectForRow(at: indexPath)
                cellRect.size.height =  cellRect.size.height
                let completelyVisible = storeInformationTable.bounds.contains(cellRect)
                
                if (completelyVisible) {
                    
                    if(!isVideoLoaded)
                    {
                        let width = UIScreen.main.bounds.size.width - CGFloat(2 * borderWidth)
                        let height = width/1.77
                        
                        cell.cellWebView.allowsInlineMediaPlayback = true
                        
                        cell.cellWebView.loadHTMLString("<video controls muted autoplay loop playsinline webkit-playsinline id=\"video1\" width=\"\(width)\" height=\"\(height)\"> <source src=\"\(store.video.videoUrl ?? "")\" type=\"video/mp4\"></video>", baseURL: nil)
                        cell.cellWebView.stringByEvaluatingJavaScript(from: "var vid = document.getElementById(\"video1\"); vid.play();")
                        
                        videoIsBeenPlaying = true
                        isVideoLoaded = true
                    }
                }
 
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case SlotType.Header.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "store_info_header") as! InformationHeaderViewCell
            
            cell.selectionStyle = .none
            return cell

        default:
            return tableView.dequeueReusableCell(withIdentifier: "store_info_image") as! InformationImageViewCell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if(indexPath.row > 1)
        {
            return UITableViewAutomaticDimension
        }
        
        if(indexPath.row == 0)
        {
            let font = UIFont (name: (storeInfoParameters.titleFont), size: CGFloat((storeInfoParameters.titleTextSize)))
            return (store.description.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: font!) + 30)
        }
        
        switch Int(store.infoType) {
        case SlotType.Carousel.rawValue:
            let carousel = store.carousel
            var titleHeight : CGFloat! = 0.0
            
            if(carousel?.hasTitles)!
            {
                titleHeight = carousel?.urls[0].title.title?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: UIFont (name: (carousel?.urls[0].title.titleFont)!, size: CGFloat((carousel?.urls[0].title.titleSize)!))!)
            }
            
            var cellHeight : CGFloat!
            let aspcetRatio = carousel?.urls[0].aspectRatio
            if(aspcetRatio != nil)
            {
                cellHeight = UIScreen.main.bounds.size.width * 0.9 * CGFloat(aspcetRatio!) + titleHeight
            }
            else
            {
                cellHeight = UIScreen.main.bounds.size.width * 0.9 + titleHeight
            }
            
            return cellHeight
        case SlotType.Video.rawValue:
            return UIScreen.main.bounds.size.width/1.77 - 2
        case SlotType.Text.rawValue:
            return UITableViewAutomaticDimension
        case SlotType.Hour.rawValue:
            return UITableViewAutomaticDimension
        case SlotType.Photo.rawValue:
            if(store.photo.aspectRatio != nil)
            {
                return UIScreen.main.bounds.size.width * 0.9 * CGFloat(store.photo.aspectRatio)
            }
            else
            {
                return UIScreen.main.bounds.size.width * 0.9
            }
            
        default:
            return UITableViewAutomaticDimension
        }
        
    }
    
    @IBAction func backPressed(_ sender: UIBarButtonItem) {
        isViewPushed = false
        self.navigationController?.popViewController(animated: true)
    }
}
