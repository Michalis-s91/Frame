//
//  ProductMenuModel.swift
//  RichReach2
//
//  Created by Eumbrella on 17/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class ProductMenuModel : Codable
{
    var clientID : Int64!
    var id : Int!
    var parentID : Int!
    var displayOrder : Int!
    var name : String!
    var image : String!
    var parentCategoryID : Int!
    var parentCategory : ProductMenuModel!
    var level : Int!
    var products : [ProductModel]!
    var childCategories : [ProductMenuModel]!
    var isExpanded = false
    
    var textSize : Int!
    var textColor : String!
    var font : String!
    var backgroundColor : String!
    var tintColor : String!
    
    private enum CodingKeys : String, CodingKey {
        case clientID = "ClientID"
        case id = "ID"
        case parentID = "ParentID"
        case displayOrder = "DisplayOrder"
        case name = "Name"
    }
}
