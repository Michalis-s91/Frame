//
//  PartnerInformationViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 15/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Creates view that shows information about partner's like stores telephones, locations etc.
class PartnerInformationViewController: ViewController {
    
    @IBOutlet var favouriteBarItem: UIBarButtonItem!
    @IBOutlet var partnerInformationContainer: UIView!
    
    var viewModel : PartnerInfoViewModel!
    var partner : PartnerModel!
    static var isFavourite : Bool!
    var isMenuItemClicked = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        viewModel = PartnerInfoViewModel(partner : partner)
        
        if (partner.isRoot || partner.IsFavourite)
        {
            PartnerInformationViewController.isFavourite = true
            favouriteBarItem.image = UIImage(named: "ic_favourite_filled")
        }
        else
        {
            PartnerInformationViewController.isFavourite = false
            favouriteBarItem.image = UIImage(named: "ic_favourite")
        }
        
        let titleFont = UIFont(name: "UIFontWeightRegular", size: 16) ?? UIFont.systemFont(ofSize: 16)
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.font: titleFont, NSAttributedStringKey.foregroundColor:UIColor.white]
        self.title = viewModel.title
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if(self.partnerInformationContainer.subviews.count == 1)
        {
            let storyBoard = UIStoryboard(name:"InformationView",bundle:nil)
            let offerInformationViewController = storyBoard.instantiateInitialViewController() as! InformationsViewController
            offerInformationViewController.isPartnerInformationView = true
            offerInformationViewController.partnerInfoViewModel = viewModel
            offerInformationViewController.navController = self.navigationController
            offerInformationViewController.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: (partnerInformationContainer?.frame.height)!)
            offerInformationViewController.willMove(toParentViewController: self)
            self.partnerInformationContainer?.addSubview((offerInformationViewController.view)!)
            //self.addChildViewController(allPartnersView)
            offerInformationViewController.parentNavigationController = self.navigationController
            offerInformationViewController.didMove(toParentViewController: self)
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    @IBAction func showProductsClicked(_ sender: UIBarButtonItem) {
        isMenuItemClicked = true
        loadPartnerOffers()
    }
    
    @IBAction func onFavouriteClicked(_ sender: UIBarButtonItem) {
        if(!(localDatabase.isAPKRegistered(bussinessID: clientID))!)
        {
            let s = ShowRegistrationDialog()
            s.viewController = self
            s.showRegistrationDialog()
        }
        else
        {
            changePartnerOptInStatus()
        }
    }
    
    
    /// Loads the partner offers and displays them in a separate view.
    func loadPartnerOffers()
    {
        if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
        {
            if(partner != nil)
            {
                let OffersStoryBoard : UIStoryboard = UIStoryboard(name: "OffersView", bundle: nil)
                let offersView =  OffersStoryBoard.instantiateInitialViewController() as! OffersViewController
                self.navigationController?.pushViewController(offersView, animated: true)
                offersView.setOffersView(partner : self.partner)
            }
        }
        else
        {
            let toast =  CustomToast()
            toast.setToast(viewController: self, message: NSLocalizedString("internetIsRequired", comment: ""))
            toast.show()
        }
    }
    
    
    /// Updates the favourite partner item icon of action bar.
    func updateFavouritePartnerActionBarItemIcon()
    {
        do
        {
            if (PartnerInformationViewController.isFavourite)
            {
                favouriteBarItem.image = UIImage(named: "ic_favourite_filled")
            }
            else
            {
                favouriteBarItem.image = UIImage(named: "ic_favourite")
            }
            
            partner.IsFavourite = PartnerInformationViewController.isFavourite
        }
        catch
        {
            
        }
    }
    
    
    /// Changes the partner's optin status asynchronously.
    func changePartnerOptInStatus()
    {
        if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
        {
            if(partner != nil)
            {
                if (!partner.isRoot)
                {
                    if(partner.isLoyalty && partner.IsFavourite)
                    {
                        let toast =  CustomToast()
                        toast.setToast(viewController: self, message: NSLocalizedString("changeLoyaltyPartnerStatusNotAllowed", comment: ""))
                        toast.show()
                    }
                    else
                    {
                        DispatchQueue.global(qos: .background).async {
                            self.changePartnerOptInStatusAsync()
                        }
                    }
                }
                else
                {
                    let toast =  CustomToast()
                    toast.setToast(viewController: self, message: NSLocalizedString("changeWhiteLabelPartnerStatusNotAllowed", comment: ""))
                    toast.show()
                }
            }
        }
        else
        {
            let toast =  CustomToast()
            toast.setToast(viewController: self, message: NSLocalizedString("internetIsRequired", comment: ""))
            toast.show()
        }
    }
    
    
    /// Changes the partner's optin status asynchronously.
    func changePartnerOptInStatusAsync()
    {
        var tempIsFavourite : Bool!
        
        do
        {
            tempIsFavourite = PartnerInformationViewController.isFavourite
            PartnerInformationViewController.isFavourite = !PartnerInformationViewController.isFavourite
            
            DispatchQueue.main.async(execute: {() -> Void in
                self.updateFavouritePartnerActionBarItemIcon()
            })
            
            do
            {
                try viewModel.modifyFavourites(isFavourite: tempIsFavourite)
            }
            catch
            {
                PartnerInformationViewController.isFavourite = !PartnerInformationViewController.isFavourite
                DispatchQueue.main.async(execute: {() -> Void in
                    self.updateFavouritePartnerActionBarItemIcon()
                    let toast =  CustomToast()
                    toast.setToast(viewController: self, message: NSLocalizedString("congestedServerNetworkTryAgain", comment: ""))
                    toast.show()
                })
            }
        }
        catch
        {
            PartnerInformationViewController.isFavourite = !PartnerInformationViewController.isFavourite
            DispatchQueue.main.async(execute: {() -> Void in
                self.updateFavouritePartnerActionBarItemIcon()
                let toast =  CustomToast()
                toast.setToast(viewController: self, message: NSLocalizedString("congestedServerNetworkTryAgain", comment: ""))
                toast.show()
            })
        }
    }

    
}
