//
//  AppUserOld.swift
//  RichReach2
//
//  Created by Eumbrella on 09/10/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class AppUserOld: Codable {
    
    /* Registration related attributes */
    var phoneNumber : String! = ""
    var deviceID : String! = ""
    var receivedRegistrationVerificationCode : Bool! = false
    
    /* Preferred business related attributes */
    var preferredBusinessID : String! = ""
    var preferredBusinessName : String! = ""
    var preferredBusinessShortName : String! = ""
    var preferredBusinessImageUrl : String! = ""
    var displayPreferredBusiness : Bool!
    
    /* User Profile related attributes */
    var title : String!
    var name : String!
    var surname : String!
    var gender : Int!
    var emailAddress : String!
    var province : String!
    var city : String!
    var homeAddress : String!
    var homeAddress2 : String!
    var postCode : String!
    var birthDate : String!
    var country : String!
    
    var hasLoyaltyProfile = false
    var hasVerifiedEmailAddress = false
    
    /*Flags*/
    var isRegistered : Bool! = false
    var isPending : Bool!  = false
    
    /* Telephony related attributes */
    var currentBalance : String!
    var lastBalanceSyncDate : String!
    
    /*Registration*/
    var networkOperator =  ""
    var hasUserReceivedRegistrationVerificationCode : Bool!
    var verificationTimeStamp : Date!
    var partnerCode : String!
    
    /*Promocode*/
    var isPromocodeApplied : Bool! = false
    var promocodeAppliedTimestamp : Date!
    var partnerID : Int! = 0
    var partnerImageUri : String!
    var partnerName : String!
    var partnerShortName : String!
    
    /*eOrdering details*/
    var hasAccessToOrdering : Bool!
    var isOrderCustomer : Bool!
    var defaultBrandID : Int!
    var displayWhiteLabelPartner : Bool! = false
    
    /*QuickNumbers Data*/
    var qNLastSync : Date!
    
    var isUserRegisteredToAPNS : Bool! = false
    var paremeterizationInitialized : Bool! = false
    
    /// Return if the user has received a registration verification code or not.
    ///
    /// - Returns: True if the user has received a registration verification code, otherwise false.
    func hasReceivedRegistrationVerificationCode() -> Bool
    {
        return receivedRegistrationVerificationCode
    }
}
