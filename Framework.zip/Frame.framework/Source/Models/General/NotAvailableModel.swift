//
//  NotAvailableModel.swift
//  RichReach2
//
//  Created by Eumbrella on 18/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class NotAvailableModel : Codable
{
    var backgroundColor : String!
    var messageTextColor : String!
    var messageTextSize : Int!
    var messageFont : String!
    var image : String!
    
    
    private enum CodingKeys : String, CodingKey {
        case backgroundColor = "BackgroundColor"
        case messageTextColor = "MessageTextColor"
        case messageTextSize = "MeesageTextSize"
        case messageFont = "MessageFont"
        case image = "ImageUrl"
    }
}
