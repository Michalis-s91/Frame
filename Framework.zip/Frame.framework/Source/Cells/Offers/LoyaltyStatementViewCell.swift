//
//  LoyaltyStatementViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 13/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// LoyaltyStatementViewCell is a cell that is been used at loyalty statement table
class LoyaltyStatementViewCell: UITableViewCell {

    @IBOutlet var transactionDateLabel: UILabel!
    @IBOutlet var ticketNoLabel: UILabel!
    @IBOutlet var amountLabel: UILabel!
    @IBOutlet var rewardPointsLabel: UILabel!
    @IBOutlet var redemptionPointsLabel: UILabel!
    @IBOutlet var balanceLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
