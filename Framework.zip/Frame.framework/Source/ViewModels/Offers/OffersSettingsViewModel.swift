
//
//  OffersSettingsViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 21/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// This view Model associated to the offers settings view. It uses the client API in order to apply the partner's business
/// code. If given business code is correct, then the partner will be set as a preferred partner.
class OffersSettingsViewModel
{
    var appUser : AppUser!
    private var partnerName : String!
    var PartnerName : String
    {
        get
        {
            return self.partnerName
        }
        
        set (partnerName)
        {
            self.partnerName  = partnerName
            
            if(!isNullOrEmpty(string: partnerName))
            {
                viewController.preferredPartnerNameLabel.text = partnerName
            }
        }
    }
    var verificationMessage : String!
    var imageUri : String!
    var partnerCode : String!
    var status : String!
    var allowUserToApplyPartnerCode = true
    private var hasWhiteLabel = false
    var HasWhiteLabel : Bool
    {
        get
        {
            return self.hasWhiteLabel
        }
        
        set(hasWhiteLabel)
        {
            self.hasWhiteLabel = hasWhiteLabel
            allowUserToApplyPartnerCode = !hasWhiteLabel
            
            if(allowUserToApplyPartnerCode)
            {
                viewController.addPreferredPartnerView.isHidden = false
            }
            else
            {
                viewController.addPreferredPartnerView.removeFromSuperview()
            }
            
            if(hasWhiteLabel)
            {
                viewController.hasPreferredPartnerView.isHidden = false
            }
            else
            {
                viewController.hasPreferredPartnerView.isHidden = true
            }
            
            viewController.view.layoutIfNeeded()
        }
    }
    var displayWhiteLabelPartner = false
    var isRegistrationSuccessful = false
    var viewController : OffersSettingsViewController!
    
    var r : RegistrationCompletedtHandler?
    
    
    /// Constructor. Sets the view controller.
    ///
    /// - Parameter viewController: The current view controller.
    init(viewController : OffersSettingsViewController)
    {
        self.viewController = viewController
        appUser = localDatabase.getAppUser()
        
        if(appUser.isPromocodeApplied)
        {
            HasWhiteLabel =  true
            imageUri = appUser.partnerImageUri
            
            PartnerName = appUser.partnerName
            if(!isNullOrEmpty(string: partnerName))
            {
                viewController.preferredPartnerNameLabel.text = partnerName
            }
            
            status = NSLocalizedString("registeredTo", comment: "") + appUser.partnerName
        }
        else
        {
            HasWhiteLabel =  false
            
            status = NSLocalizedString("notRegisteredYet", comment: "")
        }
    }
    
    
    /// Verify the provided partner code. In case the partner code is correct, register user to the partner.
    func verifyPartnerCode()
    {
        var response : String!
        
        if(!isNullOrEmpty(string: partnerCode))
        {
            response = OffersSettingsWebApi.verifyPartnerCode(userPhone: appUser.phoneNumber, partnerCode: partnerCode)
            var responseCode = 0
            
            let tempResponse = response
            
            responseCode = Int((tempResponse?.replacingOccurrences(of: " ", with: ""))!) ?? 0
            
            if (responseCode < 0)
            {
                if (responseCode == PartnerCodeVerificationEnum.UserNotFound.rawValue)
                {
                    status = NSLocalizedString("error16001UserNotFound", comment: "")
                }
                else if (responseCode == PartnerCodeVerificationEnum.WrongPartnerCode.rawValue)
                {
                    status = NSLocalizedString("error16002WrongPartnerCode", comment: "")
                }
                else if (responseCode == PartnerCodeVerificationEnum.ServiceAccessError.rawValue)
                {
                    status = NSLocalizedString("error16003ServiceAccessError", comment: "")
                }
                else
                {
                    status = NSLocalizedString("error16000", comment: "")
                }
                
                partnerCode = ""
            }
            else
            {
                do
                {
                    let partnerTuple = try OffersFormatter.unPackWhiteLabelPartner(packageString: response)
                    if (partnerTuple != nil)
                    {
                        appUser.isPromocodeApplied = true
                        appUser.partnerID = (partnerTuple?.item1)!
                        appUser.partnerName = partnerTuple?.item2
                        appUser.partnerShortName = partnerTuple?.item4
                        appUser.partnerImageUri = partnerTuple?.item3
                        localDatabase.updateAppUser(appUser: appUser)
                        let root = PartnerModel()
                        root.partnerID = partnerTuple?.item1
                        root.name = partnerTuple?.item2
                        root.imageUri = partnerTuple?.item3
                        root.IsFavourite = true
                        root.isRoot = true
                        
                        root.id = root.partnerID
                        
                        MainViewModel.partnerName = appUser.partnerShortName
                        MainViewModel.hasWhiteLabel = true
                        
                        localDatabase.insertFavouritePartner(partner: root)
                        status = NSLocalizedString("userRegisteredTo", comment: "") + (partnerTuple?.item2)!
                        HasWhiteLabel = true
                        imageUri = partnerTuple?.item3
                        
                        PartnerName = (partnerTuple?.item2)!
                        if(!isNullOrEmpty(string: partnerName))
                        {
                            viewController.preferredPartnerNameLabel.text = partnerName
                        }
                        
                        viewController.registrationCompleted()
                        
                    }
                }
                catch
                {
                    status = NSLocalizedString("whiteLabelRegistrationError", comment: "")
                }
            }
        }
    }
    
    
    /// Updates preferred label partner visibility in local database. Each time the app is launched, this visibility is
    /// checked. If set to true, then the white label partner is displayed in the left menu, otherwise not.
    func updateWhiteLabelPartnerVisibility()
    {
        appUser.displayWhiteLabelPartner = displayWhiteLabelPartner
        localDatabase.updateAppUser(appUser: appUser)
    }
}
