//
//  PhotoModel.swift
//  RichReach2
//
//  Created by Eumbrella on 18/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Holds information about photo.
class PhotoModel : Codable
{
    var imageUrl : String!
    var link : String!
    var aspectRatio : Double!
    var title : TitleModel!
    var button : ButtonModel!
    var takeFullWidth = true
    var isImageLoaded = false
    var isSignature = false
    var photoData : Data!
    //var buttonID : Int!
    //var titleID : Int!
    
    private enum CodingKeys : String, CodingKey {
        case imageUrl = "Url"
        case link = "Link"
        case aspectRatio = "AspectRatio"
        case title = "Title"
        case button = "Button"
        //case buttonID = "ButtonID"
        //case titleID = "TitleID"
    }
}
