//
//  CaruselModel.swift
//  RichReach2
//
//  Created by Eumbrella on 18/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// Holds information about carousel.
class CarouselModel : Codable
{
    var urls : [UrlModel]! = []
    var interval : Int! = 4
    var hasTitles : Bool!
    var isManual : Bool! = false
    var isAutomatic : Bool! = true
    var isScrollingEnabled : Bool! = false
    var titleSize : Int!
    var widthPercentage : Int! = 100
    
    private enum CodingKeys : String, CodingKey {
        case urls = "UrlList"
        case interval = "TimeInterval"
        case hasTitles = "HasTitles"
        case isManual = "IsManual"
        case isAutomatic = "IsAutomatic"
        case isScrollingEnabled = "IsScrollingEnabled"
        case titleSize = "TitleSize"
    }
}
