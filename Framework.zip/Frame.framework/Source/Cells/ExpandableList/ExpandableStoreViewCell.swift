//
//  StoreInfoViewCell2.swift
//  RichReach2
//
//  Created by Eumbrella on 24/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// StoreInfoViewCell is a cell that is been used at stores locator view and shows store information(address and status).
class ExpandableStoreViewCell: UITableViewCell {

    @IBOutlet var infoView: UIView!
    @IBOutlet var infoImage: UIImageView!
    @IBOutlet var addressLabel: UILabel!
    @IBOutlet var statusLabel: UILabel!
    //@IBOutlet var optionsListView: UIView!
    //@IBOutlet var optionsTable: UITableView!
    
    @IBOutlet var optionListViewHeight: NSLayoutConstraint!
    
    var store : StoreModel!
    var storeInfoParameters : StoreLocatorInfoParametersModel!
    var table : UITableView!
    //var optionsListView : OptionsListViewController!
    var indexPath : IndexPath!
    var navigationController : UINavigationController!

    override func awakeFromNib() {
        super.awakeFromNib()
        
        //optionsTable.tableFooterView = UIView()
        //optionsTable.delegate = self
        //optionsTable.dataSource = self
        
        //let onOptionsClick = UITapGestureRecognizer(target: self, action: #selector(ExpandableStoreViewCell.onOptionsClick))
        //infoView.isUserInteractionEnabled = true
        //infoView.addGestureRecognizer(onOptionsClick)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    /*func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return store.options.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "option_cell") as! OptionViewCell
        cell.optionLabel.text = store.options[indexPath.row]
        return cell
    }*/
    
    /*@objc func onOptionsClick (sender:UITapGestureRecognizer) {
        /*let rectOfCellInTableView = table.rectForRow(at: indexPath)
        StoresLocatorViewController.rectOfCellInSuperview = table.convert(rectOfCellInTableView, to: table.superview)
        
        if(store.isOptionsDisplayed)
        {
            store.isOptionsDisplayed = false
            optionsListView.view.frame = CGRect(x: Int(UIScreen.main.bounds.size.width), y: Int(UIScreen.main.bounds.size.height), width: 0, height: 0 )
        }
        else
        {
            store.isOptionsDisplayed = true
        }
        
        table.reloadData()*/
        let StoreInfoStoryBoard : UIStoryboard = UIStoryboard(name: "StoreInformationView", bundle: nil)
        let storeInfoView =  StoreInfoStoryBoard.instantiateInitialViewController() as! StoreInformationViewController
        storeInfoView.store = store
        storeInfoView.storeInfoParameters = storeInfoParameters
        self.navigationController?.pushViewController(storeInfoView, animated: true)
    }*/
}
