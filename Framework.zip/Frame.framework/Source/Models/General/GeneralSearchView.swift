//
//  GeneralSearchView.swift
//  RichReach2
//
//  Created by Eumbrella on 02/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class GeneralSearchView : Codable
{
    var id : Int!
    var tintColor : String!
    var itemBackgroundColor : String!
    var itemTextColor : String!
    var itemFont : String!
    var itemTextSize : Int!
    var searchTextColor : String!
    var searchFont : String!
    var searchTextSize : Int!
    
    private enum CodingKeys : String, CodingKey {
        case id = "ID"
        case tintColor = "TintColor"
        case itemBackgroundColor = "ItemBackgroundColor"
        case itemTextColor = "ItemTextColor"
        case itemFont = "ItemFont"
        case itemTextSize = "ItemTextSize"
        case searchTextColor = "SearchTextColor"
        case searchFont = "SearchFont"
        case searchTextSize = "SearchTextSize"
    }

}
