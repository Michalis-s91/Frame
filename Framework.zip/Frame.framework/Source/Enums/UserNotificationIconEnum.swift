//
//  UserNotificationIconEnum.swift
//  RichReach2
//
//  Created by Eumbrella on 16/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// Enum for toast notification icons which tells what icon should we use.
///
/// - InternetRequiredIcon: Use internet required icon.
/// - FavoritesIcon: Use favorite icon.
/// - BalanceIcon: Use balance icon.
/// - SyncIcon: Use sync icon.
/// - NoIcon: Don't use any icon
enum UserNotificationIconEnum : Int
{
    case InternetRequiredIcon = 0
    case FavoritesIcon = 1
    case BalanceIcon = 2
    case SyncIcon = 3
    case NoIcon = 4
}
