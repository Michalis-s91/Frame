//
//  CheckBoxAlignment.swift
//  RichReach
//
//  Created by Eumbrella on 14/03/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

enum CheckBoxAlignment : Int
{
    case Left = 1
    case Center = 2
    case Right = 3
}
