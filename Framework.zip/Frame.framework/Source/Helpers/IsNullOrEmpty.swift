//
//  IsNullOrEmpty.swift
//  RichReach2
//
//  Created by Eumbrella on 21/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/**
 * Check if input string is null or empty
 * @param string The string we want to check.
 * @return True if string is null or empty, otherwise return false.
 */
func isNullOrEmpty (string : String!) -> Bool{
    if(string == nil || string.isEmpty)
    {
        return true
    }
    else
    {
        return false
    }
}
