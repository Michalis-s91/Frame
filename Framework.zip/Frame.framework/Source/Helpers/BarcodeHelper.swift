//
//  BarcodeHelper.swift
//  RichReach2
//
//  Created by Eumbrella on 14/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import AVFoundation
import RSBarcodes

/// Helper for creating barcode images.
class BarcodeHelper{
    /// Creates barcode imaged based on input string and return the image.
    ///
    /// - Parameter barcodeID: The input string.
    /// - Returns: The barcode image.
    func getImageFromString(barcodeID: String, type : String ) -> UIImage? {

        if (barcodeID != "")
        {
            return RSUnifiedCodeGenerator.shared.generateCode(barcodeID, machineReadableCodeObjectType: type)
        }
        else
        {
            return nil
        }
    }
}
