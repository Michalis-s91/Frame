//
//  ExpandableListViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 07/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class ExpandableListViewModel
{
    var list : [ExpandableListParentModel] = []
    
    func loadFromLD()
    {
        if(viewsDB.getExpandableListView(tabID: selectedTab.id) != nil)
        {
            self.list = viewsDB.getExpandableListParents(expandableListViewID: viewsDB.getExpandableListView(tabID: selectedTab.id).id)
        }
    }
}
