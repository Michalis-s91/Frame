//
//  OrderProduct.swift
//  RichReach2
//
//  Created by Eumbrella on 09/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// OrderProduct holds the info needed for ordering a product.
class OrderProduct
{
    var productID : Int64!
    var brandID : Int!
    var businessID : Int64!
    //var String productCategory
    var productCategoryID : Int64!
    var barcode : String!
    var productDescription : String!
    private var qtyOnHand : Float! //Bigdecimal
    var QtyOnHand : Float!
    {
        get
        {
            return self.qtyOnHand
        }
        
        set (qtyOnHand)
        {
            self.qtyOnHand = qtyOnHand
            if(qtyOnHand != nil)
            {
                /*if (qtyOnHand.remainder(BigDecimal.ONE).compareTo(BigDecimal.ZERO) == 0)
                {
                    qtyOnHandStr = String.format("%.0f", qtyOnHand)
                } else
                {
                    qtyOnHandStr = String.format("%.2f", qtyOnHand)
                }*/
            }
        }
    }
    var lastNMonthsText : String!
    
    var isBackOrderAvailable : Bool!
    var documentType : Int = 0 //Byte
    var isOrderDocumentProduct : Bool!
    var ERPReferenceCode : String!
    
    var qtyPurchaseLastnMonthsStr : String!
    var previousQuantity : Int!
    var orderQty = 0
    var freeQtyStr : String!
    var shouldDisplayMinusIcon : Bool!
    var shouldDisplayFreeQtyMinusIcon : Bool!
    var shouldDisplayDiscount : Bool!
    var lineDiscount : Float! //BigDecimal
    var lineDiscountStr : String!
    var subTotalStr : String!
    var imageUrl : String!
    var creationDate : String!
    var discType : String!
    var shouldDisplayNewProductLabel : Bool!
    var storeItemStatusID : Int!
    var remarks : String!
    var returnReasonComments : String!
    var initialRemarksText : String!
    var remarksText : String!
    var priceInclVat : Float = 0.0 //new BigDecimal("0.0")
    var qtyOnHandStr : String!
    var qtyAvailable : Float! //BigDecimal
    var qtyAvailableStr : String!
    var qtyPurchaseLastnMonths : Float = 0.0 //BigDecimal
    var previousSubTotal : Float = 0.0 //BigDecimal
    var previousFreeQuantity : Int!
    var freeQty = 0
    var priceInclVatStr : String!
    {
        get
        {
            return "€" //+ String.format("%.2f",priceInclVat)
        }
    }
    var previousSubTotalStr : String!
    var subTotal : Float = 0.0 // BigDecimal.ZERO
    var checkoutQuantityStr : String!
    var orderQtyStr : String!
    
    
    //public OnSubTotalChanged onSubTotalChanged
    //public OnFreeQtyUpdate onFreeQtyUpdate
}
