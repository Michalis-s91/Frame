//
//  OfferInformationViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 09/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import Kingfisher
import MapKit

class InformationsView: InformationsViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var offerInfoTableView: UITableView!
    @IBOutlet var map: MKMapView!
    
    var viewModel : OfferInformationViewModel!

    
    var isOfferImageStoredInStorage = false
    var task : WebApiTask!
    
    var currentImagePos = 0
    var previousX = 0
    //var ScrollView partnerInformationScrollView
    var imagesUrls : [String]!
    var offersList : [OfferItemModel]!
    
    var storesTableView : UITableView!

    var isFirstTime = true
    
    var lock = NSObject()
    var synchronized = Synchronized()
    
    var activityIndicatorViewController : ActivityIndicatorViewController!
    var activityIndicator : UIActivityIndicatorView!
    var parentController : ViewController!
    
    //var partnerInfoViewModel : PartnerInfoViewModel!
    //var isPartnerInformationView = false
    //var navController : UINavigationController!
    //var offer = OfferModel()
    //var parentNavigationController : UINavigationController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.prepare(for:  UIStoryboardSegue(identifier: "a",source: UIViewController() ,destination: UIViewController()), sender: nil)
        
        //offerInfoTableView.rowHeight = UITableViewAutomaticDimension
        offerInfoTableView.tableFooterView = UIView()
        offerInfoTableView.delegate = self
        offerInfoTableView.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        DispatchQueue.global(qos: .background).async {
            let appUser = localDatabase.getAppUser()
            
            if(appUser != nil && !isNullOrEmpty(string: appUser?.phoneNumber) )
            {
                let phoneNumber = appUser?.phoneNumber
                var notificationsCountersInfo = NotificationsWebApi.getNotificationsCountersInfo(userPhone: phoneNumber)
                
                if(notificationsCountersInfo != nil)
                {
                    numberOfGeneralNotifications = notificationsCountersInfo!.unseenCampaigns
                    numberOfPromotionNotifications = notificationsCountersInfo!.unseenCoupons
                    numberOfNotifications = notificationsCountersInfo!.allUnseen
                }
                
                DispatchQueue.main.async(execute: {() -> Void in
                    if(APK == Bundle.main.bundleIdentifier! && Bundle.main.bundleIdentifier != APKsEnum.RichReach.rawValue)
                    {
                        UIApplication.shared.applicationIconBadgeNumber = numberOfNotifications
                    }
                    
                    leftDrawer.tableView.reloadData()
                    leftDrawer.selectTab(tabString: leftDrawer.highlightedTabString)
                })
            }
        }
        
        if(isFirstTime)
        {
            if(!isPartnerInformationView)
            {
                viewModel = OfferInformationViewModel(offer: &offer, viewController: self)
                parentController.title = viewModel.title
            }
            else
            {
                parentController.title = partnerInfoViewModel.title
            }
            
            if(APK != APKsEnum.RichReach.rawValue)
            {
                parentController.title = ""
            }
            
            let titleFont = UIFont(name: "UIFontWeightRegular", size: 15) ?? UIFont.systemFont(ofSize: 15)
            self.parentNavigationController.navigationBar.titleTextAttributes = [NSAttributedStringKey.font: titleFont, NSAttributedStringKey.foregroundColor:UIColor.white]
            
            if(!isPartnerInformationView)
            {
                task = WebApiTask(viewController: self, action: loadOfferInformation, displayToast: true)
                task.shouldDisplayActivityIndicator(shouldDisplayActivityIndicator: true)
                task.errorMessage = NSLocalizedString("offerInformationSyncError", comment: "")
                task.start()
            }
        }
        else
        {
            if(!isPartnerInformationView)
            {
                parentController.title = viewModel.title
            }
            else
            {
                parentController.title = partnerInfoViewModel.title
            }
        }
        
        isFirstTime = false
    }
    
    override func viewDidAppear(_ animated: Bool) {
        /*let storyBoard = UIStoryboard(name:"ActivityIndicatorView",bundle:nil)
        activityIndicatorViewController = storyBoard.instantiateInitialViewController() as! ActivityIndicatorViewController
        
        activityIndicatorViewController.view.frame =  CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: (container?.frame.height)!)
        
        activityIndicatorViewController.willMove(toParentViewController: self)
        container?.addSubview((activityIndicatorViewController.view)!)
        activityIndicatorViewController.didMove(toParentViewController: self)
        activityIndicator = activityIndicatorViewController.activityIndicator
        activityIndicator.startAnimating()*/
    }
    
    func loadOfferInformation()
    {
        viewModel.loadFromInternet()
        
        if (!isActivityActive(viewController: self))
        {
            return
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.offerInfoTableView.reloadData()
        })
        
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.title = ""
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(!isPartnerInformationView)
        {
            return viewModel.informationsList.count
        }
        else
        {
            return partnerInfoViewModel.informationsList.count
        }
    }
    
    var image : UIImageView!
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        var information : GeneralInformation!
        
        if(!isPartnerInformationView)
        {
            information = viewModel.informationsList[indexPath.row]
        }
        else
        {
            information = partnerInfoViewModel.informationsList[indexPath.row]
        }
        
        switch information.type {
        case InformationType.Title.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "offer_info_title") as! OfferInfoTitleViewCell
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            cell.titleLabel.text = information.title
            return cell
        case InformationType.Image.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "offer_info_image") as! OfferInfoImageViewCell
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            let url = URL(string: percentEncode(s: information.imageUrl))
            cell.offerImage.kf.setImage(with: url, options: [.forceRefresh])
            //cell.offerImage.kf.setImage(with: url)
            image = cell.offerImage
            imageCell = cell
            return cell
        case InformationType.Description.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "offer_info_description") as! OfferInfoDescriptionViewCell
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            //cell.titleLabel.text = "ERP Reference Code"
            //cell.descriptionLabel.text = viewModel.erpReferenceCode
            cell.titleLabel.text = information.title
            //cell.descriptionLabel.text = information.description
            var a = replaceBackslashSpecialCharacters(str: information.description)
            cell.descriptionText.text = a
            
            if(APK == APKsEnum.BeautyLine.rawValue)
            {
                cell.titleLabel.font = UIFont (name: "CharpentierSansPro-Gros", size: CGFloat(15))
                cell.titleLabel.textColor = UIColor("#1D2D51")
                
                cell.descriptionText.font = UIFont (name: "Helvetica", size: CGFloat(13))
                cell.descriptionText.textColor = UIColor("#000000")
                
                cell.splitter.backgroundColor = UIColor("#1D2D51")
            }
            
            return cell
        case InformationType.Discount.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "offer_info_discount") as! OfferInfoDiscountViewCell
            
            cell.titleLabel.text = information.title
            cell.originalPriceTitleLabel.text = information.originalPriceTitle
            cell.originalPriceTextLabel.text = information.originalPriceText
            cell.offerDescriptionTextLabel.text = information.offerDescriptionText
            cell.offerNewPriceLabel.text = information.offerNewPrice
            cell.strike.transform = CGAffineTransform(rotationAngle: CGFloat(-Double.pi/8))
            
            if(!viewModel.isStrikeThrough && !viewModel.isSetOffer)
            {
                cell.strike.removeFromSuperview()
            }
            
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case InformationType.Stores.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "offer_info_table") as! OfferInfoStoresViewCell
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            cell.titleLabel.text = information.title
            if(information.stores != nil && information.stores.count != 0)
            {
                cell.stores = information.stores
                cell.storesTableView.reloadData()
                
                if(self.parentNavigationController != nil)
                {
                    cell.navigationController = self.parentNavigationController
                }
                else
                {
                    cell.navigationController = self.navigationController
                }
            }
            else
            {
                cell.stores = []
                cell.storesTableView.isHidden = true
                cell.notAvailableStoresLabel.text = NSLocalizedString("noAvailablePointsOfSales", comment: "")
            }
            
            storesTableView = cell.storesTableView
            //tableCell.frame = CGRect(x: 0, y: 0, width: 0, height: 0)
            return cell
        case InformationType.Facebook.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "offer_info_facebook") as! OfferInfoFacebookViewCell
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            cell.titleLabel.text = information.title
            //cell.websiteLabel.text = information.website
            
            if(information.website != NSLocalizedString("noAvailableWebsite", comment: ""))
            {
                //cell.websiteLabel.attributedText =  NSAttributedString(string: information.website, attributes:[.underlineStyle: NSUnderlineStyle.styleSingle.rawValue])
                //cell.websiteLabel.textColor = Colors.blue
                cell.websiteText.text = information.website
            }
            else
            {
                //cell.websiteLabel.text = information.website
                cell.websiteText.text = information.website
            }
            
            if(!information.isHasFacebookPage)
            {
                cell.facebookImage.removeFromSuperview()
            }
            
            cell.facebookPage = information.facebookPage
            cell.facebookPageID = information.facebookPageID
            
            return cell
        case InformationType.Combo.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "offer_info_combo") as! OfferInfoComboViewCell
            
            cell.appOfferID = information.appOfferID
            cell.setImages()
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        default:
            return tableView.dequeueReusableCell(withIdentifier: "offer_info_title") as! OfferInfoTitleViewCell
        }
        
        //activityIndicatorViewController.removeFromParentViewController()
        
    }
    
    var imageCell : OfferInfoImageViewCell!
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var information : GeneralInformation!
        
        if(!isPartnerInformationView)
        {
            information = viewModel.informationsList[indexPath.row]
        }
        else
        {
            information = partnerInfoViewModel.informationsList[indexPath.row]
        }
        
        if (information.type == InformationType.Stores.rawValue)
        {
            storesTableView.layoutIfNeeded()
            //let heightOfTableView: CGFloat = storesTableView.contentSize.height
            
            if(information.stores != nil && information.stores.count > 0)
            {
                if(information.stores.count == 1)
                {
                    return 112
                }
                else
                {
                    return 32 + (CGFloat(information.stores.count) * 76)
                }
            }
            else
            {
                return 56
            }
        }
        else if (information.type == InformationType.Combo.rawValue)
        {
            return 160
        }
        else if (information.type == InformationType.Image.rawValue)
        {
            //image.image = scaleUIImageToSize(image: image.image!, size: CGSize(width: 200, height: 200))
            if(image != nil)
            {
                image.layoutIfNeeded()
                imageCell.layoutIfNeeded()
            }
            
            return UITableViewAutomaticDimension
        }
        else
        {
            return UITableViewAutomaticDimension
        }
    }
    

    
    
}
