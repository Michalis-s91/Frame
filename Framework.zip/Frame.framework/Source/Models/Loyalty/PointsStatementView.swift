//
//  PointsStamentView.swift
//  RichReach2
//
//  Created by Eumbrella on 31/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class PointsStatementView : Codable
{
    var headerBackgroundColor : String!
    var headerTextColor : String!
    var headerTextSize : Int!
    var headerFont : String!
    var style1 : Int!
    var style2 : Int!
    var style1Model : TicketStyle!
    var style2Model : TicketStyle!
    
    private enum CodingKeys : String, CodingKey {
        case headerBackgroundColor = "HeaderBackgroundColor"
        case headerTextColor = "HeaderTextColor"
        case headerTextSize = "HeaderTextSize"
        case headerFont = "HeaderFont"
        case style1 = "Style1"
        case style2 = "Style2"
    }
}
