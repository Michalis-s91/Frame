//
//  ActivityIndicatorViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 11/04/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Creates view with activity indicator in the middle of the screen.
class ActivityIndicatorViewController: UIViewController {

    @IBOutlet var activityIndicator: UIActivityIndicatorView!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
