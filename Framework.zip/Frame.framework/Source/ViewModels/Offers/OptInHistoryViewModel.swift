//
//  OptInHistoryViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 12/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// OptInHistoryViewModel associated to the partners opt in history view. It saves partners opt in history and
class OptInHistoryViewModel
{
    var optInHistoryList : [OptInHistoryModel] = []
    
    
    /// Loads partners opt in history from internet.
    func loadFromInternet()
    {        
        let history = OptInHistoryWebApi.getPartnersOptInHistory(userPhone: (localDatabase.getAppUser()?.phoneNumber)!)
        
        if (history != nil && (history?.count)! > 0)
        {
            optInHistoryList = history!
        }
    }
}
